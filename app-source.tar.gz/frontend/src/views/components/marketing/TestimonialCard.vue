<script setup>
defineProps({
  quote: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  position: {
    type: String,
    default: ''
  },
  company: {
    type: String,
    default: ''
  },
  avatarColors: {
    type: Array,
    default: () => ['#8A05FF', '#6366F1']
  },
  metrics: {
    type: Array,
    default: () => []
  }
})
</script>

<template>
  <div class="testimonial-card">
    <div class="quote-mark">"</div>

    <p class="testimonial-quote">{{ quote }}</p>

    <div v-if="metrics && metrics.length" class="testimonial-metrics">
      <div v-for="(m, idx) in metrics" :key="idx" class="metric-item">
        <span class="metric-value">{{ m.value }}</span>
        <span class="metric-label">{{ m.label }}</span>
      </div>
    </div>

    <div class="testimonial-author">
      <div
        class="author-avatar"
        :style="{ background: `linear-gradient(135deg, ${avatarColors[0]} 0%, ${avatarColors[1]} 100%)` }"
      >
        {{ name.charAt(0) }}
      </div>
      <div class="author-info">
        <div class="author-name">{{ name }}</div>
        <div class="author-meta">
          <span v-if="position">{{ position }}</span>
          <span v-if="position && company"> · </span>
          <span v-if="company">{{ company }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.testimonial-card {
  position: relative;
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  padding: 32px;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-3px);
    box-shadow: var(--adx-shadow-lg);
    border-color: var(--adx-color-primary-light);
  }
}

.quote-mark {
  position: absolute;
  top: 16px;
  right: 24px;
  font-size: 72px;
  font-family: Georgia, serif;
  line-height: 1;
  color: var(--adx-color-primary);
  opacity: 0.1;
  pointer-events: none;
}

.testimonial-quote {
  position: relative;
  font-size: 15px;
  color: var(--adx-text-secondary);
  line-height: 1.85;
  margin: 0 0 20px;
  z-index: 1;
}

.testimonial-metrics {
  display: flex;
  gap: 24px;
  padding: 16px 0;
  margin: 0 0 20px;
  border-top: 1px solid var(--adx-border-light);
  border-bottom: 1px solid var(--adx-border-light);
}

.metric-item {
  display: flex;
  flex-direction: column;
  gap: 2px;

  .metric-value {
    font-size: 24px;
    font-weight: 800;
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    line-height: 1.2;
  }

  .metric-label {
    font-size: 12px;
    color: var(--adx-text-tertiary);
  }
}

.testimonial-author {
  display: flex;
  align-items: center;
  gap: 14px;
}

.author-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 18px;
  font-weight: 700;
  flex-shrink: 0;
}

.author-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.author-name {
  font-size: 15px;
  font-weight: 700;
  color: var(--adx-text-primary);
}

.author-meta {
  font-size: 13px;
  color: var(--adx-text-tertiary);
}
</style>
