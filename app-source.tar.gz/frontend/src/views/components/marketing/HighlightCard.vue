<script setup>
defineProps({
  icon: {
    type: String,
    default: ''
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    default: ''
  },
  points: {
    type: Array,
    default: () => []
  }
})
</script>

<template>
  <div class="highlight-card">
    <div class="highlight-header">
      <div class="highlight-icon">
        <el-icon v-if="icon" :size="24">
          <component :is="icon" />
        </el-icon>
      </div>
      <div class="highlight-header-content">
        <h3 class="highlight-title">{{ title }}</h3>
      </div>
    </div>
    <p v-if="description" class="highlight-desc">{{ description }}</p>
    <ul v-if="points && points.length" class="highlight-points">
      <li v-for="(p, idx) in points" :key="idx">
        <span class="dot"></span>
        <span>{{ p }}</span>
      </li>
    </ul>
  </div>
</template>

<style scoped lang="scss">
.highlight-card {
  position: relative;
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  padding: 28px;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-3px);
    box-shadow: var(--adx-shadow-md);
    border-color: var(--adx-color-primary-light);
  }
}

.highlight-header {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  margin-bottom: 16px;
}

.highlight-icon {
  flex-shrink: 0;
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
  background: linear-gradient(135deg, rgba(138, 5, 255, 0.12) 0%, rgba(99, 102, 241, 0.12) 100%);
  color: var(--adx-color-primary);
}

.highlight-title {
  font-size: 17px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin: 0;
  line-height: 1.4;
}

.highlight-desc {
  font-size: 14px;
  color: var(--adx-text-secondary);
  line-height: 1.75;
  margin: 0 0 14px;
}

.highlight-points {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.highlight-points li {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 13.5px;
  color: var(--adx-text-secondary);
  line-height: 1.6;

  .dot {
    flex-shrink: 0;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--adx-color-primary);
    margin-top: 7px;
  }
}
</style>
