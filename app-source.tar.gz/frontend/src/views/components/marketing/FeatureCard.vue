<script setup>
defineProps({
  icon: {
    type: String,
    default: ''
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    default: ''
  },
  features: {
    type: Array,
    default: () => []
  }
})
</script>

<template>
  <div class="feature-card">
    <div class="feature-icon">
      <el-icon v-if="icon" :size="28">
        <component :is="icon" />
      </el-icon>
      <div v-else class="icon-placeholder"></div>
    </div>
    <h3 class="feature-title">{{ title }}</h3>
    <p v-if="description" class="feature-desc">{{ description }}</p>
    <ul v-if="features && features.length" class="feature-list">
      <li v-for="(item, idx) in features" :key="idx">
        <el-icon class="check-icon" color="#10B981"><Check /></el-icon>
        <span>{{ item }}</span>
      </li>
    </ul>
  </div>
</template>

<style scoped lang="scss">
.feature-card {
  position: relative;
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  padding: 32px;
  transition: all 0.3s ease;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: var(--adx-gradient-primary);
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  &:hover {
    transform: translateY(-4px);
    box-shadow: var(--adx-shadow-lg);
    border-color: var(--adx-color-primary-light);

    &::before {
      opacity: 1;
    }
  }
}

.feature-icon {
  width: 60px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 14px;
  background: var(--adx-gradient-primary);
  color: #fff;
  margin-bottom: 20px;
  box-shadow: 0 8px 20px -6px rgba(99, 102, 241, 0.35);

  .icon-placeholder {
    width: 28px;
    height: 28px;
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.3);
  }
}

.feature-title {
  font-size: 20px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin: 0 0 12px;
  line-height: 1.3;
}

.feature-desc {
  font-size: 14.5px;
  color: var(--adx-text-secondary);
  line-height: 1.75;
  margin: 0 0 16px;
}

.feature-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.feature-list li {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 14px;
  color: var(--adx-text-secondary);
  line-height: 1.6;

  .check-icon {
    flex-shrink: 0;
    margin-top: 2px;
  }
}
</style>
