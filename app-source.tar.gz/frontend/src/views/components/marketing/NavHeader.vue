<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const isScrolled = ref(false)
const mobileMenuOpen = ref(false)

const handleScroll = () => {
  isScrolled.value = window.scrollY > 10
}

onMounted(() => window.addEventListener('scroll', handleScroll))
onUnmounted(() => window.removeEventListener('scroll', handleScroll))

const navItems = [
  { label: '首页', path: '/' },
  { label: '核心功能', path: '/features' },
  { label: '系统亮点', path: '/highlights' },
  { label: '系统价值', path: '/value' },
  { label: '客户案例', path: '/cases' },
  { label: '价格方案', path: '/pricing' },
  { label: '常见问题', path: '/faq' }
]

const activePath = computed(() => route.path)

const goLogin = () => router.push('/login')
const goRegister = () => router.push('/register')
const goPricing = () => router.push('/pricing')
const goDashboard = () => router.push('/dashboard')
</script>

<template>
  <header class="nav-header" :class="{ 'is-scrolled': isScrolled }">
    <div class="adx-container nav-header-inner">
      <router-link to="/" class="nav-logo" @click="mobileMenuOpen = false">
        <span class="logo-icon">
          <svg viewBox="0 0 32 32" width="32" height="32" aria-hidden="true">
            <defs>
              <linearGradient id="navLogoGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="#6366F1" />
                <stop offset="100%" stop-color="#8A05FF" />
              </linearGradient>
            </defs>
            <rect x="2" y="2" width="28" height="28" rx="8" fill="url(#navLogoGrad)" />
            <path
              d="M9 22 L14 10 L17 18 L20 10 L25 22"
              stroke="#fff"
              stroke-width="2.2"
              fill="none"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </span>
        <span class="logo-text">
          <span class="logo-main">ADX</span>
          <span class="logo-sub">Auto</span>
        </span>
      </router-link>

      <nav class="nav-menu">
        <router-link
          v-for="item in navItems"
          :key="item.path"
          :to="item.path"
          class="nav-link"
          :class="{
            active:
              item.path === activePath ||
              (item.path !== '/' && activePath.startsWith(item.path))
          }"
        >
          {{ item.label }}
        </router-link>
      </nav>

      <div class="nav-actions">
        <template v-if="userStore.isLoggedIn">
          <el-button type="primary" class="btn-primary" @click="goDashboard">
            <el-icon><Odometer /></el-icon>
            <span>进入后台</span>
          </el-button>
        </template>
        <template v-else>
          <el-button text class="btn-ghost" @click="goLogin">登录</el-button>
          <el-button class="btn-outline" @click="goRegister">注册</el-button>
          <el-button type="primary" class="btn-primary" @click="goPricing">
            <span>立即购买</span>
            <el-icon><ArrowRight /></el-icon>
          </el-button>
        </template>

        <button
          class="mobile-toggle"
          :aria-label="mobileMenuOpen ? '关闭菜单' : '打开菜单'"
          @click="mobileMenuOpen = !mobileMenuOpen"
        >
          <el-icon v-if="!mobileMenuOpen" :size="22"><Menu /></el-icon>
          <el-icon v-else :size="22"><Close /></el-icon>
        </button>
      </div>
    </div>

    <transition name="slide-down">
      <div v-if="mobileMenuOpen" class="mobile-menu">
        <div class="adx-container">
          <nav class="mobile-nav">
            <router-link
              v-for="item in navItems"
              :key="item.path"
              :to="item.path"
              class="mobile-nav-link"
              @click="mobileMenuOpen = false"
            >
              {{ item.label }}
            </router-link>
          </nav>
          <div class="mobile-actions">
            <template v-if="userStore.isLoggedIn">
              <el-button
                type="primary"
                size="large"
                class="mobile-btn"
                @click="goDashboard; mobileMenuOpen = false"
              >
                进入后台
              </el-button>
            </template>
            <template v-else>
              <el-button
                size="large"
                class="mobile-btn"
                @click="goLogin; mobileMenuOpen = false"
              >
                登录
              </el-button>
              <el-button
                size="large"
                class="mobile-btn"
                @click="goRegister; mobileMenuOpen = false"
              >
                注册
              </el-button>
              <el-button
                type="primary"
                size="large"
                class="mobile-btn mobile-btn-primary"
                @click="goPricing; mobileMenuOpen = false"
              >
                立即购买
                <el-icon><ArrowRight /></el-icon>
              </el-button>
            </template>
          </div>
        </div>
      </div>
    </transition>
  </header>
</template>

<style scoped lang="scss">
.nav-header {
  position: sticky;
  top: 0;
  z-index: 100;
  width: 100%;
  background: rgba(255, 255, 255, 0.75);
  backdrop-filter: blur(0);
  -webkit-backdrop-filter: blur(0);
  border-bottom: 1px solid transparent;
  transition: all 0.3s ease;

  &.is-scrolled {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: saturate(180%) blur(16px);
    -webkit-backdrop-filter: saturate(180%) blur(16px);
    border-bottom: 1px solid var(--adx-border-light);
    box-shadow: var(--adx-shadow-xs);
  }
}

.nav-header-inner {
  height: 70px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
}

.nav-logo {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  text-decoration: none;
  font-weight: 800;

  .logo-icon {
    filter: drop-shadow(0 2px 6px rgba(99, 102, 241, 0.25));
  }

  .logo-text {
    display: inline-flex;
    align-items: baseline;
    gap: 2px;
    font-size: 20px;
    line-height: 1;
  }

  .logo-main {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }

  .logo-sub {
    color: var(--adx-text-primary);
    font-weight: 600;
  }
}

.nav-menu {
  display: flex;
  align-items: center;
  gap: 2px;
  flex: 1;
  justify-content: center;

  @media (max-width: 1024px) {
    display: none;
  }
}

.nav-link {
  position: relative;
  padding: 8px 16px;
  color: var(--adx-text-secondary);
  font-size: 14px;
  font-weight: 500;
  border-radius: 10px;
  transition: all 0.2s ease;
  text-decoration: none;

  &:hover {
    color: var(--adx-color-primary);
    background: var(--adx-bg-hover);
  }

  &.active {
    color: var(--adx-color-primary);
    background: rgba(99, 102, 241, 0.08);
  }
}

.nav-actions {
  display: flex;
  align-items: center;
  gap: 10px;

  @media (max-width: 1024px) {
    .btn-ghost,
    .btn-outline,
    .btn-primary {
      display: none;
    }
  }
}

.btn-ghost {
  color: var(--adx-text-secondary);
  font-weight: 500;
  &:hover {
    color: var(--adx-color-primary);
  }
}

.btn-outline {
  border-color: var(--adx-border-color);
  color: var(--adx-text-primary);
  font-weight: 500;
}

.btn-primary {
  background: var(--adx-gradient-primary);
  border: none;
  font-weight: 600;
  padding-left: 20px;
  padding-right: 20px;
  transition: transform 0.2s, box-shadow 0.2s;
  border-radius: 10px;

  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 20px -6px rgba(99, 102, 241, 0.4);
  }

  :deep(.el-icon) {
    margin-left: 4px;
  }
}

.mobile-toggle {
  display: none;
  width: 40px;
  height: 40px;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--adx-border-color);
  border-radius: 10px;
  background: var(--adx-bg-card);
  color: var(--adx-text-secondary);

  @media (max-width: 1024px) {
    display: inline-flex;
  }
}

.mobile-menu {
  border-top: 1px solid var(--adx-border-light);
  background: var(--adx-bg-color);
  padding: 16px 0 24px;
}

.mobile-nav {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: 16px;
}

.mobile-nav-link {
  padding: 12px 14px;
  font-size: 15px;
  color: var(--adx-text-primary);
  border-radius: 10px;
  text-decoration: none;

  &:hover,
  &.router-link-active {
    background: var(--adx-bg-hover);
    color: var(--adx-color-primary);
  }
}

.mobile-actions {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding-top: 16px;
  border-top: 1px solid var(--adx-border-light);
}

.mobile-btn {
  width: 100%;
  border-radius: 10px;
}

.mobile-btn-primary {
  background: var(--adx-gradient-primary);
  border: none;
}

.slide-down-enter-active,
.slide-down-leave-active {
  transition: all 0.25s ease;
  overflow: hidden;
}
.slide-down-enter-from,
.slide-down-leave-to {
  opacity: 0;
  max-height: 0;
  padding-top: 0;
  padding-bottom: 0;
}
.slide-down-enter-to,
.slide-down-leave-from {
  max-height: 600px;
}
</style>
