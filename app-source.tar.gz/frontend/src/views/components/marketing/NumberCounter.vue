<script setup>
import { ref, watch, onMounted, onUnmounted } from 'vue'

const props = defineProps({
  endValue: {
    type: Number,
    required: true
  },
  duration: {
    type: Number,
    default: 2000
  },
  suffix: {
    type: String,
    default: ''
  },
  prefix: {
    type: String,
    default: ''
  },
  decimals: {
    type: Number,
    default: 0
  },
  startOnView: {
    type: Boolean,
    default: true
  }
})

const displayValue = ref(0)
const hasStarted = ref(false)
let animationFrame = null
let observer = null
const containerRef = ref(null)

const easeOutExpo = (t) => {
  return t === 1 ? 1 : 1 - Math.pow(2, -10 * t)
}

const animate = (start, end, duration) => {
  const startTime = performance.now()

  const tick = (currentTime) => {
    const elapsed = currentTime - startTime
    const progress = Math.min(elapsed / duration, 1)
    const easedProgress = easeOutExpo(progress)
    displayValue.value = start + (end - start) * easedProgress

    if (progress < 1) {
      animationFrame = requestAnimationFrame(tick)
    }
  }

  animationFrame = requestAnimationFrame(tick)
}

const startAnimation = () => {
  if (hasStarted.value) return
  hasStarted.value = true
  animate(0, props.endValue, props.duration)
}

onMounted(() => {
  if (props.startOnView && containerRef.value) {
    observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            startAnimation()
            observer.disconnect()
          }
        })
      },
      { threshold: 0.3 }
    )
    observer.observe(containerRef.value)
  } else {
    startAnimation()
  }
})

onUnmounted(() => {
  if (animationFrame) {
    cancelAnimationFrame(animationFrame)
  }
  if (observer) {
    observer.disconnect()
  }
})

watch(
  () => props.endValue,
  (newVal) => {
    if (hasStarted.value) {
      animate(displayValue.value, newVal, props.duration)
    }
  }
)
</script>

<template>
  <span ref="containerRef" class="number-counter">
    <span class="prefix">{{ prefix }}</span>
    <span class="value">{{ displayValue.toFixed(decimals) }}</span>
    <span class="suffix">{{ suffix }}</span>
  </span>
</template>

<style scoped lang="scss">
.number-counter {
  display: inline-flex;
  align-items: baseline;
  font-weight: 800;
  line-height: 1;

  .prefix {
    font-size: 0.5em;
    color: var(--adx-text-secondary);
    margin-right: 2px;
  }

  .value {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }

  .suffix {
    font-size: 0.4em;
    color: var(--adx-text-secondary);
    margin-left: 2px;
    font-weight: 600;
  }
}
</style>
