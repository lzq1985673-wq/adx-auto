<script setup>
defineProps({
  name: {
    type: String,
    required: true
  },
  tagline: {
    type: String,
    default: ''
  },
  price: {
    type: [Number, String],
    default: 0
  },
  period: {
    type: String,
    default: ''
  },
  badge: {
    type: String,
    default: ''
  },
  highlight: {
    type: Boolean,
    default: false
  },
  features: {
    type: Array,
    default: () => []
  },
  ctaText: {
    type: String,
    default: '立即购买'
  }
})

const emit = defineEmits(['cta'])
</script>

<template>
  <div class="pricing-card" :class="{ 'is-highlight': highlight }">
    <span v-if="badge" class="pricing-badge">{{ badge }}</span>

    <div class="pricing-head">
      <h3 class="pricing-name">{{ name }}</h3>
      <p v-if="tagline" class="pricing-tagline">{{ tagline }}</p>
    </div>

    <div class="pricing-price">
      <span class="currency">¥</span>
      <span class="amount">{{ price }}</span>
      <span v-if="period" class="period">/{{ period }}</span>
    </div>

    <ul class="pricing-features">
      <li v-for="(f, idx) in features" :key="idx">
        <el-icon class="check" :size="18"><Check /></el-icon>
        <span>{{ f }}</span>
      </li>
    </ul>

    <el-button
      type="primary"
      size="large"
      class="pricing-cta"
      :class="{ 'is-gradient': !highlight }"
      @click="emit('cta')"
    >
      {{ ctaText }}
      <el-icon><ArrowRight /></el-icon>
    </el-button>
  </div>
</template>

<style scoped lang="scss">
.pricing-card {
  position: relative;
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 20px;
  padding: 36px 32px;
  display: flex;
  flex-direction: column;
  transition: all 0.35s ease;
  height: 100%;

  &.is-highlight {
    border: 2px solid transparent;
    background:
      linear-gradient(var(--adx-bg-card), var(--adx-bg-card)) padding-box,
      var(--adx-gradient-primary) border-box;
    transform: scale(1.03);
    box-shadow: var(--adx-shadow-xl);

    @media (max-width: 1024px) {
      transform: none;
    }
  }

  &:hover {
    transform: translateY(-6px);
    box-shadow: var(--adx-shadow-xl);
  }
}

.pricing-badge {
  position: absolute;
  top: -12px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--adx-gradient-primary);
  color: #fff;
  padding: 5px 18px;
  font-size: 12px;
  font-weight: 600;
  border-radius: 9999px;
  white-space: nowrap;
}

.pricing-head {
  margin-bottom: 24px;
  text-align: center;
}

.pricing-name {
  font-size: 22px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin: 0 0 6px;
}

.pricing-tagline {
  font-size: 13px;
  color: var(--adx-text-tertiary);
  margin: 0;
}

.pricing-price {
  display: flex;
  align-items: baseline;
  justify-content: center;
  margin-bottom: 28px;

  .currency {
    font-size: 22px;
    font-weight: 600;
    color: var(--adx-text-secondary);
    margin-right: 4px;
  }

  .amount {
    font-size: 52px;
    font-weight: 800;
    line-height: 1;
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }

  .period {
    font-size: 14px;
    color: var(--adx-text-tertiary);
    margin-left: 6px;
  }
}

.pricing-features {
  list-style: none;
  padding: 0;
  margin: 0 0 32px;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.pricing-features li {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  font-size: 14px;
  color: var(--adx-text-secondary);
  line-height: 1.6;

  .check {
    flex-shrink: 0;
    color: var(--adx-color-success);
    margin-top: 2px;
  }
}

.pricing-cta {
  width: 100%;
  font-weight: 600;
  border-radius: 12px;
  height: 48px;

  &.is-gradient {
    background: var(--adx-gradient-primary);
    border: none;

    &:hover {
      box-shadow: 0 8px 20px -6px rgba(99, 102, 241, 0.5);
    }
  }

  &:deep(.el-icon) {
    margin-left: 6px;
  }
}
</style>
