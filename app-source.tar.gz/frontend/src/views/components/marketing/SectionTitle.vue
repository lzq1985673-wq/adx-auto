<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  subtitle: {
    type: String,
    default: ''
  },
  center: {
    type: Boolean,
    default: true
  }
})
</script>

<template>
  <div class="section-title-wrap" :class="{ 'is-center': center }">
    <h2 class="section-title">{{ title }}</h2>
    <p v-if="subtitle" class="section-subtitle">{{ subtitle }}</p>
  </div>
</template>

<style scoped lang="scss">
.section-title-wrap {
  margin-bottom: var(--adx-spacing-2xl);

  &.is-center {
    text-align: center;
  }
}

.section-title {
  font-size: 36px;
  font-weight: 800;
  line-height: 1.25;
  margin: 0 0 var(--adx-spacing-sm);
  background: var(--adx-gradient-primary);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;

  @media (max-width: 1024px) {
    font-size: 28px;
  }
  @media (max-width: 768px) {
    font-size: 24px;
  }
}

.section-subtitle {
  font-size: 16px;
  color: var(--adx-text-secondary);
  line-height: 1.75;
  margin: 0;
  max-width: 720px;

  .is-center & {
    margin-left: auto;
    margin-right: auto;
  }

  @media (max-width: 768px) {
    font-size: 14px;
  }
}
</style>
