<script setup>
defineProps({
  type: {
    type: String,
    default: 'primary'
  },
  size: {
    type: String,
    default: 'default'
  },
  outlined: {
    type: Boolean,
    default: false
  },
  loading: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  }
})
</script>

<template>
  <el-button
    :type="outlined ? 'default' : 'primary'"
    :size="size"
    :loading="loading"
    :disabled="disabled"
    :class="['gradient-btn', { 'is-outlined': outlined }]"
  >
    <slot />
  </el-button>
</template>

<style scoped lang="scss">
.gradient-btn {
  background: var(--adx-gradient-primary);
  border: none;
  color: #fff;
  font-weight: 600;
  transition: all 0.25s ease;

  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 20px -6px rgba(99, 102, 241, 0.45);
  }

  &:active {
    transform: translateY(0);
  }

  &.is-outlined {
    background: transparent;
    border: 2px solid transparent;
    background-image: linear-gradient(var(--adx-bg-card), var(--adx-bg-card)),
      var(--adx-gradient-primary);
    background-origin: border-box;
    background-clip: padding-box, border-box;
    color: var(--adx-color-primary);

    &:hover {
      background: var(--adx-gradient-primary);
      color: #fff;
    }
  }

  :deep(.el-icon) {
    margin-left: 4px;
  }
}
</style>
