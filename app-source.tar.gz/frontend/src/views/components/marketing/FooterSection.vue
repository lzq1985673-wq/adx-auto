<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()
const currentYear = new Date().getFullYear()
</script>

<template>
  <footer class="footer-section">
    <div class="adx-container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="footer-logo">
            <span class="logo-icon">
              <svg viewBox="0 0 32 32" width="28" height="28" aria-hidden="true">
                <defs>
                  <linearGradient id="footerLogoGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stop-color="#6366F1" />
                    <stop offset="100%" stop-color="#8A05FF" />
                  </linearGradient>
                </defs>
                <rect x="2" y="2" width="28" height="28" rx="8" fill="url(#footerLogoGrad)" />
                <path
                  d="M9 22 L14 10 L17 18 L20 10 L25 22"
                  stroke="#fff"
                  stroke-width="2.2"
                  fill="none"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </span>
            <span class="logo-main">ADX</span>
            <span class="logo-sub">Auto</span>
          </div>
          <p class="footer-desc">
            专为 Google Ads 优化师、代理商与品牌方打造的
            AI 驱动自动化投放管理平台，让广告效果翻倍、人力成本减半。
          </p>
          <div class="footer-socials">
            <a href="#" aria-label="邮箱"><el-icon><Message /></el-icon></a>
            <a href="#" aria-label="微信"><el-icon><ChatDotRound /></el-icon></a>
            <a href="#" aria-label="GitHub"><el-icon><Github /></el-icon></a>
            <a href="#" aria-label="Telegram"><el-icon><Promotion /></el-icon></a>
          </div>
        </div>

        <div class="footer-col">
          <h4 class="footer-title">产品</h4>
          <ul>
            <li><router-link to="/features">核心功能</router-link></li>
            <li><router-link to="/highlights">系统亮点</router-link></li>
            <li><router-link to="/value">系统价值</router-link></li>
            <li><router-link to="/pricing">价格方案</router-link></li>
            <li><router-link to="/cases">客户案例</router-link></li>
            <li><router-link to="/faq">常见问题</router-link></li>
          </ul>
        </div>

        <div class="footer-col">
          <h4 class="footer-title">资源</h4>
          <ul>
            <li><a href="#">帮助文档</a></li>
            <li><a href="#">API 接口文档</a></li>
            <li><a href="#">更新日志</a></li>
            <li><a href="#">使用教程</a></li>
            <li><a href="#">博客资讯</a></li>
            <li><a href="#">合作伙伴</a></li>
          </ul>
        </div>

        <div class="footer-col">
          <h4 class="footer-title">联系我们</h4>
          <ul class="footer-contact">
            <li>
              <el-icon><Message /></el-icon>
              <span>support@adx-auto.com</span>
            </li>
            <li>
              <el-icon><Phone /></el-icon>
              <span>400-888-1234</span>
            </li>
            <li>
              <el-icon><Location /></el-icon>
              <span>上海市浦东新区张江科技园</span>
            </li>
            <li>
              <el-icon><Service /></el-icon>
              <span>7x12 在线客服</span>
            </li>
          </ul>
        </div>
      </div>

      <div class="footer-bottom">
        <div class="footer-copy">
          <span>© {{ currentYear }} ADX-Auto. All rights reserved.</span>
        </div>
        <div class="footer-links">
          <a href="#">隐私政策</a>
          <span class="sep">·</span>
          <a href="#">服务条款</a>
          <span class="sep">·</span>
          <a href="#">Cookie 设置</a>
          <span class="sep">·</span>
          <span>沪ICP备 2024xxxxxx号</span>
        </div>
      </div>
    </div>
  </footer>
</template>

<style scoped lang="scss">
.footer-section {
  background: var(--adx-bg-secondary);
  border-top: 1px solid var(--adx-border-light);
  padding: 64px 0 24px;
  margin-top: 64px;
}

.footer-grid {
  display: grid;
  grid-template-columns: 1.4fr 1fr 1fr 1.2fr;
  gap: 32px;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr 1fr;
    row-gap: 32px;
  }
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
}

.footer-brand .footer-logo {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 16px;
  font-weight: 800;
  font-size: 18px;
}

.footer-logo {
  .logo-main {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  .logo-sub {
    color: var(--adx-text-primary);
    font-weight: 600;
  }
}

.footer-desc {
  color: var(--adx-text-secondary);
  font-size: 13.5px;
  line-height: 1.75;
  margin: 0 0 16px;
}

.footer-socials {
  display: flex;
  gap: 10px;
  a {
    width: 36px;
    height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: var(--adx-bg-card);
    border: 1px solid var(--adx-border-color);
    border-radius: 10px;
    color: var(--adx-text-secondary);
    transition: all 0.2s;
    &:hover {
      color: var(--adx-color-primary);
      border-color: var(--adx-color-primary-light);
      transform: translateY(-1px);
    }
  }
}

.footer-title {
  font-size: 15px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin: 0 0 16px;
}

.footer-col ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.footer-col ul li a {
  color: var(--adx-text-secondary);
  font-size: 14px;
  text-decoration: none;
  transition: color 0.2s;
  &:hover {
    color: var(--adx-color-primary);
  }
}

.footer-contact li {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  color: var(--adx-text-secondary);
  font-size: 14px;

  .el-icon {
    margin-top: 3px;
    color: var(--adx-color-primary);
    font-size: 16px;
    flex-shrink: 0;
  }
}

.footer-bottom {
  margin-top: 48px;
  padding-top: 24px;
  border-top: 1px solid var(--adx-border-light);
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 16px;
  font-size: 13px;
  color: var(--adx-text-tertiary);

  @media (max-width: 640px) {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
}

.footer-links {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  .sep {
    color: var(--adx-border-color);
  }
  a {
    color: var(--adx-text-tertiary);
    text-decoration: none;
    &:hover {
      color: var(--adx-color-primary);
    }
  }
}
</style>
