<script setup>
import { ref, reactive, onMounted, nextTick, watch } from 'vue'
import * as echarts from 'echarts'
import { ElMessage } from 'element-plus'

const selectedCampaign = ref('1')
const campaigns = [
  { value: '1', label: '春季促销_品牌词搜索' },
  { value: '2', label: 'PMax_全站推广_Q3' },
  { value: '3', label: '购物智能_MainFeed' }
]

const config = reactive({
  dailyTarget: 500,
  countries: ['US', 'UK', 'CA'],
  timeSlots: [true, true, true, true, false, false, true, true],
  referers: ['google', 'bing', 'yahoo', 'duckduckgo', 'facebook', 'twitter', 'reddit', 'quora', 'pinterest', 'linkedin'],
  refererEnabled: { google: true, bing: true, yahoo: true, duckduckgo: false, facebook: true, twitter: false, reddit: true, quora: false, pinterest: false, linkedin: false },
  deviceRatio: { desktop: 45, mobile: 45, tablet: 10 }
})

const advancedConfig = reactive({
  ipProvider: 'oxylabs',
  sessionMin: 60,
  sessionMax: 240,
  pageDepth: 2,
  metrics: {
    randomMouseMove: true,
    randomScroll: true,
    randomClicks: true,
    randomKeyboard: false,
    changeUA: true,
    changeScreenRes: true,
    changeLanguage: true,
    timezoneMatch: true,
    webglFingerprint: true,
    canvasFingerprint: true,
    audioFingerprint: false,
    webrtcDisable: true,
    cookieConsent: true,
    trackingBlock: true,
    adblockRandom: false,
    historySeed: true,
    storageRandomize: true,
    gpsSpoof: true,
    fontRandomize: true,
    cpuThreadsRandom: false,
    memoryRandom: false,
    hardwareConcurrency: true,
    colorDepthRandom: true,
    dprRandom: false,
    touchSupportMatch: true,
    platformMatch: true,
    vendorRandom: false,
    pluginsRandom: true,
    mimeTypeRandom: false,
    webDriverHide: true,
    chromeFlags: true,
    stealthMode: true,
    humanTyping: true,
    randomWait: true,
    pageLoadTimeout: true,
    screenshotOnError: false,
    domDumpOnError: false,
    uaClientHints: true,
    secChUa: true,
    acceptLanguageRandom: true,
    acceptEncoding: true,
    upgradeInsecure: true,
    dnsCacheClear: false,
    cacheClearRandom: true,
    localIpLeakProtect: true,
    proxyRotate: true,
    proxyAuthAuto: true,
    proxyHealthCheck: true,
    fingerprintProfileRotate: true,
    botDetectionBypass: true,
    captchaAutoSolve: false,
    hCaptchaBypass: false,
    reCaptchaV3Bypass: false,
    turnstileBypass: false,
    cloudflareBypass: true,
    geetestBypass: false
  }
})

const ipProviders = [
  { value: 'oxylabs', label: 'Oxylabs' },
  { value: 'brightdata', label: 'BrightData (Luminati)' },
  { value: 'ipidea', label: 'IPIDEA' },
  { value: 'smartproxy', label: 'SmartProxy' },
  { value: 'geosurf', label: 'GeoSurf' },
  { value: 'custom', label: '自定义代理池' }
]

const refererList = ['google', 'bing', 'yahoo', 'duckduckgo', 'facebook', 'twitter', 'reddit', 'quora', 'pinterest', 'linkedin']
const countries = ['US', 'UK', 'CA', 'AU', 'DE', 'FR', 'JP', 'SG', 'NL', 'IT', 'ES', 'BR']
const timeSlotLabels = ['0-3点', '3-6点', '6-9点', '9-12点', '12-15点', '15-18点', '18-21点', '21-24点']

const executionLogs = ref([])
for (let i = 1; i <= 80; i++) {
  executionLogs.value.push({
    id: i,
    ad: `春季促销_RSA_${Math.ceil(Math.random() * 15)}`,
    keyword: `关键词_${Math.floor(Math.random() * 200)}`,
    country: ['US', 'UK', 'CA', 'DE', 'FR', 'AU', 'JP'][Math.floor(Math.random() * 7)],
    ip: `${Math.floor(Math.random()*223)+1}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`,
    ua: ['Chrome/125.0 Win10', 'Safari/17.4 iOS', 'Chrome/124.0 Android', 'Firefox/126 Mac', 'Edge/125.0 Win10'][Math.floor(Math.random()*5)],
    fingerprint: `fp_${Math.random().toString(36).slice(2, 10)}`,
    referer: refererList[Math.floor(Math.random() * refererList.length)],
    execTime: `2026-08-02 ${String(Math.floor(Math.random()*10)).padStart(2,'0')}:${String(Math.floor(Math.random()*60)).padStart(2,'0')}:${String(Math.floor(Math.random()*60)).padStart(2,'0')}`,
    status: Math.random() > 0.12 ? 'success' : (Math.random() > 0.5 ? 'warning' : 'error'),
    duration: `${Math.floor(Math.random() * 6) + 1}m${String(Math.floor(Math.random() * 60)).padStart(2,'0')}s`
  })
}

const statusTagType = (s) => ({ success: 'success', warning: 'warning', error: 'danger' }[s] || 'info')
const statusText = (s) => ({ success: '成功', warning: '警告', error: '失败' }[s] || s)

const countryChartRef = ref(null)
const deviceChartRef = ref(null)
const dateChartRef = ref(null)
let countryChart = null, deviceChart = null, dateChart = null

const initCharts = () => {
  if (countryChartRef.value) {
    countryChart = echarts.init(countryChartRef.value)
    const cs = ['US', 'UK', 'CA', 'DE', 'FR', 'AU', 'JP']
    countryChart.setOption({
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
      xAxis: { type: 'category', data: cs, axisLine: { lineStyle: { color: '#E5E7EB' } } },
      yAxis: { type: 'value', splitLine: { lineStyle: { color: '#F3F4F6' } } },
      series: [{
        type: 'bar',
        data: cs.map(() => Math.floor(Math.random() * 800 + 80)),
        itemStyle: {
          borderRadius: [6, 6, 0, 0],
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: '#6366F1' }, { offset: 1, color: '#8A05FF' }])
        },
        barWidth: 28
      }]
    })
  }
  if (deviceChartRef.value) {
    deviceChart = echarts.init(deviceChartRef.value)
    deviceChart.setOption({
      tooltip: { trigger: 'item' },
      legend: { bottom: 0 },
      series: [{
        type: 'pie',
        radius: ['40%', '68%'],
        center: ['50%', '45%'],
        itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
        label: { formatter: '{b}\n{d}%' },
        data: [
          { value: config.deviceRatio.desktop, name: '桌面', itemStyle: { color: '#6366F1' } },
          { value: config.deviceRatio.mobile, name: '移动', itemStyle: { color: '#10B981' } },
          { value: config.deviceRatio.tablet, name: '平板', itemStyle: { color: '#F59E0B' } }
        ]
      }]
    })
  }
  if (dateChartRef.value) {
    dateChart = echarts.init(dateChartRef.value)
    const dates = []
    for (let i = 13; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i)
      dates.push(`${d.getMonth() + 1}/${d.getDate()}`)
    }
    dateChart.setOption({
      tooltip: { trigger: 'axis' },
      legend: { data: ['点击数', '成功数'], top: 0 },
      grid: { left: '3%', right: '4%', bottom: '3%', top: 36, containLabel: true },
      xAxis: { type: 'category', boundaryGap: false, data: dates, axisLine: { lineStyle: { color: '#E5E7EB' } } },
      yAxis: { type: 'value', splitLine: { lineStyle: { color: '#F3F4F6' } } },
      series: [
        {
          name: '点击数', type: 'line', smooth: true, data: dates.map(() => Math.floor(Math.random() * 300 + 200)),
          itemStyle: { color: '#6366F1' },
          areaStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1, [{offset:0,color:'rgba(99,102,241,0.25)'},{offset:1,color:'rgba(99,102,241,0.02)'}]) }
        },
        {
          name: '成功数', type: 'line', smooth: true, data: dates.map(() => Math.floor(Math.random() * 250 + 180)),
          itemStyle: { color: '#10B981' },
          areaStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1, [{offset:0,color:'rgba(16,185,129,0.22)'},{offset:1,color:'rgba(16,185,129,0.02)'}]) }
        }
      ]
    })
  }
}

const saveConfig = () => {
  ElMessage.success('配置已保存')
}
const runNow = () => {
  ElMessage.info('已启动补点击任务，任务ID: ' + Date.now())
}

watch(() => config.deviceRatio, () => {
  if (deviceChart) {
    deviceChart.setOption({
      series: [{
        data: [
          { value: config.deviceRatio.desktop, name: '桌面', itemStyle: { color: '#6366F1' } },
          { value: config.deviceRatio.mobile, name: '移动', itemStyle: { color: '#10B981' } },
          { value: config.deviceRatio.tablet, name: '平板', itemStyle: { color: '#F59E0B' } }
        ]
      }]
    })
  }
}, { deep: true })

onMounted(async () => {
  await nextTick()
  initCharts()
  window.addEventListener('resize', () => {
    countryChart?.resize(); deviceChart?.resize(); dateChart?.resize()
  })
})
</script>

<template>
  <div class="clickbot-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">补点击配置</h2>
        <p class="page-subtitle">模拟真实用户行为，提升广告CTR与质量分</p>
      </div>
      <div>
        <el-button type="primary" plain @click="saveConfig">
          <el-icon><Save /></el-icon>保存配置
        </el-button>
        <el-button type="primary" class="el-button--gradient" style="margin-left: 8px" @click="runNow">
          <el-icon><VideoPlay /></el-icon>立即执行
        </el-button>
      </div>
    </div>

    <el-card shadow="never">
      <div class="campaign-selector">
        <label class="selector-label">选择广告系列：</label>
        <el-select v-model="selectedCampaign" style="width: 360px" filterable>
          <el-option v-for="c in campaigns" :key="c.value" :label="c.label" :value="c.value" />
        </el-select>
      </div>
    </el-card>

    <el-row :gutter="16">
      <el-col :xs="24" :lg="14">
        <el-card shadow="never" class="config-card">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-primary)"><Setting /></el-icon><span class="card-title">基础配置</span></div>
          </template>
          <el-form :model="config" label-width="130px">
            <el-form-item label="每日点击目标">
              <el-input-number v-model="config.dailyTarget" :min="1" :max="100000" controls-position="right" style="width: 220px" />
              <span style="margin-left: 12px; color: var(--adx-text-tertiary); font-size: 12px">次 / 天</span>
            </el-form-item>
            <el-form-item label="目标国家多选">
              <el-select v-model="config.countries" multiple collapse-tags collapse-tags-tooltip style="width: 100%">
                <el-option v-for="c in countries" :key="c" :label="c" :value="c" />
              </el-select>
            </el-form-item>
            <el-form-item label="时间段 (8个)">
              <div class="slot-row">
                <div v-for="(s, i) in config.timeSlots" :key="i" class="slot-item">
                  <div class="slot-top">
                    <el-switch v-model="config.timeSlots[i]" size="small" />
                  </div>
                  <div class="slot-label">{{ timeSlotLabels[i] }}</div>
                </div>
              </div>
            </el-form-item>
            <el-form-item label="Referer来源">
              <el-checkbox-group v-model="config.referers">
                <div class="referer-grid">
                  <el-checkbox v-for="r in refererList" :key="r" :value="r" border style="margin-bottom: 8px">
                    {{ r }}
                  </el-checkbox>
                </div>
              </el-checkbox-group>
            </el-form-item>
            <el-form-item label="设备分配比例">
              <div class="device-row">
                <div v-for="(k, label) in { desktop: '桌面端', mobile: '移动端', tablet: '平板' }" :key="k" class="device-item">
                  <div class="device-label">{{ label }}</div>
                  <el-slider v-model="config.deviceRatio[k]" :min="0" :max="100" style="width: 180px" />
                  <el-input-number v-model="config.deviceRatio[k]" :min="0" :max="100" size="small" controls-position="right" style="width: 80px; margin-left: 8px" />
                  <span style="margin-left: 4px; color: var(--adx-text-tertiary)">%</span>
                </div>
              </div>
            </el-form-item>
          </el-form>
        </el-card>

        <el-card shadow="never" class="config-card" style="margin-top: 16px">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-purple)"><Cpu /></el-icon><span class="card-title">高级配置 (50项)</span></div>
          </template>
          <el-form :model="advancedConfig" label-width="130px">
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="IP供应商">
                  <el-select v-model="advancedConfig.ipProvider" style="width: 100%">
                    <el-option v-for="p in ipProviders" :key="p.value" :label="p.label" :value="p.value" />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="8">
                <el-form-item label="会话时长范围">
                  <div style="display: inline-flex; align-items: center; width: 100%; gap: 6px">
                    <el-input-number v-model="advancedConfig.sessionMin" :min="1" size="small" controls-position="right" style="width: 100%" />
                    <span>~</span>
                    <el-input-number v-model="advancedConfig.sessionMax" :min="1" size="small" controls-position="right" style="width: 100%" />
                    <span style="font-size: 12px; color: var(--adx-text-tertiary)">秒</span>
                  </div>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="翻页深度">
                  <el-input-number v-model="advancedConfig.pageDepth" :min="1" :max="10" size="small" controls-position="right" style="width: 100%" />
                </el-form-item>
              </el-col>
            </el-row>

            <el-divider>行为 & 指纹开关</el-divider>
            <div class="metrics-grid">
              <div v-for="(_, k) in advancedConfig.metrics" :key="k" class="metric-item">
                <el-switch v-model="advancedConfig.metrics[k]" size="small" />
                <span class="metric-label">{{ k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()) }}</span>
              </div>
            </div>
          </el-form>
        </el-card>
      </el-col>

      <el-col :xs="24" :lg="10">
        <el-card shadow="never" class="log-card">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-success)"><Document /></el-icon><span class="card-title">执行日志 (实时100条)</span></div>
          </template>
          <el-table :data="executionLogs" size="small" stripe height="560" style="font-size: 12px">
            <el-table-column prop="ad" label="广告" min-width="120" show-overflow-tooltip />
            <el-table-column prop="keyword" label="关键词" min-width="80" show-overflow-tooltip />
            <el-table-column prop="country" label="国家" width="60" align="center">
              <template #default="{ row }"><el-tag size="small" effect="plain">{{ row.country }}</el-tag></template>
            </el-table-column>
            <el-table-column prop="ip" label="IP" width="120" show-overflow-tooltip />
            <el-table-column prop="ua" label="UA" width="100" show-overflow-tooltip />
            <el-table-column prop="fingerprint" label="指纹" width="80" show-overflow-tooltip />
            <el-table-column prop="referer" label="来源" width="72" show-overflow-tooltip />
            <el-table-column prop="execTime" label="执行时间" width="120" show-overflow-tooltip />
            <el-table-column prop="status" label="状态" width="60" align="center">
              <template #default="{ row }">
                <el-tag :type="statusTagType(row.status)" size="small" effect="light">{{ statusText(row.status) }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="duration" label="耗时" width="70" />
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never" style="margin-top: 16px">
      <template #header>
        <div class="card-title-wrap"><el-icon style="color: var(--adx-color-warning)"><DataAnalysis /></el-icon><span class="card-title">数据分析</span></div>
      </template>
      <el-row :gutter="16">
        <el-col :xs="24" :md="8">
          <div class="mini-chart-title">按国家点击分布</div>
          <div ref="countryChartRef" class="mini-chart"></div>
        </el-col>
        <el-col :xs="24" :md="8">
          <div class="mini-chart-title">按设备类型分布</div>
          <div ref="deviceChartRef" class="mini-chart"></div>
        </el-col>
        <el-col :xs="24" :md="8">
          <div class="mini-chart-title">近14天点击趋势</div>
          <div ref="dateChartRef" class="mini-chart"></div>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<style lang="scss" scoped>
.clickbot-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  display: flex; align-items: center; justify-content: space-between;
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.card-title-wrap { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; font-size: 14px; }
.card-title { color: var(--adx-text-primary); }

.campaign-selector {
  display: flex; align-items: center;
  .selector-label { font-weight: 600; margin-right: 12px; width: 130px; color: var(--adx-text-secondary); }
}

.slot-row { display: grid; grid-template-columns: repeat(8, 1fr); gap: 8px; }
.slot-item {
  padding: 10px 6px;
  background: var(--adx-bg-secondary);
  border-radius: 8px;
  text-align: center;
  .slot-top { display: flex; justify-content: center; margin-bottom: 4px; }
  .slot-label { font-size: 11px; color: var(--adx-text-tertiary); }
}

.referer-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px; }

.device-row { display: flex; flex-direction: column; gap: 10px; }
.device-item { display: flex; align-items: center;
  .device-label { width: 80px; color: var(--adx-text-secondary); font-weight: 500; }
}

.metrics-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.metric-item {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 10px;
  background: var(--adx-bg-secondary);
  border-radius: 8px;
  .metric-label { font-size: 12px; color: var(--adx-text-secondary); }
}

.mini-chart-title {
  font-weight: 600; font-size: 13px; color: var(--adx-text-secondary);
  padding: 0 4px 8px;
}
.mini-chart { width: 100%; height: 260px; }
</style>
