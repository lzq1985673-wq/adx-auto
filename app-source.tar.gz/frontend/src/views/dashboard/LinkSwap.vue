<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const selectedCampaign = ref('1')
const campaigns = [
  { value: '1', label: '春季促销_品牌词搜索' },
  { value: '2', label: 'PMax_全站推广_Q3' },
  { value: '3', label: '购物智能_MainFeed' }
]

const linkList = ref([
  { id: 1, oldUrl: 'https://example.com/offer-a', newUrl: 'https://example.com/new-offer-a', fingerprint: 'fp_2a3f8b1c', status: 'active', lastSwap: '2026-08-02 10:42:18', hits: 420 },
  { id: 2, oldUrl: 'https://example.com/product-123', newUrl: 'https://example.com/landing-page-pro', fingerprint: 'fp_7d9e2a5f', status: 'active', lastSwap: '2026-08-02 10:38:05', hits: 318 },
  { id: 3, oldUrl: 'https://example.com/old-deal', newUrl: 'https://example.com/flash-sale-v2', fingerprint: 'fp_b1c3e7a9', status: 'active', lastSwap: '2026-08-02 10:30:22', hits: 265 },
  { id: 4, oldUrl: 'https://example.com/collection-women', newUrl: 'https://example.com/ss26-women', fingerprint: 'fp_5f8d1b4e', status: 'paused', lastSwap: '2026-08-01 18:12:30', hits: 195 },
  { id: 5, oldUrl: 'https://example.com/blackfriday-2025', newUrl: 'https://example.com/summer-clearance', fingerprint: 'fp_a2e6c8d1', status: 'active', lastSwap: '2026-08-02 10:22:10', hits: 178 },
  { id: 6, oldUrl: 'https://example.com/free-trial-v1', newUrl: 'https://example.com/signup-premium', fingerprint: 'fp_4b9e1f3c', status: 'error', lastSwap: '2026-08-02 09:15:48', hits: 86 }
])

const config = reactive({
  frequencyMin: 30,
  reverseVerify: true,
  sameOrigin: true
})

const logs = ref([
  { id: 1, oldUrl: 'https://example.com/offer-a', newUrl: 'https://example.com/new-offer-a', fingerprint: 'fp_2a3f8b1c', status: 'success', time: '2026-08-02 10:42:18', reverse: 'HTTP 200 OK (反向验证通过)' },
  { id: 2, oldUrl: 'https://example.com/product-123', newUrl: 'https://example.com/landing-page-pro', fingerprint: 'fp_7d9e2a5f', status: 'success', time: '2026-08-02 10:38:05', reverse: 'HTTP 200 OK (反向验证通过)' },
  { id: 3, oldUrl: 'https://example.com/old-deal', newUrl: 'https://example.com/flash-sale-v2', fingerprint: 'fp_b1c3e7a9', status: 'success', time: '2026-08-02 10:30:22', reverse: 'HTTP 200 OK (反向验证通过)' },
  { id: 4, oldUrl: 'https://example.com/collection-women', newUrl: 'https://example.com/ss26-women', fingerprint: 'fp_5f8d1b4e', status: 'paused', time: '2026-08-01 18:12:30', reverse: '任务已暂停' },
  { id: 5, oldUrl: 'https://example.com/blackfriday-2025', newUrl: 'https://example.com/summer-clearance', fingerprint: 'fp_a2e6c8d1', status: 'success', time: '2026-08-02 10:22:10', reverse: 'HTTP 200 OK (反向验证通过)' },
  { id: 6, oldUrl: 'https://example.com/free-trial-v1', newUrl: 'https://example.com/signup-premium', fingerprint: 'fp_4b9e1f3c', status: 'error', time: '2026-08-02 09:15:48', reverse: 'HTTP 404 (新链接无法访问，请检查)' },
  { id: 7, oldUrl: 'https://example.com/offer-a', newUrl: 'https://example.com/new-offer-a', fingerprint: 'fp_2a3f8b1c', status: 'success', time: '2026-08-02 10:12:18', reverse: 'HTTP 200 OK' },
  { id: 8, oldUrl: 'https://example.com/old-deal', newUrl: 'https://example.com/flash-sale-v2', fingerprint: 'fp_b1c3e7a9', status: 'success', time: '2026-08-02 10:00:22', reverse: 'HTTP 200 OK' }
])

const statusTag = (s) => ({
  active: { type: 'success', text: '运行中' },
  paused: { type: 'info', text: '已暂停' },
  error: { type: 'danger', text: '异常' },
  success: { type: 'success', text: '成功' }
}[s] || { type: 'info', text: s })

const addLinkDialog = ref(false)
const addLinkForm = reactive({ oldUrl: '', newUrl: '' })

const openAddLink = () => {
  addLinkForm.oldUrl = ''; addLinkForm.newUrl = ''
  addLinkDialog.value = true
}
const confirmAddLink = () => {
  if (!addLinkForm.oldUrl || !addLinkForm.newUrl) { ElMessage.warning('请填写旧URL和新URL'); return }
  ElMessage.success('换链规则已添加')
  addLinkDialog.value = false
}

const toggleLink = (row, val) => {
  row.status = val ? 'active' : 'paused'
  ElMessage.success(`已${val ? '启用' : '暂停'}该换链`)
}
const deleteLink = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除此换链规则?`, '删除确认', { type: 'warning' })
    ElMessage.success('删除成功')
  } catch (_) {}
}

const runSwap = () => {
  ElMessage.success('已启动换链任务，预计执行时间: ' + (config.frequencyMin) + ' 分钟')
}
const saveConfig = () => ElMessage.success('配置已保存')
</script>

<template>
  <div class="linkswap-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">换链接管理</h2>
        <p class="page-subtitle">自动替换广告系列中的落地页URL，保护真实Offer链接</p>
      </div>
      <div>
        <el-button type="primary" plain @click="saveConfig"><el-icon><Save /></el-icon>保存配置</el-button>
        <el-button type="primary" class="el-button--gradient" style="margin-left: 8px" @click="runSwap">
          <el-icon><RefreshRight /></el-icon>立即执行换链
        </el-button>
      </div>
    </div>

    <el-card shadow="never" class="selector-card">
      <div class="selector-row">
        <label class="label">广告系列：</label>
        <el-select v-model="selectedCampaign" filterable style="width: 360px">
          <el-option v-for="c in campaigns" :key="c.value" :label="c.label" :value="c.value" />
        </el-select>
        <el-button type="primary" class="el-button--gradient" style="margin-left: auto" @click="openAddLink">
          <el-icon><Plus /></el-icon>添加换链规则
        </el-button>
      </div>
    </el-card>

    <el-card shadow="never">
      <template #header>
        <div class="card-title-wrap"><el-icon style="color: var(--adx-color-primary)"><Link /></el-icon><span class="card-title">当前换链规则列表</span></div>
      </template>
      <el-table :data="linkList" stripe>
        <el-table-column label="旧URL → 新URL" min-width="360">
          <template #default="{ row }">
            <div class="url-row">
              <div class="url-item old">
                <el-tag size="small" type="info" effect="plain" style="margin-right: 6px">OLD</el-tag>
                <span class="url-text">{{ row.oldUrl }}</span>
              </div>
              <div class="url-arrow"><el-icon><ArrowRightBold /></el-icon></div>
              <div class="url-item new">
                <el-tag size="small" type="success" effect="plain" style="margin-right: 6px">NEW</el-tag>
                <span class="url-text">{{ row.newUrl }}</span>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="指纹标签" width="140">
          <template #default="{ row }">
            <el-tag size="small" type="warning" effect="dark" round>{{ row.fingerprint }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="触发次数" width="100" align="right">
          <template #default="{ row }"><b>{{ row.hits }}</b></template>
        </el-table-column>
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">{{ statusTag(row.status).text }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="lastSwap" label="最近换链" width="170" />
        <el-table-column label="开关" width="80" align="center">
          <template #default="{ row }">
            <el-switch v-model="row.status" active-value="active" inactive-value="paused" @change="toggleLink(row, $event)" size="small" />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" size="small">编辑</el-button>
            <el-button link type="danger" size="small" @click="deleteLink(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-row :gutter="16" style="margin-top: 16px">
      <el-col :xs="24" :lg="8">
        <el-card shadow="never" class="config-card">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-primary)"><Setting /></el-icon><span class="card-title">换链配置</span></div>
          </template>
          <el-form :model="config" label-width="130px">
            <el-form-item label="换链频率">
              <el-slider v-model="config.frequencyMin" :min="10" :max="1440" :marks="{10: '10分', 60: '1时', 360: '6时', 720: '12时', 1440: '24时'}" />
              <div style="font-size: 12px; color: var(--adx-text-tertiary); margin-top: 4px">
                每 <b style="color: var(--adx-color-primary)">{{ config.frequencyMin }}</b> 分钟执行一次
              </div>
            </el-form-item>
            <el-form-item label="反向采集验证">
              <el-switch v-model="config.reverseVerify" />
              <span style="margin-left: 10px; font-size: 12px; color: var(--adx-text-tertiary)">换链后验证新URL可访问</span>
            </el-form-item>
            <el-form-item label="与补点击同源">
              <el-switch v-model="config.sameOrigin" />
              <span style="margin-left: 10px; font-size: 12px; color: var(--adx-text-tertiary)">共享补点击的代理池/指纹池</span>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
      <el-col :xs="24" :lg="16">
        <el-card shadow="never">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-success)"><Clock /></el-icon><span class="card-title">历史执行日志</span></div>
          </template>
          <el-table :data="logs" stripe size="small">
            <el-table-column label="旧URL" min-width="200" show-overflow-tooltip>
              <template #default="{ row }"><span class="log-url">{{ row.oldUrl }}</span></template>
            </el-table-column>
            <el-table-column label="新URL" min-width="200" show-overflow-tooltip>
              <template #default="{ row }"><span class="log-url new">{{ row.newUrl }}</span></template>
            </el-table-column>
            <el-table-column label="指纹" width="110">
              <template #default="{ row }"><el-tag size="small" effect="plain" round>{{ row.fingerprint }}</el-tag></template>
            </el-table-column>
            <el-table-column label="状态" width="80">
              <template #default="{ row }">
                <el-tag :type="statusTag(row.status).type" effect="light" size="small">{{ statusTag(row.status).text }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="time" label="执行时间" width="160" />
            <el-table-column label="反向验证结果" min-width="220" show-overflow-tooltip>
              <template #default="{ row }">
                <span :class="{err: row.status === 'error', ok: row.status === 'success'}">{{ row.reverse }}</span>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <el-dialog v-model="addLinkDialog" title="添加换链规则" width="600px">
      <el-form :model="addLinkForm" label-width="100px">
        <el-form-item label="旧URL">
          <el-input v-model="addLinkForm.oldUrl" placeholder="https://old-example.com/page" />
        </el-form-item>
        <el-form-item label="新URL">
          <el-input v-model="addLinkForm.newUrl" placeholder="https://new-example.com/page" />
        </el-form-item>
        <el-form-item label="指纹标签">
          <el-input placeholder="自动生成，可自定义" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="addLinkDialog = false">取消</el-button>
        <el-button type="primary" @click="confirmAddLink">确定添加</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.linkswap-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  display: flex; align-items: center; justify-content: space-between;
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.card-title-wrap { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; font-size: 14px; }
.card-title { color: var(--adx-text-primary); }

.selector-row {
  display: flex; align-items: center;
  .label { font-weight: 600; margin-right: 12px; width: 90px; color: var(--adx-text-secondary); }
}

.url-row {
  display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
  .url-item {
    display: inline-flex; align-items: center;
    max-width: 38%;
    .url-text {
      font-size: 12px;
      color: var(--adx-text-secondary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    &.new .url-text { color: var(--adx-color-success); font-weight: 500; }
  }
  .url-arrow {
    color: var(--adx-color-primary);
    font-weight: 700;
    flex-shrink: 0;
  }
}

.log-url { font-size: 12px; color: var(--adx-text-secondary);
  &.new { color: var(--adx-color-success); }
}
.ok { color: var(--adx-color-success); font-size: 12px; }
.err { color: var(--adx-color-danger); font-size: 12px; font-weight: 500; }
</style>
