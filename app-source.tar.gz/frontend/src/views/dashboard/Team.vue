<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const dialogVisible = ref(false)
const dialogMode = ref('create')

const roles = [
  { value: 'owner', label: 'Owner 所有者', tag: 'danger', color: '#EF4444', desc: '拥有所有权限，唯一' },
  { value: 'admin', label: 'Admin 管理员', tag: 'warning', color: '#F59E0B', desc: '系统配置、成员管理' },
  { value: 'member', label: 'Member 成员', tag: 'primary', color: '#6366F1', desc: '广告管理与操作' },
  { value: 'viewer', label: 'Viewer 查看者', tag: 'info', color: '#64748B', desc: '仅查看数据，无操作' }
]

const getRole = (v) => roles.find(r => r.value === v) || { label: v, tag: 'info', color: '#999' }

const memberList = ref([])

const form = reactive({
  id: null,
  username: '',
  email: '',
  role: 'member',
  password: '',
  confirmPassword: ''
})

const statusTag = (s) => ({
  active: { type: 'success', text: '正常' },
  disabled: { type: 'info', text: '已禁用' },
  pending: { type: 'warning', text: '待激活' }
}[s] || { type: 'info', text: s })

const openCreate = () => {
  dialogMode.value = 'create'
  Object.keys(form).forEach(k => {
    form[k] = k === 'id' ? null : k === 'role' ? 'member' : ''
  })
  dialogVisible.value = true
}
const openEdit = (row) => {
  dialogMode.value = 'edit'
  Object.assign(form, row, { password: '', confirmPassword: '' })
  dialogVisible.value = true
}

const validEmail = (email) => /^[\w.+-]+@[\w-]+\.[\w.-]+$/.test(email)

const handleSubmit = () => {
  if (!form.username.trim() || form.username.length < 3) { ElMessage.warning('用户名至少3位'); return }
  if (!validEmail(form.email)) { ElMessage.warning('邮箱格式不正确'); return }
  if (dialogMode.value === 'create') {
    if (!form.password || form.password.length < 6) { ElMessage.warning('密码至少6位'); return }
    if (form.password !== form.confirmPassword) { ElMessage.warning('两次密码输入不一致'); return }
  }
  ElMessage.success(dialogMode.value === 'create' ? '成员已创建，初始密码已发送邮件' : '成员信息已更新')
  dialogVisible.value = false
}

const toggleStatus = async (row) => {
  const enable = row.status !== 'active'
  try {
    await ElMessageBox.confirm(`确定${enable ? '启用' : '禁用'}成员【${row.username}】?`, '确认', { type: 'warning' })
    row.status = enable ? 'active' : 'disabled'
    ElMessage.success('操作成功')
  } catch (_) {}
}
const resetPwd = async (row) => {
  try {
    await ElMessageBox.confirm(`为【${row.username}】重置密码并发送邮件?`, '重置密码', { type: 'info' })
    ElMessage.success('临时密码已发送至 ' + row.email)
  } catch (_) {}
}
const removeMember = async (row) => {
  if (row.role === 'owner') { ElMessage.warning('不能删除Owner角色'); return }
  try {
    await ElMessageBox.confirm(`删除成员【${row.username}】，该操作不可撤销?`, '删除确认', { type: 'warning' })
    ElMessage.success('已移除')
  } catch (_) {}
}
</script>

<template>
  <div class="team-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">团队成员</h2>
        <p class="page-subtitle">管理租户下的成员账号、角色与权限</p>
      </div>
      <el-button type="primary" class="el-button--gradient" @click="openCreate">
        <el-icon><Plus /></el-icon>新建成员
      </el-button>
    </div>

    <el-row :gutter="16" class="role-stats">
      <el-col v-for="r in roles" :key="r.value" :xs="12" :sm="6" :lg="3">
        <el-card shadow="never" class="role-stat">
          <div class="role-head">
            <el-tag :color="r.color + '20'" :style="{ color: r.color, border: 'none' }" effect="dark" round>{{ r.label.split(' ')[0] }}</el-tag>
            <div class="role-count">{{ memberList.filter(m => m.role === r.value).length }}</div>
          </div>
          <div class="role-desc">{{ r.desc }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never" style="margin-top: 16px">
      <div class="table-toolbar">
        <el-input placeholder="搜索用户名/邮箱..." :prefix-icon="Search" clearable style="width: 260px" />
        <div class="toolbar-right">
          <el-select placeholder="按角色筛选" clearable style="width: 180px; margin-right: 8px">
            <el-option v-for="r in roles" :key="r.value" :label="r.label" :value="r.value" />
          </el-select>
          <el-select placeholder="按状态" clearable style="width: 140px">
            <el-option label="正常" value="active" />
            <el-option label="已禁用" value="disabled" />
            <el-option label="待激活" value="pending" />
          </el-select>
        </div>
      </div>
      <el-table :data="memberList" stripe style="margin-top: 12px">
        <el-table-column label="成员" min-width="220">
          <template #default="{ row }">
            <div style="display: inline-flex; align-items: center; gap: 10px">
              <el-avatar
                :size="40"
                :style="{ background: `linear-gradient(135deg, #6366F1, #8A05FF)`, color: '#fff', fontWeight: 700 }"
              >{{ row.username.charAt(0).toUpperCase() }}</el-avatar>
              <div>
                <div style="font-weight: 600; color: var(--adx-text-primary)">{{ row.username }}</div>
                <div style="font-size: 12px; color: var(--adx-text-tertiary)">{{ row.email }}</div>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="角色" width="130">
          <template #default="{ row }">
            <el-tag :color="getRole(row.role).color + '20'" :style="{ color: getRole(row.role).color, border: 'none' }" effect="dark" size="small">
              {{ getRole(row.role).label }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">{{ statusTag(row.status).text }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="lastLogin" label="最近登录" width="170">
          <template #default="{ row }">
            <span style="font-size: 12px; color: var(--adx-text-secondary)">{{ row.lastLogin }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="createdAt" label="加入时间" width="130" />
        <el-table-column label="操作" width="260" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="openEdit(row)">编辑</el-button>
            <el-button link type="warning" size="small" @click="toggleStatus(row)">
              {{ row.status === 'active' ? '禁用' : '启用' }}
            </el-button>
            <el-button link type="primary" size="small" @click="resetPwd(row)">重置密码</el-button>
            <el-button link type="danger" size="small" @click="removeMember(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogMode === 'create' ? '新建团队成员' : '编辑成员'" width="520px" destroy-on-close>
      <el-form :model="form" label-width="100px">
        <el-form-item label="用户名" required>
          <el-input v-model="form.username" placeholder="至少3位字母数字" />
        </el-form-item>
        <el-form-item label="邮箱" required>
          <el-input v-model="form.email" placeholder="name@example.com" />
        </el-form-item>
        <el-form-item label="角色" required>
          <el-select v-model="form.role" style="width: 100%">
            <el-option v-for="r in roles" :key="r.value" :label="r.label" :value="r.value" />
          </el-select>
        </el-form-item>
        <el-divider v-if="dialogMode === 'create'">初始密码</el-divider>
        <template v-if="dialogMode === 'create'">
          <el-form-item label="密码" required>
            <el-input v-model="form.password" type="password" show-password placeholder="至少6位" />
          </el-form-item>
          <el-form-item label="确认密码" required>
            <el-input v-model="form.confirmPassword" type="password" show-password placeholder="再次输入" />
          </el-form-item>
        </template>
        <el-alert v-else type="info" :closable="false" title="修改成员的邮箱或角色即可，密码通过「重置密码」功能单独发送" show-icon />
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">{{ dialogMode === 'create' ? '创建成员' : '保存修改' }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.team-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  display: flex; align-items: center; justify-content: space-between;
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.role-stats { margin: 0; }
.role-stat {
  :deep(.el-card__body) { padding: 16px; }
}
.role-head {
  display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;
}
.role-count {
  font-size: 24px; font-weight: 800; color: var(--adx-text-primary);
}
.role-desc {
  font-size: 12px; color: var(--adx-text-tertiary); line-height: 1.5;
}

.table-toolbar {
  display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;
}
.toolbar-right { display: inline-flex; }
</style>
