<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const dialogVisible = ref(false)
const drawerVisible = ref(false)
const dialogMode = ref('create')
const selectedTask = ref(null)

const taskTypes = [
  { value: 'sync_ads', label: '同步Ads数据', color: '#6366F1', icon: 'Refresh' },
  { value: 'click_bot', label: '补点击', color: '#10B981', icon: 'Mouse' },
  { value: 'link_swap', label: '换链', color: '#3B82F6', icon: 'Link' },
  { value: 'ai_generate', label: 'AI创意生成', color: '#8A05FF', icon: 'MagicStick' },
  { value: 'budget_update', label: '预算更新', color: '#F59E0B', icon: 'Wallet' },
  { value: 'data_export', label: '数据导出', color: '#06B6D4', icon: 'Download' },
  { value: 'cost_alert', label: '成本告警', color: '#EF4444', icon: 'Bell' },
  { value: 'ip_rotate', label: 'IP轮换', color: '#8B5CF6', icon: 'Connection' }
]

const getTaskMeta = (v) => taskTypes.find(t => t.value === v) || { label: v, color: '#999' }

const taskList = ref([
  { id: 1, name: '每日全量同步Ads', type: 'sync_ads', enabled: true, cron: '0 9 * * *', interval: null, relatedId: '全部MCC', params: '{}', lastRun: '2026-08-02 09:00:05', nextRun: '2026-08-03 09:00:00', success: 156, fail: 3 },
  { id: 2, name: '春季促销-补点击', type: 'click_bot', enabled: true, cron: null, interval: 45, relatedId: 'campaign-1', params: '{"target":500}', lastRun: '2026-08-02 10:28:02', nextRun: '2026-08-02 11:13:00', success: 42, fail: 1 },
  { id: 3, name: 'PMax系列-换链', type: 'link_swap', enabled: true, cron: '*/30 * * * *', interval: null, relatedId: 'campaign-2', params: '{}', lastRun: '2026-08-02 10:15:33', nextRun: '2026-08-02 10:45:00', success: 86, fail: 0 },
  { id: 4, name: '周度AI创意生成', type: 'ai_generate', enabled: false, cron: '0 2 * * 1', interval: null, relatedId: 'ALL', params: '{"lang":"en"}', lastRun: '2026-07-28 02:00:12', nextRun: '已暂停', success: 8, fail: 2 },
  { id: 5, name: '智能预算更新', type: 'budget_update', enabled: true, cron: '0 */6 * * *', interval: null, relatedId: 'campaign-1,2', params: '{"strategy":"roas"}', lastRun: '2026-08-02 06:00:01', nextRun: '2026-08-02 12:00:00', success: 92, fail: 0 },
  { id: 6, name: '周报数据导出', type: 'data_export', enabled: true, cron: '0 10 * * 1', interval: null, relatedId: 'ALL', params: '{"format":"xlsx"}', lastRun: '2026-07-28 10:00:08', nextRun: '2026-08-04 10:00:00', success: 12, fail: 0 },
  { id: 7, name: '单日花费>1000告警', type: 'cost_alert', enabled: true, cron: null, interval: 10, relatedId: 'ALL', params: '{"threshold":1000}', lastRun: '2026-08-02 10:50:00', nextRun: '2026-08-02 11:00:00', success: 992, fail: 4 },
  { id: 8, name: '代理池IP健康轮换', type: 'ip_rotate', enabled: true, cron: '0 * * * *', interval: null, relatedId: '-', params: '{}', lastRun: '2026-08-02 10:00:02', nextRun: '2026-08-02 11:00:00', success: 720, fail: 8 }
])

const execRecords = ref([
  { id: 1, time: '2026-08-02 10:28:02', status: 'success', duration: '45.2s', result: '执行补点击500次，成功487次', error: '', detail: {} },
  { id: 2, time: '2026-08-02 09:43:02', status: 'success', duration: '42.8s', result: '执行补点击500次，成功491次', error: '', detail: {} },
  { id: 3, time: '2026-08-02 08:58:02', status: 'warning', duration: '48.1s', result: '执行补点击500次，成功452次，代理失败48次', error: '部分代理超时', detail: {} },
  { id: 4, time: '2026-08-02 08:13:01', status: 'success', duration: '40.6s', result: '执行补点击500次，成功495次', error: '', detail: {} },
  { id: 5, time: '2026-08-02 07:28:02', status: 'error', duration: '5.2s', result: '任务失败', error: '代理池无可用节点，请检查代理配置', detail: {} },
  { id: 6, time: '2026-08-02 06:43:01', status: 'success', duration: '44.0s', result: '执行补点击500次，成功489次', error: '', detail: {} }
])

const form = reactive({
  id: null,
  name: '',
  type: 'sync_ads',
  mode: 'cron',
  cron: '0 9 * * *',
  interval: 60,
  relatedId: '',
  params: '{}'
})

const statusTag = (s) => ({
  success: { type: 'success', text: '成功' },
  warning: { type: 'warning', text: '警告' },
  error: { type: 'danger', text: '失败' },
  running: { type: 'primary', text: '运行中' }
}[s] || { type: 'info', text: s })

const openCreate = () => {
  dialogMode.value = 'create'
  Object.keys(form).forEach(k => {
    form[k] = k === 'id' ? null : k === 'mode' ? 'cron' : k === 'interval' ? 60 : k === 'cron' ? '0 9 * * *' : k === 'params' ? '{}' : ''
  })
  form.type = 'sync_ads'
  dialogVisible.value = true
}

const openEdit = (row) => {
  dialogMode.value = 'edit'
  Object.assign(form, row, { mode: row.cron ? 'cron' : 'interval' })
  dialogVisible.value = true
}

const handleSubmit = async () => {
  ElMessage.success(dialogMode.value === 'create' ? '创建成功' : '更新成功')
  dialogVisible.value = false
}

const triggerNow = async (row) => {
  try {
    await ElMessageBox.confirm(`立即执行任务【${row.name}】?`, '执行确认', { type: 'info' })
    ElMessage.success(`任务已触发，任务实例ID: ${Date.now()}`)
  } catch (_) {}
}
const toggleEnabled = (row, val) => ElMessage.success(`已${val ? '启用' : '暂停'}【${row.name}】`)
const deleteTask = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除任务【${row.name}】?`, '删除确认', { type: 'warning' })
    ElMessage.success('删除成功')
  } catch (_) {}
}
const viewRecords = (row) => {
  selectedTask.value = row
  drawerVisible.value = true
}
</script>

<template>
  <div class="tasks-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">定时任务管理</h2>
        <p class="page-subtitle">创建与调度广告自动化任务，支持Cron和Interval两种模式</p>
      </div>
      <el-button type="primary" class="el-button--gradient" @click="openCreate">
        <el-icon><Plus /></el-icon>新建任务
      </el-button>
    </div>

    <el-row :gutter="16" class="stat-row">
      <el-col v-for="t in taskTypes" :key="t.value" :xs="12" :sm="8" :md="6" :lg="3">
        <el-card shadow="never" class="stat-mini-card">
          <div class="stat-mini-inner">
            <div class="stat-mini-icon" :style="{ background: t.color + '15', color: t.color }">
              <el-icon><component :is="t.icon" /></el-icon>
            </div>
            <div class="stat-mini-info">
              <div class="stat-mini-name">{{ t.label }}</div>
              <div class="stat-mini-count">
                <b>{{ taskList.filter(x => x.type === t.value).length }}</b> 个
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never">
      <el-table :data="taskList" stripe>
        <el-table-column prop="name" label="任务名称" min-width="200">
          <template #default="{ row }">
            <div class="task-name-cell">
              <div class="task-type-dot" :style="{ background: getTaskMeta(row.type).color }"></div>
              <span style="font-weight: 600">{{ row.name }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="type" label="类型" width="130">
          <template #default="{ row }">
            <el-tag :color="getTaskMeta(row.type).color + '18'" :style="{ color: getTaskMeta(row.type).color, border: 'none' }" effect="plain" size="small">
              <el-icon style="margin-right: 2px"><component :is="getTaskMeta(row.type).icon" /></el-icon>
              {{ getTaskMeta(row.type).label }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="调度" width="170">
          <template #default="{ row }">
            <div v-if="row.cron" style="font-family: 'JetBrains Mono', monospace; font-size: 12px; background: var(--adx-bg-secondary); padding: 3px 8px; border-radius: 6px; display: inline-block">
              <el-tag size="small" effect="dark" style="margin-right: 6px" type="primary">Cron</el-tag>{{ row.cron }}
            </div>
            <div v-else style="font-size: 12px">
              <el-tag size="small" effect="dark" style="margin-right: 6px" type="warning">Interval</el-tag>每 {{ row.interval }} 分钟
            </div>
          </template>
        </el-table-column>
        <el-table-column label="开关" width="80" align="center">
          <template #default="{ row }">
            <el-switch v-model="row.enabled" @change="toggleEnabled(row, $event)" size="small" />
          </template>
        </el-table-column>
        <el-table-column prop="lastRun" label="最近运行" width="160" />
        <el-table-column prop="nextRun" label="下次运行" width="160">
          <template #default="{ row }">
            <span :style="{ color: row.enabled ? '' : 'var(--adx-text-tertiary)' }">{{ row.nextRun }}</span>
          </template>
        </el-table-column>
        <el-table-column label="成功/失败" width="110" align="center">
          <template #default="{ row }">
            <el-tag type="success" effect="plain" size="small">{{ row.success }}</el-tag>
            <span style="margin: 0 4px">/</span>
            <el-tag type="danger" effect="plain" size="small">{{ row.fail }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="300" fixed="right">
          <template #default="{ row }">
            <el-button link type="success" size="small" @click="triggerNow(row)">立即触发</el-button>
            <el-button link type="primary" size="small" @click="viewRecords(row)">执行记录</el-button>
            <el-button link type="primary" size="small" @click="openEdit(row)">编辑</el-button>
            <el-button link type="danger" size="small" @click="deleteTask(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogMode === 'create' ? '新建定时任务' : '编辑定时任务'" width="640px" destroy-on-close>
      <el-form :model="form" label-width="110px">
        <el-form-item label="任务名称" required>
          <el-input v-model="form.name" placeholder="如：每日全量同步Ads数据" />
        </el-form-item>
        <el-form-item label="任务类型" required>
          <el-select v-model="form.type" style="width: 100%">
            <el-option v-for="t in taskTypes" :key="t.value" :label="t.label" :value="t.value" />
          </el-select>
        </el-form-item>
        <el-form-item label="调度模式" required>
          <el-radio-group v-model="form.mode">
            <el-radio-button value="cron">Cron表达式</el-radio-button>
            <el-radio-button value="interval">固定间隔(分钟)</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item v-if="form.mode === 'cron'" label="Cron表达式">
          <el-input v-model="form.cron" placeholder="如: 0 9 * * * (每天9点)" />
          <div style="margin-top: 6px; font-size: 12px; color: var(--adx-text-tertiary)">
            格式: 分 时 日 月 周 · 常用：
            <el-tag size="small" effect="plain" style="margin-left: 4px; cursor: pointer" @click="form.cron = '0 */6 * * *'">每6小时</el-tag>
            <el-tag size="small" effect="plain" style="margin-left: 4px; cursor: pointer" @click="form.cron = '0 9 * * *'">每天9点</el-tag>
            <el-tag size="small" effect="plain" style="margin-left: 4px; cursor: pointer" @click="form.cron = '0 10 * * 1'">每周一10点</el-tag>
            <el-tag size="small" effect="plain" style="margin-left: 4px; cursor: pointer" @click="form.cron = '*/30 * * * *'">每30分钟</el-tag>
          </div>
        </el-form-item>
        <el-form-item v-else label="间隔(分钟)">
          <el-input-number v-model="form.interval" :min="1" :max="10080" controls-position="right" style="width: 220px" />
        </el-form-item>
        <el-form-item label="关联ID">
          <el-input v-model="form.relatedId" placeholder="广告系列ID / MCC ID / ALL 等，多个逗号分隔" />
        </el-form-item>
        <el-form-item label="参数(JSON)">
          <el-input v-model="form.params" type="textarea" :rows="4" placeholder='{"key":"value"} 格式的任务自定义参数' />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>

    <el-drawer v-model="drawerVisible" :title="`执行记录 - ${selectedTask?.name || ''}`" size="70%">
      <div v-if="selectedTask" class="drawer-meta">
        <el-tag type="primary" effect="plain">类型: {{ getTaskMeta(selectedTask.type).label }}</el-tag>
        <el-tag type="info" effect="plain">关联: {{ selectedTask.relatedId }}</el-tag>
        <el-tag effect="plain" :type="selectedTask.enabled ? 'success' : 'danger'">
          {{ selectedTask.enabled ? '任务已启用' : '任务已暂停' }}
        </el-tag>
      </div>
      <el-table :data="execRecords" stripe style="margin-top: 16px" size="small">
        <el-table-column prop="time" label="执行时间" width="170" />
        <el-table-column prop="status" label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">{{ statusTag(row.status).text }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="duration" label="耗时" width="90" />
        <el-table-column prop="result" label="执行结果" min-width="300" show-overflow-tooltip />
        <el-table-column prop="error" label="错误信息" min-width="220" show-overflow-tooltip>
          <template #default="{ row }">
            <span v-if="row.error" style="color: var(--adx-color-danger)">{{ row.error }}</span>
            <span v-else style="color: var(--adx-text-tertiary)">-</span>
          </template>
        </el-table-column>
        <el-table-column label="详细数据" width="100" fixed="right">
          <template #default>
            <el-button link type="primary" size="small">查看JSON</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-drawer>
  </div>
</template>

<style lang="scss" scoped>
.tasks-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  display: flex; align-items: center; justify-content: space-between;
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}

.stat-row { margin-bottom: 0; }
.stat-mini-card { :deep(.el-card__body) { padding: 16px; } }
.stat-mini-inner {
  display: flex; align-items: center; gap: 12px;
}
.stat-mini-icon {
  width: 42px; height: 42px;
  border-radius: 10px;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: 20px;
}
.stat-mini-info {
  .stat-mini-name { font-size: 12px; color: var(--adx-text-tertiary); margin-bottom: 2px; }
  .stat-mini-count { font-size: 16px; font-weight: 700; color: var(--adx-text-primary); }
}

.task-name-cell {
  display: inline-flex; align-items: center; gap: 8px;
  .task-type-dot {
    width: 8px; height: 8px; border-radius: 50%;
    flex-shrink: 0;
  }
}
.drawer-meta { display: flex; gap: 8px; flex-wrap: wrap; }
</style>
