<script setup>
import { ref, onMounted, watch, nextTick } from 'vue'
import * as echarts from 'echarts'
import { ElMessage } from 'element-plus'
import request from '@/utils/request'

const loading = ref(false)

const stats = ref({
  todayCost: 0,
  todayImpressions: 0,
  todayClicks: 0,
  todayConversions: 0
})

const statsConfig = [
  { key: 'todayCost', title: '今日花费', icon: 'Wallet', suffix: 'USD', color: '#6366F1' },
  { key: 'todayImpressions', title: '今日展示', icon: 'View', suffix: '次', color: '#3B82F6' },
  { key: 'todayClicks', title: '今日点击', icon: 'Mouse', suffix: '次', color: '#10B981' },
  { key: 'todayConversions', title: '今日转化', icon: 'Promotion', suffix: '次', color: '#F59E0B' }
]

const animateNumber = (target, key, duration = 1500) => {
  const start = 0
  const end = target
  const startTime = Date.now()
  const tick = () => {
    const elapsed = Date.now() - startTime
    const progress = Math.min(elapsed / duration, 1)
    const ease = 1 - Math.pow(1 - progress, 3)
    stats.value[key] = Math.floor(start + (end - start) * ease)
    if (progress < 1) requestAnimationFrame(tick)
  }
  tick()
}

const trendChartRef = ref(null)
const topCampaignChartRef = ref(null)
const accountPieChartRef = ref(null)
const countryBarChartRef = ref(null)

let trendChart = null
let topCampaignChart = null
let accountPieChart = null
let countryBarChart = null

const initTrendChart = () => {
  if (!trendChartRef.value) return
  trendChart = echarts.init(trendChartRef.value)
  const dates = []
  const costs = []
  const clicks = []
  for (let i = 29; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    dates.push(`${d.getMonth() + 1}/${d.getDate()}`)
    costs.push(Math.floor(Math.random() * 5000 + 1000))
    clicks.push(Math.floor(Math.random() * 2000 + 200))
  }
  trendChart.setOption({
    tooltip: { trigger: 'axis', axisPointer: { type: 'cross' } },
    legend: { data: ['花费(USD)', '点击数'], top: 0 },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: { type: 'category', boundaryGap: false, data: dates, axisLine: { lineStyle: { color: '#E5E7EB' } } },
    yAxis: [
      { type: 'value', name: '花费(USD)', splitLine: { lineStyle: { color: '#F3F4F6' } } },
      { type: 'value', name: '点击数', splitLine: { show: false } }
    ],
    series: [
      {
        name: '花费(USD)',
        type: 'line',
        smooth: true,
        data: costs,
        itemStyle: { color: '#6366F1' },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(99, 102, 241, 0.25)' },
            { offset: 1, color: 'rgba(99, 102, 241, 0.02)' }
          ])
        }
      },
      {
        name: '点击数',
        type: 'line',
        yAxisIndex: 1,
        smooth: true,
        data: clicks,
        itemStyle: { color: '#10B981' },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(16, 185, 129, 0.2)' },
            { offset: 1, color: 'rgba(16, 185, 129, 0.02)' }
          ])
        }
      }
    ]
  })
}

const initTopCampaignChart = () => {
  if (!topCampaignChartRef.value) return
  topCampaignChart = echarts.init(topCampaignChartRef.value)
  const campaigns = ['春季促销_US', '品牌词Campaign', 'GDN_再营销', 'YouTube_Video', '搜索_核心词', '购物智能', 'PMax_全站', '展示_冷流量', 'B2B_LinkedIn', 'Discovery_发现']
  const values = campaigns.map(() => Math.floor(Math.random() * 8000 + 2000))
  topCampaignChart.setOption({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '8%', bottom: '3%', top: '3%', containLabel: true },
    xAxis: { type: 'value', splitLine: { lineStyle: { color: '#F3F4F6' } } },
    yAxis: {
      type: 'category',
      data: campaigns.reverse(),
      axisLine: { lineStyle: { color: '#E5E7EB' } },
      axisLabel: { width: 120, overflow: 'truncate' }
    },
    series: [{
      type: 'bar',
      data: values.reverse(),
      itemStyle: {
        borderRadius: [0, 6, 6, 0],
        color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
          { offset: 0, color: '#6366F1' },
          { offset: 1, color: '#8A05FF' }
        ])
      },
      barWidth: 14
    }]
  })
}

const initAccountPieChart = () => {
  if (!accountPieChartRef.value) return
  accountPieChart = echarts.init(accountPieChartRef.value)
  accountPieChart.setOption({
    tooltip: { trigger: 'item' },
    legend: { bottom: 0 },
    series: [{
      type: 'pie',
      radius: ['40%', '65%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: false },
      emphasis: { label: { show: true, fontSize: 14, fontWeight: 'bold' } },
      data: [
        { value: 128, name: '活跃', itemStyle: { color: '#10B981' } },
        { value: 23, name: '同步中', itemStyle: { color: '#3B82F6' } },
        { value: 12, name: '异常', itemStyle: { color: '#EF4444' } },
        { value: 8, name: '停用', itemStyle: { color: '#9CA3AF' } }
      ]
    }]
  })
}

const initCountryBarChart = () => {
  if (!countryBarChartRef.value) return
  countryBarChart = echarts.init(countryBarChartRef.value)
  const countries = ['US', 'UK', 'CA', 'AU', 'DE', 'FR', 'JP', 'SG']
  const data = countries.map(() => Math.floor(Math.random() * 5000 + 500))
  countryBarChart.setOption({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '3%', containLabel: true },
    xAxis: { type: 'category', data: countries, axisLine: { lineStyle: { color: '#E5E7EB' } } },
    yAxis: { type: 'value', splitLine: { lineStyle: { color: '#F3F4F6' } } },
    series: [{
      type: 'bar',
      data,
      itemStyle: {
        borderRadius: [6, 6, 0, 0],
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: '#8A05FF' },
          { offset: 1, color: '#6366F1' }
        ])
      },
      barWidth: 24
    }]
  })
}

const taskLogs = ref([
  { id: 1, name: '同步MCC账号-主账号', type: '同步Ads', status: 'success', duration: '12s', time: '2026-08-02 10:32:15' },
  { id: 2, name: '补点击任务-春季促销', type: '补点击', status: 'running', duration: '45s', time: '2026-08-02 10:28:02' },
  { id: 3, name: '换链任务-PMax系列', type: '换链', status: 'success', duration: '8s', time: '2026-08-02 10:15:33' },
  { id: 4, name: 'AI创意生成-Offer #23', type: 'AI生成', status: 'error', duration: '22s', time: '2026-08-02 09:45:10' },
  { id: 5, name: '每日预算更新', type: '预算更新', status: 'success', duration: '5s', time: '2026-08-02 09:00:01' }
])

const clickLogs = ref([
  { id: 1, ad: '春季促销_Responsive', country: 'US', ip: '192.168.1.' + Math.floor(Math.random() * 255), status: 'success', duration: '3m12s' },
  { id: 2, ad: '品牌词_SearchAd #5', country: 'UK', ip: '10.0.0.' + Math.floor(Math.random() * 255), status: 'success', duration: '1m45s' },
  { id: 3, ad: 'GDN_Banner_728x90', country: 'CA', ip: '172.16.0.' + Math.floor(Math.random() * 255), status: 'warning', duration: '32s' },
  { id: 4, ad: '购物智能_Shopping', country: 'DE', ip: '192.168.2.' + Math.floor(Math.random() * 255), status: 'success', duration: '4m22s' },
  { id: 5, ad: 'Video_TrueView_15s', country: 'AU', ip: '10.10.10.' + Math.floor(Math.random() * 255), status: 'error', duration: '8s' },
  { id: 6, ad: 'PMax_全站推广', country: 'FR', ip: '192.168.5.' + Math.floor(Math.random() * 255), status: 'success', duration: '2m55s' }
])

const statusTagType = (s) => {
  return { success: 'success', running: 'primary', error: 'danger', warning: 'warning' }[s] || 'info'
}
const statusText = (s) => {
  return { success: '成功', running: '执行中', error: '失败', warning: '警告' }[s] || s
}

const fetchDashboard = async () => {
  loading.value = true
  try {
    // const res = await request.get('/dashboard/stats')
    // stats.value = res.data
    setTimeout(() => {
      animateNumber(12847.56, 'todayCost')
      animateNumber(238471, 'todayImpressions')
      animateNumber(8472, 'todayClicks')
      animateNumber(342, 'todayConversions')
    }, 200)
  } catch (e) {
    ElMessage.error('加载仪表盘数据失败')
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  fetchDashboard()
  await nextTick()
  initTrendChart()
  initTopCampaignChart()
  initAccountPieChart()
  initCountryBarChart()
  window.addEventListener('resize', () => {
    trendChart?.resize()
    topCampaignChart?.resize()
    accountPieChart?.resize()
    countryBarChart?.resize()
  })
})
</script>

<template>
  <div class="dashboard-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">数据仪表盘</h2>
        <p class="page-subtitle">实时查看广告投放效果与自动化任务执行情况</p>
      </div>
      <el-button type="primary" class="el-button--gradient">
        <el-icon><Refresh /></el-icon>刷新数据
      </el-button>
    </div>

    <div class="stats-grid">
      <el-card v-for="cfg in statsConfig" :key="cfg.key" class="stat-card" shadow="never">
        <div class="stat-card-inner">
          <div class="stat-info">
            <div class="stat-title">{{ cfg.title }}</div>
            <div class="stat-value">
              <span class="num">{{ stats[cfg.key].toLocaleString() }}</span>
              <span class="suffix">{{ cfg.suffix }}</span>
            </div>
            <div class="stat-trend">
              <el-tag type="success" size="small" effect="plain">↑ 12.5%</el-tag>
              <span class="vs-text">较昨日</span>
            </div>
          </div>
          <div class="stat-icon" :style="{ background: cfg.color + '15', color: cfg.color }">
            <el-icon :size="28">
              <component :is="cfg.icon" />
            </el-icon>
          </div>
        </div>
      </el-card>
    </div>

    <div class="charts-row">
      <el-card class="chart-card main-chart" shadow="never">
        <template #header>
          <div class="card-header">
            <span class="card-title">近30天 花费 & 点击趋势</span>
            <el-radio-group size="small" model-value="30d">
              <el-radio-button value="7d">7天</el-radio-button>
              <el-radio-button value="30d">30天</el-radio-button>
              <el-radio-button value="90d">90天</el-radio-button>
            </el-radio-group>
          </div>
        </template>
        <div ref="trendChartRef" class="chart-container"></div>
      </el-card>

      <el-card class="chart-card side-chart" shadow="never">
        <template #header>
          <div class="card-header">
            <span class="card-title">Top 10 广告系列</span>
            <el-button text>查看全部</el-button>
          </div>
        </template>
        <div ref="topCampaignChartRef" class="chart-container"></div>
      </el-card>
    </div>

    <div class="charts-row">
      <el-card class="chart-card half-chart" shadow="never">
        <template #header>
          <div class="card-header">
            <span class="card-title">账号状态分布</span>
          </div>
        </template>
        <div ref="accountPieChartRef" class="chart-container"></div>
      </el-card>

      <el-card class="chart-card half-chart" shadow="never">
        <template #header>
          <div class="card-header">
            <span class="card-title">按国家点击分布</span>
          </div>
        </template>
        <div ref="countryBarChartRef" class="chart-container"></div>
      </el-card>
    </div>

    <el-card class="table-card" shadow="never">
      <template #header>
        <div class="card-header">
          <span class="card-title"><el-icon><Timer /></el-icon>最近定时任务执行</span>
          <el-button text>查看全部任务</el-button>
        </div>
      </template>
      <el-table :data="taskLogs" size="small" stripe>
        <el-table-column prop="name" label="任务名" min-width="200" />
        <el-table-column prop="type" label="类型" width="100">
          <template #default="{ row }">
            <el-tag size="small">{{ row.type }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)" size="small" effect="light">
              {{ statusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="duration" label="耗时" width="100" />
        <el-table-column prop="time" label="执行时间" width="180" />
        <el-table-column label="操作" width="100">
          <template #default>
            <el-button link type="primary" size="small">查看日志</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card class="table-card" shadow="never">
      <template #header>
        <div class="card-header">
          <span class="card-title"><el-icon><Mouse /></el-icon>最新补点击日志</span>
          <el-button text>查看全部</el-button>
        </div>
      </template>
      <el-table :data="clickLogs" size="small" stripe>
        <el-table-column prop="ad" label="广告" min-width="180" show-overflow-tooltip />
        <el-table-column prop="country" label="国家" width="80" align="center">
          <template #default="{ row }">
            <el-tag size="small" effect="plain">{{ row.country }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="ip" label="IP" width="140" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)" size="small" effect="light">
              {{ statusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="duration" label="耗时" width="100" />
      </el-table>
    </el-card>
  </div>
</template>

<style lang="scss" scoped>
.dashboard-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  .page-title {
    margin: 0;
    font-size: 22px;
    font-weight: 700;
    color: var(--adx-text-primary);
  }
  .page-subtitle {
    margin: 4px 0 0;
    font-size: 13px;
    color: var(--adx-text-tertiary);
  }
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  @media (max-width: 1200px) { grid-template-columns: repeat(2, 1fr); }
  @media (max-width: 640px) { grid-template-columns: 1fr; }
}

.stat-card {
  :deep(.el-card__body) { padding: 20px; }
}
.stat-card-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.stat-info {
  .stat-title {
    font-size: 13px;
    color: var(--adx-text-tertiary);
    margin-bottom: 8px;
  }
  .stat-value {
    display: flex;
    align-items: baseline;
    gap: 4px;
    margin-bottom: 8px;
    .num {
      font-size: 28px;
      font-weight: 800;
      color: var(--adx-text-primary);
      line-height: 1;
    }
    .suffix {
      font-size: 12px;
      color: var(--adx-text-tertiary);
      font-weight: 600;
    }
  }
  .stat-trend {
    display: flex;
    align-items: center;
    gap: 6px;
    .vs-text { font-size: 12px; color: var(--adx-text-tertiary); }
  }
}
.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.charts-row {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 16px;
  &:nth-of-type(2) { grid-template-columns: 1fr 1fr; }
  @media (max-width: 1200px) {
    grid-template-columns: 1fr !important;
  }
}

.chart-card {
  .card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .card-title {
    font-weight: 600;
    font-size: 14px;
    color: var(--adx-text-primary);
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }
  :deep(.el-card__body) { padding: 12px 20px 20px; }
}
.chart-container {
  width: 100%;
  height: 320px;
}
.main-chart .chart-container { height: 340px; }

.table-card {
  .card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .card-title {
    font-weight: 600;
    font-size: 14px;
    color: var(--adx-text-primary);
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }
}
</style>
