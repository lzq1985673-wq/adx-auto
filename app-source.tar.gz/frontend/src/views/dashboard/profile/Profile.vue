<script setup>
import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()

const avatarDialog = ref(false)
const avatarFile = ref(null)
const avatarPreview = ref('')

const basicForm = reactive({
  username: userStore.username || 'admin',
  nickname: '超级管理员',
  email: 'admin@example.com',
  phone: '138****8888',
  department: '产品研发',
  position: '系统管理员',
  bio: '负责ADX-Auto平台的整体管理与运维'
})

const pwdForm = reactive({
  oldPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const loginLogs = ref([
  { id: 1, time: '2026-08-02 10:42:18', ip: '120.234.56.78', location: '中国 上海', device: 'Chrome / Windows 11', status: 'success' },
  { id: 2, time: '2026-08-01 22:08:33', ip: '120.234.56.78', location: '中国 上海', device: 'Chrome / Windows 11', status: 'success' },
  { id: 3, time: '2026-08-01 09:15:02', ip: '120.234.56.78', location: '中国 上海', device: 'Edge / Windows 11', status: 'success' },
  { id: 4, time: '2026-07-31 14:22:48', ip: '8.8.8.8', location: '美国 加州', device: 'Safari / iOS 17', status: 'warning' },
  { id: 5, time: '2026-07-30 19:45:10', ip: '120.234.56.78', location: '中国 上海', device: 'Chrome / Windows 11', status: 'success' },
  { id: 6, time: '2026-07-29 10:02:18', ip: '120.234.56.78', location: '中国 上海', device: 'Chrome / Windows 11', status: 'success' },
  { id: 7, time: '2026-07-28 23:18:55', ip: '211.22.33.44', location: '中国 北京', device: 'Firefox / macOS', status: 'success' },
  { id: 8, time: '2026-07-27 08:44:02', ip: '120.234.56.78', location: '中国 上海', device: 'Chrome / Windows 11', status: 'success' }
])

const statusTag = (s) => ({
  success: { type: 'success', text: '成功' },
  warning: { type: 'warning', text: '异地登录' },
  fail: { type: 'danger', text: '失败' }
}[s] || { type: 'info', text: s })

const saveBasic = () => { ElMessage.success('个人信息已保存') }
const changePassword = () => {
  if (!pwdForm.oldPassword || !pwdForm.newPassword || !pwdForm.confirmPassword) {
    ElMessage.warning('请完整填写密码表单'); return
  }
  if (pwdForm.newPassword.length < 6) { ElMessage.warning('新密码至少6位'); return }
  if (pwdForm.newPassword !== pwdForm.confirmPassword) { ElMessage.warning('两次输入的新密码不一致'); return }
  ElMessage.success('密码修改成功，请重新登录')
  pwdForm.oldPassword = ''
  pwdForm.newPassword = ''
  pwdForm.confirmPassword = ''
}

const beforeAvatarUpload = (file) => {
  const isImg = file.type.startsWith('image/')
  const isLt2M = file.size / 1024 / 1024 < 2
  if (!isImg) { ElMessage.error('请上传图片'); return false }
  if (!isLt2M) { ElMessage.error('图片不能超过2MB'); return false }
  const reader = new FileReader()
  reader.onload = (e) => { avatarPreview.value = e.target.result }
  reader.readAsDataURL(file)
  avatarFile.value = file
  avatarDialog.value = true
  return false
}

const saveAvatar = () => {
  ElMessage.success('头像已更新')
  avatarDialog.value = false
}

const stats = [
  { label: '管理MCC账号', value: 5, icon: 'UserFilled', color: '#6366F1' },
  { label: '广告系列', value: 24, icon: 'Histogram', color: '#3B82F6' },
  { label: '发起AI任务', value: 186, icon: 'MagicStick', color: '#8A05FF' },
  { label: '本月API调用', value: '48.2K', icon: 'Connection', color: '#10B981' }
]
</script>

<template>
  <div class="profile-page">
    <el-card shadow="never" class="hero-card">
      <div class="hero-bg"></div>
      <div class="hero-inner">
        <div class="hero-avatar-wrap">
          <el-avatar
            :size="96"
            :style="{ background: 'linear-gradient(135deg, #6366F1, #8A05FF)', color: '#fff', fontWeight: 800 }"
            class="hero-avatar"
          >
            {{ basicForm.username.charAt(0).toUpperCase() }}
          </el-avatar>
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :before-upload="beforeAvatarUpload"
            accept="image/*"
          >
            <div class="avatar-camera" title="更换头像"><el-icon><Camera /></el-icon></div>
          </el-upload>
        </div>
        <div class="hero-info">
          <div class="hero-name">
            {{ basicForm.nickname }}
            <el-tag type="danger" effect="dark" size="small" style="margin-left: 8px">Owner</el-tag>
          </div>
          <div class="hero-sub">@{{ basicForm.username }} · {{ basicForm.email }} · {{ basicForm.department }}</div>
          <div class="hero-bio">{{ basicForm.bio }}</div>
        </div>
        <div class="hero-stats">
          <div v-for="s in stats" :key="s.label" class="hero-stat">
            <div class="hero-stat-icon" :style="{ background: s.color + '18', color: s.color }">
              <el-icon><component :is="s.icon" /></el-icon>
            </div>
            <div class="hero-stat-right">
              <div class="hero-stat-val">{{ s.value }}</div>
              <div class="hero-stat-label">{{ s.label }}</div>
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <el-row :gutter="16" style="margin-top: 16px">
      <el-col :xs="24" :lg="14">
        <el-card shadow="never">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-primary)"><User /></el-icon><span class="card-title">基本信息</span></div>
          </template>
          <el-form :model="basicForm" label-width="110px">
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="用户名">
                  <el-input v-model="basicForm.username" disabled />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="昵称">
                  <el-input v-model="basicForm.nickname" />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="邮箱">
                  <el-input v-model="basicForm.email" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="手机号">
                  <el-input v-model="basicForm.phone" />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="部门">
                  <el-input v-model="basicForm.department" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="职位">
                  <el-input v-model="basicForm.position" />
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="个人简介">
              <el-input v-model="basicForm.bio" type="textarea" :rows="3" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" class="el-button--gradient" @click="saveBasic">
                <el-icon><Check /></el-icon>保存修改
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>

        <el-card shadow="never" style="margin-top: 16px">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-danger)"><Lock /></el-icon><span class="card-title">修改密码</span></div>
          </template>
          <el-form :model="pwdForm" label-width="110px" style="max-width: 500px">
            <el-form-item label="当前密码">
              <el-input v-model="pwdForm.oldPassword" type="password" show-password placeholder="请输入当前密码" />
            </el-form-item>
            <el-form-item label="新密码">
              <el-input v-model="pwdForm.newPassword" type="password" show-password placeholder="至少6位，建议大小写+符号" />
            </el-form-item>
            <el-form-item label="确认新密码">
              <el-input v-model="pwdForm.confirmPassword" type="password" show-password placeholder="再次输入新密码" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="changePassword">
                <el-icon><Key /></el-icon>确认修改密码
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>

      <el-col :xs="24" :lg="10">
        <el-card shadow="never">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-success)"><Clock /></el-icon><span class="card-title">最近登录日志</span></div>
          </template>
          <el-timeline>
            <el-timeline-item
              v-for="log in loginLogs"
              :key="log.id"
              :timestamp="log.time"
              placement="top"
              :type="statusTag(log.status).type"
              :hollow="log.status !== 'success'"
            >
              <el-card shadow="never" class="log-card">
                <div class="log-row">
                  <el-tag :type="statusTag(log.status).type" effect="light" size="small">{{ statusTag(log.status).text }}</el-tag>
                  <span class="log-ip">{{ log.ip }}</span>
                </div>
                <div class="log-info">
                  <div class="log-loc"><el-icon><Location /></el-icon>{{ log.location }}</div>
                  <div class="log-dev"><el-icon><Monitor /></el-icon>{{ log.device }}</div>
                </div>
              </el-card>
            </el-timeline-item>
          </el-timeline>
          <div style="text-align: center; margin-top: 8px">
            <el-button text type="primary">查看完整登录历史</el-button>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-dialog v-model="avatarDialog" title="裁剪并更换头像" width="520px">
      <div class="avatar-preview-wrap">
        <img :src="avatarPreview" style="width: 100%; border-radius: 12px; max-height: 360px; object-fit: contain; background: var(--adx-bg-tertiary)" />
      </div>
      <template #footer>
        <el-button @click="avatarDialog = false">取消</el-button>
        <el-button type="primary" class="el-button--gradient" @click="saveAvatar">应用新头像</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.profile-page { display: flex; flex-direction: column; gap: 0; }
.card-title-wrap { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; font-size: 14px; }
.card-title { color: var(--adx-text-primary); }

.hero-card {
  position: relative; overflow: hidden;
  :deep(.el-card__body) { padding: 0; }
}
.hero-bg {
  position: absolute; top: 0; left: 0; right: 0; height: 140px;
  background: linear-gradient(135deg, #6366F1 0%, #8A05FF 100%);
  opacity: 0.9;
}
.hero-inner {
  position: relative; padding: 28px 32px 24px;
  display: flex; align-items: flex-start; gap: 24px; flex-wrap: wrap;
  padding-top: 68px;
}
.hero-avatar-wrap {
  position: relative; flex-shrink: 0;
}
.hero-avatar {
  border: 4px solid #fff;
  box-shadow: var(--adx-shadow-lg);
}
.avatar-uploader {
  position: absolute; bottom: -4px; right: -4px;
  .avatar-camera {
    width: 32px; height: 32px;
    border-radius: 50%;
    background: #fff;
    box-shadow: var(--adx-shadow-md);
    display: inline-flex; align-items: center; justify-content: center;
    color: var(--adx-color-primary);
    cursor: pointer;
    transition: transform 0.2s;
    &:hover { transform: scale(1.1); }
  }
}
.hero-info { flex: 1; min-width: 240px; padding-top: 32px; color: #fff;
  .hero-name { font-size: 22px; font-weight: 800; margin-bottom: 6px; }
  .hero-sub { font-size: 13px; opacity: 0.9; margin-bottom: 8px; }
  .hero-bio { font-size: 13px; opacity: 0.85; max-width: 520px; line-height: 1.6; }
}
.hero-stats {
  display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px;
  padding-top: 32px; min-width: 300px;
}
.hero-stat {
  display: flex; align-items: center; gap: 10px;
  background: #fff;
  padding: 12px 14px;
  border-radius: 12px;
  box-shadow: var(--adx-shadow-sm);
}
.hero-stat-icon {
  width: 40px; height: 40px;
  border-radius: 10px;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: 20px; flex-shrink: 0;
}
.hero-stat-right {
  .hero-stat-val { font-size: 18px; font-weight: 800; color: var(--adx-text-primary); line-height: 1.1; }
  .hero-stat-label { font-size: 11px; color: var(--adx-text-tertiary); margin-top: 3px; }
}

.log-card {
  background: var(--adx-bg-secondary);
  border: none;
  :deep(.el-card__body) { padding: 10px 12px; }
}
.log-row {
  display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;
}
.log-ip {
  font-family: 'JetBrains Mono', monospace;
  font-size: 12px; color: var(--adx-text-secondary);
}
.log-info {
  font-size: 12px; color: var(--adx-text-secondary);
  div {
    display: inline-flex; align-items: center; gap: 4px;
    margin-right: 12px;
  }
}

.avatar-preview-wrap {
  display: flex; justify-content: center; align-items: center;
  padding: 8px; background: var(--adx-bg-secondary); border-radius: 12px;
}
</style>
