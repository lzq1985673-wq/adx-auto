<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const loading = ref(false)
const drawerVisible = ref(false)
const aiDialogVisible = ref(false)
const aiGenerating = ref(false)
const activeCreativeTab = ref(0)

const adList = ref([
  { id: 201, name: 'RSA_春季促销_V1', type: 'RSA', headlineCount: 12, descCount: 4, finalUrl: 'https://example.com/spring-sale', status: 'active', approval: 'approved', cost: 1280.5, impressions: 82000, clicks: 5230 },
  { id: 202, name: 'RSA_品牌价值_V2', type: 'RSA', headlineCount: 15, descCount: 4, finalUrl: 'https://example.com/features', status: 'active', approval: 'approved', cost: 820.2, impressions: 54000, clicks: 3420 },
  { id: 203, name: 'RSA_新品上市_V1', type: 'RSA', headlineCount: 8, descCount: 3, finalUrl: 'https://example.com/new-product', status: 'active', approval: 'under_review', cost: 320.0, impressions: 18000, clicks: 980 },
  { id: 204, name: 'RSA_黑五预热_V1', type: 'RSA', headlineCount: 14, descCount: 4, finalUrl: 'https://example.com/bf-deals', status: 'paused', approval: 'approved', cost: 0, impressions: 0, clicks: 0 },
  { id: 205, name: 'RSA_竞品拦截_V3', type: 'RSA', headlineCount: 10, descCount: 2, finalUrl: 'https://example.com/compare', status: 'active', approval: 'disapproved', cost: 540.3, impressions: 32000, clicks: 1820 }
])

const creativeForm = reactive({
  campaignId: '',
  adGroupId: '',
  adType: 'RSA',
  headlines: [{ text: '', pinned: '' }],
  descriptions: [{ text: '' }],
  paths: { path1: '', path2: '' },
  finalUrl: '',
  trackingTemplate: ''
})

const aiForm = reactive({ offerUrl: '' })
const aiCreatives = ref([
  {
    headlines: ['春季大促 全场5折起', '限时优惠 最高立减$200', '春季新品 热卖中', '精选好物 品质保障', '免费配送 30天无忧退换', '品牌直营 正品保证'],
    descriptions: ['精选全球优质好物，春季特惠最高5折，品牌授权正品保障，下单立享免费配送', '新用户注册立得$50优惠券，满额再减，限时活动错过再等一年'],
    keywords: ['春季促销', '限时优惠', '新品上市', '品牌折扣']
  },
  {
    headlines: ['品质生活 从这里开始', '用心做好每一件产品', '十年品牌 百万用户选择', '专业团队 贴心服务', '会员专享 额外9折', '每日更新 爆款推荐'],
    descriptions: ['专注品质十年，服务百万用户，从选品到售后全链路把控，让购物更放心', '加入会员享专属折扣、生日好礼、优先发货等多重权益，现在加入免费'],
    keywords: ['品质保证', '会员优惠', '品牌直营', '专业服务']
  },
  {
    headlines: ['爆款清单 低至3折', 'Top Rated 五星好评', '编辑精选 必买推荐', '用户挚爱 复购TOP10', '今日特价 每日更新', '尾货清仓 数量有限'],
    descriptions: ['精选平台销量TOP商品，真实用户五星好评验证，闭眼入不踩雷', '每日更新超值特价，库存有限先到先得，订阅提醒不错过任何折扣'],
    keywords: ['爆款推荐', '五星好评', '特价清仓', '编辑精选']
  }
])

const campaigns = [
  { value: '1', label: '春季促销_品牌词搜索' },
  { value: '2', label: 'PMax_全站推广_Q3' }
]
const adGroups = [
  { value: '101', label: 'AG_核心品牌词' },
  { value: '102', label: 'AG_长尾竞品词' }
]

const statusTag = (s) => ({
  active: { type: 'success', text: '投放中' },
  paused: { type: 'info', text: '已暂停' },
  removed: { type: 'danger', text: '已移除' }
}[s] || { type: 'info', text: s })

const approvalTag = (a) => ({
  approved: { type: 'success', text: '已通过' },
  under_review: { type: 'warning', text: '审核中' },
  disapproved: { type: 'danger', text: '未通过' }
}[a] || { type: 'info', text: a })

const openDrawer = () => {
  creativeForm.campaignId = ''
  creativeForm.adGroupId = ''
  creativeForm.headlines = [{ text: '', pinned: '' }]
  creativeForm.descriptions = [{ text: '' }]
  creativeForm.paths = { path1: '', path2: '' }
  creativeForm.finalUrl = ''
  creativeForm.trackingTemplate = ''
  drawerVisible.value = true
}

const addHeadline = () => {
  if (creativeForm.headlines.length < 15) creativeForm.headlines.push({ text: '', pinned: '' })
  else ElMessage.warning('RSA标题最多15条')
}
const removeHeadline = (i) => {
  if (creativeForm.headlines.length > 1) creativeForm.headlines.splice(i, 1)
}
const addDescription = () => {
  if (creativeForm.descriptions.length < 4) creativeForm.descriptions.push({ text: '' })
  else ElMessage.warning('RSA描述最多4条')
}
const removeDescription = (i) => {
  if (creativeForm.descriptions.length > 1) creativeForm.descriptions.splice(i, 1)
}

const handleAIGenerate = async () => {
  if (!aiForm.offerUrl) { ElMessage.warning('请粘贴Offer URL'); return }
  aiGenerating.value = true
  setTimeout(() => {
    aiGenerating.value = false
    ElMessage.success('已生成3组创意')
  }, 2500)
}

const applyCreative = (idx) => {
  const c = aiCreatives.value[idx]
  creativeForm.headlines = c.headlines.map(h => ({ text: h, pinned: '' }))
  creativeForm.descriptions = c.descriptions.map(d => ({ text: d }))
  ElMessage.success('已应用创意到表单')
  aiDialogVisible.value = false
}

const handleSubmit = () => {
  ElMessage.success('创建广告成功')
  drawerVisible.value = false
}

const handleApprove = async (row) => {
  try {
    await ElMessageBox.confirm(`提交广告【${row.name}】到Google Ads审核?`, '审核提交', { type: 'info' })
    ElMessage.success('已提交审核')
  } catch (_) {}
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除广告【${row.name}】?`, '删除确认', { type: 'warning' })
    ElMessage.success('删除成功')
  } catch (_) {}
}
</script>

<template>
  <div class="ads-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">广告管理</h2>
        <p class="page-subtitle">创建与管理搜索广告(RSA)等各类广告素材</p>
      </div>
    </div>

    <el-card shadow="never" class="toolbar-card">
      <div class="toolbar">
        <div class="toolbar-left">
          <el-button type="primary" class="el-button--gradient" @click="openDrawer">
            <el-icon><Plus /></el-icon>新建广告
          </el-button>
          <el-button type="success" plain><el-icon><Upload /></el-icon>批量提交审核</el-button>
        </div>
        <div class="toolbar-right">
          <el-input placeholder="搜索广告名称/URL..." :prefix-icon="Search" clearable style="width: 260px" />
          <el-select placeholder="类型" clearable style="width: 120px">
            <el-option label="RSA" value="RSA" />
          </el-select>
          <el-select placeholder="状态" clearable style="width: 120px">
            <el-option label="投放中" value="active" />
            <el-option label="已暂停" value="paused" />
          </el-select>
        </div>
      </div>
    </el-card>

    <el-card shadow="never">
      <el-table :data="adList" stripe v-loading="loading">
        <el-table-column prop="name" label="广告名称" min-width="180">
          <template #default="{ row }">
            <div style="font-weight: 500">{{ row.name }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="type" label="类型" width="80" align="center">
          <template #default="{ row }"><el-tag size="small" effect="plain">{{ row.type }}</el-tag></template>
        </el-table-column>
        <el-table-column label="标题/描述" width="120" align="center">
          <template #default="{ row }">
            <div style="font-size: 12px">
              <div>标题: <b>{{ row.headlineCount }}</b>/15</div>
              <div>描述: <b>{{ row.descCount }}</b>/4</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="finalUrl" label="最终URL" min-width="200" show-overflow-tooltip />
        <el-table-column prop="status" label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">
              {{ statusTag(row.status).text }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="approval" label="审核" width="90">
          <template #default="{ row }">
            <el-tag :type="approvalTag(row.approval).type" effect="light" size="small">
              {{ approvalTag(row.approval).text }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="花费" width="90" align="right">
          <template #default="{ row }">${{ row.cost.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="展示" width="90" align="right">
          <template #default="{ row }">{{ row.impressions.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="点击" width="80" align="right">
          <template #default="{ row }">{{ row.clicks.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" size="small">编辑</el-button>
            <el-button link type="success" size="small" @click="handleApprove(row)">提交审核</el-button>
            <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrap">
        <el-pagination background layout="total, sizes, prev, pager, next, jumper" :total="adList.length * 10" />
      </div>
    </el-card>

    <el-drawer v-model="drawerVisible" title="新建响应式搜索广告 (RSA)" size="70%">
      <el-form :model="creativeForm" label-width="120px">
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="选择广告系列">
              <el-select v-model="creativeForm.campaignId" style="width: 100%" placeholder="选择系列">
                <el-option v-for="c in campaigns" :key="c.value" :label="c.label" :value="c.value" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="选择广告组">
              <el-select v-model="creativeForm.adGroupId" style="width: 100%" placeholder="选择广告组">
                <el-option v-for="g in adGroups" :key="g.value" :label="g.label" :value="g.value" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="广告类型">
          <el-tag type="primary" effect="dark">RSA - 响应式搜索广告</el-tag>
        </el-form-item>

        <el-divider content-position="left">
          <span style="font-weight: 600">标题 (Headlines)</span>
          <span style="color: var(--adx-text-tertiary); font-weight: 400; margin-left: 8px">
            最少3条 / 最多15条 / 每条最多30字符
          </span>
          <el-button type="primary" size="small" plain style="margin-left: 12px" @click="aiDialogVisible = true">
            <el-icon><MagicStick /></el-icon>AI生成
          </el-button>
        </el-divider>

        <div v-for="(h, i) in creativeForm.headlines" :key="'h'+i" class="creative-item">
          <div class="item-index">{{ i + 1 }}</div>
          <el-input
            v-model="h.text"
            placeholder="输入标题文案，最多30字符..."
            maxlength="30"
            show-word-limit
            style="flex: 1"
          />
          <el-select v-model="h.pinned" placeholder="固定位置" style="width: 130px; margin-left: 8px">
            <el-option label="不固定" value="" />
            <el-option label="固定到位置1" value="1" />
            <el-option label="固定到位置2" value="2" />
            <el-option label="固定到位置3" value="3" />
          </el-select>
          <el-button
            v-if="creativeForm.headlines.length > 1"
            link
            type="danger"
            style="margin-left: 8px"
            @click="removeHeadline(i)"
          >
            <el-icon><Delete /></el-icon>
          </el-button>
        </div>
        <el-button type="dashed" style="width: 100%; margin-top: 8px" @click="addHeadline" :disabled="creativeForm.headlines.length >= 15">
          <el-icon><Plus /></el-icon>添加标题 ({{ creativeForm.headlines.length }}/15)
        </el-button>

        <el-divider content-position="left">
          <span style="font-weight: 600">描述 (Descriptions)</span>
          <span style="color: var(--adx-text-tertiary); font-weight: 400; margin-left: 8px">最少2条 / 最多4条 / 每条最多90字符</span>
        </el-divider>

        <div v-for="(d, i) in creativeForm.descriptions" :key="'d'+i" class="creative-item">
          <div class="item-index">{{ i + 1 }}</div>
          <el-input
            v-model="d.text"
            type="textarea"
            :autosize="{ minRows: 1, maxRows: 2 }"
            placeholder="输入描述文案，最多90字符..."
            maxlength="90"
            show-word-limit
            style="flex: 1"
          />
          <el-button
            v-if="creativeForm.descriptions.length > 1"
            link
            type="danger"
            style="margin-left: 8px"
            @click="removeDescription(i)"
          >
            <el-icon><Delete /></el-icon>
          </el-button>
        </div>
        <el-button type="dashed" style="width: 100%; margin-top: 8px" @click="addDescription" :disabled="creativeForm.descriptions.length >= 4">
          <el-icon><Plus /></el-icon>添加描述 ({{ creativeForm.descriptions.length }}/4)
        </el-button>

        <el-divider content-position="left">
          <span style="font-weight: 600">路径与链接</span>
        </el-divider>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="Path 1">
              <el-input v-model="creativeForm.paths.path1" maxlength="15" placeholder="显示路径1 (可选)" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="Path 2">
              <el-input v-model="creativeForm.paths.path2" maxlength="15" placeholder="显示路径2 (可选)" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="最终URL">
          <el-input v-model="creativeForm.finalUrl" placeholder="https://example.com/your-page" />
        </el-form-item>
        <el-form-item label="Tracking模板">
          <el-input v-model="creativeForm.trackingTemplate" placeholder="{lpurl}?utm_source=google&..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="drawerVisible = false">取消</el-button>
        <el-button type="success">保存草稿</el-button>
        <el-button type="primary" class="el-button--gradient" @click="handleSubmit">
          <el-icon><Upload /></el-icon>提交审核
        </el-button>
      </template>
    </el-drawer>

    <el-dialog v-model="aiDialogVisible" title="AI创意生成" width="620px" destroy-on-close>
      <el-form :model="aiForm" label-width="100px">
        <el-form-item label="Offer URL">
          <el-input v-model="aiForm.offerUrl" placeholder="粘贴Landing Page / Offer URL，AI自动爬取内容生成创意" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" class="el-button--gradient" @click="handleAIGenerate" :loading="aiGenerating">
            <el-icon><MagicStick /></el-icon>{{ aiGenerating ? 'AI生成中...' : '生成3组创意' }}
          </el-button>
        </el-form-item>
      </el-form>

      <el-tabs v-if="!aiGenerating && aiCreatives.value && aiCreatives.value.length" v-model="activeCreativeTab" type="border-card">
        <el-tab-pane v-for="(_, i) in aiCreatives" :key="i" :label="`创意方案 ${i + 1}`" :name="i">
          <div class="creative-preview">
            <div class="preview-section">
              <div class="preview-label"><el-icon><EditPen /></el-icon>标题 (Headlines)</div>
              <div v-for="(h, hi) in aiCreatives[activeCreativeTab].headlines" :key="hi" class="preview-chip">
                {{ h }}
              </div>
            </div>
            <div class="preview-section">
              <div class="preview-label"><el-icon><Document /></el-icon>描述 (Descriptions)</div>
              <div v-for="(d, di) in aiCreatives[activeCreativeTab].descriptions" :key="di" class="preview-desc">
                {{ d }}
              </div>
            </div>
            <div class="preview-section">
              <div class="preview-label"><el-icon><Key /></el-icon>推荐关键词</div>
              <div v-for="(k, ki) in aiCreatives[activeCreativeTab].keywords" :key="ki" class="preview-chip keyword">
                <el-tag size="small" type="warning" effect="plain">{{ k }}</el-tag>
              </div>
            </div>
          </div>
        </el-tab-pane>
      </el-tabs>

      <template v-if="aiGenerating" #default>
        <el-steps :active="2" finish-status="success" process-status="process" align-center>
          <el-step title="爬虫采集" />
          <el-step title="AI生成创意" />
          <el-step title="完成" />
        </el-steps>
        <el-progress :percentage="60" status="success" style="margin-top: 24px" :stroke-width="10" />
        <div style="text-align: center; margin-top: 12px; color: var(--adx-text-tertiary)">AI正在分析Offer页面内容，请稍候...</div>
      </template>

      <template #footer>
        <el-button @click="aiDialogVisible = false">关闭</el-button>
        <el-button type="primary" class="el-button--gradient" :disabled="aiGenerating" @click="applyCreative(activeCreativeTab)">
          <el-icon><Check /></el-icon>应用此方案到表单
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.ads-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}
.toolbar-right { display: flex; gap: 8px; flex-wrap: wrap; }
.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }

.creative-item {
  display: flex;
  align-items: flex-start;
  margin-bottom: 8px;
  padding: 8px 10px;
  background: var(--adx-bg-secondary);
  border-radius: 8px;
}
.item-index {
  width: 26px;
  height: 26px;
  border-radius: 50%;
  background: var(--adx-color-primary);
  color: #fff;
  font-size: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-right: 10px;
  flex-shrink: 0;
  margin-top: 6px;
}

.creative-preview {
  .preview-section { margin-bottom: 16px; }
  .preview-label {
    font-weight: 600;
    font-size: 13px;
    margin-bottom: 8px;
    color: var(--adx-text-secondary);
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }
  .preview-chip {
    display: inline-block;
    padding: 6px 12px;
    background: rgba(99, 102, 241, 0.08);
    color: var(--adx-color-primary);
    border-radius: 6px;
    font-size: 13px;
    margin: 0 6px 6px 0;
    font-weight: 500;
    &.keyword {
      background: transparent;
      padding: 0;
    }
  }
  .preview-desc {
    padding: 10px 12px;
    background: var(--adx-bg-secondary);
    border-radius: 8px;
    font-size: 13px;
    color: var(--adx-text-secondary);
    margin-bottom: 6px;
    line-height: 1.6;
  }
}
</style>
