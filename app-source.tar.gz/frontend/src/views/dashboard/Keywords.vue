<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const loading = ref(false)
const addDialogVisible = ref(false)
const aiDialogVisible = ref(false)
const aiGenerating = ref(false)
const selection = ref([])

const keywordList = ref([
  { id: 1, text: '春季大促 2026', matchType: 'exact', status: 'active', quality: 9, bid: 3.5, impressions: 18400, clicks: 1280, cost: 2450.3, adGroup: 'AG_核心品牌词' },
  { id: 2, text: '+春季 +促销 +优惠券', matchType: 'broad_modified', status: 'active', quality: 8, bid: 2.8, impressions: 28000, clicks: 1820, cost: 3820.5, adGroup: 'AG_核心品牌词' },
  { id: 3, text: '[品牌 春季 新品]', matchType: 'phrase', status: 'active', quality: 10, bid: 4.2, impressions: 8200, clicks: 720, cost: 1850.2, adGroup: 'AG_核心品牌词' },
  { id: 4, text: '春季连衣裙 新款', matchType: 'broad', status: 'paused', quality: 6, bid: 1.5, impressions: 12000, clicks: 380, cost: 420.8, adGroup: 'AG_通用品类词' },
  { id: 5, text: '-免费 -盗版 -破解', matchType: 'negative', status: 'active', quality: 0, bid: 0, impressions: 0, clicks: 0, cost: 0, adGroup: 'AG_长尾竞品词' },
  { id: 6, text: '竞品品牌词 替代', matchType: 'phrase', status: 'active', quality: 7, bid: 2.2, impressions: 9800, clicks: 540, cost: 920.4, adGroup: 'AG_长尾竞品词' }
])

const addForm = reactive({
  matchType: 'broad',
  keywordsText: ''
})

const aiForm = reactive({
  seedKeywords: '',
  generatedCount: 0
})

const aiGenerated = ref([])

const matchOptions = [
  { value: 'exact', label: '完全匹配', tagType: 'danger' },
  { value: 'phrase', label: '词组匹配', tagType: 'warning' },
  { value: 'broad_modified', label: '广泛匹配(修饰)', tagType: 'primary' },
  { value: 'broad', label: '广泛匹配', tagType: 'info' },
  { value: 'negative', label: '否定关键词', tagType: 'success' }
]

const matchLabel = (t) => matchOptions.find(o => o.value === t)?.label || t
const matchTagType = (t) => matchOptions.find(o => o.value === t)?.tagType || 'info'

const statusTag = (s) => ({
  active: { type: 'success', text: '启用' },
  paused: { type: 'info', text: '暂停' },
  removed: { type: 'danger', text: '移除' }
}[s] || { type: 'info', text: s })

const qualityColor = (q) => {
  if (q >= 8) return '#10B981'
  if (q >= 6) return '#F59E0B'
  if (q === 0) return '#9CA3AF'
  return '#EF4444'
}

const handleBatchAdd = () => {
  if (!addForm.keywordsText.trim()) { ElMessage.warning('请输入关键词'); return }
  ElMessage.success(`已添加 ${addForm.keywordsText.split('\n').filter(k => k.trim()).length} 个关键词`)
  addDialogVisible.value = false
}

const handleAIGenerate = async () => {
  if (!aiForm.seedKeywords) { ElMessage.warning('请输入种子关键词'); return }
  aiGenerating.value = true
  setTimeout(() => {
    const seeds = aiForm.seedKeywords.split(/[,，\s]+/).filter(s => s.trim())
    const suffixes = ['2026 新款', '优惠券 优惠码', '价格 评测', '对比 推荐', '正品 官网', '黑色星期五', '限时 折扣', '热卖 爆款', '品牌 直营', '包邮 退换']
    aiGenerated.value = []
    seeds.forEach(seed => {
      suffixes.forEach(suf => {
        if (aiGenerated.value.length < 30) aiGenerated.value.push(`${seed} ${suf}`)
      })
    })
    aiGenerating.value = false
    aiForm.generatedCount = aiGenerated.value.length
  }, 2000)
}

const applyAIGenerated = () => {
  ElMessage.success(`已选择并添加 ${aiGenerated.value.length} 个关键词到列表`)
  aiDialogVisible.value = false
}

const batchToggle = async (enable) => {
  if (selection.value.length === 0) { ElMessage.warning('请先选择关键词'); return }
  ElMessage.success(`已${enable ? '启用' : '暂停'} ${selection.value.length} 个关键词`)
}

const batchDelete = async () => {
  if (selection.value.length === 0) { ElMessage.warning('请先选择关键词'); return }
  try {
    await ElMessageBox.confirm(`确定批量删除选中的 ${selection.value.length} 个关键词?`, '批量删除', { type: 'warning' })
    ElMessage.success('删除成功')
  } catch (_) {}
}
</script>

<template>
  <div class="keywords-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">关键词管理</h2>
        <p class="page-subtitle">管理搜索广告关键词、匹配类型与出价</p>
      </div>
    </div>

    <el-card shadow="never" class="toolbar-card">
      <div class="toolbar">
        <div class="toolbar-left">
          <el-button type="primary" class="el-button--gradient" @click="addDialogVisible = true">
            <el-icon><Plus /></el-icon>批量添加
          </el-button>
          <el-button type="success" plain @click="aiDialogVisible = true">
            <el-icon><MagicStick /></el-icon>AI扩展关键词
          </el-button>
          <el-button type="success" plain @click="batchToggle(true)">批量启用</el-button>
          <el-button type="info" plain @click="batchToggle(false)">批量暂停</el-button>
          <el-button type="danger" plain @click="batchDelete">批量删除</el-button>
        </div>
        <div class="toolbar-right">
          <el-input placeholder="搜索关键词..." :prefix-icon="Search" clearable style="width: 240px" />
          <el-select placeholder="匹配类型" clearable style="width: 150px">
            <el-option v-for="o in matchOptions" :key="o.value" :label="o.label" :value="o.value" />
          </el-select>
          <el-select placeholder="状态" clearable style="width: 120px">
            <el-option label="启用" value="active" />
            <el-option label="暂停" value="paused" />
          </el-select>
        </div>
      </div>
    </el-card>

    <el-card shadow="never">
      <el-table :data="keywordList" stripe v-loading="loading" @selection-change="v => selection = v">
        <el-table-column type="selection" width="48" />
        <el-table-column prop="text" label="关键词" min-width="220">
          <template #default="{ row }">
            <span style="font-weight: 500; font-size: 14px">{{ row.text }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="matchType" label="匹配类型" width="130" align="center">
          <template #default="{ row }">
            <el-tag :type="matchTagType(row.matchType)" effect="light" size="small">
              {{ matchLabel(row.matchType) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">
              {{ statusTag(row.status).text }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="质量分" width="100" align="center">
          <template #default="{ row }">
            <span v-if="row.quality === 0" style="color: var(--adx-text-tertiary)">-</span>
            <span v-else :style="{ color: qualityColor(row.quality), fontWeight: 700, fontSize: '16px' }">
              {{ row.quality }}/10
            </span>
          </template>
        </el-table-column>
        <el-table-column label="出价($)" width="90" align="right">
          <template #default="{ row }">
            <span v-if="row.bid === 0">-</span>
            <span v-else>${{ row.bid.toFixed(2) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="展示" width="90" align="right">
          <template #default="{ row }">{{ row.impressions.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="点击" width="80" align="right">
          <template #default="{ row }">{{ row.clicks.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="花费" width="100" align="right">
          <template #default="{ row }">${{ row.cost.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column prop="adGroup" label="所属广告组" min-width="160" show-overflow-tooltip />
        <el-table-column label="操作" width="140" fixed="right">
          <template #default>
            <el-button link type="primary" size="small">编辑</el-button>
            <el-button link type="danger" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrap">
        <el-pagination background layout="total, sizes, prev, pager, next, jumper" :total="keywordList.length * 25" />
      </div>
    </el-card>

    <el-dialog v-model="addDialogVisible" title="批量添加关键词" width="560px" destroy-on-close>
      <el-form :model="addForm" label-width="100px">
        <el-form-item label="匹配类型">
          <el-select v-model="addForm.matchType" style="width: 100%">
            <el-option v-for="o in matchOptions.filter(o => o.value !== 'negative')" :key="o.value" :label="o.label" :value="o.value" />
          </el-select>
        </el-form-item>
        <el-form-item label="关键词列表">
          <el-input
            v-model="addForm.keywordsText"
            type="textarea"
            :rows="10"
            placeholder="每行一个关键词，例如：&#10;春季连衣裙&#10;2026新款女鞋&#10;夏季防晒衣&#10;..."
          />
          <div style="font-size: 12px; color: var(--adx-text-tertiary); margin-top: 6px">
            支持每行一个关键词，系统会自动按所选匹配类型添加对应符号
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="addDialogVisible = false">取消</el-button>
        <el-button type="primary" class="el-button--gradient" @click="handleBatchAdd">添加关键词</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="aiDialogVisible" title="AI智能扩展关键词" width="640px" destroy-on-close>
      <el-form :model="aiForm" label-width="120px">
        <el-form-item label="种子关键词">
          <el-input
            v-model="aiForm.seedKeywords"
            placeholder="输入1-3个种子词，逗号或空格分隔，例如：春季促销，夏季女装"
            type="textarea"
            :rows="2"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" class="el-button--gradient" @click="handleAIGenerate" :loading="aiGenerating">
            <el-icon><MagicStick /></el-icon>{{ aiGenerating ? 'AI生成中...' : '生成30+扩展关键词' }}
          </el-button>
        </el-form-item>
      </el-form>

      <div v-if="aiGenerating" class="ai-loading">
        <el-progress :percentage="72" :stroke-width="10" status="success" />
        <div style="margin-top: 12px; color: var(--adx-text-tertiary); text-align: center">
          正在基于种子词进行语义扩展、行业联想、相关词挖掘...
        </div>
      </div>

      <div v-else-if="aiGenerated.length" class="ai-result">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px">
          <div style="font-weight: 600">生成结果 <el-tag size="small" type="primary">{{ aiGenerated.length }} 个</el-tag></div>
          <el-checkbox model-value>全选</el-checkbox>
        </div>
        <div class="kw-cloud">
          <div v-for="(k, i) in aiGenerated" :key="i" class="kw-item">
            <el-checkbox :model-value="true" />
            <span>{{ k }}</span>
          </div>
        </div>
      </div>

      <template #footer>
        <el-button @click="aiDialogVisible = false">取消</el-button>
        <el-button type="primary" class="el-button--gradient" :disabled="!aiGenerated.length" @click="applyAIGenerated">
          <el-icon><Plus /></el-icon>添加选中到关键词列表
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.keywords-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}
.toolbar-left { display: flex; gap: 8px; flex-wrap: wrap; }
.toolbar-right { display: flex; gap: 8px; flex-wrap: wrap; }
.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }

.ai-loading { padding: 24px 12px; }
.kw-cloud {
  max-height: 340px;
  overflow: auto;
  padding: 12px;
  background: var(--adx-bg-secondary);
  border-radius: 8px;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.kw-item {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  background: #fff;
  border: 1px solid var(--adx-border-color);
  border-radius: 999px;
  font-size: 13px;
  transition: all 0.2s;
  &:hover {
    border-color: var(--adx-color-primary);
    background: rgba(99, 102, 241, 0.04);
  }
}
</style>
