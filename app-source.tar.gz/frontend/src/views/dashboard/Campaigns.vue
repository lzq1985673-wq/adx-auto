<script setup>
import { ref, onMounted, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/request'

const loading = ref(false)
const dialogVisible = ref(false)
const dialogMode = ref('create')

const filters = reactive({
  subAccount: '',
  status: '',
  dateRange: []
})

const subAccounts = [
  { value: 'all', label: '全部子账号' },
  { value: '871-234-5690', label: '品牌搜索-美国站' },
  { value: '871-234-5691', label: '购物广告-主Feed' },
  { value: '871-234-5692', label: 'PMax-全站推广' }
]

const form = reactive({
  id: null,
  name: '',
  budget: 0,
  bidStrategy: 'maximize_conversions',
  channel: 'search',
  startDate: '',
  endDate: '',
  clickBotEnabled: false,
  linkSwapEnabled: false
})

const channels = [
  { value: 'search', label: '搜索广告' },
  { value: 'shopping', label: '购物广告' },
  { value: 'pmax', label: 'Performance Max' },
  { value: 'display', label: '展示广告' },
  { value: 'video', label: '视频广告' },
  { value: 'discovery', label: '发现广告' }
]
const bidStrategies = [
  { value: 'maximize_conversions', label: '最大化转化' },
  { value: 'maximize_clicks', label: '最大化点击' },
  { value: 'target_cpa', label: '目标CPA' },
  { value: 'target_roas', label: '目标ROAS' },
  { value: 'manual_cpc', label: '手动CPC' },
  { value: 'ecpc', label: '增强CPC' }
]

const campaignList = ref([
  { id: 1, name: '春季促销_品牌词搜索', status: 'active', budget: 5000, cost: 2340.5, impressions: 125000, clicks: 8420, conversions: 328, ctr: 6.74, cpc: 0.28, clickBot: true, linkSwap: true, channel: 'search' },
  { id: 2, name: 'PMax_全站推广_Q3', status: 'active', budget: 8000, cost: 5120.8, impressions: 342000, clicks: 15200, conversions: 512, ctr: 4.44, cpc: 0.34, clickBot: true, linkSwap: false, channel: 'pmax' },
  { id: 3, name: '购物智能_MainFeed', status: 'active', budget: 3000, cost: 1820.1, impressions: 98000, clicks: 5420, conversions: 186, ctr: 5.53, cpc: 0.34, clickBot: false, linkSwap: true, channel: 'shopping' },
  { id: 4, name: 'GDN_再营销_弃购用户', status: 'paused', budget: 1500, cost: 980.5, impressions: 450000, clicks: 2180, conversions: 72, ctr: 0.48, cpc: 0.45, clickBot: false, linkSwap: false, channel: 'display' },
  { id: 5, name: 'YouTube_TrueView_新品', status: 'active', budget: 2500, cost: 1560.3, impressions: 580000, clicks: 920, conversions: 28, ctr: 0.16, cpc: 1.70, clickBot: false, linkSwap: false, channel: 'video' },
  { id: 6, name: 'Discovery_发现流_老客', status: 'removed', budget: 0, cost: 0, impressions: 0, clicks: 0, conversions: 0, ctr: 0, cpc: 0, clickBot: false, linkSwap: false, channel: 'discovery' }
])

const statusTag = (s) => ({
  active: { type: 'success', text: '投放中' },
  paused: { type: 'info', text: '已暂停' },
  removed: { type: 'danger', text: '已移除' },
  ended: { type: 'warning', text: '已结束' }
}[s] || { type: 'info', text: s })

const channelText = (c) => ({ search: '搜索', shopping: '购物', pmax: 'PMax', display: '展示', video: '视频', discovery: '发现' }[c] || c)

const openCreateDialog = () => {
  dialogMode.value = 'create'
  Object.keys(form).forEach(k => form[k] = k === 'id' ? null : (typeof form[k] === 'boolean' ? false : ''))
  form.budget = 0
  dialogVisible.value = true
}

const openEditDialog = (row) => {
  dialogMode.value = 'edit'
  Object.assign(form, row)
  dialogVisible.value = true
}

const handleSubmit = async () => {
  ElMessage.success(dialogMode.value === 'create' ? '创建成功' : '更新成功')
  dialogVisible.value = false
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除广告系列【${row.name}】?`, '删除确认', { type: 'warning' })
    ElMessage.success('删除成功')
  } catch (_) {}
}

const toggleStatus = async (row, enable) => {
  ElMessage.success(`已${enable ? '启动' : '暂停'}【${row.name}】`)
}

const toggleClickBot = (row, val) => {
  ElMessage.info(`${val ? '开启' : '关闭'}补点击: ${row.name}`)
}
const toggleLinkSwap = (row, val) => {
  ElMessage.info(`${val ? '开启' : '关闭'}换链: ${row.name}`)
}

onMounted(() => {
  // request.get('/ads/campaigns').then(res => campaignList.value = res.data)
})
</script>

<template>
  <div class="campaigns-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">广告系列管理</h2>
        <p class="page-subtitle">创建、编辑、监控广告系列表现</p>
      </div>
    </div>

    <el-card shadow="never" class="filter-card">
      <div class="filter-row">
        <div class="filter-left">
          <el-button type="primary" class="el-button--gradient" @click="openCreateDialog">
            <el-icon><Plus /></el-icon>新建广告系列
          </el-button>
        </div>
        <div class="filter-right">
          <el-select v-model="filters.subAccount" placeholder="子账号" style="width: 200px" clearable>
            <el-option v-for="a in subAccounts" :key="a.value" :label="a.label" :value="a.value" />
          </el-select>
          <el-select v-model="filters.status" placeholder="状态" style="width: 140px" clearable>
            <el-option label="投放中" value="active" />
            <el-option label="已暂停" value="paused" />
            <el-option label="已结束" value="ended" />
            <el-option label="已移除" value="removed" />
          </el-select>
          <el-date-picker
            v-model="filters.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="YYYY-MM-DD"
          />
          <el-input placeholder="搜索系列名称..." :prefix-icon="Search" clearable style="width: 220px" />
        </div>
      </div>
    </el-card>

    <el-card shadow="never">
      <el-table :data="campaignList" stripe v-loading="loading" sortable>
        <el-table-column type="selection" width="48" />
        <el-table-column prop="name" label="广告系列" min-width="220" sortable>
          <template #default="{ row }">
            <div class="campaign-cell">
              <el-tag size="small" effect="plain" type="primary" style="margin-right: 8px">{{ channelText(row.channel) }}</el-tag>
              <span>{{ row.name }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">
              {{ statusTag(row.status).text }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="预算/花费" width="150" align="right" sortable>
          <template #default="{ row }">
            <div class="money-cell">
              <div class="money-label">${{ row.budget.toLocaleString() }} / ${{ row.cost.toLocaleString() }}</div>
              <el-progress :percentage="Math.min(Math.round(row.cost / (row.budget || 1) * 100), 100)" :stroke-width="4" :show-text="false" />
            </div>
          </template>
        </el-table-column>
        <el-table-column label="展示" width="100" align="right" sortable>
          <template #default="{ row }">{{ row.impressions.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="点击" width="90" align="right" sortable>
          <template #default="{ row }">{{ row.clicks.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="转化" width="80" align="right" sortable>
          <template #default="{ row }">{{ row.conversions }}</template>
        </el-table-column>
        <el-table-column label="CTR" width="80" align="right" sortable>
          <template #default="{ row }">{{ row.ctr }}%</template>
        </el-table-column>
        <el-table-column label="CPC" width="80" align="right" sortable>
          <template #default="{ row }">${{ row.cpc.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="补点击" width="80" align="center">
          <template #default="{ row }">
            <el-switch v-model="row.clickBot" @change="toggleClickBot(row, $event)" size="small" />
          </template>
        </el-table-column>
        <el-table-column label="换链" width="70" align="center">
          <template #default="{ row }">
            <el-switch v-model="row.linkSwap" @change="toggleLinkSwap(row, $event)" size="small" />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="280" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="openEditDialog(row)">编辑</el-button>
            <el-button link v-if="row.status === 'active'" type="warning" size="small" @click="toggleStatus(row, false)">暂停</el-button>
            <el-button link v-else type="success" size="small" @click="toggleStatus(row, true)">启动</el-button>
            <el-button link type="info" size="small">广告组</el-button>
            <el-button link type="primary" size="small">补点击</el-button>
            <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrap">
        <el-pagination background layout="total, sizes, prev, pager, next, jumper" :total="campaignList.length * 12" />
      </div>
    </el-card>

    <el-dialog
      v-model="dialogVisible"
      :title="dialogMode === 'create' ? '新建广告系列' : '编辑广告系列'"
      width="680px"
      destroy-on-close
    >
      <el-form :model="form" label-width="110px">
        <el-form-item label="系列名称">
          <el-input v-model="form.name" placeholder="如：春季促销_品牌词搜索" />
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="每日预算">
              <el-input-number v-model="form.budget" :min="0" :precision="2" controls-position="right" style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="出价策略">
              <el-select v-model="form.bidStrategy" style="width: 100%">
                <el-option v-for="b in bidStrategies" :key="b.value" :label="b.label" :value="b.value" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="渠道">
              <el-select v-model="form.channel" style="width: 100%">
                <el-option v-for="c in channels" :key="c.value" :label="c.label" :value="c.value" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="开始日期">
              <el-date-picker v-model="form.startDate" type="date" value-format="YYYY-MM-DD" style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="结束日期">
              <el-date-picker v-model="form.endDate" type="date" value-format="YYYY-MM-DD" style="width: 100%" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-divider content-position="left">自动化配置</el-divider>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="补点击">
              <el-switch v-model="form.clickBotEnabled" />
              <span style="margin-left: 10px; color: var(--adx-text-tertiary); font-size: 12px">启用自动补点击</span>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="换链接">
              <el-switch v-model="form.linkSwapEnabled" />
              <span style="margin-left: 10px; color: var(--adx-text-tertiary); font-size: 12px">启用自动换链</span>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.campaigns-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.filter-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}
.filter-right { display: flex; gap: 8px; flex-wrap: wrap; }
.campaign-cell {
  display: inline-flex;
  align-items: center;
  font-weight: 500;
}
.money-cell {
  .money-label { font-size: 12px; font-weight: 500; margin-bottom: 4px; }
}
.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }
</style>
