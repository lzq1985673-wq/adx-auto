<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const activeTab = ref('tenant')

const tenantConfig = reactive({
  timezone: 'Asia/Shanghai',
  currency: 'USD',
  syncInterval: 30,
  defaultAIProvider: 'openai',
  defaultProxyProvider: 'oxylabs'
})

const securityConfig = reactive({
  fingerprintRotate: 24,
  ipTestCycle: 6,
  alertEmail: 'admin@example.com',
  alertWebhook: '',
  alertDingtalk: '',
  enableLoginNotify: true,
  enableCostAlert: true,
  costThreshold: 5000
})

const templateDialog = ref(false)
const templateMode = ref('create')
const templateForm = reactive({
  id: null,
  name: '',
  category: 'ad_creative',
  content: '',
  variables: []
})

const promptTemplates = ref([
  { id: 1, name: '默认RSA创意模板', category: 'ad_creative', content: `请分析Offer：{{offer_url}}
目标受众：{{target_audience}}
输出3组Google Ads RSA创意，每组包含：
1. Headlines (≤30字)
2. Descriptions (≤90字)
3. Keywords×5`, variables: ['offer_url', 'target_audience'], updated: '2026-08-01 10:18' },
  { id: 2, name: '关键词扩展模板', category: 'keyword_expand', content: `围绕以下种子词扩展关键词：{{seed_keywords}}
行业：{{industry}}
要求：
- 生成30+相关关键词
- 包含长尾词/疑问词/竞品词
- 标注推荐匹配类型`, variables: ['seed_keywords', 'industry'], updated: '2026-07-28 16:42' },
  { id: 3, name: 'LandingPage爬虫分析', category: 'crawler', content: `爬取页面：{{url}}
提取以下结构化信息：
1. 页面标题/描述/H1
2. 核心卖点(≤8条)
3. CTA号召
4. 价格/促销/折扣
5. 信任元素/评价数
6. 目标人群画像`, variables: ['url'], updated: '2026-07-20 12:00' },
  { id: 4, name: '邮件告警文案', category: 'notification', content: `【ADX告警】{{alert_level}}
类型：{{alert_type}}
时间：{{alert_time}}
详情：{{alert_detail}}
建议：{{suggestion}}
---
ADX-Auto 平台告警中心`, variables: ['alert_level', 'alert_type', 'alert_time', 'alert_detail', 'suggestion'], updated: '2026-07-15 09:30' }
])

const categoryOptions = [
  { value: 'ad_creative', label: '广告创意' },
  { value: 'keyword_expand', label: '关键词扩展' },
  { value: 'crawler', label: '爬虫分析' },
  { value: 'notification', label: '通知告警' },
  { value: 'budget', label: '预算决策' },
  { value: 'report', label: '数据分析' }
]
const timezoneOptions = [
  { value: 'UTC', label: 'UTC 世界标准时间' },
  { value: 'America/Los_Angeles', label: 'UTC-8 洛杉矶(PST)' },
  { value: 'America/New_York', label: 'UTC-5 纽约(EST)' },
  { value: 'Europe/London', label: 'UTC+0 伦敦' },
  { value: 'Europe/Berlin', label: 'UTC+1 柏林' },
  { value: 'Asia/Tokyo', label: 'UTC+9 东京' },
  { value: 'Asia/Shanghai', label: 'UTC+8 上海/北京' },
  { value: 'Asia/Singapore', label: 'UTC+8 新加坡' },
  { value: 'Australia/Sydney', label: 'UTC+10 悉尼' }
]
const currencyOptions = [
  { value: 'USD', label: 'USD 美元 ($)' },
  { value: 'CNY', label: 'CNY 人民币 (¥)' },
  { value: 'EUR', label: 'EUR 欧元 (€)' },
  { value: 'GBP', label: 'GBP 英镑 (£)' },
  { value: 'JPY', label: 'JPY 日元 (¥)' },
  { value: 'SGD', label: 'SGD 新加坡元 (S$)' },
  { value: 'AUD', label: 'AUD 澳元 (A$)' },
  { value: 'CAD', label: 'CAD 加元 (C$)' }
]

const varInput = ref('')
const addVar = () => {
  if (varInput.value.trim() && !templateForm.variables.includes(varInput.value.trim())) {
    templateForm.variables.push(varInput.value.trim())
    varInput.value = ''
  }
}
const removeVar = (v) => {
  const i = templateForm.variables.indexOf(v)
  if (i > -1) templateForm.variables.splice(i, 1)
}

const openCreateTpl = () => {
  templateMode.value = 'create'
  Object.assign(templateForm, { id: null, name: '', category: 'ad_creative', content: '', variables: [] })
  templateDialog.value = true
}
const openEditTpl = (row) => {
  templateMode.value = 'edit'
  Object.assign(templateForm, row)
  templateDialog.value = true
}
const submitTpl = () => {
  if (!templateForm.name.trim() || !templateForm.content.trim()) { ElMessage.warning('名称和内容必填'); return }
  ElMessage.success(templateMode.value === 'create' ? '模板已创建' : '模板已更新')
  templateDialog.value = false
}
const deleteTpl = async (row) => {
  try {
    await ElMessageBox.confirm(`删除模板【${row.name}】?`, '确认', { type: 'warning' })
    ElMessage.success('已删除')
  } catch (_) {}
}

const saveTenant = () => ElMessage.success('租户级配置已保存')
const saveSecurity = () => ElMessage.success('安全配置已保存')
const testEmailAlert = () => ElMessage.info('测试告警邮件已发送至：' + securityConfig.alertEmail)
</script>

<template>
  <div class="system-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">系统配置</h2>
        <p class="page-subtitle">全局参数、安全策略、提示词模板管理</p>
      </div>
    </div>

    <el-tabs v-model="activeTab" type="border-card">
      <el-tab-pane label="租户参数" name="tenant">
        <el-card shadow="never">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-primary)"><OfficeBuilding /></el-icon><span class="card-title">租户级全局参数</span></div>
          </template>
          <el-form :model="tenantConfig" label-width="160px" style="max-width: 640px">
            <el-form-item label="系统时区">
              <el-select v-model="tenantConfig.timezone" style="width: 100%">
                <el-option v-for="t in timezoneOptions" :key="t.value" :label="t.label" :value="t.value" />
              </el-select>
            </el-form-item>
            <el-form-item label="默认货币单位">
              <el-select v-model="tenantConfig.currency" style="width: 100%">
                <el-option v-for="c in currencyOptions" :key="c.value" :label="c.label" :value="c.value" />
              </el-select>
            </el-form-item>
            <el-form-item label="数据同步间隔(分钟)">
              <el-slider v-model="tenantConfig.syncInterval" :min="5" :max="360" :marks="{5:'5分', 30:'30分', 60:'1时', 180:'3时', 360:'6时'}" />
              <div style="font-size: 12px; color: var(--adx-text-tertiary); margin-top: 4px">
                每 <b style="color: var(--adx-color-primary)">{{ tenantConfig.syncInterval }}</b> 分钟从Google Ads拉取最新数据
              </div>
            </el-form-item>
            <el-form-item label="默认AI供应商">
              <el-select v-model="tenantConfig.defaultAIProvider" style="width: 100%">
                <el-option label="OpenAI (GPT系列)" value="openai" />
                <el-option label="Anthropic (Claude系列)" value="anthropic" />
                <el-option label="Google Gemini" value="google" />
                <el-option label="DeepSeek" value="deepseek" />
                <el-option label="通义千问" value="qwen" />
                <el-option label="Ollama 本地" value="ollama" />
              </el-select>
            </el-form-item>
            <el-form-item label="默认代理供应商">
              <el-select v-model="tenantConfig.defaultProxyProvider" style="width: 100%">
                <el-option label="Oxylabs" value="oxylabs" />
                <el-option label="BrightData" value="brightdata" />
                <el-option label="IPIDEA" value="ipidea" />
                <el-option label="SmartProxy" value="smartproxy" />
                <el-option label="GeoSurf" value="geosurf" />
                <el-option label="自定义" value="custom" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" class="el-button--gradient" @click="saveTenant">
                <el-icon><Check /></el-icon>保存租户配置
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="安全与告警" name="security">
        <el-card shadow="never">
          <template #header>
            <div class="card-title-wrap"><el-icon style="color: var(--adx-color-danger)"><Lock /></el-icon><span class="card-title">安全配置与告警通道</span></div>
          </template>
          <el-form :model="securityConfig" label-width="160px" style="max-width: 640px">
            <el-form-item label="指纹轮换周期(小时)">
              <el-input-number v-model="securityConfig.fingerprintRotate" :min="1" :max="720" controls-position="right" style="width: 220px" />
            </el-form-item>
            <el-form-item label="IP健康检测周期(小时)">
              <el-input-number v-model="securityConfig.ipTestCycle" :min="1" :max="72" controls-position="right" style="width: 220px" />
            </el-form-item>
            <el-divider />
            <el-form-item label="告警邮箱">
              <el-input v-model="securityConfig.alertEmail" placeholder="admin@example.com" />
            </el-form-item>
            <el-form-item label="告警Webhook URL">
              <el-input v-model="securityConfig.alertWebhook" placeholder="https://hooks.example.com/xxx" />
            </el-form-item>
            <el-form-item label="钉钉机器人Webhook">
              <el-input v-model="securityConfig.alertDingtalk" placeholder="https://oapi.dingtalk.com/robot/..." />
            </el-form-item>
            <el-form-item label="异常登录通知">
              <el-switch v-model="securityConfig.enableLoginNotify" />
              <span style="margin-left: 10px; color: var(--adx-text-tertiary); font-size: 12px">检测到异地登录时发送邮件</span>
            </el-form-item>
            <el-form-item label="花费阈值告警">
              <el-switch v-model="securityConfig.enableCostAlert" />
              <span style="margin-left: 10px; color: var(--adx-text-tertiary); font-size: 12px">当日花费超阈值自动提醒</span>
            </el-form-item>
            <el-form-item label="日花费阈值(USD)">
              <el-input-number v-model="securityConfig.costThreshold" :min="100" controls-position="right" style="width: 220px" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" class="el-button--gradient" @click="saveSecurity">
                <el-icon><Check /></el-icon>保存安全配置
              </el-button>
              <el-button plain style="margin-left: 10px" @click="testEmailAlert">
                <el-icon><Bell /></el-icon>发送测试告警
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="提示词模板" name="prompts">
        <div style="display: flex; justify-content: space-between; margin-bottom: 14px; align-items: center">
          <div class="card-title-wrap" style="margin: 0">
            <el-icon style="color: var(--adx-color-purple)"><EditPen /></el-icon>
            <span class="card-title">提示词模板管理</span>
            <span style="color: var(--adx-text-tertiary); margin-left: 8px; font-weight: 400; font-size: 12px">
              支持变量: {{变量名}}
            </span>
          </div>
          <el-button type="primary" class="el-button--gradient" @click="openCreateTpl">
            <el-icon><Plus /></el-icon>新建模板
          </el-button>
        </div>

        <el-table :data="promptTemplates" stripe>
          <el-table-column prop="name" label="模板名称" min-width="200">
            <template #default="{ row }">
              <div style="display: inline-flex; align-items: center; gap: 8px">
                <span style="font-weight: 600">{{ row.name }}</span>
                <el-tag size="small" effect="plain">
                  {{ categoryOptions.find(c => c.value === row.category)?.label || row.category }}
                </el-tag>
              </div>
            </template>
          </el-table-column>
          <el-table-column label="可用变量" min-width="280">
            <template #default="{ row }">
              <el-tag v-for="v in row.variables" :key="v" size="small" type="warning" effect="plain" style="margin: 2px 4px 2px 0">
                {{ '{' + v + '}' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="模板预览" min-width="300" show-overflow-tooltip>
            <template #default="{ row }">
              <div style="font-size: 12px; color: var(--adx-text-secondary); font-family: 'JetBrains Mono', monospace; white-space: pre-line; line-height: 1.5">
                {{ row.content.slice(0, 140) }}{{ row.content.length > 140 ? '...' : '' }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="updated" label="最近更新" width="160" />
          <el-table-column label="操作" width="180" fixed="right">
            <template #default="{ row }">
              <el-button link type="primary" size="small" @click="openEditTpl(row)">编辑</el-button>
              <el-button link type="primary" size="small">复制</el-button>
              <el-button link type="danger" size="small" @click="deleteTpl(row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>

    <el-dialog v-model="templateDialog" :title="templateMode === 'create' ? '新建提示词模板' : '编辑提示词模板'" width="720px" destroy-on-close>
      <el-form :model="templateForm" label-width="100px">
        <el-form-item label="模板名称" required>
          <el-input v-model="templateForm.name" placeholder="如：RSA创意默认模板" />
        </el-form-item>
        <el-form-item label="分类">
          <el-select v-model="templateForm.category" style="width: 100%">
            <el-option v-for="c in categoryOptions" :key="c.value" :label="c.label" :value="c.value" />
          </el-select>
        </el-form-item>
        <el-form-item label="模板内容" required>
          <div class="editor-wrap">
            <div class="editor-header">
              <span style="font-size: 12px; color: var(--adx-text-tertiary)">
                支持 <b style="color: var(--adx-color-warning)">{{变量名}}</b> 占位符
              </span>
            </div>
            <textarea
              v-model="templateForm.content"
              class="code-editor"
              rows="14"
              spellcheck="false"
              placeholder="在此输入提示词模板，使用 {{变量}} 引用变量..."
            ></textarea>
          </div>
        </el-form-item>
        <el-form-item label="变量列表">
          <div class="var-row">
            <el-input v-model="varInput" placeholder="输入变量名，如 offer_url，回车添加" size="small" style="width: 260px" @keyup.enter="addVar">
              <template #append>
                <el-button @click="addVar"><el-icon><Plus /></el-icon></el-button>
              </template>
            </el-input>
            <div class="var-tags">
              <el-tag
                v-for="v in templateForm.variables"
                :key="v"
                closable
                size="small"
                type="warning"
                effect="dark"
                @close="removeVar(v)"
                style="margin: 3px 4px"
              >
                {{ '{' + v + '}' }}
              </el-tag>
            </div>
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="templateDialog = false">取消</el-button>
        <el-button type="primary" @click="submitTpl">
          {{ templateMode === 'create' ? '创建模板' : '更新模板' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.system-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.card-title-wrap { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; font-size: 14px; }
.card-title { color: var(--adx-text-primary); }

.editor-wrap {
  border: 1px solid var(--adx-border-color);
  border-radius: 8px;
  overflow: hidden;
}
.editor-header {
  padding: 8px 12px;
  background: var(--adx-bg-tertiary);
  border-bottom: 1px solid var(--adx-border-color);
  display: flex; justify-content: space-between; align-items: center;
}
.code-editor {
  width: 100%;
  border: none;
  resize: vertical;
  padding: 14px;
  font-family: 'JetBrains Mono', 'Fira Code', 'Monaco', monospace;
  font-size: 13px;
  line-height: 1.65;
  background: #0B1020;
  color: #E5E7EB;
  outline: none;
  &::placeholder { color: #4B5563; }
}

.var-row {
  display: flex; flex-direction: column; gap: 8px;
}
.var-tags { display: inline-flex; flex-wrap: wrap; }
</style>
