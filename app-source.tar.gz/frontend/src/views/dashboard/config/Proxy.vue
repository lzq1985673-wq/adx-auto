<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const dialogVisible = ref(false)
const dialogMode = ref('create')
const testDialogVisible = ref(false)
const testing = ref(false)
const testResult = ref(null)

const vendorTemplates = [
  { id: 'oxylabs', name: 'Oxylabs', color: '#FF6B35', desc: '全球最大住宅代理池，质量顶级', website: 'oxylabs.io' },
  { id: 'brightdata', name: 'BrightData', color: '#00D4AA', desc: '原Luminati，住宅+机房+移动全覆盖', website: 'brightdata.com' },
  { id: 'ipidea', name: 'IPIDEA', color: '#13C2C2', desc: '国内优质代理服务，性价比高', website: 'ipidea.global' },
  { id: 'smartproxy', name: 'SmartProxy', color: '#5B21B6', desc: '住宅代理稳定，适合一般场景', website: 'smartproxy.com' },
  { id: 'geosurf', name: 'GeoSurf', color: '#DB2777', desc: '高质量住宅ISP，覆盖精准', website: 'geosurf.com' },
  { id: 'custom', name: '自定义', color: '#64748B', desc: '自行配置任意代理服务商', website: '-' }
]

const proxyList = ref([
  { id: 1, name: 'Oxylabs-住宅-全球', vendor: 'oxylabs', username: 'user-cc', password: '******', endpoint: 'pr.oxylabs.io', port: 7777, protocol: 'http', sessionType: 'sticky', priority: 100, active: true, countries: 48, totalIPs: '100M+', status: 'online' },
  { id: 2, name: 'BrightData-ISP-US', vendor: 'brightdata', username: 'usr-lum', password: '******', endpoint: 'zproxy.lum-superproxy.io', port: 22225, protocol: 'http', sessionType: 'sticky', priority: 90, active: true, countries: 1, totalIPs: '50K', status: 'online' },
  { id: 3, name: 'IPIDEA-亚太池', vendor: 'ipidea', username: 'ipidea_user', password: '******', endpoint: 'proxy.ipidea.io', port: 16816, protocol: 'socks5', sessionType: 'rotating', priority: 80, active: true, countries: 15, totalIPs: '8M', status: 'online' },
  { id: 4, name: 'SmartProxy-欧洲', vendor: 'smartproxy', username: 'sp_user', password: '******', endpoint: 'gate.smartproxy.com', port: 10000, protocol: 'http', sessionType: 'rotating', priority: 70, active: false, countries: 28, totalIPs: '5M', status: 'offline' },
  { id: 5, name: '自定义-Socks5-自搭', vendor: 'custom', username: 'myuser', password: '******', endpoint: 'self.proxy.local', port: 1080, protocol: 'socks5', sessionType: 'sticky', priority: 50, active: true, countries: 2, totalIPs: '100', status: 'warning' }
])

const form = reactive({
  id: null,
  name: '',
  vendor: 'oxylabs',
  username: '',
  password: '',
  endpoint: '',
  port: 0,
  protocol: 'http',
  sessionType: 'sticky',
  priority: 100,
  active: true,
  countryRules: [{ country: 'US', pool: 'residential' }]
})

const protocols = [
  { value: 'http', label: 'HTTP(S)' },
  { value: 'socks5', label: 'SOCKS5' },
  { value: 'socks4', label: 'SOCKS4' }
]
const sessionTypes = [
  { value: 'sticky', label: '会话保持(Sticky)' },
  { value: 'rotating', label: '轮换(Rotating)' }
]
const countries = ['US', 'UK', 'CA', 'AU', 'DE', 'FR', 'JP', 'SG', 'NL', 'IT', 'ES', 'BR', 'IN', 'MX', 'ALL']

const statusTag = (s) => ({
  online: { type: 'success', text: '在线' },
  offline: { type: 'danger', text: '离线' },
  warning: { type: 'warning', text: '告警' }
}[s] || { type: 'info', text: s })

const vendorMeta = (v) => vendorTemplates.find(t => t.id === v) || { name: v, color: '#666' }

const applyTemplate = (v) => {
  form.vendor = v.id
  if (v.id !== 'custom') {
    const tmpl = {
      oxylabs: { endpoint: 'pr.oxylabs.io', port: 7777, protocol: 'http' },
      brightdata: { endpoint: 'zproxy.lum-superproxy.io', port: 22225, protocol: 'http' },
      ipidea: { endpoint: 'proxy.ipidea.io', port: 16816, protocol: 'http' },
      smartproxy: { endpoint: 'gate.smartproxy.com', port: 10000, protocol: 'http' },
      geosurf: { endpoint: 'gw1.geosurf.io', port: 8000, protocol: 'http' }
    }[v.id] || {}
    Object.assign(form, tmpl)
  }
  ElMessage.success(`已应用 ${v.name} 模板`)
}

const openCreate = () => {
  dialogMode.value = 'create'
  Object.keys(form).forEach(k => {
    form[k] = k === 'id' ? null : k === 'priority' ? 100 : k === 'active' ? true : k === 'protocol' ? 'http' : k === 'sessionType' ? 'sticky' : k === 'port' ? 0 : k === 'countryRules' ? [{ country: 'US', pool: 'residential' }] : ''
  })
  form.vendor = 'oxylabs'
  dialogVisible.value = true
}
const openEdit = (row) => {
  dialogMode.value = 'edit'
  Object.assign(form, row)
  dialogVisible.value = true
}

const addCountryRule = () => form.countryRules.push({ country: 'US', pool: 'residential' })
const removeCountryRule = (i) => form.countryRules.splice(i, 1)

const handleSubmit = () => {
  ElMessage.success(dialogMode.value === 'create' ? '创建成功' : '更新成功')
  dialogVisible.value = false
}
const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除代理配置【${row.name}】?`, '删除确认', { type: 'warning' })
    ElMessage.success('删除成功')
  } catch (_) {}
}
const toggleActive = (row, val) => ElMessage.success(`已${val ? '启用' : '停用'}【${row.name}】`)

const runTest = async (row) => {
  testDialogVisible.value = true
  testing.value = true
  testResult.value = null
  setTimeout(() => {
    testing.value = false
    testResult.value = {
      endpoint: `${row.endpoint}:${row.port}`,
      latency: Math.floor(Math.random() * 200 + 50) + 'ms',
      exitIP: `${Math.floor(Math.random()*223)+1}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`,
      country: ['US', 'UK', 'DE', 'JP'][Math.floor(Math.random()*4)],
      anonymity: 'elite (高度匿名)',
      protocol: row.protocol.toUpperCase(),
      concurrency: Math.floor(Math.random() * 200 + 50) + '/s',
      status: Math.random() > 0.1 ? 'success' : 'fail'
    }
  }, 1800)
}
</script>

<template>
  <div class="proxy-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">代理配置</h2>
        <p class="page-subtitle">管理补点击/爬虫/同步等场景的代理供应商</p>
      </div>
      <el-button type="primary" class="el-button--gradient" @click="openCreate">
        <el-icon><Plus /></el-icon>新建代理配置
      </el-button>
    </div>

    <el-card shadow="never">
      <template #header>
        <div class="card-title-wrap"><el-icon style="color: var(--adx-color-primary)"><Collection /></el-icon><span class="card-title">供应商模板快速创建</span></div>
      </template>
      <div class="vendor-grid">
        <div v-for="v in vendorTemplates" :key="v.id" class="vendor-card" @click="applyTemplate(v); openCreate()">
          <div class="vendor-logo" :style="{ background: v.color + '18', color: v.color }">
            {{ v.name[0] }}
          </div>
          <div class="vendor-content">
            <div class="vendor-name">{{ v.name }}</div>
            <div class="vendor-desc">{{ v.desc }}</div>
            <div class="vendor-site">{{ v.website }}</div>
          </div>
          <el-button link type="primary" size="small"><el-icon><Right /></el-icon></el-button>
        </div>
      </div>
    </el-card>

    <el-card shadow="never" style="margin-top: 16px">
      <template #header>
        <div class="card-title-wrap"><el-icon style="color: var(--adx-color-success)"><Connection /></el-icon><span class="card-title">代理配置列表</span></div>
      </template>
      <el-table :data="proxyList" stripe>
        <el-table-column prop="name" label="名称" min-width="180">
          <template #default="{ row }">
            <div style="display: inline-flex; align-items: center; gap: 8px">
              <span class="vendor-mini" :style="{ background: vendorMeta(row.vendor).color + '20', color: vendorMeta(row.vendor).color }">
                {{ vendorMeta(row.vendor).name }}
              </span>
              <span style="font-weight: 600">{{ row.name }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="地址" min-width="200">
          <template #default="{ row }">
            <div style="font-family: 'JetBrains Mono', monospace; font-size: 12px">
              <el-tag size="small" effect="plain" style="margin-right: 6px">{{ row.protocol.toUpperCase() }}</el-tag>
              {{ row.endpoint }}:{{ row.port }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="认证" width="140">
          <template #default="{ row }">
            <div style="font-size: 12px; color: var(--adx-text-secondary)">
              {{ row.username }}<br/>
              <span style="color: var(--adx-text-tertiary)">密码: {{ row.password }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="会话" width="110" align="center">
          <template #default="{ row }">
            <el-tag size="small" effect="plain" :type="row.sessionType === 'sticky' ? 'primary' : 'warning'">
              {{ row.sessionType === 'sticky' ? '会话保持' : '轮换' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="countries" label="覆盖国" width="80" align="center">
          <template #default="{ row }"><b>{{ row.countries }}</b></template>
        </el-table-column>
        <el-table-column prop="totalIPs" label="IP规模" width="100" align="center" />
        <el-table-column label="优先级" width="90" align="center">
          <template #default="{ row }">
            <el-tag size="small" effect="dark" round :color="'#6366F1'">{{ row.priority }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">{{ statusTag(row.status).text }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="激活" width="70" align="center">
          <template #default="{ row }">
            <el-switch v-model="row.active" @change="toggleActive(row, $event)" size="small" />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <el-button link type="success" size="small" @click="runTest(row)">测试</el-button>
            <el-button link type="primary" size="small" @click="openEdit(row)">编辑</el-button>
            <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogMode === 'create' ? '新建代理配置' : '编辑代理配置'" width="680px" destroy-on-close>
      <el-form :model="form" label-width="110px">
        <el-row :gutter="16">
          <el-col :span="14">
            <el-form-item label="代理名称" required>
              <el-input v-model="form.name" placeholder="如：Oxylabs-住宅-全球池" />
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-form-item label="供应商">
              <el-select v-model="form.vendor" style="width: 100%">
                <el-option v-for="v in vendorTemplates" :key="v.id" :label="v.name" :value="v.id" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="端点(Host)">
              <el-input v-model="form.endpoint" placeholder="proxy.example.com" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="端口">
              <el-input-number v-model="form.port" :min="1" :max="65535" controls-position="right" style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="协议">
              <el-select v-model="form.protocol" style="width: 100%">
                <el-option v-for="p in protocols" :key="p.value" :label="p.label" :value="p.value" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="用户名">
              <el-input v-model="form.username" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="密码">
              <el-input v-model="form.password" type="password" show-password />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="会话类型">
              <el-select v-model="form.sessionType" style="width: 100%">
                <el-option v-for="s in sessionTypes" :key="s.value" :label="s.label" :value="s.value" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="优先级(越大越高)">
              <el-slider v-model="form.priority" :min="1" :max="1000" show-stops style="padding: 0 4px" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="是否激活">
          <el-switch v-model="form.active" />
        </el-form-item>
        <el-divider content-position="left">国家与Pool映射</el-divider>
        <div v-for="(r, i) in form.countryRules" :key="i" class="country-rule-row">
          <el-select v-model="r.country" placeholder="国家" style="width: 140px">
            <el-option v-for="c in countries" :key="c" :label="c" :value="c" />
          </el-select>
          <el-input v-model="r.pool" placeholder="Pool名称，如: residential / isp / mobile" style="width: 240px; margin-left: 8px" />
          <el-button v-if="form.countryRules.length > 1" link type="danger" style="margin-left: 8px" @click="removeCountryRule(i)">
            <el-icon><Delete /></el-icon>
          </el-button>
        </div>
        <el-button type="dashed" style="margin-top: 8px" @click="addCountryRule">
          <el-icon><Plus /></el-icon>添加国家规则
        </el-button>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="testDialogVisible" title="代理连通性测试" width="520px">
      <div v-if="testing" class="testing">
        <el-icon :size="40" class="is-loading spin-icon"><Loading /></el-icon>
        <div class="test-loading-text">正在测试代理连通性，请稍候...</div>
      </div>
      <div v-else-if="testResult" class="test-result" :class="testResult.status">
        <div class="test-status">
          <el-tag :type="testResult.status === 'success' ? 'success' : 'danger'" size="large" effect="dark" round>
            {{ testResult.status === 'success' ? '✓ 测试通过' : '✗ 测试失败' }}
          </el-tag>
        </div>
        <el-descriptions :column="1" border size="small" style="margin-top: 16px">
          <el-descriptions-item label="代理端点">{{ testResult.endpoint }}</el-descriptions-item>
          <el-descriptions-item label="协议版本">{{ testResult.protocol }}</el-descriptions-item>
          <el-descriptions-item label="响应延迟">{{ testResult.latency }}</el-descriptions-item>
          <el-descriptions-item label="并发能力">{{ testResult.concurrency }}</el-descriptions-item>
          <el-descriptions-item label="出口IP">{{ testResult.exitIP }}</el-descriptions-item>
          <el-descriptions-item label="识别国家">{{ testResult.country }}</el-descriptions-item>
          <el-descriptions-item label="匿名级别">{{ testResult.anonymity }}</el-descriptions-item>
        </el-descriptions>
      </div>
      <template #footer>
        <el-button @click="testDialogVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.proxy-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  display: flex; align-items: center; justify-content: space-between;
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.card-title-wrap { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; font-size: 14px; }
.card-title { color: var(--adx-text-primary); }

.vendor-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;
  @media (max-width: 992px) { grid-template-columns: repeat(2, 1fr); }
  @media (max-width: 640px) { grid-template-columns: 1fr; }
}
.vendor-card {
  display: flex; align-items: center; gap: 14px;
  padding: 14px 16px;
  border: 1px solid var(--adx-border-color);
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
  &:hover {
    border-color: var(--adx-color-primary);
    background: rgba(99, 102, 241, 0.04);
    transform: translateY(-2px);
    box-shadow: var(--adx-shadow-md);
  }
}
.vendor-logo {
  width: 46px; height: 46px;
  border-radius: 10px;
  display: inline-flex; align-items: center; justify-content: center;
  font-weight: 800; font-size: 20px;
  flex-shrink: 0;
}
.vendor-content { flex: 1; min-width: 0;
  .vendor-name { font-weight: 700; color: var(--adx-text-primary); margin-bottom: 2px; }
  .vendor-desc { font-size: 12px; color: var(--adx-text-secondary); line-height: 1.4; margin-bottom: 2px; }
  .vendor-site { font-size: 11px; color: var(--adx-text-tertiary); font-family: monospace; }
}
.vendor-mini {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 700;
}

.country-rule-row {
  display: flex; align-items: center; margin-bottom: 8px;
}

.testing { padding: 30px 16px; text-align: center; }
.spin-icon { animation: spin 1s linear infinite; color: var(--adx-color-primary); }
@keyframes spin { to { transform: rotate(360deg); } }
.test-loading-text { margin-top: 14px; color: var(--adx-text-secondary); }
.test-status { text-align: center; }
</style>
