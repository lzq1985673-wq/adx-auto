<script setup>
import { ref, reactive, computed } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const dialogVisible = ref(false)
const dialogMode = ref('create')

const providers = [
  { id: 'openai', name: 'OpenAI', color: '#10A37F', desc: 'GPT系列模型全球最强' },
  { id: 'anthropic', name: 'Anthropic', color: '#D97757', desc: 'Claude系列长文本首选' },
  { id: 'google', name: 'Google Gemini', color: '#4285F4', desc: '多模态能力出色' },
  { id: 'deepseek', name: 'DeepSeek', color: '#5E6AD2', desc: '国产高性价比大模型' },
  { id: 'qwen', name: '通义千问', color: '#6C4CFF', desc: '阿里达摩院出品' },
  { id: 'doubao', name: '字节豆包', color: '#00C896', desc: '字节跳动大模型' },
  { id: 'ollama', name: 'Ollama 本地', color: '#000000', desc: '本地私有化部署模型' }
]

const providerModelsMap = {
  openai: [
    { id: 'gpt-4o', name: 'GPT-4o', context: '128K', type: '旗舰多模态', costIn: 5, costOut: 15 },
    { id: 'gpt-4o-mini', name: 'GPT-4o Mini', context: '128K', type: '轻量快速', costIn: 0.15, costOut: 0.6 },
    { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', context: '128K', type: '稳定旗舰', costIn: 10, costOut: 30 },
    { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', context: '16K', type: '经济入门', costIn: 0.5, costOut: 1.5 }
  ],
  anthropic: [
    { id: 'claude-3-5-sonnet', name: 'Claude 3.5 Sonnet', context: '200K', type: '旗舰平衡', costIn: 3, costOut: 15 },
    { id: 'claude-3-opus', name: 'Claude 3 Opus', context: '200K', type: '最强推理', costIn: 15, costOut: 75 },
    { id: 'claude-3-haiku', name: 'Claude 3 Haiku', context: '200K', type: '极速轻量', costIn: 0.25, costOut: 1.25 }
  ],
  google: [
    { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro', context: '1M+', type: '超长上下文', costIn: 3.5, costOut: 10.5 },
    { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash', context: '1M+', type: '极速推理', costIn: 0.075, costOut: 0.3 },
    { id: 'gemini-1.0-pro', name: 'Gemini 1.0 Pro', context: '32K', type: '稳定版', costIn: 0.5, costOut: 1.5 }
  ],
  deepseek: [
    { id: 'deepseek-chat', name: 'DeepSeek-V2 Chat', context: '128K', type: '通用聊天', costIn: 0.14, costOut: 0.28 },
    { id: 'deepseek-coder', name: 'DeepSeek-Coder V2', context: '128K', type: '代码专用', costIn: 0.14, costOut: 0.28 }
  ],
  qwen: [
    { id: 'qwen2-72b', name: 'Qwen2-72B', context: '128K', type: '旗舰', costIn: 0.8, costOut: 2 },
    { id: 'qwen2-7b', name: 'Qwen2-7B', context: '128K', type: '轻量', costIn: 0.1, costOut: 0.2 },
    { id: 'qwen-plus', name: 'Qwen-Plus', context: '128K', type: '增强版', costIn: 0.4, costOut: 1.2 }
  ],
  doubao: [
    { id: 'doubao-pro-32k', name: 'Doubao-Pro-32K', context: '32K', type: '专业版', costIn: 0.5, costOut: 1 },
    { id: 'doubao-lite-8k', name: 'Doubao-Lite-8K', context: '8K', type: '轻便版', costIn: 0.08, costOut: 0.1 }
  ],
  ollama: [
    { id: 'llama3:70b', name: 'Llama3-70B', context: '8K', type: '开源旗舰', costIn: 0, costOut: 0 },
    { id: 'qwen2:72b', name: 'Qwen2-72B', context: '128K', type: '国产开源', costIn: 0, costOut: 0 },
    { id: 'mistral:8x22b', name: 'Mistral-8x22B', context: '64K', type: 'MoE开源', costIn: 0, costOut: 0 }
  ]
}

const aiList = ref([])

const form = reactive({
  id: null,
  name: '',
  provider: 'openai',
  model: 'gpt-4o',
  apiKey: '',
  baseUrl: '',
  maxTokens: 4096,
  temperature: 0.7,
  freeQuota: false,
  priority: 100,
  active: true
})

const availableModels = computed(() => providerModelsMap[form.provider] || [])
const providerMeta = (p) => providers.find(x => x.id === p) || { name: p, color: '#666' }

const statusTag = (s) => ({
  online: { type: 'success', text: '在线' },
  offline: { type: 'danger', text: '离线' },
  error: { type: 'warning', text: '异常' }
}[s] || { type: 'info', text: s })

const openCreate = () => {
  dialogMode.value = 'create'
  Object.keys(form).forEach(k => {
    form[k] = k === 'id' ? null : k === 'provider' ? 'openai' : k === 'model' ? 'gpt-4o' : k === 'maxTokens' ? 4096 : k === 'temperature' ? 0.7 : k === 'priority' ? 100 : k === 'active' ? true : k === 'freeQuota' ? false : ''
  })
  dialogVisible.value = true
}
const openEdit = (row) => {
  dialogMode.value = 'edit'
  Object.assign(form, row)
  dialogVisible.value = true
}
const handleSubmit = () => { ElMessage.success(dialogMode.value === 'create' ? '创建成功' : '更新成功'); dialogVisible.value = false }
const handleDelete = async (row) => { try { await ElMessageBox.confirm(`删除AI配置【${row.name}】?`, '确认', { type: 'warning' }); ElMessage.success('删除成功') } catch (_) {} }
const toggleActive = (row, v) => ElMessage.success(`已${v ? '启用' : '停用'}【${row.name}】`)
</script>

<template>
  <div class="ai-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">AI配置</h2>
        <p class="page-subtitle">管理AI供应商API Key、模型选择与优先级</p>
      </div>
      <el-button type="primary" class="el-button--gradient" @click="openCreate">
        <el-icon><Plus /></el-icon>新建AI配置
      </el-button>
    </div>

    <el-card shadow="never">
      <template #header>
        <div class="card-title-wrap"><el-icon style="color: var(--adx-color-purple)"><Cpu /></el-icon><span class="card-title">供应商模型总览</span></div>
      </template>
      <div class="provider-overview">
        <div v-for="p in providers" :key="p.id" class="prov-card">
          <div class="prov-head">
            <div class="prov-logo" :style="{ background: p.color + '18', color: p.color }">{{ p.name[0] }}</div>
            <div class="prov-text">
              <div class="prov-name">{{ p.name }}</div>
              <div class="prov-desc">{{ p.desc }}</div>
            </div>
          </div>
          <div class="prov-models">
            <el-tag v-for="m in providerModelsMap[p.id]" :key="m.id" size="small" effect="plain" style="margin: 3px 4px 3px 0">
              {{ m.name }}
              <span style="opacity: 0.5; margin-left: 4px">{{ m.context }}</span>
            </el-tag>
          </div>
        </div>
      </div>
    </el-card>

    <el-card shadow="never" style="margin-top: 16px">
      <template #header>
        <div class="card-title-wrap"><el-icon style="color: var(--adx-color-primary)"><Key /></el-icon><span class="card-title">AI配置列表</span></div>
      </template>
      <el-table :data="aiList" stripe>
        <el-table-column prop="name" label="名称" min-width="160">
          <template #default="{ row }">
            <div style="display: inline-flex; align-items: center; gap: 8px">
              <span class="prov-badge" :style="{ background: providerMeta(row.provider).color + '20', color: providerMeta(row.provider).color }">
                {{ providerMeta(row.provider).name }}
              </span>
              <b>{{ row.name }}</b>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="model" label="模型" width="200" />
        <el-table-column label="Base URL" min-width="240" show-overflow-tooltip>
          <template #default="{ row }">
            <span style="font-family: monospace; font-size: 12px">{{ row.baseUrl }}</span>
          </template>
        </el-table-column>
        <el-table-column label="参数" width="150" align="center">
          <template #default="{ row }">
            <div style="font-size: 12px; color: var(--adx-text-secondary)">
              <el-tag size="small" effect="plain" style="margin-right: 4px">{{ row.maxTokens }} tok</el-tag>
              <el-tag size="small" effect="plain">T={{ row.temperature }}</el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">{{ statusTag(row.status).text }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="额度" width="90" align="center">
          <template #default="{ row }">
            <el-tag v-if="row.freeQuota" type="success" effect="dark" size="small" round>免费</el-tag>
            <el-tag v-else type="warning" effect="plain" size="small" round>付费</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="优先级" width="90" align="center">
          <template #default="{ row }"><el-tag size="small" effect="dark" round style="background: #6366F1">{{ row.priority }}</el-tag></template>
        </el-table-column>
        <el-table-column label="累计Token" width="110" align="right">
          <template #default="{ row }">{{ (row.tokensUsed / 1000).toFixed(1) }}K</template>
        </el-table-column>
        <el-table-column label="累计成本($)" width="110" align="right">
          <template #default="{ row }"><b :style="{ color: row.costUsed > 0 ? '#EF4444' : 'var(--adx-text-secondary)' }">${{ row.costUsed.toFixed(2) }}</b></template>
        </el-table-column>
        <el-table-column label="激活" width="70" align="center">
          <template #default="{ row }"><el-switch v-model="row.active" size="small" @change="toggleActive(row, $event)" /></template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="openEdit(row)">编辑</el-button>
            <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogMode === 'create' ? '新建AI配置' : '编辑AI配置'" width="600px" destroy-on-close>
      <el-form :model="form" label-width="110px">
        <el-form-item label="配置名称" required>
          <el-input v-model="form.name" placeholder="如：主力-GPT4o" />
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="供应商" required>
              <el-select v-model="form.provider" style="width: 100%">
                <el-option v-for="p in providers" :key="p.id" :label="p.name" :value="p.id" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="模型" required>
              <el-select v-model="form.model" style="width: 100%">
                <el-option v-for="m in availableModels" :key="m.id" :label="`${m.name} (${m.context})`" :value="m.id" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="API Key" required>
          <el-input v-model="form.apiKey" type="password" show-password placeholder="sk-..." />
        </el-form-item>
        <el-form-item label="Base URL">
          <el-input v-model="form.baseUrl" placeholder="https://api.example.com/v1" />
        </el-form-item>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="最大Token">
              <el-input-number v-model="form.maxTokens" :min="1" :max="200000" :step="256" controls-position="right" style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="温度(Temperature)">
              <el-slider v-model="form.temperature" :min="0" :max="2" :step="0.1" show-input style="padding: 0 4px" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="是否免费额度">
              <el-switch v-model="form.freeQuota" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="优先级(越大优先)">
              <el-input-number v-model="form.priority" :min="1" :max="1000" controls-position="right" style="width: 100%" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="是否激活">
          <el-switch v-model="form.active" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.ai-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  display: flex; align-items: center; justify-content: space-between;
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.card-title-wrap { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; font-size: 14px; }
.card-title { color: var(--adx-text-primary); }

.provider-overview { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px;
  @media (max-width: 1200px) { grid-template-columns: repeat(3, 1fr); }
  @media (max-width: 900px) { grid-template-columns: repeat(2, 1fr); }
  @media (max-width: 600px) { grid-template-columns: 1fr; }
}
.prov-card {
  padding: 14px;
  border: 1px solid var(--adx-border-color);
  border-radius: 12px;
  transition: all 0.2s;
  &:hover {
    border-color: var(--adx-color-primary);
    box-shadow: var(--adx-shadow-sm);
  }
}
.prov-head { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.prov-logo {
  width: 40px; height: 40px;
  border-radius: 10px;
  display: inline-flex; align-items: center; justify-content: center;
  font-weight: 800;
  flex-shrink: 0;
}
.prov-text {
  .prov-name { font-weight: 700; color: var(--adx-text-primary); }
  .prov-desc { font-size: 11px; color: var(--adx-text-tertiary); margin-top: 2px; }
}
.prov-models { display: flex; flex-wrap: wrap; }

.prov-badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 700;
}
</style>
