<script setup>
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const loading = ref(false)
const dialogVisible = ref(false)
const dialogMode = ref('create')

const filterCampaign = ref('')
const campaigns = [
  { value: '1', label: '春季促销_品牌词搜索' },
  { value: '2', label: 'PMax_全站推广_Q3' },
  { value: '3', label: '购物智能_MainFeed' }
]

const adGroupList = ref([
  { id: 101, name: 'AG_核心品牌词', campaign: '春季促销_品牌词搜索', status: 'active', bid: 2.5, cost: 840.5, impressions: 42000, clicks: 2830, conversions: 128 },
  { id: 102, name: 'AG_长尾竞品词', campaign: '春季促销_品牌词搜索', status: 'active', bid: 1.8, cost: 620.2, impressions: 28000, clicks: 1920, conversions: 72 },
  { id: 103, name: 'AG_通用品类词', campaign: '春季促销_品牌词搜索', status: 'paused', bid: 3.0, cost: 320.0, impressions: 15000, clicks: 820, conversions: 28 },
  { id: 104, name: 'AG_Shopping_HighPrice', campaign: '购物智能_MainFeed', status: 'active', bid: 0.8, cost: 1250.3, impressions: 68000, clicks: 3920, conversions: 142 },
  { id: 105, name: 'AG_Shopping_SaleItems', campaign: '购物智能_MainFeed', status: 'active', bid: 1.2, cost: 570.8, impressions: 30000, clicks: 1500, conversions: 44 }
])

const form = reactive({
  id: null,
  campaignId: '',
  name: '',
  status: 'active',
  bid: 1.0
})

const statusTag = (s) => ({
  active: { type: 'success', text: '投放中' },
  paused: { type: 'info', text: '已暂停' },
  removed: { type: 'danger', text: '已移除' }
}[s] || { type: 'info', text: s })

const openCreateDialog = () => {
  dialogMode.value = 'create'
  Object.keys(form).forEach(k => form[k] = k === 'id' ? null : k === 'bid' ? 1.0 : k === 'status' ? 'active' : '')
  dialogVisible.value = true
}

const openEditDialog = (row) => {
  dialogMode.value = 'edit'
  Object.assign(form, row)
  dialogVisible.value = true
}

const handleSubmit = () => {
  ElMessage.success(dialogMode.value === 'create' ? '创建成功' : '更新成功')
  dialogVisible.value = false
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除广告组【${row.name}】?`, '删除确认', { type: 'warning' })
    ElMessage.success('删除成功')
  } catch (_) {}
}

const toggleStatus = (row, val) => {
  row.status = val ? 'active' : 'paused'
  ElMessage.success(`${val ? '启动' : '暂停'}成功`)
}
</script>

<template>
  <div class="adgroups-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">广告组管理</h2>
        <p class="page-subtitle">管理广告系列下的广告组</p>
      </div>
    </div>

    <el-card shadow="never" class="toolbar-card">
      <div class="toolbar">
        <div class="toolbar-left">
          <el-button type="primary" class="el-button--gradient" @click="openCreateDialog">
            <el-icon><Plus /></el-icon>新建广告组
          </el-button>
        </div>
        <div class="toolbar-right">
          <el-select v-model="filterCampaign" placeholder="选择广告系列" clearable style="width: 280px">
            <el-option v-for="c in campaigns" :key="c.value" :label="c.label" :value="c.value" />
          </el-select>
          <el-select placeholder="状态" clearable style="width: 140px">
            <el-option label="投放中" value="active" />
            <el-option label="已暂停" value="paused" />
          </el-select>
          <el-input placeholder="搜索广告组..." :prefix-icon="Search" clearable style="width: 220px" />
        </div>
      </div>
    </el-card>

    <el-card shadow="never">
      <el-table :data="adGroupList" stripe v-loading="loading">
        <el-table-column prop="name" label="广告组" min-width="200">
          <template #default="{ row }">
            <div style="font-weight: 500">{{ row.name }}</div>
            <div style="font-size: 12px; color: var(--adx-text-tertiary); margin-top: 2px">{{ row.campaign }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">
              {{ statusTag(row.status).text }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="出价($)" width="100" align="right">
          <template #default="{ row }">${{ row.bid.toFixed(2) }}</template>
        </el-table-column>
        <el-table-column label="花费" width="110" align="right" sortable>
          <template #default="{ row }">${{ row.cost.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="展示" width="100" align="right" sortable>
          <template #default="{ row }">{{ row.impressions.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="点击" width="90" align="right" sortable>
          <template #default="{ row }">{{ row.clicks.toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="转化" width="80" align="right" sortable>
          <template #default="{ row }">{{ row.conversions }}</template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="openEditDialog(row)">编辑</el-button>
            <el-button link v-if="row.status === 'active'" type="warning" size="small" @click="toggleStatus(row, false)">暂停</el-button>
            <el-button link v-else type="success" size="small" @click="toggleStatus(row, true)">启动</el-button>
            <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrap">
        <el-pagination background layout="total, sizes, prev, pager, next, jumper" :total="adGroupList.length * 8" />
      </div>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogMode === 'create' ? '新建广告组' : '编辑广告组'" width="520px">
      <el-form :model="form" label-width="100px">
        <el-form-item label="所属系列">
          <el-select v-model="form.campaignId" style="width: 100%">
            <el-option v-for="c in campaigns" :key="c.value" :label="c.label" :value="c.value" />
          </el-select>
        </el-form-item>
        <el-form-item label="广告组名称">
          <el-input v-model="form.name" placeholder="如：AG_核心品牌词" />
        </el-form-item>
        <el-form-item label="默认出价">
          <el-input-number v-model="form.bid" :min="0.01" :precision="2" :step="0.1" controls-position="right" style="width: 100%" />
        </el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="form.status" active-value="active" inactive-value="paused" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.adgroups-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}
.toolbar-right { display: flex; gap: 8px; flex-wrap: wrap; }
.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }
</style>
