<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'

const drawerVisible = ref(false)
const selectedTask = ref(null)
const generating = ref(false)
const genProgress = ref(0)
const genStep = ref(0)

const form = reactive({
  offerUrl: '',
  targetLang: 'en',
  targetCountry: 'US',
  industry: 'ecommerce',
  aiProvider: 'openai',
  aiModel: 'gpt-4o',
  templateId: 'default',
  templateContent: `请分析以下Offer页面：
URL: {{offer_url}}
目标语言: {{target_lang}}
目标国家: {{target_country}}
行业: {{industry}}

请输出3组Google Ads RSA广告创意，每组包含：
1. 3-5条Headlines（≤30字符）
2. 2条Descriptions（≤90字符）
3. 5个相关关键词`
})

const templates = [
  { value: 'default', label: '默认模板 - 通用RSA创意' },
  { value: 'ecommerce', label: '电商促销模板 - 突出折扣与紧迫感' },
  { value: 'saas', label: 'SaaS模板 - 突出功能与免费试用' },
  { value: 'b2b', label: 'B2B模板 - 突出ROI与客户案例' },
  { value: 'brand', label: '品牌词模板 - 突出品牌与信任' }
]

const languages = [
  { value: 'en', label: 'English 英语' },
  { value: 'zh', label: '中文简体' },
  { value: 'ja', label: '日本語' },
  { value: 'de', label: 'Deutsch 德语' },
  { value: 'fr', label: 'Français 法语' },
  { value: 'es', label: 'Español 西班牙语' }
]
const countries = [
  { value: 'US', label: '🇺🇸 美国' },
  { value: 'UK', label: '🇬🇧 英国' },
  { value: 'CA', label: '🇨🇦 加拿大' },
  { value: 'AU', label: '🇦🇺 澳大利亚' },
  { value: 'DE', label: '🇩🇪 德国' },
  { value: 'FR', label: '🇫🇷 法国' },
  { value: 'JP', label: '🇯🇵 日本' },
  { value: 'SG', label: '🇸🇬 新加坡' }
]
const industries = [
  { value: 'ecommerce', label: '电商零售' },
  { value: 'saas', label: 'SaaS/软件服务' },
  { value: 'b2b', label: 'B2B/企业服务' },
  { value: 'finance', label: '金融/加密' },
  { value: 'health', label: '健康/美容' },
  { value: 'gaming', label: '游戏/娱乐' },
  { value: 'education', label: '教育/在线课程' },
  { value: 'travel', label: '旅游/酒店' }
]
const aiProviders = [
  { value: 'openai', label: 'OpenAI' },
  { value: 'anthropic', label: 'Anthropic Claude' },
  { value: 'google', label: 'Google Gemini' },
  { value: 'deepseek', label: 'DeepSeek' },
  { value: 'qwen', label: '阿里通义千问' },
  { value: 'doubao', label: '字节豆包' },
  { value: 'ollama', label: 'Ollama 本地模型' }
]
const providerModels = {
  openai: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo'],
  anthropic: ['claude-3-5-sonnet', 'claude-3-opus', 'claude-3-haiku'],
  google: ['gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-1.0-pro'],
  deepseek: ['deepseek-chat', 'deepseek-coder'],
  qwen: ['qwen2-72b', 'qwen2-7b', 'qwen-plus'],
  doubao: ['doubao-pro-32k', 'doubao-lite-8k'],
  ollama: ['llama3:70b', 'qwen2:72b', 'mistral:8x22b']
}

const taskHistory = ref([
  { id: 1, url: 'https://example.com/spring-sale', status: 'done', createdAt: '2026-08-02 10:42:18' },
  { id: 2, url: 'https://example.com/product-x200', status: 'done', createdAt: '2026-08-02 09:18:02' },
  { id: 3, url: 'https://example.com/saas-trial', status: 'done', createdAt: '2026-08-01 22:05:33' },
  { id: 4, url: 'https://example.com/black-friday', status: 'failed', createdAt: '2026-08-01 18:30:11' },
  { id: 5, url: 'https://example.com/edu-masterclass', status: 'running', createdAt: '2026-08-02 10:58:00' }
])

const statusTag = (s) => ({
  done: { type: 'success', text: '已完成' },
  running: { type: 'primary', text: '生成中' },
  failed: { type: 'danger', text: '失败' },
  pending: { type: 'warning', text: '等待中' }
}[s] || { type: 'info', text: s })

const currentDetail = reactive({
  crawledInfo: {
    title: 'Spring Sale 2026 - Up to 70% Off Everything',
    description: 'Limited time spring sale. Shop premium products with up to 70% discount. Free shipping on orders over $99.',
    features: ['春季促销最高7折', '满$99免运费', '30天无忧退换', '24/7客户支持', '会员额外9折'],
    ratings: { overall: 4.8, reviews: 12432 }
  },
  creatives: [
    {
      headlines: ['Spring Sale Up To 70% Off', 'Limited Time Offer - Don\'t Miss', 'Premium Quality Products', 'Free Shipping On Orders $99+', '30-Day Hassle-Free Returns'],
      descriptions: ['Huge spring sale on now! Get up to 70% off premium products. Free shipping, easy returns, and 24/7 support. Shop today!', 'Shop our biggest spring sale ever. Premium quality at unbeatable prices. Limited stock available - order now!'],
      keywords: ['spring sale 2026', 'spring discount', 'free shipping', 'limited time offer', 'premium products sale']
    },
    {
      headlines: ['Save Big This Spring Season', 'Up To 70% Off Sitewide', 'Quality You Can Trust', 'Fast & Free Delivery', 'Member Exclusive Extra 10%'],
      descriptions: ['Spring savings you won\'t believe! Up to 70% off hundreds of items. Fast free shipping, 30-day returns. Shop now!', 'Upgrade your essentials this spring. Premium products at incredible prices. Members save even more.'],
      keywords: ['spring savings', 'sitewide sale', 'member discount', 'premium essentials', 'fast delivery']
    },
    {
      headlines: ['Your Spring Upgrade Starts Here', '70% Off Premium Selection', 'Shop Smarter Save More', 'Unbeatable Spring Prices', 'Thousands Of 5-Star Reviews'],
      descriptions: ['Transform your spring with our curated premium collection. Up to 70% off, loved by thousands. Free shipping today!', 'Join 10,000+ happy shoppers this spring. Premium products, honest prices, excellent service. Guaranteed satisfaction.'],
      keywords: ['spring upgrade', '5 star reviews', 'curated premium', 'guaranteed satisfaction', 'shop smarter']
    }
  ]
})

const runGenerate = async () => {
  if (!form.offerUrl) { ElMessage.warning('请输入Offer URL'); return }
  generating.value = true
  genStep.value = 0
  genProgress.value = 0
  const timer = setInterval(() => {
    genProgress.value += 3
    if (genProgress.value > 25 && genStep.value === 0) genStep.value = 1
    if (genProgress.value > 75 && genStep.value === 1) genStep.value = 2
    if (genProgress.value >= 100) {
      clearInterval(timer)
      generating.value = false
      ElMessage.success('创意生成完成！')
    }
  }, 180)
}

const viewDetail = (row) => {
  selectedTask.value = row
  drawerVisible.value = true
}

const submitToAds = async (creativeIdx) => {
  try {
    ElMessage.success(`创意方案${creativeIdx + 1} 已提交到Google Ads，等待审核`)
  } catch (e) {}
}

onMounted(() => {
  // request.get('/ai-creative/tasks').then(...)
})
</script>

<template>
  <div class="ai-creative-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">AI创意生成中心</h2>
        <p class="page-subtitle">输入Offer URL，AI自动爬取分析并生成多组Google Ads广告创意</p>
      </div>
    </div>

    <el-row :gutter="16">
      <el-col :xs="24" :lg="14">
        <el-card shadow="never" class="form-card">
          <template #header>
            <div class="card-title-wrap">
              <el-icon :size="18" style="color: var(--adx-color-primary)"><MagicStick /></el-icon>
              <span class="card-title">创意生成配置</span>
            </div>
          </template>

          <el-steps :active="generating ? (genStep + 1) : 0" finish-status="success" process-status="process" align-center style="margin-bottom: 24px">
            <el-step title="爬虫采集Offer" />
            <el-step title="AI生成创意" />
            <el-step title="完成" />
          </el-steps>

          <el-form :model="form" label-width="120px">
            <el-form-item label="Offer URL" required>
              <el-input v-model="form.offerUrl" placeholder="https://your-offer-page.com/product" clearable />
            </el-form-item>
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="目标语言">
                  <el-select v-model="form.targetLang" style="width: 100%">
                    <el-option v-for="l in languages" :key="l.value" :label="l.label" :value="l.value" />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="目标国家">
                  <el-select v-model="form.targetCountry" style="width: 100%">
                    <el-option v-for="c in countries" :key="c.value" :label="c.label" :value="c.value" />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="行业分类">
              <el-select v-model="form.industry" style="width: 100%">
                <el-option v-for="i in industries" :key="i.value" :label="i.label" :value="i.value" />
              </el-select>
            </el-form-item>
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item label="AI供应商">
                  <el-select v-model="form.aiProvider" style="width: 100%">
                    <el-option v-for="p in aiProviders" :key="p.value" :label="p.label" :value="p.value" />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="AI模型">
                  <el-select v-model="form.aiModel" style="width: 100%">
                    <el-option v-for="m in (providerModels[form.aiProvider] || [])" :key="m" :label="m" :value="m" />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>

            <el-divider content-position="left">
              <span style="font-weight: 600">高级选项</span>
            </el-divider>
            <el-form-item label="提示词模板">
              <el-select v-model="form.templateId" style="width: 100%; margin-bottom: 10px">
                <el-option v-for="t in templates" :key="t.value" :label="t.label" :value="t.value" />
              </el-select>
              <el-input
                v-model="form.templateContent"
                type="textarea"
                :rows="8"
                placeholder="可自定义提示词模板，支持变量: {{offer_url}}, {{target_lang}}, {{target_country}}, {{industry}}"
              />
              <div style="margin-top: 6px; font-size: 12px; color: var(--adx-text-tertiary)">
                可用变量：<el-tag size="small" effect="plain">{{offer_url}}</el-tag>
                <el-tag size="small" effect="plain">{{target_lang}}</el-tag>
                <el-tag size="small" effect="plain">{{target_country}}</el-tag>
                <el-tag size="small" effect="plain">{{industry}}</el-tag>
              </div>
            </el-form-item>

            <el-form-item>
              <el-button
                type="primary"
                size="large"
                class="el-button--gradient"
                style="width: 220px"
                :loading="generating"
                @click="runGenerate"
              >
                <el-icon v-if="!generating"><Sparkles /></el-icon>
                {{ generating ? '生成中...' : '🚀 开始生成创意' }}
              </el-button>
            </el-form-item>

            <el-progress
              v-if="generating"
              :percentage="genProgress"
              :stroke-width="10"
              style="margin-top: 4px"
              :status="genProgress >= 100 ? 'success' : ''"
            />
          </el-form>
        </el-card>
      </el-col>

      <el-col :xs="24" :lg="10">
        <el-card shadow="never" class="history-card">
          <template #header>
            <div class="card-title-wrap">
              <el-icon :size="18" style="color: var(--adx-color-primary)"><Clock /></el-icon>
              <span class="card-title">历史任务列表</span>
            </div>
          </template>
          <el-table :data="taskHistory" size="small" stripe>
            <el-table-column label="Offer URL" min-width="160" show-overflow-tooltip>
              <template #default="{ row }">
                <div style="font-weight: 500; font-size: 12px">{{ row.url }}</div>
              </template>
            </el-table-column>
            <el-table-column label="状态" width="80" align="center">
              <template #default="{ row }">
                <el-tag :type="statusTag(row.status).type" effect="light" size="small">
                  {{ statusTag(row.status).text }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="createdAt" label="创建时间" width="140" show-overflow-tooltip />
            <el-table-column label="操作" width="90" fixed="right">
              <template #default="{ row }">
                <el-button link type="primary" size="small" @click="viewDetail(row)">查看</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <el-drawer v-model="drawerVisible" :title="`任务详情 - ${selectedTask?.url || ''}`" size="75%">
      <div v-if="selectedTask" class="detail-wrap">
        <el-collapse v-model="activeCollapse">
          <el-collapse-item title="爬取信息分析" name="crawl">
            <div class="crawl-info">
              <div class="info-row">
                <label>页面标题：</label>
                <span class="title-text">{{ currentDetail.crawledInfo.title }}</span>
              </div>
              <div class="info-row">
                <label>Meta描述：</label>
                <span>{{ currentDetail.crawledInfo.description }}</span>
              </div>
              <div class="info-row">
                <label>核心特征：</label>
                <div class="feature-tags">
                  <el-tag v-for="(f, i) in currentDetail.crawledInfo.features" :key="i" type="primary" effect="plain">
                    {{ f }}
                  </el-tag>
                </div>
              </div>
              <div class="info-row">
                <label>评分/评价：</label>
                <span>
                  <el-rate :model-value="currentDetail.crawledInfo.ratings.overall / 2" disabled show-score text-color="#ff9900" />
                  <span style="margin-left: 10px; color: var(--adx-text-tertiary); font-size: 12px">
                    ({{ currentDetail.crawledInfo.ratings.reviews.toLocaleString() }} 条评价)
                  </span>
                </span>
              </div>
            </div>
          </el-collapse-item>
        </el-collapse>

        <div class="creatives-section">
          <h3 class="section-title">
            <el-icon><DocumentCopy /></el-icon>
            AI生成创意方案 (3组)
          </h3>
          <el-tabs v-model="activeCreativeTab" type="border-card">
            <el-tab-pane v-for="(c, idx) in currentDetail.creatives" :key="idx" :name="idx" :label="`方案 ${idx + 1}`">
              <div class="creative-scheme" style="padding: 16px 4px">
                <div class="preview-section">
                  <div class="preview-label">标题 Headlines</div>
                  <el-table :data="c.headlines.map(h => ({ h }))" size="small" border>
                    <el-table-column type="index" label="#" width="40" align="center" />
                    <el-table-column prop="h" label="文案内容" />
                    <el-table-column label="字符" width="80" align="center">
                      <template #default="{ row }">
                        <el-tag size="small" :type="row.h.length > 30 ? 'danger' : 'success'" effect="plain">
                          {{ row.h.length }}/30
                        </el-tag>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="preview-section">
                  <div class="preview-label">描述 Descriptions</div>
                  <el-table :data="c.descriptions.map(d => ({ d }))" size="small" border>
                    <el-table-column type="index" label="#" width="40" align="center" />
                    <el-table-column prop="d" label="文案内容" />
                    <el-table-column label="字符" width="80" align="center">
                      <template #default="{ row }">
                        <el-tag size="small" :type="row.d.length > 90 ? 'danger' : 'success'" effect="plain">
                          {{ row.d.length }}/90
                        </el-tag>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="preview-section">
                  <div class="preview-label">推荐关键词</div>
                  <div class="kw-tags">
                    <el-tag v-for="(k, i) in c.keywords" :key="i" type="warning" effect="plain" style="margin: 3px 6px 3px 0">{{ k }}</el-tag>
                  </div>
                </div>
                <div class="submit-row">
                  <el-button type="primary" class="el-button--gradient" @click="submitToAds(idx)">
                    <el-icon><Upload /></el-icon>一键提交到Google Ads
                  </el-button>
                  <el-button plain>复制文案</el-button>
                </div>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeCollapse: ['crawl'],
      activeCreativeTab: 0
    }
  }
}
</script>

<style lang="scss" scoped>
.ai-creative-page { display: flex; flex-direction: column; gap: 16px; }
.page-header {
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.card-title-wrap {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-weight: 600;
  font-size: 14px;
}
.card-title { color: var(--adx-text-primary); }

.detail-wrap { display: flex; flex-direction: column; gap: 20px; }
.crawl-info {
  padding: 8px 4px;
  .info-row {
    display: flex;
    margin-bottom: 12px;
    align-items: flex-start;
    label {
      width: 100px;
      flex-shrink: 0;
      color: var(--adx-text-tertiary);
      font-weight: 500;
    }
    .title-text {
      font-weight: 600;
      color: var(--adx-color-primary);
    }
  }
  .feature-tags { display: inline-flex; flex-wrap: wrap; gap: 6px; }
}

.section-title {
  margin: 0 0 12px;
  font-size: 16px;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.preview-section {
  margin-bottom: 18px;
  .preview-label {
    font-weight: 600;
    font-size: 13px;
    color: var(--adx-text-secondary);
    margin-bottom: 8px;
  }
}
.kw-tags { display: inline-flex; flex-wrap: wrap; }

.submit-row {
  display: flex;
  gap: 10px;
  padding-top: 8px;
  border-top: 1px dashed var(--adx-border-color);
  margin-top: 8px;
}
</style>
