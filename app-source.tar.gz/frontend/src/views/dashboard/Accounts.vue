<script setup>
import { ref, onMounted, reactive, computed } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useRoute, useRouter } from 'vue-router'
import request from '@/utils/request'

const route = useRoute()
const router = useRouter()
const loading = ref(false)
const syncing = ref(false)
const searchQuery = ref('')
const dialogVisible = ref(false)
const drawerVisible = ref(false)
const oauthDialogVisible = ref(false)
const selectedMcc = ref(null)
const dialogMode = ref('create')
const apiConfig = ref(null)
const oauthUrl = ref('')
const accessibleCustomers = ref([])
const accessibleCustomersVisible = ref(false)

const mccList = ref([])
const subAccountList = ref([])

const form = reactive({
  id: null,
  name: '',
  customerId: '',
  refreshToken: '',
  clientId: '',
  clientSecret: '',
  developerToken: '',
  loginCustomerId: '',
})

const formRules = {
  name: [{ required: true, message: '请输入MCC名称', trigger: 'blur' }],
  customerId: [{ required: true, message: '请输入Customer ID（格式: 123-456-7890）', trigger: 'blur' }],
}

const statusTag = (s) => ({
  active: { type: 'success', text: '正常' },
  syncing: { type: 'primary', text: '同步中' },
  error: { type: 'danger', text: '异常' },
  paused: { type: 'info', text: '已暂停' },
  disabled: { type: 'info', text: '已禁用' },
}[s] || { type: 'info', text: s })

// ==================== API 配置检查 ====================
const checkApiConfig = async () => {
  try {
    const res = await request.get('/accounts/api-config-check')
    apiConfig.value = res.data
  } catch (e) {
    apiConfig.value = { configured: false, issues: ['检查失败'] }
  }
}

// ==================== MCC 列表加载 ====================
const loadMccList = async () => {
  loading.value = true
  try {
    const res = await request.get('/accounts/mcc')
    mccList.value = (res.data.items || []).map(m => ({
      ...m,
      subCount: m.sub_accounts_count || 0,
      customerId: m.customer_id,
      lastSync: m.last_sync,
    }))
  } catch (e) {
    // 降级使用 mock 数据
    mccList.value = [
      { id: 1, name: '主MCC账号-Production', customerId: '542-896-3124', subCount: 28, status: 'active', lastSync: '2026-08-02 10:30:00' },
      { id: 2, name: '测试MCC-Staging', customerId: '198-234-5678', subCount: 12, status: 'syncing', lastSync: '2026-08-02 10:25:00' },
    ]
  } finally {
    loading.value = false
  }
}

// ==================== OAuth 授权流程 ====================
const startOAuth = async (mccId = null) => {
  try {
    const res = await request.post('/accounts/oauth/authorize', { mcc_id: mccId })
    oauthUrl.value = res.data.auth_url
    oauthDialogVisible.value = true
  } catch (e) {
    ElMessage.error('发起OAuth授权失败: ' + (e.message || ''))
  }
}

const openOAuthUrl = () => {
  if (oauthUrl.value) {
    window.open(oauthUrl.value, '_blank')
    oauthDialogVisible.value = false
  }
}

// ==================== MCC CRUD ====================
const openCreateDialog = () => {
  dialogMode.value = 'create'
  Object.keys(form).forEach(k => form[k] = k === 'id' ? null : '')
  // 预填 developerToken
  form.developerToken = '8WSsdnqyTc2QcY-ArtmgRQ'
  dialogVisible.value = true
}

const openEditDialog = (row) => {
  dialogMode.value = 'edit'
  Object.assign(form, {
    id: row.id,
    name: row.name,
    customerId: row.customerId,
    refreshToken: row.refreshToken || '',
    developerToken: row.developerToken || '8WSsdnqyTc2QcY-ArtmgRQ',
  })
  dialogVisible.value = true
}

const handleSubmit = async (formEl) => {
  await formEl.validate(async (valid) => {
    if (!valid) return
    try {
      const payload = {
        name: form.name,
        customer_id: form.customerId,
        developer_token: form.developerToken,
        client_id: form.clientId,
        client_secret: form.clientSecret,
        login_customer_id: form.loginCustomerId || form.customerId.replace(/-/g, ''),
        refresh_token: form.refreshToken,
      }
      if (dialogMode.value === 'create') {
        await request.post('/accounts/mcc', payload)
      } else {
        await request.put(`/accounts/mcc/${form.id}`, payload)
      }
      ElMessage.success(dialogMode.value === 'create' ? '创建成功' : '更新成功')
      dialogVisible.value = false
      loadMccList()
    } catch (e) {
      ElMessage.error('操作失败: ' + (e.message || ''))
    }
  })
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除MCC账号【${row.name}】？此操作不可恢复。`, '删除确认', { type: 'warning' })
    await request.delete(`/accounts/mcc/${row.id}`)
    ElMessage.success('删除成功')
    loadMccList()
  } catch (e) {
    if (e !== 'cancel') ElMessage.error('删除失败')
  }
}

// ==================== 同步 ====================
const handleSync = async (row) => {
  if (!row.refreshToken && row.status !== 'active') {
    ElMessageBox.confirm(
      '该MCC账号尚未完成OAuth授权，是否现在进行授权？',
      '需要授权',
      { type: 'info', confirmButtonText: '去授权', cancelButtonText: '取消' }
    ).then(() => startOAuth(row.id)).catch(() => {})
    return
  }

  syncing.value = true
  try {
    ElMessage.info(`正在同步【${row.name}】，请稍候...`)
    const res = await request.post(`/accounts/mcc/${row.id}/sync`)
    const stats = res.data?.stats || {}
    ElMessage.success(
      `同步完成！子账号: ${stats.sub_accounts || 0}, 广告系列: ${stats.campaigns || 0}, ` +
      `广告组: ${stats.ad_groups || 0}, 广告: ${stats.ads || 0}, 关键词: ${stats.keywords || 0}`
    )
    loadMccList()
  } catch (e) {
    ElMessage.error('同步失败: ' + (e.message || '请检查OAuth授权和Customer ID是否正确'))
  } finally {
    syncing.value = false
  }
}

// ==================== 子账号 ====================
const openSubAccounts = async (row) => {
  selectedMcc.value = row
  drawerVisible.value = true
  // 加载本地子账号
  try {
    const res = await request.get('/accounts/sub-accounts', { params: { mcc_id: row.id } })
    subAccountList.value = (res.data.items || []).map(s => ({
      id: s.id,
      externalId: s.external_id,
      name: s.name,
      currency: s.currency_code,
      timezone: s.time_zone,
      cost: s.spend,
      clicks: s.clicks,
      status: s.status,
    }))
  } catch (e) {
    subAccountList.value = []
  }
}

const loadGoogleSubAccounts = async () => {
  if (!selectedMcc.value) return
  try {
    const res = await request.get(`/accounts/google/sub-accounts/${selectedMcc.value.id}`)
    if (res.data?.sub_accounts) {
      ElMessage.success(`从Google获取到 ${res.data.count} 个子账号`)
      subAccountList.value = res.data.sub_accounts.map(s => ({
        externalId: s.external_id,
        name: s.name,
        currency: s.currency_code,
        timezone: s.time_zone,
        cost: 0,
        clicks: 0,
        status: (s.status || 'active').toLowerCase(),
      }))
    }
  } catch (e) {
    ElMessage.error('从Google获取子账号失败: ' + (e.message || ''))
  }
}

// ==================== 可访问客户列表 ====================
const loadAccessibleCustomers = async () => {
  try {
    const res = await request.get('/accounts/google/accessible-customers')
    accessibleCustomers.value = res.data.customer_ids || []
    if (accessibleCustomers.value.length > 0) {
      accessibleCustomersVisible.value = true
    }
  } catch (e) {
    accessibleCustomers.value = []
    accessibleCustomersVisible.value = false
  }
}

// ==================== OAuth 回调处理 ====================
onMounted(() => {
  checkApiConfig()
  loadMccList()
  // 检查是否从 OAuth 回调返回
  if (route.query.oauth === 'success') {
    ElMessage.success('Google OAuth 授权成功！refresh_token 已保存')
    if (route.query.mcc_id) {
      // 自动触发同步
      const mccId = parseInt(route.query.mcc_id)
      const mcc = mccList.value.find(m => m.id === mccId)
      if (mcc) handleSync(mcc)
    }
    // 清除 URL 参数
    router.replace({ query: {} })
  }
})
</script>

<template>
  <div class="accounts-page">
    <div class="page-header">
      <div>
        <h2 class="page-title">MCC账号管理</h2>
        <p class="page-subtitle">管理Google Ads MCC主账号与子账号，通过OAuth授权接入Google Ads API</p>
      </div>
    </div>

    <!-- API 配置检查提示 -->
    <el-alert
      v-if="apiConfig && !apiConfig.configured"
      type="warning"
      :closable="false"
      show-icon
      class="config-alert"
    >
      <template #title>
        <span>Google Ads API 配置不完整</span>
      </template>
      <div class="config-issues">
        <div v-for="issue in apiConfig.issues" :key="issue" class="issue-item">⚠️ {{ issue }}</div>
        <div class="config-help">
          请在 <code>backend/.env</code> 中配置以下变量后重启服务：
          <ul>
            <li><code>GOOGLE_CLIENT_ID</code> — 在 <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console</a> 创建OAuth 2.0凭据</li>
            <li><code>GOOGLE_CLIENT_SECRET</code> — OAuth客户端密钥</li>
            <li><code>GOOGLE_REDIRECT_URI</code> — 回调地址（当前: {{ apiConfig.redirect_uri }}）</li>
          </ul>
          <strong>Developer Token 已配置:</strong> ✅ 8WSsdnqyTc2QcY-ArtmgRQ
        </div>
      </div>
    </el-alert>

    <el-alert
      v-if="apiConfig && apiConfig.configured"
      type="success"
      :closable="false"
      show-icon
      class="config-alert"
    >
      <template #title>
        <span>✅ Google Ads API 已就绪 — Developer Token + OAuth 凭据已配置，可以授权接入</span>
      </template>
    </el-alert>

    <el-card shadow="never" class="toolbar-card">
      <div class="toolbar">
        <div class="toolbar-left">
          <el-button type="primary" class="el-button--gradient" @click="openCreateDialog">
            <el-icon><Plus /></el-icon>添加MCC
          </el-button>
          <el-button type="success" plain @click="startOAuth(null)">
            <el-icon><Link /></el-icon>Google OAuth 授权
          </el-button>
          <el-button @click="loadAccessibleCustomers" :loading="loading">
            <el-icon><Search /></el-icon>查看可访问账号
          </el-button>
        </div>
        <div class="toolbar-right">
          <el-input
            v-model="searchQuery"
            placeholder="搜索MCC名称或CustomerID..."
            clearable
            style="width: 280px"
          />
        </div>
      </div>
    </el-card>

    <el-card shadow="never">
      <el-table :data="mccList" stripe v-loading="loading" style="width: 100%">
        <el-table-column type="selection" width="50" />
        <el-table-column prop="name" label="MCC名称" min-width="180">
          <template #default="{ row }">
            <div class="mcc-name-cell">
              <el-icon :size="16" style="color: var(--adx-color-primary)"><UserFilled /></el-icon>
              <span>{{ row.name }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="customerId" label="Customer ID" width="160" />
        <el-table-column label="子账号" width="90" align="center">
          <template #default="{ row }">
            <el-tag type="primary" effect="plain">{{ row.subCount }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">
              {{ statusTag(row.status).text }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="lastSync" label="最近同步" width="180" />
        <el-table-column label="操作" width="360" fixed="right">
          <template #default="{ row }">
            <el-button link type="success" size="small" @click="startOAuth(row.id)">OAuth授权</el-button>
            <el-button link type="primary" size="small" @click="handleSync(row)" :loading="syncing">立即同步</el-button>
            <el-button link type="primary" size="small" @click="openEditDialog(row)">编辑</el-button>
            <el-button link type="success" size="small" @click="openSubAccounts(row)">子账号</el-button>
            <el-button link type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrap">
        <el-pagination background layout="total, sizes, prev, pager, next, jumper" :total="mccList.length" />
      </div>
    </el-card>

    <!-- 添加/编辑MCC对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogMode === 'create' ? '添加MCC账号' : '编辑MCC账号'"
      width="600px"
      destroy-on-close
    >
      <el-form ref="formRef" :model="form" :rules="formRules" label-width="120px">
        <el-form-item label="MCC名称" prop="name">
          <el-input v-model="form.name" placeholder="如：主MCC-Production" />
        </el-form-item>
        <el-form-item label="Customer ID" prop="customerId">
          <el-input v-model="form.customerId" placeholder="123-456-7890（MCC管理账号ID）" />
        </el-form-item>
        <el-divider content-position="left">
          <span style="font-size: 13px; color: #909399">凭据信息（可通过OAuth授权自动获取）</span>
        </el-divider>
        <el-form-item label="Developer Token">
          <el-input v-model="form.developerToken" type="password" show-password placeholder="Google Ads Developer Token" />
        </el-form-item>
        <el-form-item label="Refresh Token">
          <el-input v-model="form.refreshToken" type="password" show-password placeholder="通过OAuth授权自动获取" />
          <div class="form-hint">
            <el-link type="primary" :underline="false" @click="startOAuth(form.id)">点击此处进行Google OAuth授权 →</el-link>
          </div>
        </el-form-item>
        <el-form-item label="Client ID">
          <el-input v-model="form.clientId" placeholder="xxx.apps.googleusercontent.com（留空则使用系统配置）" />
        </el-form-item>
        <el-form-item label="Client Secret">
          <el-input v-model="form.clientSecret" type="password" show-password placeholder="留空则使用系统配置" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit($refs.formRef)">确定</el-button>
      </template>
    </el-dialog>

    <!-- OAuth 授权URL对话框 -->
    <el-dialog v-model="oauthDialogVisible" title="Google OAuth 授权" width="560px" destroy-on-close>
      <div class="oauth-content">
        <el-alert type="info" :closable="false" show-icon style="margin-bottom: 16px">
          <template #title>点击下方按钮在浏览器中完成Google账号授权</template>
        </el-alert>
        <div class="oauth-steps">
          <p><strong>步骤：</strong></p>
          <ol>
            <li>点击"打开授权页面"按钮</li>
            <li>在Google登录页面选择你的MCC管理账号</li>
            <li>授权应用访问你的Google Ads数据</li>
            <li>授权成功后页面会自动跳回，系统自动保存 refresh_token</li>
            <li>返回此页面点击"立即同步"即可拉取所有广告数据</li>
          </ol>
        </div>
        <div class="oauth-url-preview">
          <el-text type="info" size="small" truncated>{{ oauthUrl.substring(0, 80) }}...</el-text>
        </div>
      </div>
      <template #footer>
        <el-button @click="oauthDialogVisible = false">关闭</el-button>
        <el-button type="primary" @click="openOAuthUrl">
          <el-icon><Link /></el-icon> 打开授权页面
        </el-button>
      </template>
    </el-dialog>

    <!-- 可访问客户账号列表 -->
    <el-dialog v-model="accessibleCustomersVisible" title="可访问的Google Ads客户账号" width="500px" @close="accessibleCustomers = []; accessibleCustomersVisible = false">
      <el-table :data="accessibleCustomers.map(id => ({ id }))" stripe>
        <el-table-column prop="id" label="Customer ID" />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="form.customerId = row.id; accessibleCustomers = []; accessibleCustomersVisible = false">选择</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <!-- 子账号抽屉 -->
    <el-drawer v-model="drawerVisible" :title="`子账号列表 - ${selectedMcc?.name || ''}`" size="75%">
      <div v-if="selectedMcc" class="drawer-meta">
        <el-tag type="info">CustomerID: {{ selectedMcc.customerId }}</el-tag>
        <el-tag type="primary">子账号: {{ subAccountList.length }}</el-tag>
        <el-button type="primary" size="small" plain @click="loadGoogleSubAccounts">
          <el-icon><Refresh /></el-icon>从Google实时获取
        </el-button>
      </div>
      <el-table :data="subAccountList" stripe style="margin-top: 16px">
        <el-table-column prop="externalId" label="外部ID" width="150" />
        <el-table-column prop="name" label="子账号名称" min-width="200" />
        <el-table-column prop="currency" label="币种" width="80" align="center">
          <template #default="{ row }"><el-tag size="small" effect="plain">{{ row.currency || '-' }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="timezone" label="时区" width="200" />
        <el-table-column label="花费(USD)" width="120" align="right">
          <template #default="{ row }">${{ (row.cost || 0).toLocaleString() }}</template>
        </el-table-column>
        <el-table-column label="点击" width="100" align="right">
          <template #default="{ row }">{{ (row.clicks || 0).toLocaleString() }}</template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status).type" effect="light" size="small">
              {{ statusTag(row.status).text }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-drawer>
  </div>
</template>

<style lang="scss" scoped>
.accounts-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.page-header {
  .page-title { margin: 0; font-size: 22px; font-weight: 700; color: var(--adx-text-primary); }
  .page-subtitle { margin: 4px 0 0; font-size: 13px; color: var(--adx-text-tertiary); }
}
.config-alert { border-radius: 12px; }
.config-issues {
  .issue-item { margin: 4px 0; font-size: 14px; }
  .config-help {
    margin-top: 12px; padding: 12px; background: #f8fafc; border-radius: 8px;
    font-size: 13px; color: #64748b; line-height: 1.8;
    ul { margin: 6px 0 6px 20px; padding: 0; }
    code { background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-size: 12px; color: #8A05FF; }
    a { color: #6366F1; }
  }
}
.toolbar {
  display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;
}
.toolbar-left { display: flex; gap: 8px; flex-wrap: wrap; }
.mcc-name-cell { display: inline-flex; align-items: center; gap: 6px; font-weight: 500; }
.pagination-wrap { display: flex; justify-content: flex-end; padding-top: 16px; }
.drawer-meta { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
.form-hint { margin-top: 4px; font-size: 12px; }
.oauth-content {
  .oauth-steps {
    margin: 16px 0; padding: 16px; background: #f8fafc; border-radius: 8px;
    ol { margin: 8px 0 0 20px; padding: 0; line-height: 2; }
  }
  .oauth-url-preview { margin-top: 12px; }
}
</style>
