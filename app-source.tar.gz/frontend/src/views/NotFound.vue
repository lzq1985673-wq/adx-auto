<script setup>
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()

const goHome = () => router.push('/')
const goBack = () => router.go(-1)
const goDashboard = () => router.push('/dashboard')
const goLogin = () => router.push('/login')
</script>

<template>
  <div class="not-found-page">
    <div class="bg-decoration">
      <div class="bg-blur bg-blur-1"></div>
      <div class="bg-blur bg-blur-2"></div>
    </div>

    <div class="nf-container">
      <div class="nf-visual">
        <div class="nf-number">
          <span class="n n1">4</span>
          <span class="n n0">
            <svg viewBox="0 0 100 100" width="100%" height="100%">
              <defs>
                <linearGradient id="nfGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stop-color="#8A05FF" />
                  <stop offset="100%" stop-color="#6366F1" />
                </linearGradient>
              </defs>
              <circle cx="50" cy="50" r="42" fill="none" stroke="url(#nfGrad)" stroke-width="6" />
              <circle cx="50" cy="50" r="30" fill="none" stroke="url(#nfGrad)" stroke-width="4" stroke-dasharray="6 8" opacity="0.7" />
              <g transform="translate(50, 50)">
                <path
                  d="M-18 -10 Q-8 -28 0 -22 Q8 -18 18 -30"
                  fill="none"
                  stroke="url(#nfGrad)"
                  stroke-width="4"
                  stroke-linecap="round"
                />
                <circle cx="-18" cy="-10" r="4" fill="url(#nfGrad)" />
                <circle cx="18" cy="-30" r="4" fill="url(#nfGrad)" />
              </g>
            </svg>
          </span>
          <span class="n n2">4</span>
        </div>
      </div>

      <h1 class="nf-title">页面走丢了</h1>
      <p class="nf-desc">
        抱歉，您访问的页面不存在，可能是链接错误或页面已被移除。
        <br class="hide-mobile" />
        您可以返回首页继续浏览，或联系我们的客服获取帮助。
      </p>

      <div class="nf-actions">
        <el-button type="primary" size="large" class="btn-primary" @click="goHome">
          <el-icon><HomeFilled /></el-icon>
          <span>返回首页</span>
        </el-button>
        <el-button size="large" class="btn-outline" @click="goBack">
          <el-icon><ArrowLeft /></el-icon>
          <span>返回上一页</span>
        </el-button>
        <template v-if="userStore.isLoggedIn">
          <el-button size="large" class="btn-ghost" @click="goDashboard">
            <el-icon><Odometer /></el-icon>
            <span>前往控制台</span>
          </el-button>
        </template>
        <template v-else>
          <el-button size="large" class="btn-ghost" @click="goLogin">
            <el-icon><User /></el-icon>
            <span>登录系统</span>
          </el-button>
        </template>
      </div>

      <div class="nf-help">
        <div class="help-label">需要帮助？</div>
        <div class="help-items">
          <a href="#" class="help-item">
            <el-icon color="#8A05FF"><Message /></el-icon>
            <span>support@adx-auto.com</span>
          </a>
          <a href="#" class="help-item">
            <el-icon color="#8A05FF"><Phone /></el-icon>
            <span>400-888-1234</span>
          </a>
          <a href="#" class="help-item">
            <el-icon color="#8A05FF"><Service /></el-icon>
            <span>7x12 在线客服</span>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.not-found-page {
  position: relative;
  min-height: 100vh;
  width: 100%;
  overflow: hidden;
  background: var(--adx-bg-color);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
}

.bg-decoration {
  position: absolute;
  inset: 0;
  pointer-events: none;
  z-index: 0;
}

.bg-blur {
  position: absolute;
  border-radius: 50%;
  filter: blur(100px);
  opacity: 0.5;
}
.bg-blur-1 {
  top: -200px;
  left: -100px;
  width: 600px;
  height: 600px;
  background: radial-gradient(circle, rgba(138, 5, 255, 0.22), transparent 70%);
}
.bg-blur-2 {
  bottom: -200px;
  right: -100px;
  width: 600px;
  height: 600px;
  background: radial-gradient(circle, rgba(99, 102, 241, 0.22), transparent 70%);
}

.nf-container {
  position: relative;
  z-index: 1;
  max-width: 680px;
  width: 100%;
  text-align: center;
}

.nf-visual {
  margin-bottom: 32px;
}

.nf-number {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-weight: 900;
  line-height: 1;
  letter-spacing: -4px;

  .n {
    font-size: clamp(120px, 22vw, 200px);
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    filter: drop-shadow(0 20px 40px rgba(99, 102, 241, 0.2));
  }

  .n0 {
    width: clamp(120px, 22vw, 190px);
    height: clamp(120px, 22vw, 190px);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    -webkit-text-fill-color: initial;
    background: none;
    animation: spinSlow 18s linear infinite;
  }
}

@keyframes spinSlow {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.nf-title {
  font-size: clamp(24px, 4vw, 36px);
  font-weight: 800;
  color: var(--adx-text-primary);
  margin: 0 0 14px;
  line-height: 1.3;
}

.nf-desc {
  font-size: clamp(14px, 2vw, 16px);
  line-height: 1.8;
  color: var(--adx-text-secondary);
  margin: 0 auto 36px;
  max-width: 560px;
}

.nf-actions {
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 12px;
  margin-bottom: 40px;
}

.btn-primary {
  background: var(--adx-gradient-primary);
  border: none;
  font-weight: 600;
  border-radius: 12px;
  height: 48px;
  padding: 0 22px;
  transition: all 0.25s;

  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 10px 24px -8px rgba(99, 102, 241, 0.5);
  }

  :deep(.el-icon) { margin-right: 6px; }
}

.btn-outline {
  border: 2px solid var(--adx-border-color);
  color: var(--adx-text-primary);
  font-weight: 600;
  border-radius: 12px;
  height: 48px;
  padding: 0 22px;

  &:hover {
    color: var(--adx-color-primary);
    border-color: var(--adx-color-primary-light);
  }

  :deep(.el-icon) { margin-right: 6px; }
}

.btn-ghost {
  color: var(--adx-text-secondary);
  font-weight: 500;
  height: 48px;
  padding: 0 22px;

  &:hover {
    color: var(--adx-color-primary);
  }

  :deep(.el-icon) { margin-right: 6px; }
}

.nf-help {
  padding: 24px;
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(12px);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
}

.help-label {
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 1px;
  color: var(--adx-text-tertiary);
  text-transform: uppercase;
  margin-bottom: 14px;
}

.help-items {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px 20px;
}

.help-item {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 13.5px;
  color: var(--adx-text-secondary);
  text-decoration: none;
  padding: 6px 12px;
  border-radius: 10px;
  transition: all 0.2s;

  &:hover {
    color: var(--adx-color-primary);
    background: var(--adx-bg-hover);
  }
}

@media (max-width: 640px) {
  .hide-mobile { display: none; }
}
</style>
