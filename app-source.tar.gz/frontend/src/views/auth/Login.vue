<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const loading = ref(false)
const loginFormRef = ref(null)

const form = reactive({
  username: '',
  password: '',
  remember: true
})

const rules = {
  username: [
    { required: true, message: '请输入用户名或邮箱', trigger: 'blur' },
    { min: 2, max: 64, message: '长度在 2 到 64 个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入登录密码', trigger: 'blur' },
    { min: 6, max: 64, message: '密码长度 6 到 64 位', trigger: 'blur' }
  ]
}

const goHome = () => router.push('/')
const goRegister = () => router.push('/register')
const goForgotPassword = () => {
  ElMessage.info('忘记密码功能即将上线，请联系客服 support@adx-auto.com')
}

const handleLogin = async () => {
  if (!loginFormRef.value) return
  try {
    await loginFormRef.value.validate()
  } catch {
    return
  }

  loading.value = true
  try {
    const res = await userStore.login({
      username: form.username,
      password: form.password,
      remember: form.remember
    })

    if (res.code === 0 || res.code === 200) {
      ElMessage.success('登录成功，正在跳转...')
      const redirect = route.query.redirect
        ? decodeURIComponent(route.query.redirect)
        : '/dashboard'
      setTimeout(() => {
        router.replace(redirect)
      }, 500)
    } else {
      ElMessage.error(res.msg || '登录失败，请检查账号密码')
    }
  } catch (err) {
    // request 拦截器已经弹了错误提示
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  if (import.meta.env.DEV) {
    form.username = 'admin'
    form.password = '123456'
  }
})
</script>

<template>
  <div class="auth-page auth-login">
    <div class="bg-decoration">
      <div class="bg-blur bg-blur-1"></div>
      <div class="bg-blur bg-blur-2"></div>
      <div class="bg-blur bg-blur-3"></div>
      <div class="bg-grid"></div>
    </div>

    <div class="auth-container">
      <a href="#" class="back-home" @click.prevent="goHome">
        <el-icon :size="16"><ArrowLeft /></el-icon>
        <span>返回首页</span>
      </a>

      <div class="auth-card-wrap">
        <div class="auth-left">
          <div class="left-logo">
            <span class="logo-icon">
              <svg viewBox="0 0 32 32" width="40" height="40" aria-hidden="true">
                <defs>
                  <linearGradient id="loginLogoGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stop-color="#6366F1" />
                    <stop offset="100%" stop-color="#8A05FF" />
                  </linearGradient>
                </defs>
                <rect x="2" y="2" width="28" height="28" rx="8" fill="url(#loginLogoGrad)" />
                <path
                  d="M9 22 L14 10 L17 18 L20 10 L25 22"
                  stroke="#fff"
                  stroke-width="2.2"
                  fill="none"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </span>
            <span class="logo-text">
              <span class="logo-main">ADX</span>
              <span class="logo-sub">Auto</span>
            </span>
          </div>

          <h1 class="left-title">
            Google Ads
            <br />
            <span class="gradient-text">自动化投放管理平台</span>
          </h1>

          <p class="left-desc">
            无需申请 Google Ads API · 无需频繁切换代理与指纹浏览器 ·
            10分钟完成 Offer 上线
          </p>

          <ul class="left-features">
            <li>
              <el-icon color="#fff" :size="18"><Check /></el-icon>
              <span>MCC一键录入，多账号隔离管理</span>
            </li>
            <li>
              <el-icon color="#fff" :size="18"><Check /></el-icon>
              <span>补点击 / 换链接 智能执行</span>
            </li>
            <li>
              <el-icon color="#fff" :size="18"><Check /></el-icon>
              <span>AI 生成广告创意，一键提交</span>
            </li>
            <li>
              <el-icon color="#fff" :size="18"><Check /></el-icon>
              <span>5家代理 + 13+AI 模型 自由切换</span>
            </li>
          </ul>

          <div class="left-trust">
            <div class="trust-dot"></div>
            <span>500+ 团队信赖 · 99.9% 可用性 · 7天无理由退款</span>
          </div>
        </div>

        <div class="auth-right">
          <div class="auth-card">
            <h2 class="auth-title">登录账号</h2>
            <p class="auth-subtitle">欢迎回来，请输入您的账号信息</p>

            <el-form
              ref="loginFormRef"
              :model="form"
              :rules="rules"
              class="auth-form"
              label-position="top"
              @keyup.enter="handleLogin"
            >
              <el-form-item label="用户名 / 邮箱" prop="username">
                <el-input
                  v-model="form.username"
                  size="large"
                  placeholder="请输入用户名或邮箱"
                  :prefix-icon="User"
                  clearable
                />
              </el-form-item>

              <el-form-item label="密码" prop="password">
                <el-input
                  v-model="form.password"
                  size="large"
                  type="password"
                  placeholder="请输入登录密码"
                  :prefix-icon="Lock"
                  show-password
                />
              </el-form-item>

              <div class="form-extra">
                <el-checkbox v-model="form.remember" label="记住我 7 天" />
                <a class="link-forgot" href="#" @click.prevent="goForgotPassword">
                  忘记密码？
                </a>
              </div>

              <el-button
                type="primary"
                size="large"
                class="btn-submit"
                :loading="loading"
                @click="handleLogin"
              >
                {{ loading ? '登录中...' : '登 录' }}
              </el-button>
            </el-form>

            <div class="divider-or">
              <span>或</span>
            </div>

            <div class="sso-row">
              <el-button class="sso-btn">
                <el-icon><ChatDotRound /></el-icon>
                <span>企业微信登录</span>
              </el-button>
              <el-button class="sso-btn">
                <el-icon><Promotion /></el-icon>
                <span>飞书登录</span>
              </el-button>
              <el-button class="sso-btn">
                <el-icon><Github /></el-icon>
                <span>GitHub</span>
              </el-button>
            </div>

            <div class="register-link">
              还没有账号？
              <a href="#" @click.prevent="goRegister">立即注册 →</a>
            </div>
          </div>
        </div>
      </div>

      <div class="auth-footer">
        <span>© {{ new Date().getFullYear() }} ADX-Auto. All rights reserved.</span>
        <span class="sep">·</span>
        <a href="#">隐私政策</a>
        <span class="sep">·</span>
        <a href="#">服务条款</a>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.auth-page {
  position: relative;
  min-height: 100vh;
  width: 100%;
  overflow: hidden;
  background: #f8fafc;
}

// Background
.bg-decoration {
  position: absolute;
  inset: 0;
  pointer-events: none;
  z-index: 0;
}

.bg-blur {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.5;
}
.bg-blur-1 {
  top: -150px;
  left: -100px;
  width: 520px;
  height: 520px;
  background: radial-gradient(circle, rgba(138, 5, 255, 0.22), transparent 70%);
}
.bg-blur-2 {
  top: 40%;
  right: -120px;
  width: 560px;
  height: 560px;
  background: radial-gradient(circle, rgba(99, 102, 241, 0.2), transparent 70%);
}
.bg-blur-3 {
  bottom: -160px;
  left: 30%;
  width: 500px;
  height: 500px;
  background: radial-gradient(circle, rgba(6, 182, 212, 0.15), transparent 70%);
}

.bg-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(99, 102, 241, 0.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(99, 102, 241, 0.05) 1px, transparent 1px);
  background-size: 48px 48px;
  mask-image: radial-gradient(ellipse at center, black 30%, transparent 75%);
}

// Container
.auth-container {
  position: relative;
  z-index: 1;
  min-height: 100vh;
  max-width: 1200px;
  margin: 0 auto;
  padding: 28px 32px;
  display: flex;
  flex-direction: column;
}

.back-home {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: var(--adx-text-secondary);
  text-decoration: none;
  padding: 6px 12px;
  background: rgba(255, 255, 255, 0.6);
  backdrop-filter: blur(8px);
  border: 1px solid var(--adx-border-light);
  border-radius: 10px;
  width: fit-content;
  transition: all 0.2s;
  margin-bottom: 24px;

  &:hover {
    color: var(--adx-color-primary);
    border-color: var(--adx-color-primary-light);
    transform: translateX(-2px);
  }
}

.auth-card-wrap {
  flex: 1;
  display: grid;
  grid-template-columns: 1.05fr 1fr;
  gap: 48px;
  align-items: center;
  min-height: 0;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    gap: 32px;
  }
}

// Left panel
.auth-left {
  color: var(--adx-text-primary);

  @media (max-width: 1024px) {
    text-align: center;
  }
}

.left-logo {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 40px;

  .logo-text {
    display: inline-flex;
    align-items: baseline;
    gap: 3px;
    font-weight: 800;
    font-size: 22px;
    line-height: 1;
  }
  .logo-main {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  .logo-sub {
    color: var(--adx-text-primary);
    font-weight: 600;
  }

  @media (max-width: 1024px) {
    margin: 0 auto 24px;
  }
}

.left-title {
  font-size: 44px;
  font-weight: 800;
  line-height: 1.2;
  margin: 0 0 18px;
  color: var(--adx-text-primary);

  .gradient-text {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }

  @media (max-width: 1280px) { font-size: 36px; }
  @media (max-width: 640px) { font-size: 26px; }
}

.left-desc {
  font-size: 16px;
  line-height: 1.75;
  color: var(--adx-text-secondary);
  max-width: 480px;
  margin: 0 0 28px;

  @media (max-width: 1024px) { margin-left: auto; margin-right: auto; }
}

.left-features {
  list-style: none;
  padding: 0;
  margin: 0 0 32px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-width: 460px;

  li {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14.5px;
    color: var(--adx-text-secondary);
    line-height: 1.5;

    .el-icon {
      flex-shrink: 0;
      width: 24px;
      height: 24px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(6, 182, 212, 0.12));
      border-radius: 50%;
      color: var(--adx-color-success) !important;
    }
  }

  @media (max-width: 1024px) {
    margin-left: auto;
    margin-right: auto;
    text-align: left;
    display: inline-flex;
  }
}

.left-trust {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 8px 14px;
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(6px);
  border: 1px solid var(--adx-border-light);
  border-radius: 9999px;
  font-size: 12.5px;
  color: var(--adx-text-tertiary);

  .trust-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--adx-color-success);
    box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.12);
  }
}

// Right panel - card
.auth-right {
  display: flex;
  align-items: center;
  justify-content: center;
}

.auth-card {
  width: 100%;
  max-width: 420px;
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 20px;
  padding: 36px 32px;
  box-shadow: 0 30px 60px -15px rgba(99, 102, 241, 0.15),
    0 0 0 1px rgba(99, 102, 241, 0.03);
}

.auth-title {
  font-size: 24px;
  font-weight: 800;
  color: var(--adx-text-primary);
  margin: 0 0 6px;
  line-height: 1.3;
}

.auth-subtitle {
  font-size: 13.5px;
  color: var(--adx-text-tertiary);
  margin: 0 0 28px;
}

.auth-form {
  :deep(.el-form-item__label) {
    font-size: 13px;
    font-weight: 600;
    color: var(--adx-text-secondary);
  }

  :deep(.el-input__wrapper) {
    border-radius: 12px;
    padding: 4px 14px;
    box-shadow: 0 0 0 1px var(--adx-border-color) inset;
    transition: box-shadow 0.2s;

    &.is-focus {
      box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.25) inset;
    }
  }
}

.form-extra {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: -4px 0 20px;
  font-size: 13px;

  .link-forgot {
    color: var(--adx-color-primary);
    text-decoration: none;
    font-weight: 500;
    &:hover { text-decoration: underline; }
  }

  :deep(.el-checkbox__label) {
    font-size: 13px;
    color: var(--adx-text-secondary);
  }
}

.btn-submit {
  width: 100%;
  height: 48px;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: 4px;
  border-radius: 12px;
  background: var(--adx-gradient-primary);
  border: none;
  transition: all 0.25s;

  &:hover {
    box-shadow: 0 10px 24px -8px rgba(99, 102, 241, 0.5);
    transform: translateY(-1px);
  }
}

.divider-or {
  display: flex;
  align-items: center;
  margin: 24px 0;
  gap: 12px;
  color: var(--adx-text-tertiary);
  font-size: 12px;

  &::before, &::after {
    content: '';
    flex: 1;
    height: 1px;
    background: var(--adx-border-color);
  }
}

.sso-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  margin-bottom: 24px;
}

.sso-btn {
  height: 40px;
  border-radius: 10px;
  background: var(--adx-bg-secondary);
  border: 1px solid var(--adx-border-color);
  color: var(--adx-text-secondary);
  font-size: 12px;

  &:hover {
    color: var(--adx-color-primary);
    border-color: var(--adx-color-primary-light);
    background: rgba(99, 102, 241, 0.05);
  }

  .el-icon { margin-right: 2px; }
}

.register-link {
  text-align: center;
  font-size: 13.5px;
  color: var(--adx-text-secondary);

  a {
    color: var(--adx-color-primary);
    text-decoration: none;
    font-weight: 600;
    &:hover { text-decoration: underline; }
  }
}

// footer
.auth-footer {
  margin-top: 24px;
  text-align: center;
  font-size: 12px;
  color: var(--adx-text-tertiary);
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  gap: 10px;

  .sep { color: var(--adx-border-color); }

  a {
    color: var(--adx-text-tertiary);
    text-decoration: none;
    &:hover { color: var(--adx-color-primary); }
  }
}
</style>
