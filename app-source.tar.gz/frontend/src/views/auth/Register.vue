<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import request from '@/utils/request'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const loading = ref(false)
const registerFormRef = ref(null)

const form = reactive({
  username: '',
  email: '',
  company: '',
  password: '',
  confirmPassword: '',
  agree: true
})

const validateConfirmPassword = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('请再次输入密码'))
  } else if (value !== form.password) {
    callback(new Error('两次输入的密码不一致'))
  } else {
    callback()
  }
}

const rules = {
  username: [
    { required: true, message: '请设置用户名', trigger: 'blur' },
    { min: 3, max: 32, message: '用户名长度 3-32 个字符', trigger: 'blur' },
    { pattern: /^[A-Za-z0-9_\u4e00-\u9fa5]+$/, message: '仅支持字母、数字、下划线和中文', trigger: 'blur' }
  ],
  email: [
    { required: true, message: '请输入邮箱地址', trigger: 'blur' },
    { type: 'email', message: '邮箱格式不正确', trigger: ['blur', 'change'] }
  ],
  company: [
    { required: false },
    { min: 2, max: 64, message: '公司名称长度 2-64 个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请设置密码', trigger: 'blur' },
    { min: 8, max: 64, message: '密码长度 8-64 位', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (!value) { callback(); return }
        const hasLetter = /[A-Za-z]/.test(value)
        const hasNumber = /[0-9]/.test(value)
        if (!(hasLetter && hasNumber)) {
          callback(new Error('密码需至少包含字母和数字'))
        } else {
          callback()
        }
      },
      trigger: 'blur'
    }
  ],
  confirmPassword: [
    { required: true, validator: validateConfirmPassword, trigger: ['blur', 'change'] }
  ],
  agree: [
    {
      validator: (rule, value, callback) => {
        if (!value) {
          callback(new Error('请先阅读并同意服务条款和隐私政策'))
        } else {
          callback()
        }
      },
      trigger: 'change'
    }
  ]
}

const goHome = () => router.push('/')
const goLogin = () => router.push('/login')

const handleRegister = async () => {
  if (!registerFormRef.value) return
  try {
    await registerFormRef.value.validate()
  } catch {
    return
  }

  loading.value = true
  try {
    const payload = {
      username: form.username,
      email: form.email,
      password: form.password,
      company: form.company || undefined
    }

    const res = await request.post('/auth/register', payload)

    if (res.code === 0 || res.code === 200) {
      ElMessage.success('注册成功！正在为你自动登录...')
      try {
        await userStore.login({ username: form.username, password: form.password })
        setTimeout(() => {
          router.replace('/dashboard')
        }, 600)
      } catch {
        setTimeout(() => {
          router.replace('/login')
        }, 800)
      }
    } else {
      ElMessage.error(res.msg || '注册失败，请稍后再试')
    }
  } catch (err) {
    // 拦截器已弹错误
  } finally {
    loading.value = false
  }
}

const checkStrength = (pwd) => {
  let score = 0
  if (!pwd) return score
  if (pwd.length >= 8) score++
  if (/[A-Z]/.test(pwd)) score++
  if (/[0-9]/.test(pwd)) score++
  if (/[^A-Za-z0-9]/.test(pwd)) score++
  return score
}
</script>

<template>
  <div class="auth-page auth-register">
    <div class="bg-decoration">
      <div class="bg-blur bg-blur-1"></div>
      <div class="bg-blur bg-blur-2"></div>
      <div class="bg-blur bg-blur-3"></div>
      <div class="bg-grid"></div>
    </div>

    <div class="auth-container">
      <a href="#" class="back-home" @click.prevent="goHome">
        <el-icon :size="16"><ArrowLeft /></el-icon>
        <span>返回首页</span>
      </a>

      <div class="auth-card-wrap">
        <div class="auth-left">
          <div class="left-logo">
            <span class="logo-icon">
              <svg viewBox="0 0 32 32" width="40" height="40" aria-hidden="true">
                <defs>
                  <linearGradient id="regLogoGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stop-color="#6366F1" />
                    <stop offset="100%" stop-color="#8A05FF" />
                  </linearGradient>
                </defs>
                <rect x="2" y="2" width="28" height="28" rx="8" fill="url(#regLogoGrad)" />
                <path
                  d="M9 22 L14 10 L17 18 L20 10 L25 22"
                  stroke="#fff"
                  stroke-width="2.2"
                  fill="none"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </span>
            <span class="logo-text">
              <span class="logo-main">ADX</span>
              <span class="logo-sub">Auto</span>
            </span>
          </div>

          <h1 class="left-title">
            立即加入，
            <br />
            <span class="gradient-text">让投放效率翻倍</span>
          </h1>

          <p class="left-desc">
            注册即送 7 天专业版试用 · 无需绑定信用卡 ·
            30 分钟 1 对 1 陪跑服务 · 全程中文支持
          </p>

          <div class="benefits-grid">
            <div class="benefit-item">
              <div class="bi-icon" style="background: linear-gradient(135deg, #8A05FF, #6366F1);">
                <el-icon :size="22"><Lightning /></el-icon>
              </div>
              <div class="bi-text">
                <div class="bi-title">10分钟上线</div>
                <div class="bi-sub">无需API审批即开即用</div>
              </div>
            </div>
            <div class="benefit-item">
              <div class="bi-icon" style="background: linear-gradient(135deg, #06B6D4, #10B981);">
                <el-icon :size="22"><TrendCharts /></el-icon>
              </div>
              <div class="bi-text">
                <div class="bi-title">平均ROAS +85%</div>
                <div class="bi-sub">基于500+客户真实数据</div>
              </div>
            </div>
            <div class="benefit-item">
              <div class="bi-icon" style="background: linear-gradient(135deg, #F59E0B, #EF4444);">
                <el-icon :size="22"><Coin /></el-icon>
              </div>
              <div class="bi-text">
                <div class="bi-title">首月即可回本</div>
                <div class="bi-sub">综合成本下降 40%+</div>
              </div>
            </div>
            <div class="benefit-item">
              <div class="bi-icon" style="background: linear-gradient(135deg, #EC4899, #8A05FF);">
                <el-icon :size="22"><Headset /></el-icon>
              </div>
              <div class="bi-text">
                <div class="bi-title">7x12 中文支持</div>
                <div class="bi-sub">钉钉群/邮件/电话 多渠道</div>
              </div>
            </div>
          </div>
        </div>

        <div class="auth-right">
          <div class="auth-card">
            <h2 class="auth-title">创建账号</h2>
            <p class="auth-subtitle">只需 30 秒，开启你的高效投放之旅</p>

            <el-form
              ref="registerFormRef"
              :model="form"
              :rules="rules"
              class="auth-form"
              label-position="top"
              @keyup.enter="handleRegister"
            >
              <el-form-item label="用户名" prop="username">
                <el-input
                  v-model="form.username"
                  size="large"
                  placeholder="3-32位字母/数字/下划线/中文"
                  :prefix-icon="User"
                  clearable
                />
              </el-form-item>

              <el-form-item label="邮箱" prop="email">
                <el-input
                  v-model="form.email"
                  size="large"
                  type="email"
                  placeholder="your@email.com"
                  :prefix-icon="Message"
                  clearable
                />
              </el-form-item>

              <el-form-item label="公司名称（选填）" prop="company">
                <el-input
                  v-model="form.company"
                  size="large"
                  placeholder="你的公司/团队名称"
                  :prefix-icon="OfficeBuilding"
                  clearable
                />
              </el-form-item>

              <el-form-item label="设置密码" prop="password">
                <el-input
                  v-model="form.password"
                  size="large"
                  type="password"
                  placeholder="至少8位，包含字母+数字"
                  :prefix-icon="Lock"
                  show-password
                />
                <div v-if="form.password" class="strength-bar">
                  <div
                    class="strength-block"
                    :class="{ active: checkStrength(form.password) >= 1 }"
                  ></div>
                  <div
                    class="strength-block"
                    :class="{ active: checkStrength(form.password) >= 2 }"
                  ></div>
                  <div
                    class="strength-block"
                    :class="{ active: checkStrength(form.password) >= 3 }"
                  ></div>
                  <div
                    class="strength-block"
                    :class="{ active: checkStrength(form.password) >= 4 }"
                  ></div>
                  <span class="strength-text">
                    {{ ['弱', '一般', '良好', '强'][checkStrength(form.password) - 1] || '太短' }}
                  </span>
                </div>
              </el-form-item>

              <el-form-item label="确认密码" prop="confirmPassword">
                <el-input
                  v-model="form.confirmPassword"
                  size="large"
                  type="password"
                  placeholder="请再次输入密码"
                  :prefix-icon="Lock"
                  show-password
                />
              </el-form-item>

              <el-form-item prop="agree">
                <el-checkbox v-model="form.agree">
                  我已阅读并同意
                  <a href="#" class="text-link">《服务条款》</a>
                  与
                  <a href="#" class="text-link">《隐私政策》</a>
                </el-checkbox>
              </el-form-item>

              <el-button
                type="primary"
                size="large"
                class="btn-submit"
                :loading="loading"
                @click="handleRegister"
              >
                {{ loading ? '注册中...' : '立即注册' }}
              </el-button>
            </el-form>

            <div class="register-link">
              已经有账号？
              <a href="#" @click.prevent="goLogin">直接登录 →</a>
            </div>
          </div>
        </div>
      </div>

      <div class="auth-footer">
        <span>© {{ new Date().getFullYear() }} ADX-Auto. All rights reserved.</span>
        <span class="sep">·</span>
        <a href="#">隐私政策</a>
        <span class="sep">·</span>
        <a href="#">服务条款</a>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.auth-page {
  position: relative;
  min-height: 100vh;
  width: 100%;
  overflow: hidden;
  background: #f8fafc;
}

.bg-decoration {
  position: absolute;
  inset: 0;
  pointer-events: none;
  z-index: 0;
}

.bg-blur {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.55;
}
.bg-blur-1 {
  top: -120px;
  right: -80px;
  width: 520px;
  height: 520px;
  background: radial-gradient(circle, rgba(99, 102, 241, 0.22), transparent 70%);
}
.bg-blur-2 {
  bottom: 30%;
  left: -140px;
  width: 560px;
  height: 560px;
  background: radial-gradient(circle, rgba(138, 5, 255, 0.2), transparent 70%);
}
.bg-blur-3 {
  bottom: -160px;
  right: 30%;
  width: 500px;
  height: 500px;
  background: radial-gradient(circle, rgba(16, 185, 129, 0.15), transparent 70%);
}

.bg-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(138, 5, 255, 0.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(138, 5, 255, 0.05) 1px, transparent 1px);
  background-size: 48px 48px;
  mask-image: radial-gradient(ellipse at center, black 30%, transparent 75%);
}

.auth-container {
  position: relative;
  z-index: 1;
  min-height: 100vh;
  max-width: 1240px;
  margin: 0 auto;
  padding: 28px 32px;
  display: flex;
  flex-direction: column;
}

.back-home {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: var(--adx-text-secondary);
  text-decoration: none;
  padding: 6px 12px;
  background: rgba(255, 255, 255, 0.6);
  backdrop-filter: blur(8px);
  border: 1px solid var(--adx-border-light);
  border-radius: 10px;
  width: fit-content;
  transition: all 0.2s;
  margin-bottom: 24px;

  &:hover {
    color: var(--adx-color-primary);
    border-color: var(--adx-color-primary-light);
    transform: translateX(-2px);
  }
}

.auth-card-wrap {
  flex: 1;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 48px;
  align-items: center;
  min-height: 0;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    gap: 32px;
  }
}

.auth-left {
  color: var(--adx-text-primary);

  @media (max-width: 1024px) {
    text-align: center;
  }
}

.left-logo {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 32px;

  .logo-text {
    display: inline-flex;
    align-items: baseline;
    gap: 3px;
    font-weight: 800;
    font-size: 22px;
    line-height: 1;
  }
  .logo-main {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  .logo-sub {
    color: var(--adx-text-primary);
    font-weight: 600;
  }

  @media (max-width: 1024px) {
    margin: 0 auto 20px;
  }
}

.left-title {
  font-size: 42px;
  font-weight: 800;
  line-height: 1.2;
  margin: 0 0 16px;
  color: var(--adx-text-primary);

  .gradient-text {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }

  @media (max-width: 1280px) { font-size: 34px; }
  @media (max-width: 640px) { font-size: 26px; }
}

.left-desc {
  font-size: 16px;
  line-height: 1.75;
  color: var(--adx-text-secondary);
  max-width: 520px;
  margin: 0 0 32px;

  @media (max-width: 1024px) { margin-left: auto; margin-right: auto; }
}

.benefits-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
  max-width: 520px;

  @media (max-width: 1024px) { margin: 0 auto; }
  @media (max-width: 480px) { grid-template-columns: 1fr; }
}

.benefit-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px;
  background: rgba(255, 255, 255, 0.65);
  backdrop-filter: blur(8px);
  border: 1px solid var(--adx-border-light);
  border-radius: 14px;
  transition: all 0.2s;

  &:hover {
    transform: translateY(-2px);
    box-shadow: var(--adx-shadow-md);
  }
}

.bi-icon {
  flex-shrink: 0;
  width: 42px;
  height: 42px;
  border-radius: 10px;
  color: #fff;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px -4px rgba(99, 102, 241, 0.3);
}

.bi-text {
  min-width: 0;
  .bi-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--adx-text-primary);
    margin-bottom: 2px;
    line-height: 1.3;
  }
  .bi-sub {
    font-size: 12px;
    color: var(--adx-text-tertiary);
    line-height: 1.4;
  }
}

// Right
.auth-right {
  display: flex;
  align-items: center;
  justify-content: center;
}

.auth-card {
  width: 100%;
  max-width: 460px;
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 20px;
  padding: 32px 30px;
  box-shadow: 0 30px 60px -15px rgba(138, 5, 255, 0.15),
    0 0 0 1px rgba(138, 5, 255, 0.03);
}

.auth-title {
  font-size: 24px;
  font-weight: 800;
  color: var(--adx-text-primary);
  margin: 0 0 6px;
  line-height: 1.3;
}

.auth-subtitle {
  font-size: 13.5px;
  color: var(--adx-text-tertiary);
  margin: 0 0 22px;
}

.auth-form {
  :deep(.el-form-item) {
    margin-bottom: 16px;
  }
  :deep(.el-form-item__label) {
    font-size: 13px;
    font-weight: 600;
    color: var(--adx-text-secondary);
  }
  :deep(.el-input__wrapper) {
    border-radius: 12px;
    padding: 4px 14px;
    box-shadow: 0 0 0 1px var(--adx-border-color) inset;
    transition: box-shadow 0.2s;

    &.is-focus {
      box-shadow: 0 0 0 2px rgba(138, 5, 255, 0.22) inset;
    }
  }

  :deep(.el-checkbox__label) {
    font-size: 13px;
    color: var(--adx-text-secondary);
    line-height: 1.6;
  }
}

.text-link {
  color: var(--adx-color-primary);
  text-decoration: none;
  font-weight: 500;
  &:hover { text-decoration: underline; }
}

.strength-bar {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 8px;
}

.strength-block {
  flex: 1;
  height: 5px;
  border-radius: 4px;
  background: var(--adx-border-color);
  max-width: 50px;
  transition: all 0.2s;

  &.active {
    &:nth-child(1) { background: #EF4444; }
    &:nth-child(2) { background: #F59E0B; }
    &:nth-child(3) { background: #3B82F6; }
    &:nth-child(4) { background: #10B981; }
  }
}

.strength-text {
  font-size: 12px;
  color: var(--adx-text-tertiary);
  margin-left: 4px;
  min-width: 32px;
}

.btn-submit {
  width: 100%;
  height: 48px;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: 2px;
  border-radius: 12px;
  background: var(--adx-gradient-primary);
  border: none;
  transition: all 0.25s;
  margin-top: 4px;

  &:hover {
    box-shadow: 0 10px 24px -8px rgba(138, 5, 255, 0.5);
    transform: translateY(-1px);
  }
}

.register-link {
  text-align: center;
  font-size: 13.5px;
  color: var(--adx-text-secondary);
  margin-top: 20px;

  a {
    color: var(--adx-color-primary);
    text-decoration: none;
    font-weight: 600;
    &:hover { text-decoration: underline; }
  }
}

// footer
.auth-footer {
  margin-top: 24px;
  text-align: center;
  font-size: 12px;
  color: var(--adx-text-tertiary);
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  gap: 10px;

  .sep { color: var(--adx-border-color); }

  a {
    color: var(--adx-text-tertiary);
    text-decoration: none;
    &:hover { color: var(--adx-color-primary); }
  }
}
</style>
