<script setup>
import { useRouter } from 'vue-router'
import SectionTitle from '@/views/components/marketing/SectionTitle.vue'
import GradientButton from '@/views/components/marketing/GradientButton.vue'
import NumberCounter from '@/views/components/marketing/NumberCounter.vue'
import FeatureCard from '@/views/components/marketing/FeatureCard.vue'
import HighlightCard from '@/views/components/marketing/HighlightCard.vue'
import PricingCard from '@/views/components/marketing/PricingCard.vue'
import TestimonialCard from '@/views/components/marketing/TestimonialCard.vue'

const router = useRouter()

const goPricing = () => router.push('/pricing')
const goLogin = () => router.push('/login')
const goContact = () => router.push('/faq')

const painPoints = [
  {
    icon: 'Connection',
    title: '操作繁琐效率低',
    desc: '多账号频繁切换，手动创建广告耗时耗力，Offer上线需要数天才能完成，团队协作效率极低。',
    color: '#F59E0B'
  },
  {
    icon: 'Warning',
    title: '账号关联风险高',
    desc: '同一环境操作多个账号容易被Google关联封号，账号丢失造成巨大损失，安全隐患无时不在。',
    color: '#EF4444'
  },
  {
    icon: 'Money',
    title: '投放成本不可控',
    desc: '预算浪费严重，关键词出价全靠经验，CTR/CVR长期低迷，补点击和换链接没有系统化工具支撑。',
    color: '#6366F1'
  }
]

const coreFeatures = [
  {
    icon: 'UserFilled',
    title: 'Ads账号管理',
    description: '多账号集中化管理，一键同步MCC数据，权限分级保障安全',
    features: [
      'MCC一键录入+子账号同步',
      '多账号数据集中展示',
      '权限分级/角色管理',
      '账号状态实时监控'
    ]
  },
  {
    icon: 'DataAnalysis',
    title: '广告全维度管理',
    description: '覆盖广告系列、广告组、广告、关键词全链路运营操作',
    features: [
      '广告系列批量创建/调整',
      '广告组结构优化',
      '广告一键启停/批量更新',
      '关键词批量添加/否定'
    ]
  },
  {
    icon: 'MagicStick',
    title: '自动广告生成',
    description: 'AI驱动的创意引擎，爬虫+大模型自动产出高质量广告',
    features: [
      '爬虫采集竞品落地页',
      'AI生成3组差异化创意',
      '一键提交Google Ads',
      '多语言多场景适配'
    ]
  },
  {
    icon: 'Setting',
    title: '系统灵活配置',
    description: '丰富的第三方集成，满足不同规模团队的个性化需求',
    features: [
      '5家代理厂商API接入',
      '13+AI模型自由切换',
      '自定义提示词模板',
      'AI调用成本可视化控制'
    ]
  }
]

const highlights = [
  {
    icon: 'Refresh',
    title: '双向数据同步 · 无需API审批',
    description: '独创数据同步机制，无需申请Google Ads官方API即可实现双向数据互通，上线时间从数周缩短到10分钟。',
    points: ['支持MCC及子账号双向同步', '数据延迟低于5分钟', '账号秒级接入无门槛']
  },
  {
    icon: 'Aim',
    title: '精准补点击算法 · 模拟自然流量',
    description: '基于真实用户行为模型的补点击引擎，多维度行为模拟规避检测，大幅提升广告质量得分。',
    points: ['设备/地域/时段精准匹配', '停留时长/深度点击模拟', '点击成本/频次智能控制']
  },
  {
    icon: 'Link',
    title: '严谨换链接逻辑 · 数据闭环',
    description: '多层级换链接策略，确保广告数据与落地页数据全程可追溯，归因准确不丢失。',
    points: ['支持短链/追踪链/跳转链', '曝光-点击-转化全链路追踪', 'A/B测试分组自动管理']
  },
  {
    icon: 'Clock',
    title: '高效定时任务 · 全程可追溯',
    description: '可视化定时任务调度，支持Crontab表达式，执行日志完整记录便于复盘审计。',
    points: ['可视化任务配置面板', '失败重试/异常告警', '完整执行日志存档']
  },
  {
    icon: 'Grid',
    title: '丰富配置能力 · 降低依赖风险',
    description: '支持5家代理厂商+13+AI模型自由切换，避免单一供应商锁死，成本和风险双降。',
    points: ['代理/模型快速切换', '调用成本透明可查', '故障自动降级备用']
  },
  {
    icon: 'Lock',
    title: '顶级防关联设计 · 保障账号安全',
    description: '独立环境隔离+指纹随机化+代理轮换，从底层杜绝账号关联，封号风险下降90%。',
    points: ['账号环境100%隔离', '浏览器指纹动态随机', '代理池自动健康检测']
  }
]

const valueMetrics = [
  { endValue: 80, suffix: '%', label: '效率提升', icon: 'Lightning' },
  { endValue: 40, suffix: '%', label: '成本降低', icon: 'TrendCharts' },
  { endValue: 90, suffix: '%', label: '风险控制', icon: 'Shield' },
  { endValue: 99, suffix: '%', label: '数据完整', icon: 'PieChart' },
  { endValue: 3, suffix: 'x', label: 'Offer挖掘', icon: 'Gem' },
  { endValue: 5, suffix: 'x', label: '团队协作', icon: 'User' }
]

const testimonials = [
  {
    quote:
      '之前我们团队要3个人手动管理20多个Ads账号，每天切换代理和指纹浏览器头都大了。用了ADX-Auto后，1个人就能搞定，关键是再也没出现过账号关联封号的情况，ROI提升了将近一倍！',
    name: '张明远',
    position: '投放总监',
    company: '某跨境电商独立站',
    avatarColors: ['#8A05FF', '#6366F1'],
    metrics: [
      { value: '+92%', label: 'ROI提升' },
      { value: '-70%', label: '人力成本' }
    ]
  },
  {
    quote:
      'AI自动生成广告创意这个功能太惊艳了！以前写3组文案+配图要大半天，现在输入落地页链接，几分钟就能出好几套方案，而且效果比我们手动写的CTR还高20%左右。',
    name: '李思琪',
    position: '创意负责人',
    company: '某数字营销代理公司',
    avatarColors: ['#F59E0B', '#EF4444'],
    metrics: [
      { value: '+21%', label: '平均CTR' },
      { value: '5x', label: '创意产能' }
    ]
  },
  {
    quote:
      '补点击和换链接一直是行业灰色地带，ADX-Auto把这块做到了系统化、可配置、可追溯。我们的账号质量得分稳步上升，CPC下降了近三分之一，客户续费率也涨了不少。',
    name: '王海峰',
    position: '创始人',
    company: '某出海MCN机构',
    avatarColors: ['#10B981', '#3B82F6'],
    metrics: [
      { value: '-31%', label: '平均CPC' },
      { value: '+45%', label: '客户续费率' }
    ]
  }
]

const pricingPlans = [
  {
    name: '年费版',
    tagline: '适合中小团队快速上手',
    price: '9,800',
    period: '年',
    badge: '',
    highlight: false,
    ctaText: '立即购买',
    features: [
      '最多管理 20 个Ads账号',
      'AI创意生成 2,000 次/月',
      '补点击 10,000 次/月',
      '换链接 500 次/月',
      '定时任务 200 次/月',
      '标准代理API接入（2家）',
      '5个团队成员席位',
      '邮件工单支持 7x12h',
      '基础数据报表导出'
    ]
  },
  {
    name: '两年版',
    tagline: '最受欢迎，送2个月时长',
    price: '17,800',
    period: '2年+2月',
    badge: '🔥 最受欢迎',
    highlight: true,
    ctaText: '立即购买',
    features: [
      '最多管理 100 个Ads账号',
      'AI创意生成 20,000 次/月',
      '补点击 100,000 次/月',
      '换链接 5,000 次/月',
      '定时任务 2,000 次/月',
      '全部5家代理API接入',
      '20个团队成员席位',
      '专属客户经理 + 钉钉群',
      '高级数据看板 + BI对接',
      '定制化提示词模板库'
    ]
  },
  {
    name: '永久版',
    tagline: '终身授权，一次投入持续收益',
    price: '39,800',
    period: '永久',
    badge: '',
    highlight: false,
    ctaText: '立即购买',
    features: [
      'Ads账号数量无上限',
      'AI创意生成 不限次数',
      '补点击 不限次数',
      '换链接 不限次数',
      '定时任务 不限次数',
      '全部5家代理API接入',
      '团队成员 不限席位',
      '7x24 一对一VIP支持',
      '私有化部署支持',
      '定制功能开发优先权',
      '未来新功能免费更新'
    ]
  }
]
</script>

<template>
  <div class="home-page">
    <!-- ============================================================ -->
    <!-- Section 1: Hero -->
    <!-- ============================================================ -->
    <section class="hero-section">
      <div class="hero-bg-decor">
        <div class="bg-blur bg-blur-1"></div>
        <div class="bg-blur bg-blur-2"></div>
      </div>

      <div class="adx-container hero-inner">
        <div class="hero-left">
          <div class="hero-badge">
            <el-icon color="#8A05FF"><Stars /></el-icon>
            <span>Google Ads 全流程自动化 · 无需API审批即可接入</span>
          </div>

          <h1 class="hero-title">
            告别繁琐操作，让
            <span class="highlight"> Google Ads 投放 </span>
            更安全、更高效、更简单
          </h1>

          <p class="hero-desc">
            ADX-Auto
            一站式广告管理系统，无需申请Google Ads
            API、无需频繁切换代理和指纹浏览器，10分钟完成Offer上线，多账号隔离管理，补点击/换链接智能执行，AI生成广告创意，全面提升投放效率与安全性。即使是新入行的小白都能轻松驾驭！
          </p>

          <div class="hero-actions">
            <GradientButton size="large" @click="goPricing">
              立即购买
              <el-icon><ArrowRight /></el-icon>
            </GradientButton>
            <el-button size="large" class="btn-outline" @click="goContact">
              <el-icon><Calendar /></el-icon>
              预约演示
            </el-button>
            <el-button size="large" text class="btn-login" @click="goLogin">
              登录系统 <el-icon><ArrowRight /></el-icon>
            </el-button>
          </div>

          <div class="hero-trust">
            <div class="trust-item">
              <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
              <span>500+ 团队信赖</span>
            </div>
            <div class="trust-item">
              <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
              <span>10万+ 账号运营</span>
            </div>
            <div class="trust-item">
              <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
              <span>99.9% 可用性</span>
            </div>
          </div>
        </div>

        <div class="hero-right">
          <div class="dashboard-preview">
            <div class="preview-header">
              <div class="preview-dots">
                <span class="dot red"></span>
                <span class="dot yellow"></span>
                <span class="dot green"></span>
              </div>
              <div class="preview-title">ADX-Auto 控制台</div>
              <div class="preview-spacer"></div>
            </div>

            <div class="preview-body">
              <div class="preview-stats">
                <div class="stat-card">
                  <div class="stat-label">今日消耗</div>
                  <div class="stat-value">¥ 128,560</div>
                  <div class="stat-trend up">↑ 12.5%</div>
                </div>
                <div class="stat-card">
                  <div class="stat-label">展示次数</div>
                  <div class="stat-value">2.38M</div>
                  <div class="stat-trend up">↑ 8.3%</div>
                </div>
                <div class="stat-card">
                  <div class="stat-label">点击次数</div>
                  <div class="stat-value">156,420</div>
                  <div class="stat-trend down">↓ 1.2%</div>
                </div>
                <div class="stat-card">
                  <div class="stat-label">ROAS</div>
                  <div class="stat-value">3.24x</div>
                  <div class="stat-trend up">↑ 18.7%</div>
                </div>
              </div>

              <div class="preview-chart">
                <div class="chart-bar-wrap">
                  <div class="chart-bar" style="height: 45%; background: linear-gradient(180deg, #A855F7 0%, #6366F1 100%);"></div>
                  <div class="chart-bar" style="height: 65%; background: linear-gradient(180deg, #A855F7 0%, #6366F1 100%);"></div>
                  <div class="chart-bar" style="height: 50%; background: linear-gradient(180deg, #A855F7 0%, #6366F1 100%);"></div>
                  <div class="chart-bar" style="height: 80%; background: linear-gradient(180deg, #A855F7 0%, #6366F1 100%);"></div>
                  <div class="chart-bar" style="height: 70%; background: linear-gradient(180deg, #A855F7 0%, #6366F1 100%);"></div>
                  <div class="chart-bar" style="height: 92%; background: linear-gradient(180deg, #A855F7 0%, #6366F1 100%);"></div>
                  <div class="chart-bar" style="height: 78%; background: linear-gradient(180deg, #A855F7 0%, #6366F1 100%);"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Section 2: 痛点 -->
    <!-- ============================================================ -->
    <section class="adx-section pain-section">
      <div class="adx-container">
        <SectionTitle
          title="你是否正面临这些投放难题？"
          subtitle="做Google Ads的人都懂的痛，ADX-Auto一次性帮你彻底解决"
        />

        <div class="pain-grid">
          <div v-for="(p, idx) in painPoints" :key="idx" class="pain-card">
            <div class="pain-icon" :style="{ background: `${p.color}15`, color: p.color }">
              <el-icon :size="28"><component :is="p.icon" /></el-icon>
            </div>
            <h3 class="pain-title">{{ p.title }}</h3>
            <p class="pain-desc">{{ p.desc }}</p>
          </div>
        </div>
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Section 3: 核心功能 -->
    <!-- ============================================================ -->
    <section class="adx-section feature-section">
      <div class="adx-container">
        <SectionTitle
          title="四大核心功能模块，覆盖投放全链路"
          subtitle="从账号管理到创意生成，从自动执行到系统配置，真正做到端到端自动化"
        />

        <div class="feature-grid">
          <FeatureCard
            v-for="(f, idx) in coreFeatures"
            :key="idx"
            :icon="f.icon"
            :title="f.title"
            :description="f.description"
            :features="f.features"
          />
        </div>
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Section 4: 系统亮点 -->
    <!-- ============================================================ -->
    <section class="adx-section highlight-section">
      <div class="adx-container">
        <SectionTitle
          title="六大差异化优势，行业领先设计"
          subtitle="经过500+团队实战打磨的核心能力，拉开与普通工具的本质差距"
        />

        <div class="highlight-grid">
          <HighlightCard
            v-for="(h, idx) in highlights"
            :key="idx"
            :icon="h.icon"
            :title="h.title"
            :description="h.description"
            :points="h.points"
          />
        </div>
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Section 5: 系统价值 -->
    <!-- ============================================================ -->
    <section class="adx-section value-section">
      <div class="adx-container">
        <SectionTitle
          title="用数据说话，见证真实系统价值"
          subtitle="基于500+付费客户实际使用数据统计，结果超乎想象"
        />

        <div class="value-grid">
          <div v-for="(m, idx) in valueMetrics" :key="idx" class="value-card">
            <div class="value-icon">
              <el-icon :size="28"><component :is="m.icon" /></el-icon>
            </div>
            <div class="value-number">
              <NumberCounter :endValue="m.endValue" :suffix="m.suffix" :duration="2200" />
            </div>
            <div class="value-label">{{ m.label }}</div>
          </div>
        </div>
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Section 6: 客户案例 -->
    <!-- ============================================================ -->
    <section class="adx-section testimonial-section">
      <div class="adx-container">
        <SectionTitle
          title="来自一线投放团队的真实反馈"
          subtitle="不吹不黑，看看真实用户使用ADX-Auto后的亲身体验"
        />

        <div class="testimonial-grid">
          <TestimonialCard
            v-for="(t, idx) in testimonials"
            :key="idx"
            :quote="t.quote"
            :name="t.name"
            :position="t.position"
            :company="t.company"
            :avatarColors="t.avatarColors"
            :metrics="t.metrics"
          />
        </div>
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Section 7: 价格方案 -->
    <!-- ============================================================ -->
    <section class="adx-section pricing-section">
      <div class="adx-container">
        <SectionTitle
          title="选择适合你的方案，开启高效投放之旅"
          subtitle="灵活定价，年付/两年付/永久多种选择，总有一款适合你"
        />

        <div class="pricing-grid">
          <PricingCard
            v-for="(p, idx) in pricingPlans"
            :key="idx"
            :name="p.name"
            :tagline="p.tagline"
            :price="p.price"
            :period="p.period"
            :badge="p.badge"
            :highlight="p.highlight"
            :features="p.features"
            :ctaText="p.ctaText"
            @cta="goPricing"
          />
        </div>
      </div>
    </section>

    <!-- ============================================================ -->
    <!-- Section 8: CTA 行动号召 -->
    <!-- ============================================================ -->
    <section class="cta-section">
      <div class="adx-container cta-inner">
        <div class="cta-bg-decor"></div>
        <div class="cta-content">
          <h2 class="cta-title">
            还在犹豫？现在就联系我们，
            <br class="hide-mobile" />
            让你的 Google Ads 投放效能翻倍
          </h2>
          <p class="cta-desc">
            30分钟专属演示 · 7天免费试用 · 不满意全额退款 ·
            1对1专属顾问全程陪跑
          </p>
          <div class="cta-actions">
            <GradientButton size="large" @click="goPricing">
              立即购买
              <el-icon><ArrowRight /></el-icon>
            </GradientButton>
            <el-button size="large" class="cta-outline" @click="goContact">
              <el-icon><Phone /></el-icon>
              联系销售
            </el-button>
          </div>
          <div class="cta-contact-row">
            <div class="contact-item">
              <el-icon><Message /></el-icon>
              <span>support@adx-auto.com</span>
            </div>
            <div class="contact-item">
              <el-icon><Phone /></el-icon>
              <span>400-888-1234</span>
            </div>
            <div class="contact-item">
              <el-icon><Service /></el-icon>
              <span>7x12 在线客服</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.home-page {
  background: var(--adx-bg-color);
}

// ============================================================
// Hero Section
// ============================================================
.hero-section {
  position: relative;
  overflow: hidden;
  padding: 64px 0 96px;
  background: linear-gradient(
    180deg,
    rgba(138, 5, 255, 0.06) 0%,
    rgba(99, 102, 241, 0.04) 40%,
    var(--adx-bg-color) 100%
  );

  @media (max-width: 1024px) {
    padding: 48px 0 64px;
  }
}

.hero-bg-decor {
  position: absolute;
  inset: 0;
  pointer-events: none;
  overflow: hidden;
}

.bg-blur {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.5;
}
.bg-blur-1 {
  top: -120px;
  right: -100px;
  width: 520px;
  height: 520px;
  background: radial-gradient(circle, rgba(138, 5, 255, 0.22) 0%, transparent 70%);
}
.bg-blur-2 {
  bottom: -160px;
  left: -80px;
  width: 460px;
  height: 460px;
  background: radial-gradient(circle, rgba(99, 102, 241, 0.18) 0%, transparent 70%);
}

.hero-inner {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: 1.05fr 1fr;
  gap: 64px;
  align-items: center;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    gap: 48px;
  }
}

.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 14px;
  background: rgba(138, 5, 255, 0.08);
  border: 1px solid rgba(138, 5, 255, 0.18);
  border-radius: 9999px;
  font-size: 13px;
  font-weight: 500;
  color: #8a05ff;
  margin-bottom: 24px;
}

.hero-title {
  font-size: 52px;
  font-weight: 800;
  line-height: 1.2;
  color: var(--adx-text-primary);
  margin: 0 0 24px;

  .highlight {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }

  @media (max-width: 1280px) {
    font-size: 44px;
  }
  @media (max-width: 1024px) {
    font-size: 38px;
  }
  @media (max-width: 768px) {
    font-size: 28px;
  }
}

.hero-desc {
  font-size: 17px;
  line-height: 1.85;
  color: var(--adx-text-secondary);
  margin: 0 0 36px;
  max-width: 620px;

  @media (max-width: 768px) {
    font-size: 15px;
    margin-bottom: 28px;
  }
}

.hero-actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 14px;
  margin-bottom: 36px;
}

.btn-outline {
  border: 2px solid var(--adx-border-color);
  color: var(--adx-text-primary);
  font-weight: 600;
  border-radius: 12px;
  height: 46px;
  padding: 0 22px;
}

.btn-login {
  color: var(--adx-color-primary);
  font-weight: 600;
  padding: 0 8px;
}

.hero-trust {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 24px;
}

.trust-item {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  color: var(--adx-text-secondary);
  font-weight: 500;
}

// Dashboard Preview
.hero-right {
  position: relative;
}

.dashboard-preview {
  position: relative;
  background: var(--adx-bg-card);
  border-radius: 20px;
  box-shadow: 0 30px 60px -15px rgba(99, 102, 241, 0.25),
    0 0 0 1px rgba(99, 102, 241, 0.08);
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: -30%;
    right: -20%;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(138, 5, 255, 0.18) 0%, transparent 70%);
    pointer-events: none;
  }
}

.preview-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 20px;
  border-bottom: 1px solid var(--adx-border-light);
  background: rgba(248, 250, 252, 0.7);
}

.preview-dots {
  display: inline-flex;
  gap: 6px;
}
.preview-dots .dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  display: inline-block;
}
.dot.red { background: #EF4444; }
.dot.yellow { background: #F59E0B; }
.dot.green { background: #10B981; }

.preview-title {
  font-size: 13px;
  color: var(--adx-text-secondary);
  font-weight: 500;
}

.preview-spacer {
  flex: 1;
}

.preview-body {
  padding: 24px;
  position: relative;
  z-index: 1;
}

.preview-stats {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 14px;
  margin-bottom: 20px;
}

.stat-card {
  background: linear-gradient(135deg, rgba(138, 5, 255, 0.04) 0%, rgba(99, 102, 241, 0.04) 100%);
  border: 1px solid rgba(99, 102, 241, 0.08);
  border-radius: 14px;
  padding: 14px;
}

.stat-label {
  font-size: 12px;
  color: var(--adx-text-tertiary);
  margin-bottom: 6px;
}

.stat-value {
  font-size: 20px;
  font-weight: 800;
  background: var(--adx-gradient-primary);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  margin-bottom: 4px;
}

.stat-trend {
  font-size: 12px;
  font-weight: 600;
  &.up { color: var(--adx-color-success); }
  &.down { color: var(--adx-color-danger); }
}

.preview-chart {
  height: 160px;
  padding: 16px;
  background: rgba(248, 250, 252, 0.5);
  border-radius: 14px;
  border: 1px solid var(--adx-border-light);
}

.chart-bar-wrap {
  display: flex;
  align-items: flex-end;
  justify-content: space-around;
  height: 100%;
  gap: 10px;
}

.chart-bar {
  flex: 1;
  border-radius: 6px 6px 0 0;
  max-width: 40px;
  opacity: 0.85;
}

// ============================================================
// Pain Section
// ============================================================
.pain-section {
  background: var(--adx-bg-secondary);
}

.pain-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;

  @media (max-width: 1024px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
}

.pain-card {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  padding: 32px;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-4px);
    box-shadow: var(--adx-shadow-lg);
  }
}

.pain-icon {
  width: 60px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 14px;
  margin-bottom: 20px;
}

.pain-title {
  font-size: 20px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin: 0 0 12px;
}

.pain-desc {
  font-size: 14.5px;
  color: var(--adx-text-secondary);
  line-height: 1.8;
  margin: 0;
}

// ============================================================
// Feature Section
// ============================================================
.feature-section {
  background: var(--adx-bg-color);
}

.feature-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 24px;

  @media (max-width: 1280px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
}

// ============================================================
// Highlight Section
// ============================================================
.highlight-section {
  background: var(--adx-bg-secondary);
}

.highlight-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;

  @media (max-width: 1280px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
}

// ============================================================
// Value Section
// ============================================================
.value-section {
  background: var(--adx-bg-color);
}

.value-grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 20px;

  @media (max-width: 1280px) {
    grid-template-columns: repeat(3, 1fr);
  }
  @media (max-width: 640px) {
    grid-template-columns: repeat(2, 1fr);
  }
}

.value-card {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  padding: 28px 20px;
  text-align: center;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-4px);
    box-shadow: var(--adx-shadow-md);
    border-color: var(--adx-color-primary-light);
  }
}

.value-icon {
  width: 52px;
  height: 52px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 14px;
  background: var(--adx-gradient-primary);
  color: #fff;
  margin-bottom: 16px;
  box-shadow: 0 6px 16px -4px rgba(99, 102, 241, 0.35);
}

.value-number {
  font-size: 42px;
  margin-bottom: 8px;
}

.value-label {
  font-size: 14px;
  color: var(--adx-text-secondary);
  font-weight: 500;
}

// ============================================================
// Testimonial Section
// ============================================================
.testimonial-section {
  background: var(--adx-bg-secondary);
}

.testimonial-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    max-width: 640px;
    margin: 0 auto;
  }
}

// ============================================================
// Pricing Section
// ============================================================
.pricing-section {
  background: var(--adx-bg-color);
}

.pricing-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 32px;
  align-items: stretch;
  max-width: 1120px;
  margin: 0 auto;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    max-width: 460px;
    gap: 24px;
  }
}

// ============================================================
// CTA Section
// ============================================================
.cta-section {
  padding: 64px 0;
  background: var(--adx-bg-color);
}

.cta-inner {
  position: relative;
  border-radius: 24px;
  overflow: hidden;
  background: linear-gradient(135deg, #8a05ff 0%, #6366f1 100%);
}

.cta-bg-decor {
  position: absolute;
  inset: 0;
  pointer-events: none;

  &::before {
    content: '';
    position: absolute;
    top: -80px;
    right: -60px;
    width: 300px;
    height: 300px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.12);
    filter: blur(40px);
  }
  &::after {
    content: '';
    position: absolute;
    bottom: -100px;
    left: -60px;
    width: 360px;
    height: 360px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.08);
    filter: blur(50px);
  }
}

.cta-content {
  position: relative;
  z-index: 1;
  padding: 64px 48px;
  text-align: center;
  color: #fff;

  @media (max-width: 768px) {
    padding: 48px 24px;
  }
}

.cta-title {
  font-size: 34px;
  font-weight: 800;
  line-height: 1.35;
  margin: 0 0 16px;
  color: #fff;

  @media (max-width: 768px) {
    font-size: 24px;

    .hide-mobile { display: none; }
  }
}

.cta-desc {
  font-size: 16px;
  line-height: 1.75;
  margin: 0 0 32px;
  color: rgba(255, 255, 255, 0.9);
}

.cta-actions {
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 14px;
  margin-bottom: 28px;
}

.cta-actions :deep(.gradient-btn) {
  background: #fff;
  color: var(--adx-color-primary);

  &:hover {
    background: #f8fafc;
    color: var(--adx-color-purple);
  }
}

.cta-outline {
  background: transparent;
  border: 2px solid rgba(255, 255, 255, 0.35);
  color: #fff;
  font-weight: 600;
  height: 46px;
  border-radius: 12px;
  padding: 0 22px;

  &:hover {
    background: rgba(255, 255, 255, 0.12);
    border-color: rgba(255, 255, 255, 0.55);
    color: #fff;
  }
}

.cta-contact-row {
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 28px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.contact-item {
  display: inline-flex;
  align-items: center;
  gap: 8px;

  .el-icon {
    color: rgba(255, 255, 255, 0.85);
  }
}
</style>
