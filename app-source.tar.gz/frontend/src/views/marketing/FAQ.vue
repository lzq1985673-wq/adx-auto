<script setup>
import { useRouter } from 'vue-router'
import SectionTitle from '@/views/components/marketing/SectionTitle.vue'
import GradientButton from '@/views/components/marketing/GradientButton.vue'

const router = useRouter()
const goPricing = () => router.push('/pricing')

const faqs = [
  {
    category: '入门与购买',
    items: [
      {
        q: 'Q1: 我是新手，完全没用过 Google Ads，能上手 ADX-Auto 吗？',
        a: '完全可以！ADX-Auto 的目标用户就包括新入行的小白。我们有图文+视频的新手引导，以及30分钟的1对1陪跑服务，即使没有广告投放经验，也能在1-2天内掌握基本操作。系统还内置了大量行业模板和最佳实践建议。'
      },
      {
        q: 'Q2: 如何开始使用？需要准备哪些材料？',
        a: '购买后我们会在10分钟内为你开通账号（工作时间），然后通过欢迎邮件指引你：①登录系统 → ②绑定你的 Google Ads MCC（只需授权，无需Developer Token）→ ③配置代理和AI模型（可一键默认）→ ④开始使用。你只需要有可用的MCC账号即可。'
      },
      {
        q: 'Q3: 是否需要申请 Google Ads API (Developer Token)？',
        a: '不需要。ADX-Auto 独创的双向同步机制，不需要你申请 Google 官方的 Developer Token。传统申请需要数周审批还可能被拒，我们直接省掉了这一步，只需授权登录即可同步所有账号数据，这是我们的核心亮点之一。'
      },
      {
        q: 'Q4: 支持哪些付款方式？是否可以开发票？',
        a: '支持支付宝、微信支付、对公打款、USDT 等多种方式。支持开具增值税专用发票和普通发票，发票内容为"软件服务费"或"技术服务费"。企业版客户支持分期付款和合同签订。'
      },
      {
        q: 'Q5: 购买后可以退款吗？',
        a: '可以。年费版 7 天无理由退款，两年版 30 天无理由，永久版 60 天无理由。只要你觉得不满意，不需要任何理由即可全额退款。我们对产品有足够的自信，这也是我们对你的承诺。'
      }
    ]
  },
  {
    category: '账号与安全',
    items: [
      {
        q: 'Q6: 最多支持管理多少个 Google Ads 账号？',
        a: '年费版上限 20 个 Ads 子账号，两年版 100 个，永久版不限数量。同时年费版支持绑定 5 个 MCC，两年版 20 个 MCC，永久版不限 MCC。如果你的规模超出上述范围，可以联系我们的企业销售定制方案。'
      },
      {
        q: 'Q7: 账号安全吗？会有被关联封号的风险吗？',
        a: 'ADX-Auto 从底层设计就以账号安全为第一优先级：①每个账号绑定独立的浏览器环境和指纹；②独立代理出口（支持5家代理厂商接入）；③操作行为模型模拟真人节奏（不会批量秒操作）；④内置风控规则自动熔断异常行为。综合下来封号风险下降 90%。'
      },
      {
        q: 'Q8: 你们会看到我 Ads 账号里的数据吗？',
        a: '系统默认是 SaaS 部署，数据按租户严格隔离，只有你的团队成员可见。对数据安全有更高要求的客户，可以选择永久版+私有化部署方案，数据完全存储在你自己的服务器，我们连数据库都碰不到。'
      },
      {
        q: 'Q9: 支持给团队成员分配不同权限吗？',
        a: '当然支持。系统内置"管理员/运营主管/优化师/创意/财务/只读"等多种角色，也可以自定义角色和权限。每个操作都会完整记录操作日志，谁在什么时候做了什么操作，都可以在审计日志里精确查询。'
      }
    ]
  },
  {
    category: '核心功能原理',
    items: [
      {
        q: 'Q10: 补点击的原理是什么？会不会被 Google 检测到？',
        a: 'ADX-Auto 的补点击不是简单的"刷点击"，而是基于数百万真实用户行为数据训练的模型：多维度精准匹配（设备/地域/ISP/时段/浏览器）、多行为链路模拟（停留时长/滚动深度/点击热区/二跳/返回）、频次与成本控制。每个环节都贴近真实用户，Google 无法区分。'
      },
      {
        q: 'Q11: 换链接一般多久换一次？你们如何控制频率？',
        a: '换链接频率由用户根据自己的策略配置，从"每次点击动态换链"到"每N小时/每M次展示换一次"均可灵活配置。系统保证：①UTM与ClickID全程透传不丢；②A/B分组严格一致；③落地页异常时自动切换备用链接。'
      },
      {
        q: 'Q12: AI 生成广告创意的效果如何？怎么保证质量？',
        a: 'AI创意基于落地页爬虫+行业最佳实践+竞品参考三方面综合生成，一次产出3组差异化方案并附带质量预估。我们建议第一次使用时人工挑选+微调，随后就可以直接提交。500+客户的实际数据显示，AI创意的平均 CTR 比纯人工高约 18%。'
      },
      {
        q: 'Q13: 双向数据同步的实时性如何？延迟大吗？',
        a: '核心数据（消耗、展示、点击、转化）同步延迟通常在 3-5 分钟，后台操作（启停广告、调整预算等）在 Google 端生效是毫秒级。对于需要实时数据监控的客户，我们还支持"极速同步模式"，可以将关键指标同步延迟压缩到 60 秒以内。'
      }
    ]
  },
  {
    category: 'AI 模型与成本',
    items: [
      {
        q: 'Q14: AI 调用需要另外付费吗？是否设置上限？',
        a: '在版本额度范围内不另外收费。年费版每月 2000 次 AI 创意，两年版 20000 次，永久版不限。你可以在系统中看到每一个模型的调用价格，但我们不会赚 AI 的差价——你付的只是软件授权费，超额部分我们只收成本价。'
      },
      {
        q: 'Q15: 支持哪些 AI 模型？可以自己换吗？',
        a: '目前内置支持 13 款大模型：GPT-4o / GPT-4o-mini / Claude 3.5 Sonnet / Claude 3 Opus / Gemini 1.5 Pro / 通义千问-max / 通义千问-plus / 文心一言 4.0 / DeepSeek V2 / 月之暗面 Kimi / 智谱 GLM-4 / 腾讯混元 / 字节豆包。你可以随时切换对比，或设置主备自动降级。'
      },
      {
        q: 'Q16: 提示词可以自定义吗？还是只能用内置的？',
        a: '都支持。系统内置了电商、游戏、SaaS、B2B、App等多个行业的模板库。你也可以完全自定义自己的提示词，并保存为模板在团队内共享。永久版客户还可以让我们协助定制专属私有模板库。'
      }
    ]
  },
  {
    category: '服务与支持',
    items: [
      {
        q: 'Q17: 客户支持渠道有哪些？响应时间多久？',
        a: '年费版：邮件工单 7x12h（工作日4小时内响应）；两年版：1对1客户经理+专属钉钉/企业微信群（工作时间30分钟内响应）；永久版：7x24 VIP支持（15分钟内响应）+ 专属技术群。企业客户额外提供 SLA 99.9% 可用性保障。'
      },
      {
        q: 'Q18: 是否提供使用教程和培训？',
        a: '提供。系统内置帮助中心、视频教程、最佳实践文档库；购买后附赠30分钟1对1陪跑；两年版和永久版客户每月可预约一次深度优化咨询；企业客户可安排线下培训和入驻式带教。'
      },
      {
        q: 'Q19: 产品更新频率如何？新功能另外收费吗？',
        a: '我们的团队保持平均每 2 周一个小版本、每月一个中版本、每季度一个大版本的迭代节奏。所有现有客户的功能更新全部免费，不会因为加了新功能就额外收费。两年版和永久版客户还可以优先体验内测新功能。'
      },
      {
        q: 'Q20: 如果我中途想升级套餐（如年费 → 两年版），可以补差价吗？',
        a: '可以，随时可以升级，且按原价折算已使用天数补差价即可。比如年费版用了3个月想升级两年版，只需补足两年版总价减去原年费版价格的 9/12。降级则不支持，但我们相信你只会想升级不会想降级。'
      }
    ]
  }
]
</script>

<template>
  <div class="faq-page">
    <!-- Page Hero -->
    <section class="page-hero">
      <div class="adx-container">
        <div class="page-hero-inner">
          <span class="page-tag">常见问题 · FAQ</span>
          <h1 class="page-title">20个高频问题，为你彻底解答疑惑</h1>
          <p class="page-desc">
            购买前、使用中、升级时，你的疑问这里几乎都有答案。如果还不够，欢迎直接联系我们。
          </p>
        </div>
      </div>
    </section>

    <!-- FAQ Content -->
    <section class="adx-section">
      <div class="adx-container faq-container">
        <div class="faq-side">
          <div class="side-card">
            <div class="side-title">快速导航</div>
            <ul class="side-nav">
              <li v-for="(c, cidx) in faqs" :key="cidx">
                <a :href="`#cat-${cidx}`">
                  <span class="nav-dot"></span>
                  {{ c.category }}
                </a>
              </li>
            </ul>
            <div class="side-contact">
              <div class="sc-title">还没找到答案？</div>
              <div class="sc-item">
                <el-icon color="#8A05FF"><Message /></el-icon>
                <span>support@adx-auto.com</span>
              </div>
              <div class="sc-item">
                <el-icon color="#8A05FF"><Phone /></el-icon>
                <span>400-888-1234</span>
              </div>
              <GradientButton class="sc-btn" size="default" @click="goPricing">
                查看价格方案
                <el-icon><ArrowRight /></el-icon>
              </GradientButton>
            </div>
          </div>
        </div>

        <div class="faq-main">
          <div v-for="(c, cidx) in faqs" :key="cidx" class="faq-cat-block" :id="`cat-${cidx}`">
            <SectionTitle
              :title="c.category"
              center="false"
            />
            <el-collapse accordion class="adx-collapse">
              <el-collapse-item
                v-for="(item, iidx) in c.items"
                :key="iidx"
                :name="`${cidx}-${iidx}`"
              >
                <template #title>
                  <div class="collapse-title">{{ item.q }}</div>
                </template>
                <div class="collapse-content">{{ item.a }}</div>
              </el-collapse-item>
            </el-collapse>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="page-cta">
      <div class="adx-container">
        <div class="cta-card">
          <h3>问题解答完毕，是时候让投放起飞了</h3>
          <p>选择适合你的方案，或联系我们获取行业解决方案与专属演示。</p>
          <div class="cta-actions">
            <GradientButton size="large" @click="goPricing">
              查看价格方案
              <el-icon><ArrowRight /></el-icon>
            </GradientButton>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.faq-page {
  background: var(--adx-bg-color);
}

.page-hero {
  padding: 80px 0 48px;
  background: linear-gradient(
    180deg,
    rgba(99, 102, 241, 0.06) 0%,
    rgba(138, 5, 255, 0.03) 50%,
    var(--adx-bg-color) 100%
  );
  text-align: center;
}

.page-tag {
  display: inline-block;
  padding: 5px 14px;
  background: rgba(99, 102, 241, 0.08);
  border: 1px solid rgba(99, 102, 241, 0.18);
  color: var(--adx-color-primary);
  border-radius: 9999px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 18px;
}

.page-title {
  font-size: 44px;
  font-weight: 800;
  line-height: 1.3;
  margin: 0 0 18px;
  background: var(--adx-gradient-primary);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;

  @media (max-width: 1024px) { font-size: 32px; }
  @media (max-width: 640px) { font-size: 24px; }
}

.page-desc {
  font-size: 17px;
  color: var(--adx-text-secondary);
  line-height: 1.8;
  max-width: 780px;
  margin: 0 auto;

  @media (max-width: 640px) { font-size: 15px; }
}

// FAQ layout
.faq-container {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 32px;
  align-items: flex-start;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
}

.faq-side {
  position: sticky;
  top: 90px;

  @media (max-width: 1024px) {
    position: relative;
    top: 0;
  }
}

.side-card {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  padding: 20px;
  box-shadow: var(--adx-shadow-xs);
}

.side-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--adx-text-tertiary);
  letter-spacing: 1px;
  text-transform: uppercase;
  margin-bottom: 14px;
}

.side-nav {
  list-style: none;
  padding: 0 0 20px;
  margin: 0 0 20px;
  border-bottom: 1px solid var(--adx-border-light);
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.side-nav li a {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 10px;
  border-radius: 10px;
  font-size: 14px;
  color: var(--adx-text-secondary);
  text-decoration: none;
  transition: all 0.2s;

  .nav-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--adx-border-color);
    transition: all 0.2s;
  }

  &:hover {
    background: var(--adx-bg-hover);
    color: var(--adx-color-primary);

    .nav-dot {
      background: var(--adx-color-primary);
    }
  }
}

.side-contact {
  .sc-title {
    font-size: 15px;
    font-weight: 700;
    color: var(--adx-text-primary);
    margin-bottom: 14px;
  }

  .sc-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13.5px;
    color: var(--adx-text-secondary);
    padding: 6px 0;
  }

  .sc-btn {
    width: 100%;
    margin-top: 16px;
    border-radius: 10px;
  }
}

// FAQ main
.faq-cat-block {
  margin-bottom: 56px;

  &:last-child { margin-bottom: 0; }
}

.adx-collapse {
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  overflow: hidden;
  background: var(--adx-bg-card);
  box-shadow: var(--adx-shadow-xs);

  :deep(.el-collapse-item) {
    border-bottom: 1px solid var(--adx-border-light);

    &:last-child { border-bottom: none; }
  }

  :deep(.el-collapse-item__header) {
    padding: 18px 22px;
    font-size: 15px;
    font-weight: 600;
    color: var(--adx-text-primary);
    background: transparent;
    height: auto;
    line-height: 1.55;
    border-bottom: none;
    transition: background 0.2s;

    &:hover {
      background: var(--adx-bg-hover);
    }
  }

  :deep(.el-collapse-item__wrap) {
    border-bottom: none;
    background: transparent;
  }

  :deep(.el-collapse-item__content) {
    padding: 0 22px 20px 22px;
    color: var(--adx-text-secondary);
    font-size: 14.5px;
    line-height: 1.9;
  }
}

.collapse-title {
  padding-right: 20px;
}

.collapse-content {
  p {
    margin: 0;
  }
}

// CTA
.page-cta {
  padding: 48px 0 80px;
}

.cta-card {
  background: linear-gradient(135deg, #8a05ff 0%, #6366f1 100%);
  border-radius: 20px;
  padding: 48px 32px;
  text-align: center;
  color: #fff;

  h3 {
    font-size: 28px;
    font-weight: 800;
    margin: 0 0 10px;
    color: #fff;
  }
  p {
    font-size: 16px;
    color: rgba(255, 255, 255, 0.9);
    margin: 0 0 24px;
  }

  .cta-actions {
    display: inline-flex;
    gap: 14px;
    flex-wrap: wrap;
    justify-content: center;
  }

  :deep(.gradient-btn) {
    background: #fff;
    color: var(--adx-color-primary);
    &:hover {
      background: #f8fafc;
      color: var(--adx-color-purple);
    }
  }
}
</style>
