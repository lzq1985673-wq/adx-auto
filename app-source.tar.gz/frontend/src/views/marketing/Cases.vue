<script setup>
import { useRouter } from 'vue-router'
import SectionTitle from '@/views/components/marketing/SectionTitle.vue'
import GradientButton from '@/views/components/marketing/GradientButton.vue'
import TestimonialCard from '@/views/components/marketing/TestimonialCard.vue'

const router = useRouter()
const goPricing = () => router.push('/pricing')
const goContact = () => router.push('/faq')

const cases = [
  {
    industry: '跨境电商独立站',
    company: '某家居品类独立站',
    logo: '家',
    avatarColors: ['#8A05FF', '#6366F1'],
    quote:
      '做欧美家居品类3年了，一直受困于账号频繁被关联封号。换了ADX-Auto之后，25个账号稳定运营快一年只封过2个，加上AI创意和自动补点击，整体ROAS从1.8涨到了3.4，真的相见恨晚！',
    name: '周建国',
    position: '联合创始人 & 投放负责人',
    heroMetric: 'ROAS 1.8 → 3.4',
    before: {
      title: '使用 ADX-Auto 前',
      items: [
        { label: '月广告费', value: '¥180万' },
        { label: 'ROAS', value: '1.8x' },
        { label: '封号率', value: '18%/季' },
        { label: '优化团队', value: '7人' },
        { label: 'Offer月上新', value: '8-12款' }
      ]
    },
    after: {
      title: '使用 ADX-Auto 后',
      items: [
        { label: '月广告费', value: '¥260万' },
        { label: 'ROAS', value: '3.4x' },
        { label: '封号率', value: '2%/季' },
        { label: '优化团队', value: '4人' },
        { label: 'Offer月上新', value: '30-40款' }
      ]
    }
  },
  {
    industry: '数字营销代理公司',
    company: '某上市4A旗下数字营销公司',
    logo: 'A',
    avatarColors: ['#06B6D4', '#10B981'],
    quote:
      '我们手上有40+品牌客户共300多个Ads账号，以前用Excel+手动切账号的方式根本管不过来。ADX-Auto的MCC同步+权限分级+绩效看板彻底改变了我们的工作方式，客户续费率提升了40%以上。',
    name: 'Emily Chen',
    position: 'Performance Director',
    heroMetric: '客户续费率 +45%',
    before: {
      title: '使用 ADX-Auto 前',
      items: [
        { label: '管理账号数', value: '~300个' },
        { label: '客户续费率', value: '55%' },
        { label: '人均管理账号', value: '15个' },
        { label: '月报制作', value: '3-5天' },
        { label: '客户投诉', value: '高，归因混乱' }
      ]
    },
    after: {
      title: '使用 ADX-Auto 后',
      items: [
        { label: '管理账号数', value: '~300个' },
        { label: '客户续费率', value: '100%' },
        { label: '人均管理账号', value: '40个' },
        { label: '月报制作', value: '小时级自动' },
        { label: '客户投诉', value: '几乎为0' }
      ]
    }
  },
  {
    industry: '游戏 App 出海',
    company: '某中度手游出海团队',
    logo: 'G',
    avatarColors: ['#F59E0B', '#EF4444'],
    quote:
      '以前最头疼的就是CPI忽高忽低、一个新市场测试要两三周才跑出结论。用ADX-Auto之后，AI创意批量产出+定时任务自动调预算，CPI下降了28%，新市场测试时间缩短到了原来的三分之一。',
    name: '马骁',
    position: 'UA 负责人',
    heroMetric: 'CPI 下降 28%',
    before: {
      title: '使用 ADX-Auto 前',
      items: [
        { label: '新市场测试周期', value: '2-3周' },
        { label: '平均 CPI', value: '$4.2' },
        { label: '创意产能/周', value: '40组' },
        { label: '次留率', value: '28%' },
        { label: '月ROI', value: '-12%' }
      ]
    },
    after: {
      title: '使用 ADX-Auto 后',
      items: [
        { label: '新市场测试周期', value: '4-5天' },
        { label: '平均 CPI', value: '$3.02' },
        { label: '创意产能/周', value: '300组+' },
        { label: '次留率', value: '34%' },
        { label: '月ROI', value: '+18%' }
      ]
    }
  },
  {
    industry: 'B2B SaaS 出海',
    company: '某企业协作SaaS',
    logo: 'S',
    avatarColors: ['#10B981', '#06B6D4'],
    quote:
      'B2B的线索表单投放对质量要求极高，我们以前最头疼的就是垃圾线索太多，销售团队怨声载道。ADX-Auto的AI生成+否定词策略+补高质量点击组合拳打下来，有效线索率翻倍，CAC下降了将近三分之一。',
    name: 'Leo Wang',
    position: 'Growth VP',
    heroMetric: 'CAC 下降 31%',
    before: {
      title: '使用 ADX-Auto 前',
      items: [
        { label: '月投入', value: '¥80万' },
        { label: '获客成本 CAC', value: '¥1,800' },
        { label: 'MQL有效率', value: '32%' },
        { label: 'SQL转化率', value: '8%' },
        { label: '销售满意度', value: '★★☆☆☆' }
      ]
    },
    after: {
      title: '使用 ADX-Auto 后',
      items: [
        { label: '月投入', value: '¥80万' },
        { label: '获客成本 CAC', value: '¥1,240' },
        { label: 'MQL有效率', value: '68%' },
        { label: 'SQL转化率', value: '15%' },
        { label: '销售满意度', value: '★★★★★' }
      ]
    }
  },
  {
    industry: '品牌 DTC 电商',
    company: '某设计师女装DTC品牌',
    logo: 'D',
    avatarColors: ['#EC4899', '#8A05FF'],
    quote:
      '我们品牌客单价高，ROI一直波动很大。ADX-Auto的Lookalike+换链接+A/B测试自动化让我们第一次真正跑出了稳定可复制的爆品模型。现在投放团队只关心创意和产品，技术苦活全部交给系统。',
    name: '沈嘉怡',
    position: '品牌增长总监',
    heroMetric: '稳定爆品 + 复制成功',
    before: {
      title: '使用 ADX-Auto 前',
      items: [
        { label: 'ROAS月波动', value: '1.4 ~ 3.8' },
        { label: '爆款成功率', value: '<20%' },
        { label: '大促人力需求', value: '3倍临时团队' },
        { label: '归因准确率', value: '50%' },
        { label: '复购率', value: '18%' }
      ]
    },
    after: {
      title: '使用 ADX-Auto 后',
      items: [
        { label: 'ROAS月波动', value: '2.8 ~ 3.5' },
        { label: '爆款成功率', value: '50%+' },
        { label: '大促人力需求', value: '原班人马即可' },
        { label: '归因准确率', value: '95%' },
        { label: '复购率', value: '28%' }
      ]
    }
  },
  {
    industry: 'MCN / 联盟营销',
    company: '某东南亚头部出海MCN',
    logo: 'M',
    avatarColors: ['#6366F1', '#8A05FF'],
    quote:
      '我们手上有上百个网红带货的Offer要跑，之前每个Offer配1个投手都忙不过来。ADX-Auto一上，2个投手就能管80个Offer，加上补点击+换链接机制带来的质量分提升，整个MCN利润率涨了整整10个点。',
    name: 'Rizky Aulia',
    position: 'Operations Director',
    heroMetric: '利润率 +10pt',
    before: {
      title: '使用 ADX-Auto 前',
      items: [
        { label: '运营Offer数', value: '80个' },
        { label: '投放团队', value: '12人' },
        { label: '平均质量分', value: '6.5/10' },
        { label: '利润率', value: '22%' },
        { label: 'Offer存活率', value: '40%/月' }
      ]
    },
    after: {
      title: '使用 ADX-Auto 后',
      items: [
        { label: '运营Offer数', value: '200个+' },
        { label: '投放团队', value: '5人' },
        { label: '平均质量分', value: '8.7/10' },
        { label: '利润率', value: '32%' },
        { label: 'Offer存活率', value: '65%/月' }
      ]
    }
  }
]

const testimonials = [
  {
    quote:
      'ADX-Auto把我们团队从重复劳动中彻底解放出来了，现在只专注创意和策略。',
    name: '周建国',
    position: '联合创始人',
    company: '某家居品类独立站',
    avatarColors: ['#8A05FF', '#6366F1']
  },
  {
    quote:
      '客户续费率和人均产出双双翻倍，代理公司一定要试，真的是降本增效神器。',
    name: 'Emily Chen',
    position: 'Performance Director',
    company: '某4A数字营销公司',
    avatarColors: ['#06B6D4', '#10B981']
  },
  {
    quote:
      'CPI下降近三成，测试周期缩短三分之二，游戏UA团队值得拥有。',
    name: '马骁',
    position: 'UA 负责人',
    company: '某中度手游出海团队',
    avatarColors: ['#F59E0B', '#EF4444']
  }
]
</script>

<template>
  <div class="cases-page">
    <!-- Page Hero -->
    <section class="page-hero">
      <div class="adx-container">
        <div class="page-hero-inner">
          <span class="page-tag">客户案例 · Cases</span>
          <h1 class="page-title">6大行业真实案例，数据对比见证效果</h1>
          <p class="page-desc">
            跨境电商、代理公司、游戏、SaaS、DTC、MCN……不管你是哪类投放团队，都能在这里找到自己的影子。
          </p>
        </div>
      </div>
    </section>

    <!-- Case Cards -->
    <section class="adx-section">
      <div class="adx-container">
        <div class="case-grid">
          <div v-for="(c, idx) in cases" :key="idx" class="case-card">
            <div class="case-head">
              <div
                class="case-logo"
                :style="{ background: `linear-gradient(135deg, ${c.avatarColors[0]}, ${c.avatarColors[1]})` }"
              >
                {{ c.logo }}
              </div>
              <div class="case-head-info">
                <div class="case-industry">{{ c.industry }}</div>
                <div class="case-company">{{ c.company }}</div>
              </div>
            </div>

            <div class="case-quote">"{{ c.quote }}"</div>

            <div class="case-author">
              — {{ c.name }}，{{ c.position }}
            </div>

            <div class="hero-metric">
              <el-icon color="#10B981" :size="20"><TrendCharts /></el-icon>
              <span>{{ c.heroMetric }}</span>
            </div>

            <div class="compare-wrap">
              <div class="compare-col before">
                <div class="col-tag">Before</div>
                <div class="col-title">{{ c.before.title }}</div>
                <ul class="col-list">
                  <li v-for="(it, i) in c.before.items" :key="i">
                    <span class="il-label">{{ it.label }}</span>
                    <span class="il-value">{{ it.value }}</span>
                  </li>
                </ul>
              </div>

              <div class="compare-divider">
                <el-icon color="#10B981" :size="24"><Right /></el-icon>
              </div>

              <div class="compare-col after">
                <div class="col-tag">After</div>
                <div class="col-title">{{ c.after.title }}</div>
                <ul class="col-list">
                  <li v-for="(it, i) in c.after.items" :key="i">
                    <span class="il-label">{{ it.label }}</span>
                    <span class="il-value positive">{{ it.value }}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Testimonials -->
    <section class="adx-section testimonials-section">
      <div class="adx-container">
        <SectionTitle
          title="更多来自一线的真实声音"
          subtitle="听听更多ADX-Auto用户的亲身体验"
        />
        <div class="testimonial-grid">
          <TestimonialCard
            v-for="(t, idx) in testimonials"
            :key="idx"
            :quote="t.quote"
            :name="t.name"
            :position="t.position"
            :company="t.company"
            :avatarColors="t.avatarColors"
          />
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="page-cta">
      <div class="adx-container">
        <div class="cta-card">
          <h3>想了解和你同行业的客户更多细节？</h3>
          <p>联系我们获取完整案例白皮书，或直接预约1对1行业解决方案演示。</p>
          <div class="cta-actions">
            <GradientButton size="large" @click="goPricing">
              立即购买
              <el-icon><ArrowRight /></el-icon>
            </GradientButton>
            <el-button size="large" class="btn-outline" @click="goContact">
              <el-icon><Phone /></el-icon>
              联系销售
            </el-button>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.cases-page {
  background: var(--adx-bg-color);
}

.page-hero {
  padding: 80px 0 48px;
  background: linear-gradient(
    180deg,
    rgba(99, 102, 241, 0.06) 0%,
    rgba(138, 5, 255, 0.03) 50%,
    var(--adx-bg-color) 100%
  );
  text-align: center;
}

.page-tag {
  display: inline-block;
  padding: 5px 14px;
  background: rgba(99, 102, 241, 0.08);
  border: 1px solid rgba(99, 102, 241, 0.18);
  color: var(--adx-color-primary);
  border-radius: 9999px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 18px;
}

.page-title {
  font-size: 44px;
  font-weight: 800;
  line-height: 1.3;
  margin: 0 0 18px;
  background: var(--adx-gradient-primary);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;

  @media (max-width: 1024px) { font-size: 32px; }
  @media (max-width: 640px) { font-size: 24px; }
}

.page-desc {
  font-size: 17px;
  color: var(--adx-text-secondary);
  line-height: 1.8;
  max-width: 780px;
  margin: 0 auto;

  @media (max-width: 640px) { font-size: 15px; }
}

// Case cards
.case-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 28px;

  @media (max-width: 1024px) { grid-template-columns: 1fr; }
}

.case-card {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 20px;
  padding: 28px;
  transition: all 0.3s;

  &:hover {
    transform: translateY(-4px);
    box-shadow: var(--adx-shadow-xl);
    border-color: var(--adx-color-primary-light);
  }
}

.case-head {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 18px;
}

.case-logo {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  color: #fff;
  font-size: 22px;
  font-weight: 800;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 4px 12px -4px rgba(99, 102, 241, 0.3);
}

.case-industry {
  font-size: 12px;
  font-weight: 600;
  color: var(--adx-color-primary);
  margin-bottom: 4px;
}

.case-company {
  font-size: 17px;
  font-weight: 700;
  color: var(--adx-text-primary);
}

.case-quote {
  position: relative;
  font-size: 14.5px;
  line-height: 1.85;
  color: var(--adx-text-secondary);
  padding: 14px 16px;
  background: var(--adx-bg-secondary);
  border-left: 3px solid var(--adx-color-primary);
  border-radius: 0 10px 10px 0;
  margin: 0 0 10px;
}

.case-author {
  font-size: 13px;
  color: var(--adx-text-tertiary);
  font-style: italic;
  margin-bottom: 16px;
}

.hero-metric {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 8px 14px;
  background: rgba(16, 185, 129, 0.08);
  border: 1px solid rgba(16, 185, 129, 0.2);
  color: var(--adx-color-success);
  border-radius: 9999px;
  font-size: 14px;
  font-weight: 700;
  margin-bottom: 20px;
}

.compare-wrap {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  gap: 12px;
  align-items: stretch;

  @media (max-width: 480px) {
    grid-template-columns: 1fr;
    .compare-divider { transform: rotate(90deg); justify-self: center; padding: 4px 0; }
  }
}

.compare-col {
  border-radius: 14px;
  padding: 16px;

  &.before {
    background: rgba(239, 68, 68, 0.04);
    border: 1px solid rgba(239, 68, 68, 0.14);
  }
  &.after {
    background: rgba(16, 185, 129, 0.05);
    border: 1px solid rgba(16, 185, 129, 0.18);
  }
}

.col-tag {
  display: inline-block;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 1px;
  padding: 2px 8px;
  border-radius: 6px;
  margin-bottom: 6px;

  .before & { background: rgba(239, 68, 68, 0.15); color: var(--adx-color-danger); }
  .after & { background: rgba(16, 185, 129, 0.15); color: var(--adx-color-success); }
}

.col-title {
  font-size: 14px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin-bottom: 10px;
}

.col-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.col-list li {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  font-size: 12.5px;
  line-height: 1.5;
}

.il-label {
  color: var(--adx-text-tertiary);
  flex-shrink: 1;
}

.il-value {
  color: var(--adx-text-secondary);
  font-weight: 600;
  text-align: right;
  flex-shrink: 0;

  &.positive {
    color: var(--adx-color-success);
  }
}

.compare-divider {
  align-self: center;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: rgba(16, 185, 129, 0.1);
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

// testimonials
.testimonials-section {
  background: var(--adx-bg-secondary);
  margin-top: 40px;
}

.testimonial-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    max-width: 640px;
    margin: 0 auto;
  }
}

// CTA
.page-cta { padding: 48px 0 80px; }

.cta-card {
  background: linear-gradient(135deg, #8a05ff 0%, #6366f1 100%);
  border-radius: 20px;
  padding: 48px 32px;
  text-align: center;
  color: #fff;

  h3 {
    font-size: 28px;
    font-weight: 800;
    margin: 0 0 10px;
    color: #fff;
  }
  p {
    font-size: 16px;
    color: rgba(255, 255, 255, 0.9);
    margin: 0 0 24px;
  }

  .cta-actions {
    display: inline-flex;
    flex-wrap: wrap;
    gap: 14px;
    justify-content: center;
  }

  :deep(.gradient-btn) {
    background: #fff;
    color: var(--adx-color-primary);
    &:hover {
      background: #f8fafc;
      color: var(--adx-color-purple);
    }
  }

  .btn-outline {
    background: transparent;
    border: 2px solid rgba(255, 255, 255, 0.35);
    color: #fff;
    font-weight: 600;
    height: 46px;
    border-radius: 12px;
    padding: 0 22px;

    &:hover {
      background: rgba(255, 255, 255, 0.12);
      border-color: rgba(255, 255, 255, 0.55);
      color: #fff;
    }
  }
}
</style>
