<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import SectionTitle from '@/views/components/marketing/SectionTitle.vue'
import GradientButton from '@/views/components/marketing/GradientButton.vue'

const router = useRouter()
const goContact = () => router.push('/faq')
const goLogin = () => router.push('/login')

const billingCycle = ref('yearly')

const plans = [
  {
    id: 'yearly',
    name: '年费版',
    tagline: '适合中小团队快速上手',
    priceYearly: 9800,
    priceDisplay: '¥ 9,800',
    period: '/年',
    badge: '',
    highlight: false,
    features: [
      { name: 'Ads账号上限', yearly: '20 个', twoYear: '100 个', permanent: '不限' },
      { name: 'AI创意生成', yearly: '2,000 次/月', twoYear: '20,000 次/月', permanent: '不限次数' },
      { name: '补点击', yearly: '10,000 次/月', twoYear: '100,000 次/月', permanent: '不限次数' },
      { name: '换链接', yearly: '500 次/月', twoYear: '5,000 次/月', permanent: '不限次数' },
      { name: '定时任务', yearly: '200 次/月', twoYear: '2,000 次/月', permanent: '不限次数' },
      { name: '代理厂商API', yearly: '2家接入', twoYear: '5家全部接入', permanent: '5家全部接入' },
      { name: 'AI模型库', yearly: '常用5款', twoYear: '全部13款', permanent: '全部13款' },
      { name: '团队成员席位', yearly: '5个', twoYear: '20个', permanent: '不限席位' },
      { name: '客户支持', yearly: '邮件工单 7x12h', twoYear: '1v1客户经理+钉钉群', permanent: '7x24 VIP支持' },
      { name: '数据看板', yearly: '基础报表导出', twoYear: '高级看板+BI对接', permanent: '私有化部署+定制' },
      { name: '提示词模板库', yearly: '基础模板', twoYear: '行业模板库', permanent: '定制化私有模板' },
      { name: '功能更新', yearly: '常规更新', twoYear: '优先体验新功能', permanent: '定制功能开发优先权' },
      { name: '退款保证', yearly: '7天无理由', twoYear: '30天无理由', permanent: '60天无理由' },
      { name: '专属部署', yearly: '—', twoYear: '—', permanent: '支持私有化' }
    ]
  },
  {
    id: 'two-year',
    name: '两年版',
    tagline: '最受欢迎，送2个月时长',
    priceYearly: 17800,
    priceDisplay: '¥ 17,800',
    period: '/2年+赠2月',
    badge: '🔥 最受欢迎',
    highlight: true,
    features: [
      { name: 'Ads账号上限', yearly: '20 个', twoYear: '100 个', permanent: '不限' },
      { name: 'AI创意生成', yearly: '2,000 次/月', twoYear: '20,000 次/月', permanent: '不限次数' },
      { name: '补点击', yearly: '10,000 次/月', twoYear: '100,000 次/月', permanent: '不限次数' },
      { name: '换链接', yearly: '500 次/月', twoYear: '5,000 次/月', permanent: '不限次数' },
      { name: '定时任务', yearly: '200 次/月', twoYear: '2,000 次/月', permanent: '不限次数' },
      { name: '代理厂商API', yearly: '2家接入', twoYear: '5家全部接入', permanent: '5家全部接入' },
      { name: 'AI模型库', yearly: '常用5款', twoYear: '全部13款', permanent: '全部13款' },
      { name: '团队成员席位', yearly: '5个', twoYear: '20个', permanent: '不限席位' },
      { name: '客户支持', yearly: '邮件工单 7x12h', twoYear: '1v1客户经理+钉钉群', permanent: '7x24 VIP支持' },
      { name: '数据看板', yearly: '基础报表导出', twoYear: '高级看板+BI对接', permanent: '私有化部署+定制' },
      { name: '提示词模板库', yearly: '基础模板', twoYear: '行业模板库', permanent: '定制化私有模板' },
      { name: '功能更新', yearly: '常规更新', twoYear: '优先体验新功能', permanent: '定制功能开发优先权' },
      { name: '退款保证', yearly: '7天无理由', twoYear: '30天无理由', permanent: '60天无理由' },
      { name: '专属部署', yearly: '—', twoYear: '—', permanent: '支持私有化' }
    ]
  },
  {
    id: 'permanent',
    name: '永久版',
    tagline: '终身授权，一次投入持续收益',
    priceYearly: 39800,
    priceDisplay: '¥ 39,800',
    period: '/永久授权',
    badge: '🏆 企业首选',
    highlight: false,
    features: [
      { name: 'Ads账号上限', yearly: '20 个', twoYear: '100 个', permanent: '不限' },
      { name: 'AI创意生成', yearly: '2,000 次/月', twoYear: '20,000 次/月', permanent: '不限次数' },
      { name: '补点击', yearly: '10,000 次/月', twoYear: '100,000 次/月', permanent: '不限次数' },
      { name: '换链接', yearly: '500 次/月', twoYear: '5,000 次/月', permanent: '不限次数' },
      { name: '定时任务', yearly: '200 次/月', twoYear: '2,000 次/月', permanent: '不限次数' },
      { name: '代理厂商API', yearly: '2家接入', twoYear: '5家全部接入', permanent: '5家全部接入' },
      { name: 'AI模型库', yearly: '常用5款', twoYear: '全部13款', permanent: '全部13款' },
      { name: '团队成员席位', yearly: '5个', twoYear: '20个', permanent: '不限席位' },
      { name: '客户支持', yearly: '邮件工单 7x12h', twoYear: '1v1客户经理+钉钉群', permanent: '7x24 VIP支持' },
      { name: '数据看板', yearly: '基础报表导出', twoYear: '高级看板+BI对接', permanent: '私有化部署+定制' },
      { name: '提示词模板库', yearly: '基础模板', twoYear: '行业模板库', permanent: '定制化私有模板' },
      { name: '功能更新', yearly: '常规更新', twoYear: '优先体验新功能', permanent: '定制功能开发优先权' },
      { name: '退款保证', yearly: '7天无理由', twoYear: '30天无理由', permanent: '60天无理由' },
      { name: '专属部署', yearly: '—', twoYear: '—', permanent: '支持私有化' }
    ]
  }
]

const faqQuick = [
  { q: '如何开始使用 ADX-Auto？', a: '购买后10分钟内开通账号，通过欢迎邮件和引导教程即可开始使用，无需申请Google Ads API。' },
  { q: '是否支持多个MCC？', a: '年费版支持5个MCC、两年版支持20个、永久版不限MCC数量，任意切换无压力。' },
  { q: 'AI调用成本另外收费吗？', a: '我们赚的是软件授权费，不是AI差价。按版本内额度使用不限，额度用尽可优惠价加购。' }
]

const buyPlan = (plan) => {
  goLogin()
}
</script>

<template>
  <div class="pricing-page">
    <!-- Page Hero -->
    <section class="page-hero">
      <div class="adx-container">
        <div class="page-hero-inner">
          <span class="page-tag">价格方案 · Pricing</span>
          <h1 class="page-title">灵活定价，总有一款适合你的团队</h1>
          <p class="page-desc">
            7天/30天/60天无理由退款承诺 · 购买即送30分钟1对1陪跑 · 不满意全额退款，零风险体验
          </p>
        </div>
      </div>
    </section>

    <!-- Pricing Cards -->
    <section class="adx-section pricing-cards-section">
      <div class="adx-container">
        <div class="pricing-grid">
          <div
            v-for="(plan, idx) in plans"
            :key="plan.id"
            class="pricing-card"
            :class="{ 'is-highlight': plan.highlight }"
          >
            <span v-if="plan.badge" class="pricing-badge">{{ plan.badge }}</span>

            <div class="pricing-head">
              <h3 class="plan-name">{{ plan.name }}</h3>
              <p class="plan-tagline">{{ plan.tagline }}</p>
            </div>

            <div class="plan-price">
              <span class="currency">¥</span>
              <span class="amount">{{ plan.priceDisplay.replace('¥ ', '').replace(',', '') === '9800' ? '9,800' : plan.priceDisplay.replace('¥ ', '').replace(',', '') === '17800' ? '17,800' : '39,800' }}</span>
              <span class="period">{{ plan.period }}</span>
            </div>

            <ul class="plan-feature-list">
              <li v-for="(f, fidx) in plan.features.slice(0, 8)" :key="fidx">
                <el-icon class="check" color="#10B981" :size="16"><Check /></el-icon>
                <span class="fn">{{ f.name }}</span>
                <span class="fv">{{ plan.id === 'yearly' ? f.yearly : plan.id === 'two-year' ? f.twoYear : f.permanent }}</span>
              </li>
            </ul>

            <el-button
              type="primary"
              size="large"
              class="plan-cta"
              :class="{ 'is-gradient': !plan.highlight }"
              @click="buyPlan(plan)"
            >
              立即购买
              <el-icon><ArrowRight /></el-icon>
            </el-button>

            <div class="plan-bottom">
              <el-icon color="#10B981" :size="14"><CircleCheckFilled /></el-icon>
              <span>7天无理由退款 · 即买即用</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Feature Comparison Table -->
    <section class="adx-section compare-section">
      <div class="adx-container">
        <SectionTitle
          title="完整功能对比表"
          subtitle="14项核心能力详细对比，帮助你选择最适合的方案"
        />

        <div class="compare-table-wrap">
          <table class="compare-table">
            <thead>
              <tr>
                <th class="col-feature">功能项</th>
                <th class="col-plan">
                  <div class="th-plan">年费版</div>
                  <div class="th-price">¥ 9,800 /年</div>
                </th>
                <th class="col-plan highlight">
                  <div class="th-plan">两年版 <span class="tag">🔥 推荐</span></div>
                  <div class="th-price">¥ 17,800 / 2年+2月</div>
                </th>
                <th class="col-plan">
                  <div class="th-plan">永久版 <span class="tag gold">🏆 企业首选</span></div>
                  <div class="th-price">¥ 39,800 / 永久</div>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(f, fidx) in plans[0].features" :key="fidx">
                <td class="col-feature">{{ f.name }}</td>
                <td class="col-plan">{{ f.yearly }}</td>
                <td class="col-plan highlight-cell">{{ f.twoYear }}</td>
                <td class="col-plan">{{ f.permanent }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- Quick FAQ -->
    <section class="adx-section faq-section">
      <div class="adx-container">
        <SectionTitle
          title="购买前常见问题"
          subtitle="更多问题请查看完整FAQ页面或联系销售顾问"
        />
        <div class="faq-quick-grid">
          <div v-for="(q, idx) in faqQuick" :key="idx" class="faq-quick-item">
            <div class="fq-q">
              <span class="fq-index">Q{{ idx + 1 }}</span>
              <span>{{ q.q }}</span>
            </div>
            <div class="fq-a">
              <span class="fq-label">A</span>
              <p>{{ q.a }}</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Enterprise CTA -->
    <section class="adx-section enterprise-section">
      <div class="adx-container">
        <div class="enterprise-card">
          <div class="ent-left">
            <span class="ent-tag">ENTERPRISE · 企业定制</span>
            <h3>账号数更多 / 需要私有化部署 / 需要定制功能开发？</h3>
            <p>
              我们为大型代理商、品牌方和集团客户提供专属定制服务：不限账号席位、私有化服务器部署、定制功能开发、专属技术对接群、SLA保障。立即联系获取企业专属报价。
            </p>
            <ul class="ent-list">
              <li>
                <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
                <span>私有化部署（本地 / 私有云 / 专有云）</span>
              </li>
              <li>
                <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
                <span>定制功能开发 + 专属产品经理对接</span>
              </li>
              <li>
                <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
                <span>不限账号 / 不限席位 / 不限调用次数</span>
              </li>
              <li>
                <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
                <span>7x24 专属客户成功经理 + 技术群</span>
              </li>
            </ul>
          </div>
          <div class="ent-right">
            <div class="ent-contact-card">
              <div class="ent-contact-title">立即联系我们</div>
              <div class="ent-contact-item">
                <el-icon color="#8A05FF"><Message /></el-icon>
                <span>enterprise@adx-auto.com</span>
              </div>
              <div class="ent-contact-item">
                <el-icon color="#8A05FF"><Phone /></el-icon>
                <span>400-888-1234 转 企业专线</span>
              </div>
              <div class="ent-contact-item">
                <el-icon color="#8A05FF"><Service /></el-icon>
                <span>5分钟内响应 · 中文商务顾问</span>
              </div>
              <GradientButton class="ent-btn" size="large" @click="goContact">
                获取企业报价
                <el-icon><ArrowRight /></el-icon>
              </GradientButton>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.pricing-page {
  background: var(--adx-bg-color);
}

.page-hero {
  padding: 80px 0 48px;
  background: linear-gradient(
    180deg,
    rgba(138, 5, 255, 0.06) 0%,
    rgba(99, 102, 241, 0.03) 50%,
    var(--adx-bg-color) 100%
  );
  text-align: center;
}

.page-tag {
  display: inline-block;
  padding: 5px 14px;
  background: rgba(138, 5, 255, 0.08);
  border: 1px solid rgba(138, 5, 255, 0.16);
  color: #8a05ff;
  border-radius: 9999px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 18px;
}

.page-title {
  font-size: 44px;
  font-weight: 800;
  line-height: 1.3;
  margin: 0 0 18px;
  background: var(--adx-gradient-primary);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;

  @media (max-width: 1024px) { font-size: 32px; }
  @media (max-width: 640px) { font-size: 24px; }
}

.page-desc {
  font-size: 17px;
  color: var(--adx-text-secondary);
  line-height: 1.8;
  max-width: 780px;
  margin: 0 auto;

  @media (max-width: 640px) { font-size: 15px; }
}

// Pricing cards
.pricing-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 32px;
  align-items: stretch;
  max-width: 1120px;
  margin: 0 auto;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    max-width: 460px;
    gap: 24px;
  }
}

.pricing-card {
  position: relative;
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 20px;
  padding: 36px 28px;
  display: flex;
  flex-direction: column;
  transition: all 0.35s ease;

  &.is-highlight {
    border: 2px solid transparent;
    background:
      linear-gradient(var(--adx-bg-card), var(--adx-bg-card)) padding-box,
      var(--adx-gradient-primary) border-box;
    transform: scale(1.03);
    box-shadow: var(--adx-shadow-xl);

    @media (max-width: 1024px) { transform: none; }
  }

  &:hover {
    transform: translateY(-6px);
    box-shadow: var(--adx-shadow-xl);
  }
}

.pricing-badge {
  position: absolute;
  top: -12px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--adx-gradient-primary);
  color: #fff;
  padding: 5px 18px;
  font-size: 12px;
  font-weight: 600;
  border-radius: 9999px;
  white-space: nowrap;
}

.pricing-head {
  text-align: center;
  margin-bottom: 24px;
}

.plan-name {
  font-size: 22px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin: 0 0 6px;
}

.plan-tagline {
  font-size: 13px;
  color: var(--adx-text-tertiary);
  margin: 0;
}

.plan-price {
  display: flex;
  align-items: baseline;
  justify-content: center;
  margin-bottom: 28px;

  .currency {
    font-size: 20px;
    font-weight: 600;
    color: var(--adx-text-secondary);
    margin-right: 4px;
  }
  .amount {
    font-size: 52px;
    font-weight: 800;
    line-height: 1;
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  .period {
    font-size: 13px;
    color: var(--adx-text-tertiary);
    margin-left: 4px;
  }
}

.plan-feature-list {
  list-style: none;
  padding: 0;
  margin: 0 0 28px;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.plan-feature-list li {
  display: grid;
  grid-template-columns: 18px auto 1fr;
  gap: 8px;
  align-items: flex-start;
  font-size: 13.5px;
  line-height: 1.55;

  .check { flex-shrink: 0; margin-top: 1px; }
  .fn { color: var(--adx-text-secondary); }
  .fv {
    color: var(--adx-text-primary);
    font-weight: 600;
    text-align: right;
  }
}

.plan-cta {
  width: 100%;
  font-weight: 600;
  border-radius: 12px;
  height: 48px;

  &.is-gradient {
    background: var(--adx-gradient-primary);
    border: none;
    &:hover {
      box-shadow: 0 8px 20px -6px rgba(99, 102, 241, 0.5);
    }
  }

  :deep(.el-icon) { margin-left: 6px; }
}

.plan-bottom {
  margin-top: 14px;
  font-size: 12px;
  color: var(--adx-text-tertiary);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

// Comparison table
.compare-section {
  background: var(--adx-bg-secondary);
  margin-top: 40px;
}

.compare-table-wrap {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 18px;
  overflow: hidden;
  box-shadow: var(--adx-shadow-sm);
  overflow-x: auto;
}

.compare-table {
  width: 100%;
  min-width: 820px;
  border-collapse: collapse;
  font-size: 14px;

  th, td {
    padding: 16px 20px;
    text-align: center;
    border-bottom: 1px solid var(--adx-border-light);
  }
}

.compare-table thead th {
  background: var(--adx-bg-secondary);
  font-weight: 700;
  color: var(--adx-text-primary);
  border-bottom: 1px solid var(--adx-border-color);

  &.highlight {
    background: linear-gradient(180deg, rgba(138, 5, 255, 0.06), rgba(99, 102, 241, 0.02));
  }

  .th-plan {
    font-size: 15px;
    margin-bottom: 4px;
  }

  .th-price {
    font-size: 13px;
    color: var(--adx-color-primary);
    font-weight: 600;
  }

  .tag {
    display: inline-block;
    padding: 1px 8px;
    background: rgba(245, 158, 11, 0.12);
    color: var(--adx-color-warning);
    border-radius: 9999px;
    font-size: 11px;
    font-weight: 600;
    margin-left: 4px;

    &.gold {
      background: linear-gradient(135deg, rgba(138, 5, 255, 0.12), rgba(99, 102, 241, 0.12));
      color: var(--adx-color-purple);
    }
  }
}

.compare-table tbody {
  .col-feature {
    text-align: left;
    color: var(--adx-text-secondary);
    background: var(--adx-bg-secondary);
    font-weight: 500;
  }

  .col-plan {
    color: var(--adx-text-primary);

    &.highlight-cell {
      background: linear-gradient(180deg, rgba(138, 5, 255, 0.04), transparent);
      color: var(--adx-color-primary);
      font-weight: 600;
    }
  }

  tr:last-child td { border-bottom: none; }
}

// Quick FAQ
.faq-quick-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;

  @media (max-width: 1024px) { grid-template-columns: 1fr; max-width: 720px; margin: 0 auto; }
}

.faq-quick-item {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  padding: 22px;
  transition: all 0.3s;

  &:hover {
    transform: translateY(-3px);
    box-shadow: var(--adx-shadow-md);
  }
}

.fq-q {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  font-size: 15px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin-bottom: 12px;
  line-height: 1.5;
}

.fq-index {
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--adx-gradient-primary);
  color: #fff;
  font-size: 13px;
}

.fq-a {
  display: flex;
  gap: 10px;

  .fq-label {
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 8px;
    background: rgba(16, 185, 129, 0.12);
    color: var(--adx-color-success);
    font-size: 13px;
    font-weight: 700;
  }

  p {
    margin: 0;
    font-size: 14px;
    line-height: 1.75;
    color: var(--adx-text-secondary);
    padding-top: 4px;
  }
}

// Enterprise
.enterprise-section {
  background: var(--adx-bg-secondary);
  margin-top: 40px;
}

.enterprise-card {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 20px;
  padding: 40px;
  display: grid;
  grid-template-columns: 1.3fr 1fr;
  gap: 40px;
  box-shadow: var(--adx-shadow-md);
  overflow: hidden;
  position: relative;

  &::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 460px;
    height: 460px;
    background: radial-gradient(circle, rgba(138, 5, 255, 0.1), transparent 70%);
    pointer-events: none;
  }

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    padding: 28px 20px;
    gap: 28px;
  }
}

.ent-left {
  position: relative;
  z-index: 1;
}

.ent-tag {
  display: inline-block;
  padding: 4px 12px;
  background: rgba(138, 5, 255, 0.1);
  color: var(--adx-color-purple);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 1px;
  border-radius: 9999px;
  margin-bottom: 14px;
}

.ent-left h3 {
  font-size: 24px;
  font-weight: 800;
  color: var(--adx-text-primary);
  margin: 0 0 12px;
  line-height: 1.4;
}

.ent-left > p {
  font-size: 15px;
  line-height: 1.85;
  color: var(--adx-text-secondary);
  margin: 0 0 20px;
}

.ent-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;

  @media (max-width: 640px) { grid-template-columns: 1fr; }
}

.ent-list li {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13.5px;
  color: var(--adx-text-secondary);
  line-height: 1.5;
}

.ent-right {
  position: relative;
  z-index: 1;
}

.ent-contact-card {
  background: linear-gradient(135deg, rgba(138, 5, 255, 0.06), rgba(99, 102, 241, 0.06));
  border: 1px solid rgba(138, 5, 255, 0.15);
  border-radius: 16px;
  padding: 28px 24px;
}

.ent-contact-title {
  font-size: 18px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin-bottom: 20px;
}

.ent-contact-item {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 14px;
  color: var(--adx-text-secondary);
  padding: 10px 0;
  border-bottom: 1px dashed var(--adx-border-light);

  &:last-of-type { border-bottom: none; margin-bottom: 20px; }
}

.ent-btn {
  width: 100%;
  border-radius: 12px;
}
</style>
