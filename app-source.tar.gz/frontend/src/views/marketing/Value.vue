<script setup>
import { useRouter } from 'vue-router'
import SectionTitle from '@/views/components/marketing/SectionTitle.vue'
import GradientButton from '@/views/components/marketing/GradientButton.vue'
import NumberCounter from '@/views/components/marketing/NumberCounter.vue'

const router = useRouter()
const goPricing = () => router.push('/pricing')

const valueItems = [
  {
    icon: 'Lightning',
    tag: 'VALUE · 01',
    number: 80,
    suffix: '%',
    title: '效率提升 80%',
    subtitle: '从手动操作到自动执行',
    description:
      '过去一个优化师最多管好5-8个账号，用了ADX-Auto后，同样人力可以管好30+账号。广告创建、预算调整、关键词优化、报表导出等重复性工作全部自动化，释放团队核心精力到策略和创意等高价值环节。',
    dataPoints: [
      { label: 'Offer上线时间', before: '3-5天', after: '10分钟' },
      { label: '单账号运营耗时/周', before: '10-15小时', after: '1-2小时' },
      { label: '批量处理广告', before: '数小时', after: '数分钟' },
      { label: '报表生成', before: '半天', after: '秒级' }
    ],
    gradient: 'linear-gradient(135deg, #F59E0B 0%, #EF4444 100%)'
  },
  {
    icon: 'TrendCharts',
    tag: 'VALUE · 02',
    number: 40,
    suffix: '%',
    title: '成本降低 40%',
    subtitle: '每一分广告费都花在刀刃上',
    description:
      'AI出价优化、异常消耗自动熔断、无效点击智能过滤、代理/模型成本透明对比……多维度综合降本。500+客户平均CPC下降31%，CPM下降27%，AI创意生成+批量投放让人力成本直接减半。',
    dataPoints: [
      { label: '平均CPC', before: '¥1.2-2.5', after: '¥0.8-1.5' },
      { label: '平均CPM', before: '¥30-50', after: '¥22-36' },
      { label: 'AI替代创意人力', before: '3人/组', after: '0.5人/组' },
      { label: '浪费消耗挽回', before: '-', after: '10-15%/月' }
    ],
    gradient: 'linear-gradient(135deg, #10B981 0%, #06B6D4 100%)'
  },
  {
    icon: 'Shield',
    tag: 'VALUE · 03',
    number: 90,
    suffix: '%',
    title: '风险控制 90%',
    subtitle: '封号风险大幅下降',
    description:
      '环境隔离+指纹随机+代理池+行为风控四层防护，让账号关联封号概率下降90%。同时预算上限熔断、违规关键词检测、落地页健康监控等机制，把可预见的风险全部提前拦截。',
    dataPoints: [
      { label: '账号关联封号率', before: '30-40%/季', after: '3-5%/季' },
      { label: '异常消耗拦截', before: '人工发现', after: '秒级自动' },
      { label: '违规广告命中', before: '靠经验', after: 'AI前置检测' },
      { label: '代理故障影响', before: '全组中断', after: '无感切换' }
    ],
    gradient: 'linear-gradient(135deg, #6366F1 0%, #8A05FF 100%)'
  },
  {
    icon: 'PieChart',
    tag: 'VALUE · 04',
    number: 99,
    suffix: '%',
    title: '数据完整 99%',
    subtitle: '告别数据断链和归因混乱',
    description:
      '从广告曝光、点击到落地页访问、加购、下单、复购，每一步数据都有稳定的打点和透传机制。ClickID+UTM+服务端回传三重保障，数据准确率99%+，优化决策不再建立在错误数据之上。',
    dataPoints: [
      { label: '点击数据准确率', before: '60-70%', after: '99%+' },
      { label: '转化归因匹配率', before: '40-50%', after: '90%+' },
      { label: '跨账号数据汇总', before: '手工拼接', after: '自动看板' },
      { label: '报表一致性', before: '经常对不上', after: '单数据源' }
    ],
    gradient: 'linear-gradient(135deg, #06B6D4 0%, #6366F1 100%)'
  },
  {
    icon: 'Gem',
    tag: 'VALUE · 05',
    number: 3,
    suffix: 'x',
    title: 'Offer挖掘 3倍速',
    subtitle: '更快发现爆款与潜力广告',
    description:
      '竞品落地页爬虫+AI创意生成让你快速测试大量Offer组合；多维度数据分析自动识别ROAS > 3的爆款广告和潜力关键词；A/B测试自动分组+显著性分析，发现爆款的速度直接提升3倍。',
    dataPoints: [
      { label: 'Offer上线速度', before: '3-5款/周', after: '10-15款/周' },
      { label: '创意产出速度', before: '5-10组/天', after: '50-100组/天' },
      { label: '爆款识别速度', before: '3-7天', after: '24-48小时' },
      { label: 'A/B测试显著性', before: '靠肉眼判断', after: '自动统计检验' }
    ],
    gradient: 'linear-gradient(135deg, #EC4899 0%, #8A05FF 100%)'
  },
  {
    icon: 'User',
    tag: 'VALUE · 06',
    number: 5,
    suffix: 'x',
    title: '团队协作 5倍顺',
    subtitle: '从混乱沟通到清晰分工',
    description:
      '多角色权限+操作审计+任务分配+审批流+团队绩效看板，让老板、运营、优化、创意、财务各司其职。所有操作留痕可追溯，数据看板按角色定制，沟通成本直接下降80%。',
    dataPoints: [
      { label: '跨角色沟通成本', before: '高/群消息轰炸', after: '低/系统内协作' },
      { label: '操作追责与审计', before: '困难', after: '一键查询' },
      { label: '新人上手时间', before: '1-2月', after: '3-5天' },
      { label: '绩效数据公平性', before: '人工统计争议多', after: '自动看板无争议' }
    ],
    gradient: 'linear-gradient(135deg, #111827 0%, #6366F1 100%)'
  }
]
</script>

<template>
  <div class="value-page">
    <!-- Page Hero -->
    <section class="page-hero">
      <div class="adx-container">
        <div class="page-hero-inner">
          <span class="page-tag">系统价值 · Value</span>
          <h1 class="page-title">用数据说话，见证六大核心价值</h1>
          <p class="page-desc">
            基于500+付费客户的真实使用数据和反馈，我们总结出ADX-Auto带来的6个最核心、最可量化的系统价值。
          </p>
        </div>
      </div>
    </section>

    <!-- Metrics Hero -->
    <section class="metrics-hero">
      <div class="adx-container">
        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-icon" style="background: linear-gradient(135deg, #F59E0B, #EF4444);">
              <el-icon :size="28"><Lightning /></el-icon>
            </div>
            <div class="metric-num">
              <NumberCounter :endValue="80" suffix="%" :duration="2200" />
            </div>
            <div class="metric-label">平均效率提升</div>
          </div>
          <div class="metric-card">
            <div class="metric-icon" style="background: linear-gradient(135deg, #10B981, #06B6D4);">
              <el-icon :size="28"><TrendCharts /></el-icon>
            </div>
            <div class="metric-num">
              <NumberCounter :endValue="40" suffix="%" :duration="2200" />
            </div>
            <div class="metric-label">综合成本下降</div>
          </div>
          <div class="metric-card">
            <div class="metric-icon" style="background: linear-gradient(135deg, #6366F1, #8A05FF);">
              <el-icon :size="28"><Shield /></el-icon>
            </div>
            <div class="metric-num">
              <NumberCounter :endValue="90" suffix="%" :duration="2200" />
            </div>
            <div class="metric-label">封号风险下降</div>
          </div>
          <div class="metric-card">
            <div class="metric-icon" style="background: linear-gradient(135deg, #06B6D4, #6366F1);">
              <el-icon :size="28"><PieChart /></el-icon>
            </div>
            <div class="metric-num">
              <NumberCounter :endValue="99" suffix="%" :duration="2200" />
            </div>
            <div class="metric-label">数据准确率</div>
          </div>
          <div class="metric-card">
            <div class="metric-icon" style="background: linear-gradient(135deg, #EC4899, #8A05FF);">
              <el-icon :size="28"><Gem /></el-icon>
            </div>
            <div class="metric-num">
              <NumberCounter :endValue="3" suffix="x" :duration="2200" />
            </div>
            <div class="metric-label">爆款挖掘速度</div>
          </div>
          <div class="metric-card">
            <div class="metric-icon" style="background: linear-gradient(135deg, #111827, #6366F1);">
              <el-icon :size="28"><User /></el-icon>
            </div>
            <div class="metric-num">
              <NumberCounter :endValue="5" suffix="x" :duration="2200" />
            </div>
            <div class="metric-label">协作效率提升</div>
          </div>
        </div>
      </div>
    </section>

    <!-- Value Detail List -->
    <section class="adx-section">
      <div class="adx-container">
        <div class="value-list">
          <div
            v-for="(v, idx) in valueItems"
            :key="idx"
            class="value-block"
            :class="{ 'is-reverse': idx % 2 === 1 }"
          >
            <div class="value-visual">
              <div class="vv-card" :style="{ background: v.gradient }">
                <div class="vv-number">
                  <span class="vv-num">
                    <NumberCounter :endValue="v.number" :suffix="v.suffix" :duration="2400" />
                  </span>
                </div>
                <div class="vv-icon-wrap">
                  <el-icon :size="44"><component :is="v.icon" /></el-icon>
                </div>
                <div class="vv-tag">{{ v.tag }}</div>
              </div>
            </div>

            <div class="value-content">
              <div class="v-tag">{{ v.tag }}</div>
              <h2 class="v-title">{{ v.title }}</h2>
              <div class="v-subtitle">{{ v.subtitle }}</div>
              <p class="v-desc">{{ v.description }}</p>

              <div class="compare-table">
                <div class="ct-row ct-head">
                  <div class="ct-label">对比维度</div>
                  <div class="ct-before">Before · 使用前</div>
                  <div class="ct-after">After · 使用后</div>
                </div>
                <div v-for="(p, pidx) in v.dataPoints" :key="pidx" class="ct-row">
                  <div class="ct-label">{{ p.label }}</div>
                  <div class="ct-before">{{ p.before }}</div>
                  <div class="ct-after">{{ p.after }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ROI Calculator -->
    <section class="adx-section roi-section">
      <div class="adx-container">
        <div class="roi-card">
          <div class="roi-left">
            <span class="roi-tag">ROI 测算</span>
            <h3>简单算一笔账，投入产出比一目了然</h3>
            <ul class="roi-list">
              <li>
                <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
                <span>假设你团队月广告费 <b>¥50万</b>，佣金+人力 <b>¥15万/月</b></span>
              </li>
              <li>
                <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
                <span>用ADX-Auto后，CPC下降31% + 人力减半 = <b>每月省 ¥23万</b></span>
              </li>
              <li>
                <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
                <span>同时爆款挖掘提速3倍 → <b>ROAS平均再提升20%+</b></span>
              </li>
              <li>
                <el-icon color="#10B981"><CircleCheckFilled /></el-icon>
                <span>年费版仅 <b>¥9,800</b> → <b>首月即回本，年净赚 ¥250万+</b></span>
              </li>
            </ul>
          </div>

          <div class="roi-right">
            <div class="roi-metric">
              <div class="rm-label">年投入</div>
              <div class="rm-value small">¥ 9,800</div>
            </div>
            <div class="roi-arrow">→</div>
            <div class="roi-metric highlight">
              <div class="rm-label">年净省/赚</div>
              <div class="rm-value">¥ 2,500,000+</div>
            </div>
            <div class="roi-arrow">→</div>
            <div class="roi-metric big">
              <div class="rm-label">投入产出比 ROI</div>
              <div class="rm-value text-gradient">250x+</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="page-cta">
      <div class="adx-container">
        <div class="cta-card">
          <h3>这笔账，越算越心动</h3>
          <p>与其继续在低效和风险中挣扎，不如现在就用 ADX-Auto 彻底升级你的投放体系。</p>
          <GradientButton size="large" @click="goPricing">
            立即购买，享受超高ROI
            <el-icon><ArrowRight /></el-icon>
          </GradientButton>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.value-page {
  background: var(--adx-bg-color);
}

.page-hero {
  padding: 80px 0 48px;
  background: linear-gradient(
    180deg,
    rgba(138, 5, 255, 0.06) 0%,
    rgba(99, 102, 241, 0.03) 50%,
    var(--adx-bg-color) 100%
  );
  text-align: center;
}

.page-tag {
  display: inline-block;
  padding: 5px 14px;
  background: rgba(138, 5, 255, 0.08);
  border: 1px solid rgba(138, 5, 255, 0.16);
  color: #8a05ff;
  border-radius: 9999px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 18px;
}

.page-title {
  font-size: 44px;
  font-weight: 800;
  line-height: 1.3;
  margin: 0 0 18px;
  background: var(--adx-gradient-primary);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;

  @media (max-width: 1024px) { font-size: 32px; }
  @media (max-width: 640px) { font-size: 24px; }
}

.page-desc {
  font-size: 17px;
  color: var(--adx-text-secondary);
  line-height: 1.8;
  max-width: 780px;
  margin: 0 auto;

  @media (max-width: 640px) { font-size: 15px; }
}

// Metrics hero
.metrics-hero {
  padding: 0 0 64px;
}

.metrics-grid {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 16px;

  @media (max-width: 1280px) { grid-template-columns: repeat(3, 1fr); }
  @media (max-width: 640px) { grid-template-columns: repeat(2, 1fr); }
}

.metric-card {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 16px;
  padding: 24px 16px;
  text-align: center;
  transition: all 0.3s;

  &:hover {
    transform: translateY(-4px);
    box-shadow: var(--adx-shadow-md);
    border-color: var(--adx-color-primary-light);
  }
}

.metric-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  color: #fff;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 14px;
}

.metric-num {
  font-size: 36px;
  margin-bottom: 6px;
}

.metric-label {
  font-size: 13px;
  color: var(--adx-text-secondary);
  font-weight: 500;
}

// value list
.value-list {
  display: flex;
  flex-direction: column;
  gap: 72px;

  @media (max-width: 640px) { gap: 48px; }
}

.value-block {
  display: grid;
  grid-template-columns: 1fr 1.3fr;
  gap: 48px;
  align-items: center;

  &.is-reverse {
    .value-visual { order: 2; }
    .value-content { order: 1; }
  }

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    gap: 32px;

    &.is-reverse {
      .value-visual, .value-content { order: unset; }
    }
  }
}

.vv-card {
  position: relative;
  aspect-ratio: 1 / 1;
  max-width: 360px;
  margin: 0 auto;
  border-radius: 24px;
  color: #fff;
  padding: 32px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  overflow: hidden;
  box-shadow: var(--adx-shadow-xl);

  &::before {
    content: '';
    position: absolute;
    top: -30%;
    right: -20%;
    width: 220px;
    height: 220px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    filter: blur(20px);
  }
}

.vv-number {
  position: relative;
  z-index: 1;
}

.vv-num {
  font-size: 80px;
  font-weight: 800;
  line-height: 1;
  color: #fff;
}

.vv-icon-wrap {
  position: relative;
  z-index: 1;
  background: rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(8px);
  align-self: flex-start;
  padding: 14px;
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.vv-tag {
  position: relative;
  z-index: 1;
  font-size: 14px;
  font-weight: 700;
  letter-spacing: 2px;
  opacity: 0.7;
}

.v-tag {
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 1px;
  color: var(--adx-color-primary);
  margin-bottom: 10px;
}

.v-title {
  font-size: 30px;
  font-weight: 800;
  margin: 0 0 10px;
  color: var(--adx-text-primary);
  line-height: 1.25;

  @media (max-width: 640px) { font-size: 22px; }
}

.v-subtitle {
  font-size: 17px;
  color: var(--adx-color-purple);
  font-weight: 600;
  margin-bottom: 14px;
}

.v-desc {
  font-size: 15px;
  line-height: 1.9;
  color: var(--adx-text-secondary);
  margin: 0 0 24px;
}

.compare-table {
  border: 1px solid var(--adx-border-color);
  border-radius: 14px;
  overflow: hidden;
  font-size: 13.5px;
}

.ct-row {
  display: grid;
  grid-template-columns: 1.1fr 1fr 1fr;

  &:not(:last-child) {
    border-bottom: 1px solid var(--adx-border-light);
  }

  > div {
    padding: 10px 12px;
    &:not(:last-child) {
      border-right: 1px solid var(--adx-border-light);
    }
  }
}

.ct-head {
  background: var(--adx-bg-secondary);
  font-weight: 700;
  color: var(--adx-text-primary);
  font-size: 12.5px;

  .ct-before { color: var(--adx-text-secondary); }
  .ct-after { color: var(--adx-color-primary); }
}

.ct-label {
  color: var(--adx-text-secondary);
  font-weight: 500;
}

.ct-before { color: var(--adx-text-tertiary); }
.ct-after { color: var(--adx-text-primary); font-weight: 600; }

// ROI
.roi-section {
  background: var(--adx-bg-secondary);
  margin-top: 40px;
}

.roi-card {
  background: var(--adx-bg-card);
  border: 1px solid var(--adx-border-color);
  border-radius: 20px;
  padding: 40px;
  display: grid;
  grid-template-columns: 1.2fr 1fr;
  gap: 40px;
  align-items: center;
  box-shadow: var(--adx-shadow-md);

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    padding: 28px 20px;
    gap: 28px;
  }
}

.roi-tag {
  display: inline-block;
  padding: 4px 12px;
  background: rgba(16, 185, 129, 0.1);
  color: var(--adx-color-success);
  border-radius: 9999px;
  font-size: 12px;
  font-weight: 700;
  margin-bottom: 12px;
}

.roi-left h3 {
  font-size: 24px;
  font-weight: 800;
  color: var(--adx-text-primary);
  margin: 0 0 16px;
  line-height: 1.35;
}

.roi-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;

  li {
    display: flex;
    align-items: flex-start;
    gap: 8px;
    font-size: 14.5px;
    color: var(--adx-text-secondary);
    line-height: 1.6;

    .el-icon { flex-shrink: 0; margin-top: 3px; }
    b { color: var(--adx-text-primary); }
  }
}

.roi-right {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;

  @media (max-width: 640px) { flex-direction: row; flex-wrap: wrap; justify-content: center; }
}

.roi-metric {
  width: 100%;
  background: var(--adx-bg-secondary);
  border: 1px solid var(--adx-border-light);
  border-radius: 14px;
  padding: 16px 20px;
  text-align: center;

  &.highlight {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.08), rgba(6, 182, 212, 0.08));
    border-color: rgba(16, 185, 129, 0.3);
  }

  &.big {
    background: linear-gradient(135deg, rgba(138, 5, 255, 0.1), rgba(99, 102, 241, 0.1));
    border-color: rgba(138, 5, 255, 0.3);
  }
}

.rm-label {
  font-size: 12.5px;
  color: var(--adx-text-tertiary);
  margin-bottom: 4px;
}

.rm-value {
  font-size: 28px;
  font-weight: 800;
  color: var(--adx-text-primary);
  line-height: 1.2;

  &.small { font-size: 22px; color: var(--adx-text-secondary); }

  &.text-gradient {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    font-size: 36px;
  }
}

.roi-arrow {
  font-size: 20px;
  color: var(--adx-color-primary-light);
  font-weight: 700;
  @media (max-width: 640px) { display: none; }
}

// CTA
.page-cta { padding: 48px 0 80px; }

.cta-card {
  background: linear-gradient(135deg, #8a05ff 0%, #6366f1 100%);
  border-radius: 20px;
  padding: 48px 32px;
  text-align: center;
  color: #fff;

  h3 {
    font-size: 28px;
    font-weight: 800;
    margin: 0 0 10px;
    color: #fff;
  }
  p {
    font-size: 16px;
    color: rgba(255, 255, 255, 0.9);
    margin: 0 0 24px;
  }

  :deep(.gradient-btn) {
    background: #fff;
    color: var(--adx-color-primary);
    &:hover {
      background: #f8fafc;
      color: var(--adx-color-purple);
    }
  }
}
</style>
