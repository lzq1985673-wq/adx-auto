<script setup>
import { useRouter } from 'vue-router'
import SectionTitle from '@/views/components/marketing/SectionTitle.vue'
import GradientButton from '@/views/components/marketing/GradientButton.vue'
import HighlightCard from '@/views/components/marketing/HighlightCard.vue'

const router = useRouter()
const goPricing = () => router.push('/pricing')

const highlightDetail = [
  {
    icon: 'Refresh',
    tag: '01',
    title: '双向数据同步 · 无需API审批',
    subtitle: '独创免API接入方案，告别漫长等待',
    description:
      '传统接入Google Ads需要申请官方Developer Token，审批周期长达数周甚至数月，还容易被拒。ADX-Auto独创的双向数据同步机制，无需申请API即可实现MCC及所有子账号的双向数据互通，让你10分钟内完成所有账号接入。',
    advantages: [
      { title: '零审批接入', desc: '无需Developer Token，无需Google审核流程，授权即可使用。' },
      { title: '双向实时同步', desc: '后台变更自动同步到Google，Google数据实时回传后台，延迟低于5分钟。' },
      { title: '支持全层级结构', desc: 'MCC → 子账号 → 广告系列 → 广告组 → 广告 → 关键词 全层级完整支持。' },
      { title: '账号秒级切换', desc: '上百个账号一键切换，无需登录登出，无需切换代理环境。' }
    ],
    gradient: 'linear-gradient(135deg, #8A05FF 0%, #6366F1 100%)'
  },
  {
    icon: 'Aim',
    tag: '02',
    title: '精准补点击算法 · 模拟自然流量',
    subtitle: '真实用户行为模型，质量分稳步提升',
    description:
      '补点击是所有优化师的刚需，但做得不好反而会害了账号。ADX-Auto的补点击引擎基于数百万真实用户行为数据训练，从设备、地域、时段、浏览深度、二跳行为等多维度严格模拟真实用户，让补过来的每一次点击都像真的一样。',
    advantages: [
      { title: '多维度精准匹配', desc: '可按设备类型/操作系统/地域/ISP运营商/时段/浏览器等精准定向补点击。' },
      { title: '行为链路模拟', desc: '停留时长、滚动深度、点击热区、二跳页面、返回行为都可自定义概率分布。' },
      { title: '成本频次控制', desc: '单日预算/单IP频次/小时间隔/TCPA上限多重控制，避免过度点击被识别。' },
      { title: '效果数据闭环', desc: '补点击后CTR/CPC/质量分变化实时分析，自动迭代优化补点击策略。' }
    ],
    gradient: 'linear-gradient(135deg, #F59E0B 0%, #EF4444 100%)'
  },
  {
    icon: 'Link',
    tag: '03',
    title: '严谨换链接逻辑 · 数据闭环',
    subtitle: '归因准确不丢失，数据全程可追溯',
    description:
      '换链接是优化师最常用的手段之一，但传统方法数据断链、归因混乱。ADX-Auto内置完整的链接管理模块，从短链生成、追踪参数注入、302跳转、A/B分组，到最终落地页数据回传，实现曝光-点击-转化全链路数据闭环。',
    advantages: [
      { title: '多种链接形态', desc: '短链/追踪链/302跳转链/多阶跳转链/域名池轮换，灵活选择不留痕。' },
      { title: '全链路归因', desc: '曝光→点击→跳转→落地→加购→下单 全链路事件打点，UTM/ClickID完整透传。' },
      { title: 'A/B测试自动分组', desc: '链接分流按权重/地域/时段自动分组，实验数据自动统计显著性。' },
      { title: '链接健康检测', desc: '7x24检测落地页可访问性、重定向次数、SSL证书、被墙状态，异常秒级告警。' }
    ],
    gradient: 'linear-gradient(135deg, #06B6D4 0%, #6366F1 100%)'
  },
  {
    icon: 'Clock',
    tag: '04',
    title: '高效定时任务 · 全程可追溯',
    subtitle: '可视化任务调度，复杂规则轻松配置',
    description:
      '投放优化很多是重复性动作，比如半夜调预算、上班前停广告、每周导出报表。ADX-Auto的定时任务模块支持丰富的触发条件和动作组合，复杂工作流几分钟配置完，后台自动执行，每一次执行都有完整日志记录。',
    advantages: [
      { title: '可视化配置面板', desc: '简单模式选频率+动作，高级模式直接写Crontab表达式，新手老手都能上手。' },
      { title: '丰富任务类型', desc: '预算调整、广告启停、关键词出价、数据报表、补点击计划、换链接策略…通通支持。' },
      { title: '失败重试与告警', desc: '任务失败自动重试+钉钉/邮件/短信多渠道告警，不让问题过夜。' },
      { title: '完整日志审计', desc: '谁什么时候创建了什么任务、执行结果、修改记录，完整日志随时可查。' }
    ],
    gradient: 'linear-gradient(135deg, #10B981 0%, #06B6D4 100%)'
  },
  {
    icon: 'Grid',
    tag: '05',
    title: '丰富配置能力 · 降低依赖风险',
    subtitle: '多供应商接入，避免单一锁定',
    description:
      '很多工具绑定某一家代理、某一家AI服务，一旦涨价或宕机就束手无策。ADX-Auto从设计之初就坚持开放生态路线，内置5家主流代理厂商API和13+主流大模型，你可以随时切换或并行使用，成本和风险双降。',
    advantages: [
      { title: '5家代理厂商', desc: 'BrightData / Oxylabs / GeoSurf / SmartProxy / NetNut 全部内置，一家出问题秒切另一家。' },
      { title: '13+大模型', desc: 'GPT-4o / Claude 3.5 / Gemini / 通义千问 / 文心一言 / DeepSeek 等，自由对比效果。' },
      { title: '调用成本透明', desc: '每个模型每一次调用多少钱，按天/周/月的维度清晰展示，并可设置预算上限。' },
      { title: '自动故障降级', desc: '配置主备模型，主模型故障时自动切换到备用模型，保证任务不中断。' }
    ],
    gradient: 'linear-gradient(135deg, #8B5CF6 0%, #EC4899 100%)'
  },
  {
    icon: 'Lock',
    tag: '06',
    title: '顶级防关联设计 · 保障账号安全',
    subtitle: '底层环境隔离，封号风险直降90%',
    description:
      '账号关联封号是所有投手的噩梦。ADX-Auto从底层做起：每个账号独立环境、独立指纹、独立代理，外加操作行为风控模型，让你的每个账号在Google看来都是完全不同的真实用户在不同地方操作。',
    advantages: [
      { title: '100%环境隔离', desc: '每个账号绑定独立浏览器指纹+独立代理+独立UA/时区/语言，数据互通但环境完全隔离。' },
      { title: '浏览器指纹随机化', desc: 'Canvas/WebGL/WebRTC/Fonts/AudioContext 等主流指纹点全部可配置随机化。' },
      { title: '代理池健康检测', desc: '7x24监控代理节点的匿名度、地理准确性、速度，自动剔除问题节点。' },
      { title: '行为风控模型', desc: '基于真实用户操作频率/节奏/鼠标轨迹训练的风控模型，异常行为自动熔断。' }
    ],
    gradient: 'linear-gradient(135deg, #111827 0%, #6366F1 100%)'
  }
]
</script>

<template>
  <div class="highlights-page">
    <!-- Page Hero -->
    <section class="page-hero">
      <div class="adx-container">
        <div class="page-hero-inner">
          <span class="page-tag">系统亮点 · Highlights</span>
          <h1 class="page-title">六大差异化设计，真正拉开与普通工具的差距</h1>
          <p class="page-desc">
            这些能力看起来"不起眼"，但在长期大规模投放场景下，才是决定账号安全和投放ROI的胜负手。
          </p>
        </div>
      </div>
    </section>

    <!-- Highlights Detail List -->
    <section class="adx-section">
      <div class="adx-container">
        <div class="hl-list">
          <div
            v-for="(h, idx) in highlightDetail"
            :key="idx"
            class="hl-block"
            :class="{ 'is-reverse': idx % 2 === 1 }"
          >
            <div class="hl-visual">
              <div class="hl-visual-inner" :style="{ background: h.gradient }">
                <div class="hl-tag-big">{{ h.tag }}</div>
                <el-icon :size="56" class="hl-icon-big"><component :is="h.icon" /></el-icon>
              </div>
            </div>

            <div class="hl-content">
              <div class="hl-tag-text">Highlight {{ h.tag }}</div>
              <h2 class="hl-title">{{ h.title }}</h2>
              <div class="hl-subtitle">{{ h.subtitle }}</div>
              <p class="hl-desc">{{ h.description }}</p>

              <div class="hl-adv-grid">
                <div v-for="(a, aidx) in h.advantages" :key="aidx" class="adv-item">
                  <div class="adv-title">
                    <el-icon color="#6366F1" :size="16"><StarFilled /></el-icon>
                    <span>{{ a.title }}</span>
                  </div>
                  <div class="adv-desc">{{ a.desc }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Highlights Cards Summary -->
    <section class="adx-section summary-section">
      <div class="adx-container">
        <SectionTitle
          title="一个平台，六大核心优势同时具备"
          subtitle="市面上大多数工具只能覆盖其中1-2项，ADX-Auto让你一站集齐"
        />

        <div class="summary-grid">
          <HighlightCard
            icon="Refresh"
            title="双向数据同步"
            description="无需官方API审批，MCC和子账号双向实时同步"
            :points="['零审批接入流程', '双向实时同步', '全层级数据支持', '账号秒级切换']"
          />
          <HighlightCard
            icon="Aim"
            title="精准补点击算法"
            description="多维度真实用户行为模拟，质量分稳步提升"
            :points="['设备地域时段定向', '浏览行为链路模拟', '成本频次上限', '效果闭环分析']"
          />
          <HighlightCard
            icon="Link"
            title="严谨换链接逻辑"
            description="多形态链接管理，曝光到转化全链路归因"
            :points="['短链/追踪链/跳转链', 'UTM/ClickID透传', 'A/B自动分组', '链接健康检测']"
          />
          <HighlightCard
            icon="Clock"
            title="高效定时任务"
            description="Crontab可视化配置，复杂工作流轻松搞定"
            :points="['简单/高级双模式', '20+任务类型', '失败重试告警', '完整日志审计']"
          />
          <HighlightCard
            icon="Grid"
            title="丰富配置能力"
            description="5家代理+13+大模型，避免供应商锁定"
            :points="['主流厂商全覆盖', '模型成本透明', '主备自动切换', '预算阈值告警']"
          />
          <HighlightCard
            icon="Lock"
            title="顶级防关联设计"
            description="环境+指纹+行为三层防护，账号安全更稳"
            :points="['环境完全隔离', '指纹动态随机', '代理健康检测', '行为风控模型']"
          />
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="page-cta">
      <div class="adx-container">
        <div class="cta-card">
          <h3>想亲眼看看这些能力是如何工作的？</h3>
          <p>预约30分钟专属演示，我们用你的真实场景跑一遍给你看。</p>
          <GradientButton size="large" @click="goPricing">
            立即购买体验
            <el-icon><ArrowRight /></el-icon>
          </GradientButton>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.highlights-page {
  background: var(--adx-bg-color);
}

.page-hero {
  padding: 80px 0 48px;
  background: linear-gradient(
    180deg,
    rgba(99, 102, 241, 0.06) 0%,
    rgba(138, 5, 255, 0.03) 50%,
    var(--adx-bg-color) 100%
  );
  text-align: center;
}

.page-tag {
  display: inline-block;
  padding: 5px 14px;
  background: rgba(99, 102, 241, 0.08);
  border: 1px solid rgba(99, 102, 241, 0.18);
  color: var(--adx-color-primary);
  border-radius: 9999px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 18px;
}

.page-title {
  font-size: 44px;
  font-weight: 800;
  line-height: 1.3;
  margin: 0 0 18px;
  background: var(--adx-gradient-primary);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;

  @media (max-width: 1024px) {
    font-size: 32px;
  }
  @media (max-width: 640px) {
    font-size: 24px;
  }
}

.page-desc {
  font-size: 17px;
  color: var(--adx-text-secondary);
  line-height: 1.8;
  max-width: 780px;
  margin: 0 auto;

  @media (max-width: 640px) {
    font-size: 15px;
  }
}

// highlight detail list
.hl-list {
  display: flex;
  flex-direction: column;
  gap: 72px;

  @media (max-width: 640px) {
    gap: 48px;
  }
}

.hl-block {
  display: grid;
  grid-template-columns: 1fr 1.2fr;
  gap: 48px;
  align-items: center;

  &.is-reverse {
    .hl-visual { order: 2; }
    .hl-content { order: 1; }
  }

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    gap: 32px;

    &.is-reverse {
      .hl-visual, .hl-content { order: unset; }
    }
  }
}

.hl-visual-inner {
  position: relative;
  aspect-ratio: 5 / 4;
  border-radius: 20px;
  color: #fff;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 20px;
  overflow: hidden;
  box-shadow: var(--adx-shadow-xl);
}

.hl-tag-big {
  position: absolute;
  top: 20px;
  left: 20px;
  font-size: 72px;
  font-weight: 800;
  opacity: 0.15;
  line-height: 1;
}

.hl-icon-big {
  background: rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(8px);
  padding: 24px;
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.hl-tag-text {
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 1px;
  color: var(--adx-color-primary);
  margin-bottom: 10px;
}

.hl-title {
  font-size: 30px;
  font-weight: 800;
  color: var(--adx-text-primary);
  margin: 0 0 10px;
  line-height: 1.25;

  @media (max-width: 640px) {
    font-size: 22px;
  }
}

.hl-subtitle {
  font-size: 17px;
  color: var(--adx-color-purple);
  font-weight: 600;
  margin-bottom: 14px;
}

.hl-desc {
  font-size: 15px;
  color: var(--adx-text-secondary);
  line-height: 1.9;
  margin: 0 0 22px;
}

.hl-adv-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;

  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
}

.adv-item {
  padding: 12px 14px;
  background: var(--adx-bg-secondary);
  border: 1px solid var(--adx-border-light);
  border-radius: 12px;

  .adv-title {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    font-weight: 700;
    color: var(--adx-text-primary);
    margin-bottom: 4px;
  }

  .adv-desc {
    font-size: 13px;
    color: var(--adx-text-secondary);
    line-height: 1.6;
    padding-left: 22px;
  }
}

// Summary
.summary-section {
  background: var(--adx-bg-secondary);
  margin-top: 40px;
}

.summary-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;

  @media (max-width: 1024px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
}

// CTA
.page-cta {
  padding: 48px 0 80px;
}

.cta-card {
  background: linear-gradient(135deg, #8a05ff 0%, #6366f1 100%);
  border-radius: 20px;
  padding: 48px 32px;
  text-align: center;
  color: #fff;

  h3 {
    font-size: 28px;
    font-weight: 800;
    margin: 0 0 10px;
    color: #fff;
  }
  p {
    font-size: 16px;
    color: rgba(255, 255, 255, 0.9);
    margin: 0 0 24px;
  }

  :deep(.gradient-btn) {
    background: #fff;
    color: var(--adx-color-primary);
    &:hover {
      background: #f8fafc;
      color: var(--adx-color-purple);
    }
  }
}
</style>
