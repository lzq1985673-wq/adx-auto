<script setup>
import { useRouter } from 'vue-router'
import SectionTitle from '@/views/components/marketing/SectionTitle.vue'
import GradientButton from '@/views/components/marketing/GradientButton.vue'
import FeatureCard from '@/views/components/marketing/FeatureCard.vue'

const router = useRouter()
const goPricing = () => router.push('/pricing')

const moduleList = [
  {
    icon: 'UserFilled',
    tag: 'Module 01',
    title: 'Ads账号管理',
    subtitle: '多账号集中管控，告别切换混乱',
    description:
      '通过MCC一键录入及子账号自动同步，将所有Google Ads账号统一在ADX-Auto平台内管理。支持权限分级、角色分配，谁看数据谁操作投放，一目了然。',
    imageGradient: 'linear-gradient(135deg, #8A05FF 0%, #6366F1 100%)',
    highlights: [
      { title: 'MCC一键录入+子账号同步', desc: '粘贴MCC ID即可一键拉取所有子账号结构，包括广告系列、广告组层级，零手动配置。' },
      { title: '多账号数据集中展示', desc: '跨账号数据看板，消耗/展示/点击/转化/ROAS全部汇总展示，可按账号/时间维度灵活筛选对比。' },
      { title: '权限分级/角色管理', desc: '管理员/运营/财务/只读等多角色体系，结合部门维度实现精细化权限控制，操作全程审计。' },
      { title: '账号状态实时监控', desc: '异常消耗、账号封禁、支付异常等事件秒级告警，支持邮件/钉钉/短信多渠道通知。' }
    ]
  },
  {
    icon: 'DataAnalysis',
    tag: 'Module 02',
    title: '广告全维度管理',
    subtitle: '全链路运营，告别手动繁琐',
    description:
      '从广告系列、广告组、广告创意到关键词，提供完整的CRUD操作能力。批量创建、批量调整、批量启停，复杂运营动作一键完成。',
    imageGradient: 'linear-gradient(135deg, #06B6D4 0%, #6366F1 100%)',
    highlights: [
      { title: '广告系列批量创建/调整', desc: '基于模板批量创建多账号广告系列，预算/出价策略/地域/语言统一配置，数分钟上线数百系列。' },
      { title: '广告组结构优化', desc: '广告组健康度评分、SKAG最佳实践建议，自动识别长尾关键词并推荐新建广告组。' },
      { title: '广告一键启停/批量更新', desc: '根据ROAS/CPA阈值自动启停广告，批量更新落地页链接、CTA文案、展示图片。' },
      { title: '关键词批量添加/否定', desc: '根据搜索词报告一键添加精准匹配词，自动识别高消费低转化词并批量否定，7x24优化。' }
    ]
  },
  {
    icon: 'MagicStick',
    tag: 'Module 03',
    title: '自动广告生成',
    subtitle: 'AI创意引擎，告别灵感枯竭',
    description:
      '只需输入落地页链接或竞品链接，AI自动完成爬虫采集、卖点提炼、多组文案撰写、配图生成到一键提交Google Ads的完整链路。',
    imageGradient: 'linear-gradient(135deg, #F59E0B 0%, #EF4444 100%)',
    highlights: [
      { title: '爬虫采集竞品落地页', desc: '内置无头浏览器爬取任意落地页/竞品站点，自动提取H1-H6、产品卖点、CTA、用户评价等结构化信息。' },
      { title: 'AI生成3组差异化创意', desc: '基于收集到的信息，一次输出3组风格不同的广告创意（标题+描述+路径+图片建议），每一组都附带质量得分预估。' },
      { title: '一键提交Google Ads', desc: '生成的创意直接关联指定广告系列和广告组，点击确认即可提交至Google后台，无需二次手动录入。' },
      { title: '多语言多场景适配', desc: '支持中英日韩西法等20+语种自动翻译与本地化改写，覆盖电商、App安装、线索表单等主流投放场景。' }
    ]
  },
  {
    icon: 'Setting',
    tag: 'Module 04',
    title: '系统灵活配置',
    subtitle: '开放集成生态，告别供应商锁定',
    description:
      '内置5家主流代理厂商API、13+主流AI模型，支持自定义提示词、AI预算阈值，让系统完全适配你的团队工作流和成本预算。',
    imageGradient: 'linear-gradient(135deg, #10B981 0%, #06B6D4 100%)',
    highlights: [
      { title: '5家代理厂商API接入', desc: 'BrightData / Oxylabs / GeoSurf / SmartProxy / NetNut 全球主流住宅/数据中心代理一键接入，代理池健康自动检测。' },
      { title: '13+AI模型自由切换', desc: 'GPT-4o / Claude 3.5 / Gemini Pro / 通义千问 / 文心一言 / DeepSeek 等大模型任意切换，对比成本和输出效果。' },
      { title: '自定义提示词模板', desc: '内置行业模板库（电商/B2B/金融/游戏…），支持自定义提示词版本管理，团队成员共享最佳实践。' },
      { title: 'AI成本可视化控制', desc: '按用户/按日/按月设置AI调用预算，超支自动告警或降级到便宜模型，成本明细报表一键导出。' }
    ]
  }
]
</script>

<template>
  <div class="features-page">
    <!-- Page Hero -->
    <section class="page-hero">
      <div class="adx-container">
        <div class="page-hero-inner">
          <span class="page-tag">核心功能 · Features</span>
          <h1 class="page-title">四大功能模块，真正实现投放全链路自动化</h1>
          <p class="page-desc">
            从账号接入、广告运营、AI创意到系统集成，每个模块都经过500+团队实战打磨，
            为你的Google Ads业务提供从1到100的成长动力。
          </p>
        </div>
      </div>
    </section>

    <!-- Feature Modules -->
    <section class="adx-section">
      <div class="adx-container">
        <div class="module-list">
          <div
            v-for="(m, idx) in moduleList"
            :key="idx"
            class="module-block"
            :class="{ 'is-reverse': idx % 2 === 1 }"
          >
            <div class="module-visual">
              <div class="visual-card" :style="{ background: m.imageGradient }">
                <div class="visual-icon">
                  <el-icon :size="64"><component :is="m.icon" /></el-icon>
                </div>
                <div class="visual-pattern">
                  <div v-for="n in 6" :key="n" class="pattern-dot"></div>
                </div>
              </div>
            </div>

            <div class="module-content">
              <div class="module-tag">{{ m.tag }}</div>
              <h2 class="module-title">{{ m.title }}</h2>
              <div class="module-subtitle">{{ m.subtitle }}</div>
              <p class="module-desc">{{ m.description }}</p>

              <div class="module-highlights">
                <div v-for="(h, hidx) in m.highlights" :key="hidx" class="highlight-item">
                  <div class="hi-icon">
                    <el-icon color="#10B981" :size="18"><CircleCheckFilled /></el-icon>
                  </div>
                  <div class="hi-body">
                    <div class="hi-title">{{ h.title }}</div>
                    <div class="hi-desc">{{ h.desc }}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Feature Cards Grid -->
    <section class="adx-section grid-section">
      <div class="adx-container">
        <SectionTitle
          title="还有更多实用小功能，提升日常效率"
          subtitle="细节决定体验，我们为你准备了丰富的贴心小能力"
        />

        <div class="extra-grid">
          <FeatureCard
            icon="Calendar"
            title="智能定时任务"
            description="支持Crontab表达式配置任意执行计划"
            :features="['预算定时调增调降', '时段自动启停广告', '数据报表定时推送', '关键词批量定时否词']"
          />
          <FeatureCard
            icon="PieChart"
            title="多维数据分析"
            description="全维度数据看板，快速定位问题机会"
            :features="['账号/系列/组/广告漏斗', '自定义指标计算公式', '数据多维度下钻', '周/月自动报告生成']"
          />
          <FeatureCard
            icon="Share"
            title="补点击智能引擎"
            description="模拟真实用户行为，提升广告质量得分"
            :features="['设备/地域/时段精准匹配', '多行为链路模拟', '频次与成本智能控制', '完整点击日志可追溯']"
          />
          <FeatureCard
            icon="Link"
            title="换链接全链路"
            description="从短链生成到追踪归因实现数据闭环"
            :features="['短链/追踪链/跳转链', '曝光-点击-转化全链路', 'A/B测试自动分组', '链接健康度自动检测']"
          />
          <FeatureCard
            icon="Lock"
            title="账号防关联"
            description="底层环境隔离，账号安全更有保障"
            :features="['独立环境完全隔离', '浏览器指纹随机', '代理池健康检测', '操作行为风控模型']"
          />
          <FeatureCard
            icon="User"
            title="团队协作空间"
            description="多人协作高效配合，操作清晰可追溯"
            :features="['多角色权限体系', '操作日志完整审计', '任务分配与审批', '团队成员绩效统计']"
          />
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="page-cta">
      <div class="adx-container">
        <div class="cta-card">
          <h3>准备好让你的投放效率起飞了吗？</h3>
          <p>立即购买 ADX-Auto，开启 Google Ads 全自动化新时代。</p>
          <GradientButton size="large" @click="goPricing">
            查看价格方案
            <el-icon><ArrowRight /></el-icon>
          </GradientButton>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.features-page {
  background: var(--adx-bg-color);
}

.page-hero {
  padding: 80px 0 48px;
  background: linear-gradient(
    180deg,
    rgba(138, 5, 255, 0.06) 0%,
    rgba(99, 102, 241, 0.03) 50%,
    var(--adx-bg-color) 100%
  );
  text-align: center;
}

.page-tag {
  display: inline-block;
  padding: 5px 14px;
  background: rgba(138, 5, 255, 0.08);
  border: 1px solid rgba(138, 5, 255, 0.16);
  color: #8a05ff;
  border-radius: 9999px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 18px;
}

.page-title {
  font-size: 44px;
  font-weight: 800;
  line-height: 1.3;
  margin: 0 0 18px;
  background: var(--adx-gradient-primary);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;

  @media (max-width: 1024px) {
    font-size: 32px;
  }
  @media (max-width: 640px) {
    font-size: 24px;
  }
}

.page-desc {
  font-size: 17px;
  color: var(--adx-text-secondary);
  line-height: 1.8;
  max-width: 780px;
  margin: 0 auto;

  @media (max-width: 640px) {
    font-size: 15px;
  }
}

// Module list
.module-list {
  display: flex;
  flex-direction: column;
  gap: 80px;

  @media (max-width: 640px) {
    gap: 48px;
  }
}

.module-block {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 56px;
  align-items: center;

  &.is-reverse {
    .module-visual {
      order: 2;
    }
    .module-content {
      order: 1;
    }
  }

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    gap: 32px;

    &.is-reverse {
      .module-visual,
      .module-content {
        order: unset;
      }
    }
  }
}

.module-visual {
  position: relative;
}

.visual-card {
  position: relative;
  aspect-ratio: 4 / 3;
  border-radius: 20px;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow: var(--adx-shadow-xl);
}

.visual-icon {
  position: relative;
  z-index: 2;
  background: rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(10px);
  padding: 32px;
  border-radius: 24px;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.visual-pattern {
  position: absolute;
  inset: 0;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(2, 1fr);
  padding: 24px;
  gap: 20px;
  z-index: 1;
  opacity: 0.25;
}

.pattern-dot {
  border: 2px solid rgba(255, 255, 255, 0.6);
  border-radius: 12px;
}

.module-tag {
  display: inline-block;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 1px;
  color: var(--adx-color-primary);
  margin-bottom: 10px;
}

.module-title {
  font-size: 32px;
  font-weight: 800;
  color: var(--adx-text-primary);
  margin: 0 0 10px;
  line-height: 1.25;

  @media (max-width: 640px) {
    font-size: 24px;
  }
}

.module-subtitle {
  font-size: 17px;
  color: var(--adx-color-primary);
  font-weight: 600;
  margin-bottom: 14px;
}

.module-desc {
  font-size: 15px;
  color: var(--adx-text-secondary);
  line-height: 1.85;
  margin: 0 0 24px;
}

.module-highlights {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.highlight-item {
  display: flex;
  gap: 12px;
  padding: 14px;
  background: var(--adx-bg-secondary);
  border-radius: 12px;
  border: 1px solid var(--adx-border-light);
  transition: all 0.2s;

  &:hover {
    border-color: var(--adx-color-primary-light);
    transform: translateX(2px);
  }
}

.hi-icon {
  flex-shrink: 0;
  margin-top: 2px;
}

.hi-title {
  font-size: 14.5px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin-bottom: 3px;
}

.hi-desc {
  font-size: 13.5px;
  color: var(--adx-text-secondary);
  line-height: 1.65;
}

// Extra Grid
.grid-section {
  background: var(--adx-bg-secondary);
  margin-top: 40px;
}

.extra-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;

  @media (max-width: 1280px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
}

// CTA
.page-cta {
  padding: 48px 0 80px;
}

.cta-card {
  background: linear-gradient(135deg, #8a05ff 0%, #6366f1 100%);
  border-radius: 20px;
  padding: 48px 32px;
  text-align: center;
  color: #fff;

  h3 {
    font-size: 28px;
    font-weight: 800;
    margin: 0 0 10px;
    color: #fff;
  }
  p {
    font-size: 16px;
    color: rgba(255, 255, 255, 0.9);
    margin: 0 0 24px;
  }

  :deep(.gradient-btn) {
    background: #fff;
    color: var(--adx-color-primary);
    &:hover {
      background: #f8fafc;
      color: var(--adx-color-purple);
    }
  }
}
</style>
