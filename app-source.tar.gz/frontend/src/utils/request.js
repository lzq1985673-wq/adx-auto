import axios from 'axios'
import { ElMessage, ElNotification } from 'element-plus'
import NProgress from 'nprogress'
import { useUserStore } from '@/stores/user'
import router from '@/router'

/**
 * Axios 封装
 * - 统一 baseURL、请求/响应拦截
 * - 自动携带 Bearer Token
 * - 401 自动清理 token 并跳转登录
 * - 统一响应结构 { code, msg, data }
 * - 集成 NProgress 进度条
 */

// 创建 axios 实例
const service = axios.create({
  baseURL: import.meta.env.VITE_API_BASE || '/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json;charset=UTF-8'
  }
})

// 记录当前请求数量（用于NProgress多请求协调）
let pendingRequests = 0

const startProgress = () => {
  if (pendingRequests === 0) {
    NProgress.start()
  }
  pendingRequests++
}

const endProgress = () => {
  pendingRequests--
  if (pendingRequests <= 0) {
    pendingRequests = 0
    NProgress.done()
  }
}

/**
 * 请求拦截器
 * 1. 开始 NProgress
 * 2. 注入 Authorization: Bearer {token}
 */
service.interceptors.request.use(
  (config) => {
    startProgress()

    const userStore = useUserStore()
    const token = userStore.token

    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }

    // 针对 form-data 请求自动处理 Content-Type
    if (config.data instanceof FormData) {
      delete config.headers['Content-Type']
    }

    return config
  },
  (error) => {
    endProgress()
    console.error('[Request] 请求错误:', error)
    return Promise.reject(error)
  }
)

/**
 * 响应拦截器
 * 1. 结束 NProgress
 * 2. 统一处理 { code, msg, data } 结构
 * 3. 401 清 token 跳登录
 * 4. 错误提示
 */
service.interceptors.response.use(
  (response) => {
    endProgress()

    const res = response.data

    // 处理 Blob 类型（下载文件）
    if (response.config.responseType === 'blob') {
      return res
    }

    // 兼容后端返回 { code, msg, data } 或直接返回数据
    // 若无 code 字段，则包装为标准结构
    if (res && typeof res === 'object' && ('code' in res)) {
      // 标准结构
      const { code, msg } = res

      if (code === 0 || code === 200) {
        // 成功
        return res
      } else if (code === 401) {
        // 未授权 / Token失效
        handleUnauthorized(msg)
        return Promise.reject(new Error(msg || '登录已过期'))
      } else if (code === 403) {
        // 无权限
        ElNotification.warning({
          title: '权限不足',
          message: msg || '您没有权限执行此操作'
        })
        return Promise.reject(new Error(msg || '权限不足'))
      } else {
        // 业务错误
        ElMessage.error(msg || '请求失败')
        return Promise.reject(new Error(msg || '请求失败'))
      }
    } else {
      // 非标准结构，直接返回包装后的对象
      return { code: 200, msg: 'success', data: res }
    }
  },
  (error) => {
    endProgress()

    const status = error?.response?.status
    const data = error?.response?.data
    const message = data?.msg || data?.message || error.message

    console.error('[Response] 错误:', { status, message, data })

    switch (status) {
      case 400:
        ElMessage.error(message || '请求参数错误')
        break
      case 401:
        handleUnauthorized(message)
        break
      case 403:
        ElNotification.warning({
          title: '权限不足',
          message: message || '您没有权限执行此操作'
        })
        break
      case 404:
        ElMessage.error('请求的资源不存在 (404)')
        break
      case 500:
        ElMessage.error(message || '服务器内部错误 (500)')
        break
      case 502:
      case 503:
      case 504:
        ElMessage.error('服务器暂时不可用，请稍后重试')
        break
      default:
        if (message?.includes('timeout')) {
          ElMessage.error('请求超时，请检查网络后重试')
        } else if (message?.includes('Network Error')) {
          ElMessage.error('网络连接失败，请检查网络')
        } else {
          ElMessage.error(message || '请求失败')
        }
    }

    return Promise.reject(error)
  }
)

/**
 * 处理 401 未授权
 * 清理 token，跳转登录页
 */
const handleUnauthorized = (msg) => {
  const userStore = useUserStore()

  // 避免重复跳转
  if (!userStore.token) return

  userStore.logout()

  ElNotification.warning({
    title: '登录已过期',
    message: msg || '请重新登录后继续操作'
  })

  // 跳转登录页，带上当前地址便于回跳
  const currentPath = router.currentRoute.value.fullPath
  router.push({
    path: '/login',
    query: currentPath !== '/login' ? { redirect: currentPath } : undefined
  })
}

/**
 * 常用请求方法封装
 * 使用方式：
 *   request.get('/xxx', { params: {...} })
 *   request.post('/xxx', data)
 *   request.put('/xxx', data)
 *   request.delete('/xxx', { params: {...} })
 *   request.download('/xxx') -> 返回 Blob
 */
const request = {
  get: (url, config = {}) => service.get(url, config),
  post: (url, data = {}, config = {}) => service.post(url, data, config),
  put: (url, data = {}, config = {}) => service.put(url, data, config),
  delete: (url, config = {}) => service.delete(url, config),
  patch: (url, data = {}, config = {}) => service.patch(url, data, config),

  // 文件下载
  download: (url, method = 'get', data) => {
    return service.request({
      url,
      method,
      data,
      responseType: 'blob'
    })
  },

  // 上传文件（FormData）
  upload: (url, formData, onProgress) => {
    return service.post(url, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      onUploadProgress: onProgress
    })
  }
}

export default request
