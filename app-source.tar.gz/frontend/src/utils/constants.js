/**
 * 全局常量定义
 * 包含系统所有枚举类型、选项配置、价格方案等
 */

// ==========================================
// 1. 通用状态选项 (STATUS_OPTIONS)
// ==========================================
export const STATUS_OPTIONS = [
  { value: 'enabled', label: '启用', type: 'success', color: '#10B981' },
  { value: 'paused', label: '暂停', type: 'warning', color: '#F59E0B' },
  { value: 'removed', label: '已移除', type: 'info', color: '#6B7280' },
  { value: 'pending', label: '待审核', type: 'warning', color: '#F59E0B' },
  { value: 'rejected', label: '已拒绝', type: 'danger', color: '#EF4444' },
  { value: 'archived', label: '已归档', type: 'info', color: '#9CA3AF' }
]

export const STATUS_MAP = STATUS_OPTIONS.reduce((acc, item) => {
  acc[item.value] = item
  return acc
}, {})

// ==========================================
// 2. 广告类型 (AD_TYPES)
// ==========================================
export const AD_TYPES = [
  { value: 'SEARCH', label: '搜索广告', icon: 'Search', desc: 'Google搜索结果页展示' },
  { value: 'DISPLAY', label: '展示广告', icon: 'Picture', desc: 'Google展示广告网络' },
  { value: 'SHOPPING', label: '购物广告', icon: 'Goods', desc: 'Google Shopping商品广告' },
  { value: 'VIDEO', label: '视频广告', icon: 'VideoPlay', desc: 'YouTube视频广告' },
  { value: 'APP', label: '应用广告', icon: 'Mobile', desc: '应用推广广告' },
  { value: 'PERFORMANCE_MAX', label: 'PMax广告', icon: 'Promotion', desc: '效果最大化广告' },
  { value: 'RESPONSIVE_SEARCH', label: 'RSA搜索', icon: 'Document', desc: '自适应搜索广告' },
  { value: 'EXPANDED_TEXT', label: 'ETA文字广告', icon: 'EditPen', desc: '扩展文字广告' }
]

export const AD_TYPE_MAP = AD_TYPES.reduce((acc, item) => {
  acc[item.value] = item
  return acc
}, {})

// ==========================================
// 3. 关键词匹配类型 (MATCH_TYPES)
// ==========================================
export const MATCH_TYPES = [
  { value: 'EXACT', label: '精确匹配', symbol: '[keyword]', color: '#6366F1', desc: '完全匹配搜索词' },
  { value: 'PHRASE', label: '词组匹配', symbol: '"keyword"', color: '#8A05FF', desc: '包含完整词组' },
  { value: 'BROAD', label: '广泛匹配', symbol: 'keyword', color: '#10B981', desc: '相关变体也匹配' },
  { value: 'BROAD_MODIFIER', label: '广泛匹配修饰符', symbol: '+keyword', color: '#F59E0B', desc: '必须包含修饰词' },
  { value: 'NEGATIVE_EXACT', label: '否定精确', symbol: '-[keyword]', color: '#EF4444', desc: '排除精确匹配' },
  { value: 'NEGATIVE_PHRASE', label: '否定词组', symbol: '-\"keyword\"', color: '#DC2626', desc: '排除词组匹配' },
  { value: 'NEGATIVE_BROAD', label: '否定广泛', symbol: '-keyword', color: '#B91C1C', desc: '排除广泛匹配' }
]

export const MATCH_TYPE_MAP = MATCH_TYPES.reduce((acc, item) => {
  acc[item.value] = item
  return acc
}, {})

// ==========================================
// 4. AI 服务提供商 (AI_PROVIDERS)
// ==========================================
export const AI_PROVIDERS = [
  { value: 'openai', label: 'OpenAI (GPT)', icon: 'Cpu', desc: 'GPT-4 / GPT-3.5 Turbo', website: 'https://openai.com' },
  { value: 'anthropic', label: 'Anthropic (Claude)', icon: 'ChatDotRound', desc: 'Claude 3 / Claude 2', website: 'https://anthropic.com' },
  { value: 'google_ai', label: 'Google AI (Gemini)', icon: 'Google', desc: 'Gemini Pro / Ultra', website: 'https://ai.google.dev' },
  { value: 'deepseek', label: 'DeepSeek', icon: 'MagicStick', desc: 'DeepSeek V2 / Coder', website: 'https://deepseek.com' },
  { value: 'qwen', label: '通义千问 (Alibaba)', icon: 'Aim', desc: 'Qwen2 / Qwen-Max', website: 'https://tongyi.aliyun.com' },
  { value: 'doubao', label: '豆包 (ByteDance)', icon: 'Sparkles', desc: 'Doubao Pro / Lite', website: 'https://doubao.com' },
  { value: 'zhipu', label: '智谱AI (GLM)', icon: 'Medal', desc: 'GLM-4 / GLM-3', website: 'https://zhipuai.cn' }
]

export const AI_PROVIDER_MAP = AI_PROVIDERS.reduce((acc, item) => {
  acc[item.value] = item
  return acc
}, {})

// ==========================================
// 5. 代理服务提供商 (PROXY_PROVIDERS)
// ==========================================
export const PROXY_PROVIDERS = [
  { value: 'brightdata', label: 'BrightData (Luminati)', icon: 'Connection', desc: '全球住宅代理，质量最优', price: '$12.5/GB起' },
  { value: 'oxylabs', label: 'Oxylabs', icon: 'Link', desc: '数据中心+住宅代理', price: '$10/GB起' },
  { value: 'smartproxy', label: 'SmartProxy', icon: 'Share', desc: '高匿住宅代理池', price: '$7.5/GB起' },
  { value: 'iproyal', label: 'IPRoyal', icon: 'TurnOff', desc: '实惠型海外代理', price: '$5/GB起' },
  { value: 'custom', label: '自定义代理', icon: 'Setting', desc: '自填代理服务器列表', price: '自定义' }
]

export const PROXY_PROVIDER_MAP = PROXY_PROVIDERS.reduce((acc, item) => {
  acc[item.value] = item
  return acc
}, {})

// ==========================================
// 6. 定时任务类型 (TASK_TYPES)
// ==========================================
export const TASK_TYPES = [
  { value: 'campaign_sync', label: '广告系列同步', icon: 'Refresh', desc: '从Google Ads同步广告系列数据', cron: '0 */4 * * *' },
  { value: 'keyword_bid_adjust', label: '关键词出价优化', icon: 'TrendCharts', desc: '基于ROI自动调整关键词出价', cron: '0 * * * *' },
  { value: 'ai_generate_ad', label: 'AI批量生成广告', icon: 'MagicStick', desc: '自动生成RSA/ETA广告文案', cron: '0 3 * * *' },
  { value: 'click_bot_run', label: '补点击任务', icon: 'Mouse', desc: '执行模拟点击补量任务', cron: '0 */2 * * *' },
  { value: 'link_swap_switch', label: '换链接切换', icon: 'Switch', desc: '按计划切换落地页链接', cron: '0 0 * * *' },
  { value: 'budget_reallocate', label: '预算再分配', icon: 'Wallet', desc: '根据表现重新分配系列预算', cron: '0 2 * * MON' },
  { value: 'account_health_check', label: '账号健康检查', icon: 'CircleCheck', desc: '检查账号异常及政策风险', cron: '0 1 * * *' },
  { value: 'report_export', label: '数据报表导出', icon: 'Download', desc: '自动生成并发送周报/月报', cron: '0 8 * * MON' }
]

export const TASK_TYPE_MAP = TASK_TYPES.reduce((acc, item) => {
  acc[item.value] = item
  return acc
}, {})

// ==========================================
// 7. 价格方案 (PRICING_PLANS) - 对标 adxkit
// ==========================================
export const PRICING_PLANS = [
  {
    value: 'free',
    name: 'Free 基础版',
    price: 0,
    priceMonthly: 0,
    priceYearly: 0,
    tagline: '适合个人体验',
    highlight: false,
    features: [
      { name: 'MCC账号数量', limit: '1 个账号' },
      { name: '广告系列数', limit: '最多 10 个' },
      { name: 'AI创意生成', limit: '20 次/月' },
      { name: '补点击功能', limit: '未开放' },
      { name: '换链接管理', limit: '5 组/月' },
      { name: '定时任务', limit: '3 个任务' },
      { name: '团队成员', limit: '仅自己' },
      { name: '技术支持', limit: '社区支持' },
      { name: 'API访问', limit: '未开放' }
    ],
    cta: '免费开始',
    ctaType: 'default'
  },
  {
    value: 'pro',
    name: 'Pro 专业版',
    price: 499,
    priceMonthly: 499,
    priceYearly: 4990,
    tagline: '适合中小团队/独立优化师',
    highlight: true,
    features: [
      { name: 'MCC账号数量', limit: '10 个账号' },
      { name: '广告系列数', limit: '最多 500 个' },
      { name: 'AI创意生成', limit: '2000 次/月' },
      { name: '补点击功能', limit: '10 万点击/月' },
      { name: '换链接管理', limit: '500 组/月' },
      { name: '定时任务', limit: '50 个任务' },
      { name: '团队成员', limit: '5 人' },
      { name: '技术支持', limit: '7x12 工单+群支持' },
      { name: 'API访问', limit: '开放调用' }
    ],
    cta: '立即升级',
    ctaType: 'primary'
  },
  {
    value: 'enterprise',
    name: 'Enterprise 企业版',
    price: 0,
    priceMonthly: null,
    priceYearly: null,
    tagline: '适合代理商/品牌方定制',
    highlight: false,
    features: [
      { name: 'MCC账号数量', limit: '不限' },
      { name: '广告系列数', limit: '不限' },
      { name: 'AI创意生成', limit: '不限' },
      { name: '补点击功能', limit: '不限（专属IP池）' },
      { name: '换链接管理', limit: '不限' },
      { name: '定时任务', limit: '不限' },
      { name: '团队成员', limit: '不限 + 角色权限' },
      { name: '技术支持', limit: '7x24 专属客户经理' },
      { name: 'API访问', limit: '无限调用 + 定制' },
      { name: '私有化部署', limit: '支持' },
      { name: 'SLA保障', limit: '99.9%可用性承诺' }
    ],
    cta: '联系销售',
    ctaType: 'default'
  }
]

export const PRICING_PLAN_MAP = PRICING_PLANS.reduce((acc, item) => {
  acc[item.value] = item
  return acc
}, {})

// ==========================================
// 8. 响应式断点（与SCSS保持一致）
// ==========================================
export const BREAKPOINTS = {
  xs: 480,
  sm: 768,
  md: 1024,
  lg: 1280,
  xl: 1536
}

// ==========================================
// 9. 货币选项
// ==========================================
export const CURRENCY_OPTIONS = [
  { value: 'CNY', label: '人民币 (¥)', symbol: '¥' },
  { value: 'USD', label: '美元 ($)', symbol: '$' },
  { value: 'EUR', label: '欧元 (€)', symbol: '€' },
  { value: 'GBP', label: '英镑 (£)', symbol: '£' },
  { value: 'JPY', label: '日元 (¥)', symbol: '¥' },
  { value: 'HKD', label: '港币 (HK$)', symbol: 'HK$' }
]
