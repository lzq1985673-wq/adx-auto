import { createRouter, createWebHistory } from 'vue-router'
import NProgress from 'nprogress'
import { useUserStore } from '@/stores/user'

// 路由配置
const routes = [
  // ====== 营销页面（Marketing Layout） ======
  {
    path: '/',
    component: () => import('@/layouts/MarketingLayout.vue'),
    children: [
      {
        path: '',
        name: 'Home',
        component: () => import('@/views/marketing/Home.vue'),
        meta: { title: '首页 - ADX-Auto' }
      },
      {
        path: 'features',
        name: 'Features',
        component: () => import('@/views/marketing/Features.vue'),
        meta: { title: '核心功能 - ADX-Auto' }
      },
      {
        path: 'highlights',
        name: 'Highlights',
        component: () => import('@/views/marketing/Highlights.vue'),
        meta: { title: '系统亮点 - ADX-Auto' }
      },
      {
        path: 'value',
        name: 'Value',
        component: () => import('@/views/marketing/Value.vue'),
        meta: { title: '系统价值 - ADX-Auto' }
      },
      {
        path: 'pricing',
        name: 'Pricing',
        component: () => import('@/views/marketing/Pricing.vue'),
        meta: { title: '价格方案 - ADX-Auto' }
      },
      {
        path: 'cases',
        name: 'Cases',
        component: () => import('@/views/marketing/Cases.vue'),
        meta: { title: '客户案例 - ADX-Auto' }
      },
      {
        path: 'faq',
        name: 'FAQ',
        component: () => import('@/views/marketing/FAQ.vue'),
        meta: { title: '常见问题 - ADX-Auto' }
      }
    ]
  },

  // ====== 登录注册页（独立布局） ======
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/auth/Login.vue'),
    meta: { title: '登录 - ADX-Auto', public: true }
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/auth/Register.vue'),
    meta: { title: '注册 - ADX-Auto', public: true }
  },

  // ====== 后台管理（Admin Layout，需登录） ======
  {
    path: '/dashboard',
    component: () => import('@/layouts/AdminLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      {
        path: '',
        name: 'Dashboard',
        component: () => import('@/views/dashboard/Dashboard.vue'),
        meta: { title: '仪表盘 - ADX-Auto', requiresAuth: true }
      },
      // MCC账号管理
      {
        path: 'accounts',
        name: 'Accounts',
        component: () => import('@/views/dashboard/Accounts.vue'),
        meta: { title: 'MCC账号管理 - ADX-Auto', requiresAuth: true }
      },
      // 广告系列
      {
        path: 'campaigns',
        name: 'Campaigns',
        component: () => import('@/views/dashboard/Campaigns.vue'),
        meta: { title: '广告系列 - ADX-Auto', requiresAuth: true }
      },
      // 广告组
      {
        path: 'adgroups',
        name: 'AdGroups',
        component: () => import('@/views/dashboard/AdGroups.vue'),
        meta: { title: '广告组 - ADX-Auto', requiresAuth: true }
      },
      // 广告管理
      {
        path: 'ads',
        name: 'Ads',
        component: () => import('@/views/dashboard/Ads.vue'),
        meta: { title: '广告管理 - ADX-Auto', requiresAuth: true }
      },
      // 关键词
      {
        path: 'keywords',
        name: 'Keywords',
        component: () => import('@/views/dashboard/Keywords.vue'),
        meta: { title: '关键词 - ADX-Auto', requiresAuth: true }
      },
      // AI创意生成
      {
        path: 'ai-creative',
        name: 'AICreative',
        component: () => import('@/views/dashboard/AICreative.vue'),
        meta: { title: 'AI创意生成 - ADX-Auto', requiresAuth: true }
      },
      // 补点击配置
      {
        path: 'click-bot',
        name: 'ClickBot',
        component: () => import('@/views/dashboard/ClickBot.vue'),
        meta: { title: '补点击配置 - ADX-Auto', requiresAuth: true }
      },
      // 换链接管理
      {
        path: 'link-swap',
        name: 'LinkSwap',
        component: () => import('@/views/dashboard/LinkSwap.vue'),
        meta: { title: '换链接管理 - ADX-Auto', requiresAuth: true }
      },
      // 定时任务
      {
        path: 'tasks',
        name: 'Tasks',
        component: () => import('@/views/dashboard/Tasks.vue'),
        meta: { title: '定时任务 - ADX-Auto', requiresAuth: true }
      },
      // 配置管理 - 代理配置
      {
        path: 'config/proxy',
        name: 'ConfigProxy',
        component: () => import('@/views/dashboard/config/Proxy.vue'),
        meta: { title: '代理配置 - ADX-Auto', requiresAuth: true }
      },
      // 配置管理 - AI配置
      {
        path: 'config/ai',
        name: 'ConfigAI',
        component: () => import('@/views/dashboard/config/AI.vue'),
        meta: { title: 'AI配置 - ADX-Auto', requiresAuth: true }
      },
      // 配置管理 - 系统配置
      {
        path: 'config/system',
        name: 'ConfigSystem',
        component: () => import('@/views/dashboard/config/System.vue'),
        meta: { title: '系统配置 - ADX-Auto', requiresAuth: true }
      },
      // 团队成员
      {
        path: 'team',
        name: 'Team',
        component: () => import('@/views/dashboard/Team.vue'),
        meta: { title: '团队成员 - ADX-Auto', requiresAuth: true }
      },
      // 个人中心
      {
        path: 'profile',
        name: 'Profile',
        component: () => import('@/views/dashboard/profile/Profile.vue'),
        meta: { title: '个人中心 - ADX-Auto', requiresAuth: true }
      }
    ]
  },

  // ====== 404 ======
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/NotFound.vue'),
    meta: { title: '页面不存在 - ADX-Auto' }
  }
]

// 创建路由实例
const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    // 路由切换滚动行为
    if (savedPosition) {
      return savedPosition
    } else {
      return { top: 0 }
    }
  }
})

// 全局前置守卫：路由守卫 + NProgress
router.beforeEach((to, from, next) => {
  // 开始进度条
  NProgress.start()

  // 设置页面标题
  if (to.meta && to.meta.title) {
    document.title = to.meta.title
  }

  const userStore = useUserStore()
  const token = userStore.token

  // 已登录用户访问登录/注册页，跳转到dashboard
  if (token && (to.path === '/login' || to.path === '/register')) {
    next('/dashboard')
    return
  }

  // 检查是否需要登录
  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!token) {
      // 未登录，跳转登录页，带上回调地址
      next({
        path: '/login',
        query: { redirect: to.fullPath }
      })
    } else {
      next()
    }
  } else {
    next()
  }
})

// 全局后置钩子：结束进度条
router.afterEach(() => {
  NProgress.done()
})

export default router
