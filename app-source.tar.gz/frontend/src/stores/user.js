import { defineStore } from 'pinia'
import request from '@/utils/request'

// localStorage 存储key
const TOKEN_KEY = 'ADX_AUTO_TOKEN'
const USER_INFO_KEY = 'ADX_AUTO_USER_INFO'

/**
 * 用户状态管理 Store
 * 管理token、用户信息、权限、租户信息等
 */
export const useUserStore = defineStore('user', {
  // 状态
  state: () => ({
    // JWT Token，优先从localStorage恢复
    token: localStorage.getItem(TOKEN_KEY) || '',
    // 用户信息对象
    userInfo: JSON.parse(localStorage.getItem(USER_INFO_KEY) || 'null'),
    // 权限列表（权限标识数组）
    permissions: [],
    // 租户信息（多租户场景）
    tenantInfo: null
  }),

  // 计算属性
  getters: {
    // 是否已登录
    isLoggedIn: (state) => !!state.token,
    // 用户名（带空值保护）
    username: (state) => state.userInfo?.username || '',
    // 用户头像
    avatar: (state) => state.userInfo?.avatar || '',
    // 租户ID
    tenantId: (state) => state.tenantInfo?.id || state.userInfo?.tenant_id || ''
  },

  // 动作
  actions: {
    /**
     * 用户登录
     * @param {Object} credentials - 登录凭证 { username, password, captcha? }
     * @returns {Promise<Object>} 登录结果
     */
    async login(credentials) {
      try {
        const res = await request.post('/auth/login', credentials)

        if (res.code === 0 || res.code === 200) {
          const { token, userInfo, permissions, tenantInfo } = res.data || {}

          // 保存到 state
          this.token = token || ''
          this.userInfo = userInfo || null
          this.permissions = permissions || []
          this.tenantInfo = tenantInfo || null

          // 持久化到 localStorage
          if (token) {
            localStorage.setItem(TOKEN_KEY, token)
          }
          if (userInfo) {
            localStorage.setItem(USER_INFO_KEY, JSON.stringify(userInfo))
          }
        }

        return res
      } catch (error) {
        console.error('[UserStore] 登录失败:', error)
        throw error
      }
    },

    /**
     * 用户登出
     * 清除本地token和用户信息，可调用后端接口
     */
    async logout() {
      try {
        // 可选：调用后端登出接口
        if (this.token) {
          await request.post('/auth/logout').catch(() => {
            // 忽略后端登出错误，本地仍然清掉
          })
        }
      } finally {
        // 清除 state
        this.token = ''
        this.userInfo = null
        this.permissions = []
        this.tenantInfo = null

        // 清除 localStorage
        localStorage.removeItem(TOKEN_KEY)
        localStorage.removeItem(USER_INFO_KEY)
      }
    },

    /**
     * 获取当前用户信息
     * 通常用于页面刷新后重新拉取用户详情
     * @returns {Promise<Object>} 用户信息
     */
    async getUserInfo() {
      try {
        const res = await request.get('/auth/user-info')

        if (res.code === 0 || res.code === 200) {
          const { userInfo, permissions, tenantInfo } = res.data || {}

          this.userInfo = userInfo || this.userInfo
          this.permissions = permissions || this.permissions
          this.tenantInfo = tenantInfo || this.tenantInfo

          if (userInfo) {
            localStorage.setItem(USER_INFO_KEY, JSON.stringify(userInfo))
          }
        }

        return res
      } catch (error) {
        console.error('[UserStore] 获取用户信息失败:', error)
        throw error
      }
    },

    /**
     * 刷新Token
     * 当token即将过期时调用，获取新的token
     * @returns {Promise<Object>} 刷新结果
     */
    async refreshToken() {
      try {
        const res = await request.post('/auth/refresh-token', {
          token: this.token
        })

        if (res.code === 0 || res.code === 200) {
          const { token } = res.data || {}

          if (token) {
            this.token = token
            localStorage.setItem(TOKEN_KEY, token)
          }
        }

        return res
      } catch (error) {
        console.error('[UserStore] 刷新Token失败:', error)
        // 刷新失败则执行登出
        this.logout()
        throw error
      }
    },

    /**
     * 检查是否拥有指定权限
     * @param {String|Array} permission - 权限标识或标识数组
     * @returns {Boolean} 是否拥有权限
     */
    hasPermission(permission) {
      if (!permission) return true
      if (this.permissions.includes('*')) return true

      if (Array.isArray(permission)) {
        return permission.some(p => this.permissions.includes(p))
      }

      return this.permissions.includes(permission)
    }
  }
})
