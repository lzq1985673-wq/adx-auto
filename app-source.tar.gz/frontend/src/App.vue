<script setup>
/**
 * App.vue - 根组件
 * 包含 router-view 路由视图和全局 NProgress 进度条
 */
import { onMounted } from 'vue'
import { useRoute } from 'vue-router'
import NProgress from 'nprogress'

const route = useRoute()

// 初始化 NProgress 配置
NProgress.configure({
  easing: 'ease',
  speed: 500,
  showSpinner: false,
  trickleSpeed: 200,
  minimum: 0.1
})

// 组件挂载完成后可执行全局初始化
onMounted(() => {
  // 可在此添加全局初始化逻辑
  console.log('[ADX-Auto] 应用启动成功')
})
</script>

<template>
  <!-- 全局根容器 -->
  <div id="app-root" class="app-root">
    <!-- 路由视图 -->
    <router-view v-slot="{ Component }">
      <transition name="fade-transform" mode="out-in">
        <component :is="Component" :key="route.fullPath" />
      </transition>
    </router-view>
  </div>
</template>

<style lang="scss" scoped>
// 应用根容器
.app-root {
  width: 100%;
  min-height: 100vh;
  background-color: var(--adx-bg-color);
  transition: background-color 0.3s ease;
}

// 页面切换过渡动画
.fade-transform-enter-active,
.fade-transform-leave-active {
  transition: all 0.3s ease;
}

.fade-transform-enter-from {
  opacity: 0;
  transform: translateX(20px);
}

.fade-transform-leave-to {
  opacity: 0;
  transform: translateX(-20px);
}
</style>
