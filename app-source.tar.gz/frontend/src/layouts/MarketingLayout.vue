<script setup>
/**
 * MarketingLayout.vue - 营销页面布局
 * 结构：顶部导航(Header) + 内容区(<slot>) + 底部(Footer)
 * 风格：对标 adxkit 紫色系营销站风格
 */
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

// 滚动状态（用于顶栏毛玻璃效果）
const isScrolled = ref(false)
const handleScroll = () => {
  isScrolled.value = window.scrollY > 10
}
onMounted(() => window.addEventListener('scroll', handleScroll))
onUnmounted(() => window.removeEventListener('scroll', handleScroll))

// 移动端菜单开关
const mobileMenuOpen = ref(false)

// 顶栏菜单（对应路由 meta title）
const navItems = [
  { label: '核心功能', path: '/features' },
  { label: '系统亮点', path: '/highlights' },
  { label: '系统价值', path: '/value' },
  { label: '客户案例', path: '/cases' },
  { label: '价格方案', path: '/pricing' }
]

// 当前激活的菜单项
const activePath = computed(() => route.path)

// 跳转到登录
const goLogin = () => router.push('/login')
// 跳转到注册
const goRegister = () => router.push('/register')
// 跳转到价格（立即购买）
const goPricing = () => router.push('/pricing')
// 跳转到仪表盘（已登录时）
const goDashboard = () => router.push('/dashboard')
</script>

<template>
  <div class="marketing-layout">
    <!-- ========== 顶部导航栏 ========== -->
    <header
      class="mk-header"
      :class="{ 'is-scrolled': isScrolled, 'is-mobile-open': mobileMenuOpen }"
    >
      <div class="adx-container mk-header-inner">
        <!-- Logo -->
        <router-link to="/" class="mk-logo" @click="mobileMenuOpen = false">
          <span class="logo-icon">
            <svg viewBox="0 0 32 32" width="32" height="32" aria-hidden="true">
              <defs>
                <linearGradient id="mkLogoGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stop-color="#6366F1" />
                  <stop offset="100%" stop-color="#8A05FF" />
                </linearGradient>
              </defs>
              <rect x="2" y="2" width="28" height="28" rx="8" fill="url(#mkLogoGrad)" />
              <path
                d="M9 22 L14 10 L17 18 L20 10 L25 22"
                stroke="#fff"
                stroke-width="2.2"
                fill="none"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </span>
          <span class="logo-text">
            <span class="logo-text-main">ADX</span>
            <span class="logo-text-sub">Auto</span>
          </span>
        </router-link>

        <!-- 桌面端菜单 -->
        <nav class="mk-nav">
          <router-link
            v-for="item in navItems"
            :key="item.path"
            :to="item.path"
            class="mk-nav-link"
            :class="{ active: activePath === item.path || (item.path !== '/' && activePath.startsWith(item.path)) }"
          >
            {{ item.label }}
          </router-link>
        </nav>

        <!-- 右侧按钮组 -->
        <div class="mk-actions">
          <template v-if="userStore.isLoggedIn">
            <el-button type="primary" class="btn-cta" @click="goDashboard">
              <el-icon><Odometer /></el-icon>
              <span>进入后台</span>
            </el-button>
          </template>
          <template v-else>
            <el-button text class="btn-ghost" @click="goLogin">登录</el-button>
            <el-button class="btn-outline" @click="goRegister">注册</el-button>
            <el-button type="primary" class="btn-cta" @click="goPricing">
              <span>立即购买</span>
              <el-icon><ArrowRight /></el-icon>
            </el-button>
          </template>

          <!-- 移动端菜单按钮 -->
          <button
            class="mk-mobile-toggle"
            :aria-label="mobileMenuOpen ? '关闭菜单' : '打开菜单'"
            @click="mobileMenuOpen = !mobileMenuOpen"
          >
            <el-icon v-if="!mobileMenuOpen"><Menu /></el-icon>
            <el-icon v-else><Close /></el-icon>
          </button>
        </div>
      </div>

      <!-- 移动端下拉菜单 -->
      <transition name="slide-down">
        <div v-if="mobileMenuOpen" class="mk-mobile-menu">
          <div class="adx-container">
            <nav class="mk-mobile-nav">
              <router-link
                v-for="item in navItems"
                :key="item.path"
                :to="item.path"
                class="mk-mobile-nav-link"
                @click="mobileMenuOpen = false"
              >
                {{ item.label }}
              </router-link>
            </nav>
            <div class="mk-mobile-actions">
              <template v-if="userStore.isLoggedIn">
                <el-button type="primary" size="large" class="mk-mobile-btn" @click="goDashboard; mobileMenuOpen = false">
                  进入后台
                </el-button>
              </template>
              <template v-else>
                <el-button size="large" class="mk-mobile-btn" @click="goLogin; mobileMenuOpen = false">
                  登录
                </el-button>
                <el-button size="large" class="mk-mobile-btn" @click="goRegister; mobileMenuOpen = false">
                  注册
                </el-button>
                <el-button type="primary" size="large" class="mk-mobile-btn mk-mobile-btn-primary" @click="goPricing; mobileMenuOpen = false">
                  立即购买 <el-icon><ArrowRight /></el-icon>
                </el-button>
              </template>
            </div>
          </div>
        </div>
      </transition>
    </header>

    <!-- ========== 内容区 ========== -->
    <main class="mk-main">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>

    <!-- ========== 底部 Footer ========== -->
    <footer class="mk-footer">
      <div class="adx-container">
        <div class="mk-footer-grid">
          <!-- 品牌介绍 -->
          <div class="mk-footer-brand">
            <div class="mk-footer-logo">
              <span class="logo-icon">
                <svg viewBox="0 0 32 32" width="28" height="28" aria-hidden="true">
                  <rect x="2" y="2" width="28" height="28" rx="8" fill="url(#mkLogoGrad)" />
                  <path
                    d="M9 22 L14 10 L17 18 L20 10 L25 22"
                    stroke="#fff"
                    stroke-width="2.2"
                    fill="none"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>
              </span>
              <span class="logo-text-main">ADX</span>
              <span class="logo-text-sub">Auto</span>
            </div>
            <p class="mk-footer-desc">
              专为 Google Ads 优化师、代理商与品牌方打造的
              AI 驱动自动化投放管理平台，让广告效果翻倍、人力成本减半。
            </p>
            <div class="mk-footer-socials">
              <a href="#" aria-label="邮箱"><el-icon><Message /></el-icon></a>
              <a href="#" aria-label="微信"><el-icon><ChatDotRound /></el-icon></a>
              <a href="#" aria-label="GitHub"><el-icon><Github /></el-icon></a>
              <a href="#" aria-label="Twitter"><el-icon><Promotion /></el-icon></a>
            </div>
          </div>

          <!-- 产品 -->
          <div class="mk-footer-col">
            <h4 class="mk-footer-title">产品</h4>
            <ul>
              <li><router-link to="/features">核心功能</router-link></li>
              <li><router-link to="/highlights">系统亮点</router-link></li>
              <li><router-link to="/value">系统价值</router-link></li>
              <li><router-link to="/pricing">价格方案</router-link></li>
              <li><router-link to="/cases">客户案例</router-link></li>
              <li><router-link to="/faq">常见问题</router-link></li>
            </ul>
          </div>

          <!-- 资源 -->
          <div class="mk-footer-col">
            <h4 class="mk-footer-title">资源</h4>
            <ul>
              <li><a href="#">帮助文档</a></li>
              <li><a href="#">API 接口文档</a></li>
              <li><a href="#">更新日志</a></li>
              <li><a href="#">使用教程</a></li>
              <li><a href="#">博客资讯</a></li>
              <li><a href="#">合作伙伴</a></li>
            </ul>
          </div>

          <!-- 联系我们 -->
          <div class="mk-footer-col">
            <h4 class="mk-footer-title">联系我们</h4>
            <ul class="mk-footer-contact">
              <li>
                <el-icon><Message /></el-icon>
                <span>support@adx-auto.com</span>
              </li>
              <li>
                <el-icon><Phone /></el-icon>
                <span>400-888-1234</span>
              </li>
              <li>
                <el-icon><Location /></el-icon>
                <span>上海市浦东新区张江科技园</span>
              </li>
              <li>
                <el-icon><Service /></el-icon>
                <span>7x12 在线客服</span>
              </li>
            </ul>
          </div>
        </div>

        <!-- 版权栏 -->
        <div class="mk-footer-bottom">
          <div class="mk-footer-copy">
            <span>© {{ new Date().getFullYear() }} ADX-Auto. All rights reserved.</span>
          </div>
          <div class="mk-footer-links">
            <a href="#">隐私政策</a>
            <span class="sep">·</span>
            <a href="#">服务条款</a>
            <span class="sep">·</span>
            <a href="#">Cookie 设置</a>
            <span class="sep">·</span>
            <span>沪ICP备 2024xxxxxx号</span>
          </div>
        </div>
      </div>
    </footer>
  </div>
</template>

<style lang="scss" scoped>
// ========== 容器 ==========
.marketing-layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background: var(--adx-bg-color);
}

.mk-main {
  flex: 1;
}

// ========== 顶栏 ==========
.mk-header {
  position: sticky;
  top: 0;
  z-index: 100;
  width: 100%;
  background: rgba(255, 255, 255, 0.75);
  backdrop-filter: blur(0);
  -webkit-backdrop-filter: blur(0);
  border-bottom: 1px solid transparent;
  transition: all 0.3s ease;

  &.is-scrolled {
    background: rgba(255, 255, 255, 0.85);
    backdrop-filter: saturate(180%) blur(16px);
    -webkit-backdrop-filter: saturate(180%) blur(16px);
    border-bottom: 1px solid var(--adx-border-light);
    box-shadow: var(--adx-shadow-xs);
  }
}

html.dark .mk-header {
  background: rgba(11, 15, 25, 0.75);
  &.is-scrolled {
    background: rgba(11, 15, 25, 0.85);
  }
}

.mk-header-inner {
  height: 70px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--adx-spacing-lg);
}

// Logo
.mk-logo {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  color: var(--adx-text-primary);
  font-weight: 800;
  text-decoration: none;

  .logo-icon {
    display: inline-flex;
    filter: drop-shadow(0 2px 6px rgba(99, 102, 241, 0.25));
  }

  .logo-text {
    display: inline-flex;
    align-items: baseline;
    gap: 2px;
    font-size: 20px;
    line-height: 1;
  }
  .logo-text-main {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  .logo-text-sub {
    color: var(--adx-text-primary);
    font-weight: 600;
  }
}

// 桌面导航
.mk-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1;
  justify-content: center;

  @media (max-width: 1024px) { display: none; }
}

.mk-nav-link {
  position: relative;
  padding: 8px 16px;
  color: var(--adx-text-secondary);
  font-size: 14px;
  font-weight: 500;
  border-radius: var(--adx-radius-md);
  transition: all 0.2s ease;
  text-decoration: none;

  &:hover {
    color: var(--adx-color-primary);
    background: var(--adx-bg-hover);
  }

  &.active {
    color: var(--adx-color-primary);
    background: rgba(99, 102, 241, 0.08);
    &::after {
      content: '';
      position: absolute;
      left: 16px;
      right: 16px;
      bottom: 2px;
      height: 2px;
      background: var(--adx-gradient-primary);
      border-radius: 2px;
    }
  }
}

// 右侧按钮
.mk-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.btn-ghost {
  color: var(--adx-text-secondary);
  font-weight: 500;
  &:hover { color: var(--adx-color-primary); }
}

.btn-outline {
  border-color: var(--adx-border-color);
  color: var(--adx-text-primary);
  font-weight: 500;
}

.btn-cta {
  background: var(--adx-gradient-primary);
  border: none;
  font-weight: 600;
  padding-left: 20px;
  padding-right: 20px;
  transition: transform 0.2s, box-shadow 0.2s;
  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 20px -6px rgba(99, 102, 241, 0.4);
  }
}

// 移动端菜单按钮
.mk-mobile-toggle {
  display: none;
  width: 40px;
  height: 40px;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--adx-border-color);
  border-radius: var(--adx-radius-md);
  background: var(--adx-bg-card);
  color: var(--adx-text-secondary);
  font-size: 20px;

  @media (max-width: 1024px) { display: inline-flex; }
  @media (max-width: 1024px) {
    .btn-ghost, .btn-outline, .btn-cta { display: none; }
  }
}

// 移动端下拉
.mk-mobile-menu {
  border-top: 1px solid var(--adx-border-light);
  background: var(--adx-bg-color);
  padding: var(--adx-spacing-md) 0 var(--adx-spacing-lg);
}

.mk-mobile-nav {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin-bottom: var(--adx-spacing-md);
}

.mk-mobile-nav-link {
  padding: 12px 14px;
  font-size: 15px;
  color: var(--adx-text-primary);
  border-radius: var(--adx-radius-md);
  &:hover, &.router-link-active {
    background: var(--adx-bg-hover);
    color: var(--adx-color-primary);
  }
}

.mk-mobile-actions {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding-top: var(--adx-spacing-md);
  border-top: 1px solid var(--adx-border-light);
}
.mk-mobile-btn { width: 100%; }
.mk-mobile-btn-primary {
  background: var(--adx-gradient-primary);
  border: none;
}

.slide-down-enter-active,
.slide-down-leave-active {
  transition: all 0.25s ease;
  overflow: hidden;
}
.slide-down-enter-from,
.slide-down-leave-to {
  opacity: 0;
  max-height: 0;
  padding-top: 0;
  padding-bottom: 0;
}
.slide-down-enter-to,
.slide-down-leave-from {
  max-height: 600px;
}

// ========== 底部 Footer ==========
.mk-footer {
  background: var(--adx-bg-secondary);
  border-top: 1px solid var(--adx-border-light);
  padding: var(--adx-spacing-2xl) 0 var(--adx-spacing-lg);
  margin-top: var(--adx-spacing-3xl);
}

.mk-footer-grid {
  display: grid;
  grid-template-columns: 1.4fr 1fr 1fr 1.2fr;
  gap: var(--adx-spacing-xl);

  @media (max-width: 1024px) {
    grid-template-columns: 1fr 1fr;
    row-gap: var(--adx-spacing-xl);
  }
  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
}

.mk-footer-brand .mk-footer-logo {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-bottom: var(--adx-spacing-md);
  font-weight: 800;
  font-size: 18px;
}

.mk-footer-desc {
  color: var(--adx-text-secondary);
  font-size: 13.5px;
  line-height: 1.75;
  margin: 0 0 var(--adx-spacing-md);
}

.mk-footer-socials {
  display: flex;
  gap: 10px;
  a {
    width: 36px;
    height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: var(--adx-bg-card);
    border: 1px solid var(--adx-border-color);
    border-radius: var(--adx-radius-md);
    color: var(--adx-text-secondary);
    transition: all 0.2s;
    &:hover {
      color: var(--adx-color-primary);
      border-color: var(--adx-color-primary-light);
      transform: translateY(-1px);
    }
  }
}

.mk-footer-title {
  font-size: 15px;
  font-weight: 700;
  color: var(--adx-text-primary);
  margin: 0 0 var(--adx-spacing-md);
}

.mk-footer-col ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;

  li a {
    color: var(--adx-text-secondary);
    font-size: 14px;
    transition: color 0.2s;
    &:hover { color: var(--adx-color-primary); }
  }
}

.mk-footer-contact li {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  color: var(--adx-text-secondary);
  font-size: 14px;

  .el-icon {
    margin-top: 3px;
    color: var(--adx-color-primary);
    font-size: 16px;
    flex-shrink: 0;
  }
}

.mk-footer-bottom {
  margin-top: var(--adx-spacing-2xl);
  padding-top: var(--adx-spacing-lg);
  border-top: 1px solid var(--adx-border-light);
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: var(--adx-spacing-md);
  font-size: 13px;
  color: var(--adx-text-tertiary);

  @media (max-width: 640px) {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
}

.mk-footer-links {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  .sep { color: var(--adx-border-color); }
  a {
    color: var(--adx-text-tertiary);
    &:hover { color: var(--adx-color-primary); }
  }
}

// 内容过渡
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
