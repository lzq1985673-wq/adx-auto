<script setup>
/**
 * AdminLayout.vue - 后台管理布局
 * 结构：左侧菜单(可折叠) + 顶栏(Logo/搜索/通知/用户) + 面包屑 + 内容区
 * 风格：Element Plus 经典后台风格，配色同品牌紫色系
 */
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

// ============ 侧边栏 ============
const sidebarCollapsed = ref(false)
const toggleSidebar = () => { sidebarCollapsed.value = !sidebarCollapsed.value }

// 侧边栏菜单配置（含分组、子菜单）
const menuConfig = [
  // 仪表盘
  {
    path: '/dashboard',
    title: '仪表盘',
    icon: 'Odometer'
  },
  // Ads 账号 & 广告管理
  {
    group: '广告管理',
    children: [
      { path: '/dashboard/accounts', title: 'MCC账号管理', icon: 'UserFilled' },
      { path: '/dashboard/campaigns', title: '广告系列', icon: 'Histogram' },
      { path: '/dashboard/adgroups', title: '广告组', icon: 'Collection' },
      { path: '/dashboard/ads', title: '广告管理', icon: 'Promotion' },
      { path: '/dashboard/keywords', title: '关键词', icon: 'Key' }
    ]
  },
  // AI & 自动化工具
  {
    group: 'AI & 自动化',
    children: [
      { path: '/dashboard/ai-creative', title: 'AI创意生成', icon: 'MagicStick' },
      { path: '/dashboard/click-bot', title: '补点击配置', icon: 'Mouse' },
      { path: '/dashboard/link-swap', title: '换链接管理', icon: 'Link' },
      { path: '/dashboard/tasks', title: '定时任务', icon: 'AlarmClock' }
    ]
  },
  // 配置管理（含子菜单）
  {
    path: '/dashboard/config',
    title: '配置管理',
    icon: 'Setting',
    children: [
      { path: '/dashboard/config/proxy', title: '代理配置', icon: 'Connection' },
      { path: '/dashboard/config/ai', title: 'AI配置', icon: 'Cpu' },
      { path: '/dashboard/config/system', title: '系统配置', icon: 'Tools' }
    ]
  },
  // 团队
  {
    path: '/dashboard/team',
    title: '团队成员',
    icon: 'User'
  }
]

// 计算当前激活的菜单（高亮）
const activeMenu = computed(() => route.path)

// 计算默认展开的父级菜单（用于配置管理含子菜单）
const openMenus = computed(() => {
  const opened = []
  if (route.path.startsWith('/dashboard/config')) {
    opened.push('/dashboard/config')
  }
  return opened
})

// 菜单点击跳转
const handleMenuClick = (key) => {
  if (key && key !== route.path) {
    router.push(key)
  }
}

// ============ 顶栏 - 用户下拉 ============
const userDropdownCommand = async (command) => {
  switch (command) {
    case 'profile':
      router.push('/dashboard/profile')
      break
    case 'password':
      router.push('/dashboard/profile#password')
      break
    case 'logout':
      try {
        await ElMessageBox.confirm(
          '确定要退出登录吗？',
          '退出确认',
          { confirmButtonText: '确定退出', cancelButtonText: '取消', type: 'warning' }
        )
        await userStore.logout()
        ElMessage.success('已退出登录')
        router.push('/login')
      } catch (_) { /* 用户取消 */ }
      break
  }
}

// 回到首页
const goHome = () => router.push('/dashboard')

// ============ 面包屑 ============
const breadcrumbItems = computed(() => {
  const items = [{ title: '后台', path: '/dashboard' }]
  const map = {
    '/dashboard/accounts': ['MCC账号管理'],
    '/dashboard/campaigns': ['广告管理', '广告系列'],
    '/dashboard/adgroups': ['广告管理', '广告组'],
    '/dashboard/ads': ['广告管理', '广告管理'],
    '/dashboard/keywords': ['广告管理', '关键词'],
    '/dashboard/ai-creative': ['AI & 自动化', 'AI创意生成'],
    '/dashboard/click-bot': ['AI & 自动化', '补点击配置'],
    '/dashboard/link-swap': ['AI & 自动化', '换链接管理'],
    '/dashboard/tasks': ['AI & 自动化', '定时任务'],
    '/dashboard/config/proxy': ['配置管理', '代理配置'],
    '/dashboard/config/ai': ['配置管理', 'AI配置'],
    '/dashboard/config/system': ['配置管理', '系统配置'],
    '/dashboard/team': ['团队成员'],
    '/dashboard/profile': ['个人中心']
  }
  const chain = map[route.path]
  if (chain) chain.forEach(t => items.push({ title: t }))
  return items
})

// 搜索框
const searchQuery = ref('')
const handleSearch = () => {
  if (searchQuery.value.trim()) {
    ElMessage.info(`搜索: ${searchQuery.value}（功能待接入）`)
  }
}

// 组件挂载后，可预拉取用户信息
onMounted(async () => {
  if (userStore.token && !userStore.userInfo) {
    try { await userStore.getUserInfo() } catch (_) { /* 忽略 */ }
  }
})
</script>

<template>
  <div class="admin-layout" :class="{ 'is-collapsed': sidebarCollapsed }">
    <!-- ============ 左侧菜单 ============ -->
    <aside class="admin-sidebar">
      <!-- 侧边栏 Logo 区 -->
      <div class="admin-sidebar-logo" @click="goHome">
        <span class="logo-icon">
          <svg viewBox="0 0 32 32" width="28" height="28" aria-hidden="true">
            <defs>
              <linearGradient id="adminLogoGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="#6366F1" />
                <stop offset="100%" stop-color="#8A05FF" />
              </linearGradient>
            </defs>
            <rect x="2" y="2" width="28" height="28" rx="8" fill="url(#adminLogoGrad)" />
            <path
              d="M9 22 L14 10 L17 18 L20 10 L25 22"
              stroke="#fff"
              stroke-width="2.2"
              fill="none"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </span>
        <span v-if="!sidebarCollapsed" class="logo-text">
          <span class="logo-main">ADX</span><span class="logo-sub">Auto</span>
        </span>
      </div>

      <!-- 菜单主体 -->
      <el-scrollbar class="admin-sidebar-scroll">
        <el-menu
          :default-active="activeMenu"
          :default-openeds="openMenus"
          :collapse="sidebarCollapsed"
          :collapse-transition="false"
          background-color="transparent"
          unique-opened
          router
          @select="handleMenuClick"
        >
          <template v-for="(item, idx) in menuConfig" :key="idx">
            <!-- 分组标题（仅非折叠展示） -->
            <div
              v-if="item.group && !sidebarCollapsed"
              class="admin-menu-group"
            >
              <span>{{ item.group }}</span>
            </div>

            <!-- 单级菜单 -->
            <el-menu-item
              v-if="!item.children && !item.group"
              :index="item.path"
            >
              <el-icon>
                <component :is="item.icon" />
              </el-icon>
              <template #title>{{ item.title }}</template>
            </el-menu-item>

            <!-- 带子菜单（父级菜单） -->
            <el-sub-menu
              v-if="item.children && !item.group"
              :index="item.path"
            >
              <template #title>
                <el-icon>
                  <component :is="item.icon" />
                </el-icon>
                <span>{{ item.title }}</span>
              </template>
              <el-menu-item
                v-for="child in item.children"
                :key="child.path"
                :index="child.path"
              >
                <el-icon>
                  <component :is="child.icon" />
                </el-icon>
                <template #title>{{ child.title }}</template>
              </el-menu-item>
            </el-sub-menu>

            <!-- 分组下的菜单项（扁平） -->
            <template v-if="item.group && item.children">
              <el-menu-item
                v-for="child in item.children"
                :key="child.path"
                :index="child.path"
              >
                <el-icon>
                  <component :is="child.icon" />
                </el-icon>
                <template #title>{{ child.title }}</template>
              </el-menu-item>
            </template>
          </template>
        </el-menu>
      </el-scrollbar>

      <!-- 侧边栏底部（返回营销站/折叠提示） -->
      <div v-if="!sidebarCollapsed" class="admin-sidebar-footer">
        <router-link to="/" class="back-home-link">
          <el-icon><House /></el-icon>
          <span>返回官网首页</span>
        </router-link>
      </div>
    </aside>

    <!-- ============ 右侧主区域 ============ -->
    <div class="admin-main-wrap">
      <!-- 顶栏 -->
      <header class="admin-header">
        <div class="header-left">
          <button class="collapse-btn" @click="toggleSidebar" title="折叠/展开菜单">
            <el-icon :size="20"><Fold v-if="!sidebarCollapsed" /><Expand v-else /></el-icon>
          </button>
          <el-breadcrumb separator="/" class="admin-breadcrumb">
            <el-breadcrumb-item
              v-for="(item, idx) in breadcrumbItems"
              :key="idx"
              :to="item.path ? item.path : undefined"
            >
              {{ item.title }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>

        <div class="header-right">
          <!-- 搜索框 -->
          <el-input
            v-model="searchQuery"
            placeholder="搜索菜单、账号、广告..."
            class="header-search"
            clearable
            :prefix-icon="Search"
            @keyup.enter="handleSearch"
          >
            <template #append>
              <el-button :icon="Search" @click="handleSearch" />
            </template>
          </el-input>

          <!-- 折叠侧栏时，显示一个菜单切换按钮占位 -->
          <button v-if="sidebarCollapsed" class="collapse-toggle-mini" @click="toggleSidebar" title="展开菜单">
            <el-icon :size="18"><Expand /></el-icon>
          </button>

          <!-- 通知 -->
          <el-badge :value="5" :hidden="sidebarCollapsed" class="header-badge">
            <el-button text :icon="Bell" class="header-icon-btn" />
          </el-badge>

          <!-- 折叠按钮（移动端风格简化） -->
          <button class="mobile-toggle" @click="toggleSidebar">
            <el-icon :size="18"><Menu /></el-icon>
          </button>

          <!-- 用户头像 & 下拉菜单 -->
          <el-dropdown trigger="click" @command="userDropdownCommand">
            <div class="admin-user">
              <el-avatar
                :size="34"
                :src="userStore.avatar || undefined"
                style="background: var(--adx-gradient-primary); color: #fff; font-weight: 700;"
              >
                {{ (userStore.username || 'A').charAt(0).toUpperCase() }}
              </el-avatar>
              <div v-if="!sidebarCollapsed" class="admin-user-info">
                <div class="admin-user-name">{{ userStore.username || '管理员' }}</div>
                <div class="admin-user-role">
                  {{ userStore.tenantId ? '租户管理' : '系统管理' }}
                </div>
              </div>
              <el-icon class="admin-user-caret"><CaretBottom /></el-icon>
            </div>

            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">
                  <el-icon><User /></el-icon>个人中心
                </el-dropdown-item>
                <el-dropdown-item command="password">
                  <el-icon><Lock /></el-icon>修改密码
                </el-dropdown-item>
                <el-dropdown-item divided command="logout">
                  <el-icon><SwitchButton /></el-icon>退出登录
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>

      <!-- 主内容区 -->
      <main class="admin-content">
        <router-view v-slot="{ Component }">
          <transition name="fade-page" mode="out-in">
            <component :is="Component" :key="route.fullPath" />
          </transition>
        </router-view>
      </main>
    </div>
  </div>
</template>

<style lang="scss" scoped>
// ========== 整体布局 ==========
.admin-layout {
  display: flex;
  width: 100%;
  min-height: 100vh;
  background: var(--adx-bg-secondary);

  &.is-collapsed {
    .admin-sidebar { width: 64px; }
    .admin-main-wrap { margin-left: 64px; }
  }
}

// ========== 侧边栏 ==========
.admin-sidebar {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: 20;
  width: 232px;
  background: var(--adx-bg-card);
  border-right: 1px solid var(--adx-border-light);
  display: flex;
  flex-direction: column;
  transition: width 0.25s ease;
  overflow: hidden;
}

.admin-sidebar-logo {
  height: 60px;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 18px;
  border-bottom: 1px solid var(--adx-border-light);
  cursor: pointer;
  user-select: none;
  flex-shrink: 0;

  .logo-icon { flex-shrink: 0; }

  .logo-text {
    display: inline-flex;
    align-items: baseline;
    gap: 2px;
    font-size: 18px;
    font-weight: 800;
    line-height: 1;
    overflow: hidden;
    white-space: nowrap;
  }
  .logo-main {
    background: var(--adx-gradient-primary);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
  }
  .logo-sub {
    color: var(--adx-text-primary);
    font-weight: 700;
  }
}

.admin-sidebar-scroll {
  flex: 1;
  min-height: 0;
  :deep(.el-menu) {
    border-right: none !important;
    padding: 8px 8px 80px;
  }
}

// 菜单分组
.admin-menu-group {
  padding: 18px 16px 6px;
  font-size: 11.5px;
  letter-spacing: 0.05em;
  color: var(--adx-text-tertiary);
  text-transform: uppercase;
  font-weight: 700;
}

// 菜单项样式增强
:deep(.el-menu-item),
:deep(.el-sub-menu__title) {
  height: 42px !important;
  line-height: 42px !important;
  border-radius: 8px !important;
  margin: 2px 0;

  &:hover {
    background: var(--adx-bg-hover) !important;
  }
}

:deep(.el-menu-item.is-active) {
  background: linear-gradient(90deg, rgba(99, 102, 241, 0.12), rgba(138, 5, 255, 0.06)) !important;
  color: var(--adx-color-primary) !important;
  font-weight: 600;

  &::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 3px;
    height: 18px;
    background: var(--adx-gradient-primary);
    border-radius: 0 3px 3px 0;
  }
}

.admin-sidebar-footer {
  padding: 12px;
  border-top: 1px solid var(--adx-border-light);
  flex-shrink: 0;

  .back-home-link {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    font-size: 13px;
    color: var(--adx-text-secondary);
    border-radius: 8px;
    transition: all 0.2s;

    &:hover {
      background: var(--adx-bg-hover);
      color: var(--adx-color-primary);
    }
  }
}

//  右侧主区域
.admin-main-wrap {
  flex: 1;
  margin-left: 232px;
  min-width: 0;
  display: flex;
  flex-direction: column;
  transition: margin-left 0.25s ease;
}

//  顶栏
.admin-header {
  height: 60px;
  background: var(--adx-bg-card);
  border-bottom: 1px solid var(--adx-border-light);
  padding: 0 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  position: sticky;
  top: 0;
  z-index: 10;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  flex: 1;
}

.collapse-btn {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  border: none;
  background: transparent;
  color: var(--adx-text-secondary);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;

  &:hover {
    background: var(--adx-bg-hover);
    color: var(--adx-color-primary);
  }
}

.admin-breadcrumb {
  flex: 1;
  min-width: 0;
}

//  右侧操作区
.header-right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-search {
  width: 320px;
  @media (max-width: 1280px) { width: 240px; }
  @media (max-width: 1024px) { display: none; }
}

.header-icon-btn {
  color: var(--adx-text-secondary);
  &:hover { color: var(--adx-color-primary); }
}

.header-badge {
  :deep(.el-badge__content) {
    background: var(--adx-color-danger);
  }
}

.collapse-toggle-mini,
.mobile-toggle {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  border: none;
  background: transparent;
  color: var(--adx-text-secondary);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  &:hover { background: var(--adx-bg-hover); color: var(--adx-color-primary); }
}

.collapse-toggle-mini { display: none; }
.mobile-toggle { display: none; }

@media (max-width: 1024px) {
  .mobile-toggle { display: inline-flex; }
}
.is-collapsed .collapse-toggle-mini { display: inline-flex; }

//  用户信息
.admin-user {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 4px 10px 4px 4px;
  border-radius: 9999px;
  cursor: pointer;
  transition: background 0.2s;

  &:hover { background: var(--adx-bg-hover); }

  .admin-user-info {
    display: flex;
    flex-direction: column;
    line-height: 1.2;
    @media (max-width: 768px) { display: none; }
  }

  .admin-user-name {
    font-size: 13.5px;
    font-weight: 600;
    color: var(--adx-text-primary);
    max-width: 110px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .admin-user-role {
    font-size: 11.5px;
    color: var(--adx-text-tertiary);
  }

  .admin-user-caret {
    color: var(--adx-text-tertiary);
    font-size: 12px;
    @media (max-width: 768px) { display: none; }
  }
}

//  主内容区
.admin-content {
  flex: 1;
  padding: 20px;
  min-width: 0;
  min-height: calc(100vh - 60px - 40px);

  @media (max-width: 768px) { padding: 12px; }
}

//  页面过渡
.fade-page-enter-active,
.fade-page-leave-active {
  transition: all 0.22s ease;
}
.fade-page-enter-from {
  opacity: 0;
  transform: translateY(8px);
}
.fade-page-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}

//  响应式：移动端侧栏抽屉风格
@media (max-width: 1024px) {
  .admin-sidebar {
    transform: translateX(-100%);
    width: 232px !important;
    box-shadow: var(--adx-shadow-xl);
    transition: transform 0.25s ease;
  }
  .admin-main-wrap {
    margin-left: 0 !important;
  }
  .admin-layout:not(.is-collapsed) .admin-sidebar {
    transform: translateX(0);
  }
}
</style>
