import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-me-2024!')
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'jwt-secret-change-me-2024!')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=7)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)

    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        'sqlite:///' + os.path.join(basedir, 'adx_auto.db')
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }

    CORS_HEADERS = 'Content-Type'

    # Pagination
    ITEMS_PER_PAGE = 20

    # Upload
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50MB

    # AI Models
    AI_PROVIDERS = {
        'openai': {
            'name': 'OpenAI',
            'models': ['gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-4', 'gpt-4-turbo-preview'],
            'api_key_env': 'OPENAI_API_KEY',
            'base_url': 'https://api.openai.com/v1',
        },
        'anthropic': {
            'name': 'Anthropic (Claude)',
            'models': ['claude-3-haiku-20240307', 'claude-3-sonnet-20240229', 'claude-3-opus-20240229'],
            'api_key_env': 'ANTHROPIC_API_KEY',
            'base_url': 'https://api.anthropic.com/v1',
        },
        'google': {
            'name': 'Google AI (Gemini)',
            'models': ['gemini-pro', 'gemini-pro-vision', 'gemini-ultra'],
            'api_key_env': 'GOOGLE_AI_API_KEY',
            'base_url': 'https://generativelanguage.googleapis.com/v1beta2',
        },
        'deepseek': {
            'name': 'DeepSeek',
            'models': ['deepseek-chat', 'deepseek-coder'],
            'api_key_env': 'DEEPSEEK_API_KEY',
            'base_url': 'https://api.deepseek.com/v1',
        },
        'zhipu': {
            'name': '智谱AI (GLM)',
            'models': ['glm-4', 'glm-4v', 'glm-3-turbo'],
            'api_key_env': 'ZHIPU_API_KEY',
            'base_url': 'https://open.bigmodel.cn/api/paas/v4',
        },
        'moonshot': {
            'name': '月之暗面 (Kimi)',
            'models': ['moonshot-v1-8k', 'moonshot-v1-32k', 'moonshot-v1-128k'],
            'api_key_env': 'MOONSHOT_API_KEY',
            'base_url': 'https://api.moonshot.cn/v1',
        },
        'qwen': {
            'name': '通义千问',
            'models': ['qwen-turbo', 'qwen-plus', 'qwen-max', 'qwen-max-longcontext'],
            'api_key_env': 'QWEN_API_KEY',
            'base_url': 'https://dashscope.aliyuncs.com/compatible-mode/v1',
        },
    }

    DEFAULT_AI_PROVIDER = os.environ.get('DEFAULT_AI_PROVIDER', 'openai')
    DEFAULT_AI_MODEL = os.environ.get('DEFAULT_AI_MODEL', 'gpt-3.5-turbo')

    # Proxy Providers (5 as per ADXKit spec)
    PROXY_PROVIDERS = {
        'oxylabs': {
            'name': 'Oxylabs',
            'user_env': 'PROXY_OXYLABS_USER',
            'pass_env': 'PROXY_OXYLABS_PASS',
            'endpoint': 'pr.oxylabs.io:7777',
        },
        'brightdata': {
            'name': 'BrightData',
            'user_env': 'PROXY_BRIGHTDATA_USER',
            'pass_env': 'PROXY_BRIGHTDATA_PASS',
            'endpoint': 'zproxy.lum-superproxy.io:22225',
        },
        'ipidea': {
            'name': 'IPIDEA',
            'user_env': 'PROXY_IPIDEA_USER',
            'pass_env': 'PROXY_IPIDEA_PASS',
            'endpoint': 'proxy.ipidea.io:16818',
        },
        'smartproxy': {
            'name': 'SmartProxy',
            'user_env': 'PROXY_SMARTPROXY_USER',
            'pass_env': 'PROXY_SMARTPROXY_PASS',
            'endpoint': 'gate.smartproxy.com:10000',
        },
        'geosurf': {
            'name': 'GeoSurf',
            'user_env': 'PROXY_GEO_SURF_USER',
            'pass_env': 'PROXY_GEO_SURF_PASS',
            'endpoint': 'gw1.geosurf.io:8000',
        },
    }

    # Click Bot Default Settings
    CLICK_BOT_DEFAULTS = {
        'time_slots': 8,  # 8时间段
        'referer_count': 10,  # 10个头部媒体referer
        'metrics_match': 50,  # 50项指标匹配
        'min_interval_minutes': 10,  # 最小间隔10分钟
    }

    # Google Ads API
    GOOGLE_ADS_DEVELOPER_TOKEN = os.environ.get('GOOGLE_ADS_DEVELOPER_TOKEN', '')
    GOOGLE_CLIENT_ID = os.environ.get('GOOGLE_CLIENT_ID', '')
    GOOGLE_CLIENT_SECRET = os.environ.get('GOOGLE_CLIENT_SECRET', '')
    GOOGLE_REDIRECT_URI = os.environ.get(
        'GOOGLE_REDIRECT_URI',
        'http://localhost:5000/api/accounts/oauth/callback'
    )
    GOOGLE_ADS_API_VERSION = os.environ.get('GOOGLE_ADS_API_VERSION', 'v17')
    GOOGLE_ADS_LOGIN_CUSTOMER_ID = os.environ.get('GOOGLE_ADS_LOGIN_CUSTOMER_ID', '')

    # OAuth Scopes
    GOOGLE_ADS_SCOPES = [
        'https://www.googleapis.com/auth/adwords',
    ]

    # Google Ads Script Sync
    ADS_SYNC_INTERVAL_MINUTES = 15

    # Multi-Tenant
    ENABLE_MULTI_TENANT = True

    # Security - Anti-Association
    FINGERPRINT_SALT = os.environ.get('FINGERPRINT_SALT', 'adx-auto-fp-salt-2024')


class ProductionConfig(Config):
    DEBUG = False
    TESTING = False


class DevelopmentConfig(Config):
    DEBUG = True
    TESTING = False


class TestingConfig(Config):
    DEBUG = False
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig,
}
