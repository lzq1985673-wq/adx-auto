import os
import multiprocessing

# Server socket
bind = f"0.0.0.0:{os.environ.get('PORT', '10000')}"
backlog = 2048

# Worker processes
cores = multiprocessing.cpu_count()
workers = int(os.environ.get('GUNICORN_WORKERS', max(2, cores * 2 + 1)))
worker_class = 'gthread'
threads = int(os.environ.get('GUNICORN_THREADS', 4))
worker_connections = 1000
timeout = 120
keepalive = 5

# Server mechanics
daemon = False
pidfile = None
umask = 0
user = None
group = None
tmp_upload_dir = None

# Logging - Render captures stdout/stderr
loglevel = os.environ.get('GUNICORN_LOG_LEVEL', 'info')
accesslog = '-'  # stdout
errorlog = '-'   # stderr
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(L)ss'

# Process naming
proc_name = 'adx-auto'

# Server hooks
def pre_fork(server, worker):
    pass

def post_fork(server, worker):
    server.log.info("Worker spawned (pid: %s)", worker.pid)

def pre_exec(server):
    server.log.info("Forked child, re-executing.")

def when_ready(server):
    server.log.info("Server is ready. Spawning workers (%s workers, %s threads each)", workers, threads)

def worker_int(worker):
    worker.log.info("worker received INT or QUIT signal")

def worker_abort(worker):
    worker.log.info("worker received SIGABRT signal")

# Max requests per worker (prevent memory leaks)
max_requests = 1000
max_requests_jitter = 100

# Reload on code change (dev only)
reload = os.environ.get('FLASK_ENV', 'production') == 'development'
reload_engine = 'auto'
