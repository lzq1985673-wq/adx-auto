from .extensions import db, bcrypt
from .models import Tenant, User, PromptTemplate, AIConfig, ProxyConfig
from sqlalchemy.exc import IntegrityError
import os


def init_default_data():
    """初始化默认数据 - 幂等操作，并发安全"""
    try:
        # Create default tenant if none exists (use get_or_create pattern)
        default_tenant = Tenant.query.filter_by(slug='default').first()
        if not default_tenant:
            default_tenant = Tenant(
                name='Default Tenant',
                slug='default',
                plan='pro',
                settings={
                    'timezone': 'Asia/Shanghai',
                    'currency': 'USD',
                }
            )
            db.session.add(default_tenant)
            db.session.flush()
        else:
            db.session.flush()

        # Create default admin user
        if not User.query.filter_by(username='admin').first():
            admin = User(
                tenant_id=default_tenant.id,
                username='admin',
                email='admin@adx-auto.com',
                role='owner',
                status='active',
            )
            default_pass = os.environ.get('DEFAULT_ADMIN_PASSWORD', 'admin123')
            admin.set_password(default_pass)
            db.session.add(admin)

        # Create default Prompt Templates (预置优质提示词)
        default_prompts = [
            {
                'name': '通用电商广告创意生成',
                'category': 'creative',
                'language': 'en',
                'template': '''
You are an expert Google Ads copywriter for {niche} niche.
Based on the following landing page information:
Title: {crawled_title}
Description: {crawled_description}
Key Features: {crawled_features}
Customer Reviews: {crawled_reviews}

Generate 3 sets of high-converting RESPONSIVE_SEARCH_AD creatives for target country {target_country} in {target_language}:
For EACH creative set, provide:
- 5 HEADLINES (max 30 chars each, compelling hooks, pain points, urgency, benefits)
- 4 DESCRIPTIONS (max 90 chars each, detailed benefits, social proof, CTAs)
- 10 KEYWORDS (mix of match types, high intent, long tail, buyer keywords)
- 2 PATH values (max 15 chars each)

Return ONLY valid JSON:
{{
  "creatives": [
    {{
      "headlines": [{{"text": "..."}}, ...],
      "descriptions": [{{"text": "..."}}, ...],
      "paths": ["path1", "path2"],
      "keywords": [{{"text": "keyword1", "match_type": "EXACT"}}, ...]
    }}
  ]
}}
'''.strip(),
                'variables': ['niche', 'crawled_title', 'crawled_description', 'crawled_features',
                              'crawled_reviews', 'target_country', 'target_language'],
                'is_system': True,
            },
            {
                'name': '独立站Offer创意生成 (中文优化)',
                'category': 'creative',
                'language': 'zh',
                'template': '''
你是 {niche} 领域的Google Ads顶级优化师。基于以下Offer落地页信息：
标题：{crawled_title}
描述：{crawled_description}
核心卖点：{crawled_features}
用户评价：{crawled_reviews}

为目标国家 {target_country} 生成 3 组高转化率 RESPONSIVE_SEARCH_AD 创意（语言：{target_language}）：
每组创意包含：
- 5个标题（最多30字符，抓痛点/给利益/造紧迫/造稀缺）
- 4个描述（最多90字符，详细卖点+社会证明+行动号召）
- 10个关键词（混合匹配类型，高意图长尾购买词）
- 2个PATH路径（最多15字符）

只返回JSON：
{{
  "creatives": [
    {{
      "headlines": [{{"text": "..."}}],
      "descriptions": [{{"text": "..."}}],
      "paths": ["...", "..."],
      "keywords": [{{"text": "...", "match_type": "PHRASE"}}]
    }}
  ]
}}
'''.strip(),
                'variables': ['niche', 'crawled_title', 'crawled_description', 'crawled_features',
                              'crawled_reviews', 'target_country', 'target_language'],
                'is_system': True,
            },
            {
                'name': '关键词扩展生成',
                'category': 'keyword',
                'language': 'en',
                'template': '''
Expand 30+ high-intent Google Ads keywords for niche: {niche}, seed keywords: {seed_keywords}.
Include:
- Exact match (high intent, branded, buy now)
- Phrase match (problem/solution, how to)
- Broad match modifier (research terms)
- Long tail keywords (4+ words)
- Negative keywords to avoid

Return JSON: {{"keywords": [{{"text":"...","match_type":"...","intent_score":0.0-1.0}}], "negative_keywords": ["..."]}}
'''.strip(),
                'variables': ['niche', 'seed_keywords'],
                'is_system': True,
            },
        ]
        for p in default_prompts:
            # Check if prompt already exists before creating
            if not PromptTemplate.query.filter_by(tenant_id=default_tenant.id, name=p['name']).first():
                pt = PromptTemplate(tenant_id=default_tenant.id, **p)
                db.session.add(pt)

        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        # 另一个worker已经创建了数据，忽略错误
        pass
    except Exception as e:
        db.session.rollback()
        print(f"init_default_data error: {e}")
        raise
