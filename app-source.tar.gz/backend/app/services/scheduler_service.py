import logging
import traceback
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

from flask import current_app

from ..extensions import scheduler, db
from ..models import ScheduledTask, TaskExecution, Campaign, MCCAccount

logger = logging.getLogger(__name__)

MAX_RETRY_COUNT = 3


def register_all_scheduled_tasks():
    try:
        tasks = ScheduledTask.query.filter_by(is_active=True).all()
        registered = 0
        for t in tasks:
            job_id = f'task_{t.id}'
            if scheduler.get_job(job_id):
                continue
            try:
                added = add_task_to_scheduler(t)
                if added:
                    registered += 1
                if t.interval_minutes and not t.next_run:
                    t.next_run = datetime.utcnow() + timedelta(minutes=t.interval_minutes)
            except Exception as e:
                logger.warning(f"register task {t.id} failed: {e}")
        db.session.commit()
        logger.info(f"registered {registered} scheduled tasks")
    except Exception as e:
        logger.warning(f"register_all_scheduled_tasks failed: {e}")


def add_task_to_scheduler(task: ScheduledTask) -> bool:
    job_id = f'task_{task.id}'
    trigger = None

    try:
        if task.cron_expression:
            from apscheduler.triggers.cron import CronTrigger
            parts = task.cron_expression.split()
            if len(parts) == 5:
                m, h, dom, mon, dow = parts
                trigger = CronTrigger(
                    minute=m, hour=h, day=dom, month=mon, day_of_week=dow
                )
            else:
                logger.warning(f"Invalid cron expression for task {task.id}: {task.cron_expression}")
                return False
        elif task.interval_minutes:
            from apscheduler.triggers.interval import IntervalTrigger
            trigger = IntervalTrigger(minutes=task.interval_minutes)
        else:
            logger.warning(f"Task {task.id} has no trigger (no cron or interval)")
            return False

        scheduler.add_job(
            execute_scheduled_task,
            trigger=trigger,
            id=job_id,
            args=[task.id],
            replace_existing=True,
            misfire_grace_time=3600,
            coalesce=True,
            max_instances=1,
        )
        logger.info(f"Added task {task.id} ({task.name}) to scheduler")
        return True
    except Exception as e:
        logger.error(f"add_task_to_scheduler failed for task {task.id}: {e}")
        return False


def _update_task_pre_run(task: ScheduledTask) -> None:
    task.run_count = (task.run_count or 0) + 1
    task.last_run = datetime.utcnow()
    task.status = 'running'
    if task.interval_minutes:
        task.next_run = datetime.utcnow() + timedelta(minutes=task.interval_minutes)


def _update_task_post_run(task: ScheduledTask, success: bool,
                          error: Optional[str] = None) -> None:
    if success:
        task.success_count = (task.success_count or 0) + 1
        task.status = 'idle'
    else:
        task.failure_count = (task.failure_count or 0) + 1
        task.status = 'error'
        task.last_error = error[:2000] if error else None


def _finalize_execution(exec_log: TaskExecution, success: bool,
                        result: Optional[Dict] = None,
                        error: Optional[str] = None,
                        tb: Optional[str] = None) -> None:
    exec_log.finished_at = datetime.utcnow()
    exec_log.duration_seconds = (
        exec_log.finished_at - exec_log.started_at
    ).total_seconds()
    exec_log.status = 'success' if success else 'failed'
    if result:
        exec_log.result_data = result
    if error:
        exec_log.error_message = error[:2000] if len(error) > 2000 else error
    if tb:
        exec_log.traceback = tb[:5000] if len(tb) > 5000 else tb


def execute_sync_task(task_id: int) -> Dict[str, Any]:
    result = {'success': False, 'synced': 0, 'error': None}
    try:
        from .google_ads_service import GoogleAdsService
        task = ScheduledTask.query.get(task_id)
        if not task:
            result['error'] = 'Task not found'
            return result

        mcc_id = task.related_id
        params = task.params or {}

        if not mcc_id:
            mcc = MCCAccount.query.filter_by(tenant_id=task.tenant_id).first()
            if mcc:
                mcc_id = mcc.id

        if not mcc_id:
            result['error'] = 'No MCC account associated'
            return result

        ads_service = GoogleAdsService(tenant_id=task.tenant_id)

        if mcc_id:
            mcc = MCCAccount.query.get(mcc_id)
            if mcc and mcc.worker_domain:
                endpoint = f"https://{mcc.worker_domain}/ads-sync/{mcc.script_fingerprint or 'default'}"
                pull_result = ads_service.pull_data_via_script(
                    endpoint, params=params
                )
                if pull_result['success']:
                    result['synced'] = pull_result.get('records', 0)
                    result['success'] = True
                else:
                    result['error'] = pull_result.get('error')
            else:
                result['success'] = True
                result['synced'] = 0
                logger.info(f"Sync task {task_id}: MCC {mcc_id} has no worker domain configured (dry run)")

        return result
    except Exception as e:
        result['error'] = f"execute_sync_task failed: {e}"
        logger.error(result['error'], exc_info=True)
        return result


def execute_click_task(task_id: int) -> Dict[str, Any]:
    result = {'success': False, 'clicks_run': 0, 'click_details': [], 'error': None}
    try:
        from .click_service import ClickExecutionService
        task = ScheduledTask.query.get(task_id)
        if not task:
            result['error'] = 'Task not found'
            return result

        params = task.params or {}
        campaign_id = task.related_id or params.get('campaign_id')

        if not campaign_id:
            campaigns = Campaign.query.filter_by(
                tenant_id=task.tenant_id, click_bot_enabled=True
            ).all()
            campaign_ids = [c.id for c in campaigns]
        else:
            campaign_ids = [campaign_id]

        click_service = ClickExecutionService(tenant_id=task.tenant_id)
        clicks_per_campaign = params.get('clicks_per_campaign', 1)

        for cid in campaign_ids:
            for _ in range(clicks_per_campaign):
                click_res = click_service.run_single_click(
                    cid, click_task_params=params
                )
                if click_res['success']:
                    result['clicks_run'] += 1
                    result['click_details'].append({
                        'click_task_id': click_res.get('click_task_id'),
                        'ip': click_res.get('ip'),
                        'country': click_res.get('country'),
                        'duration': click_res.get('duration_seconds'),
                    })

        result['success'] = result['clicks_run'] > 0 or len(campaign_ids) == 0
        logger.info(f"Click task {task_id}: executed {result['clicks_run']} clicks")
        return result
    except Exception as e:
        result['error'] = f"execute_click_task failed: {e}"
        logger.error(result['error'], exc_info=True)
        return result


def execute_link_swap_task(task_id: int) -> Dict[str, Any]:
    result = {'success': False, 'swapped': 0, 'error': None}
    try:
        from .link_swap_service import LinkSwapService
        task = ScheduledTask.query.get(task_id)
        if not task:
            result['error'] = 'Task not found'
            return result

        params = task.params or {}
        campaign_id = task.related_id or params.get('campaign_id')
        ad_id = params.get('ad_id')
        new_urls = params.get('new_urls', [])

        if not campaign_id:
            result['error'] = 'No campaign specified for link swap'
            return result

        swap_service = LinkSwapService(tenant_id=task.tenant_id)
        swap_res = swap_service.swap_ad_links(campaign_id, ad_id, new_urls)

        result['success'] = swap_res['success']
        result['swapped'] = swap_res.get('swapped_count', 0)
        result['error'] = swap_res.get('error')
        logger.info(
            f"Link swap task {task_id}: swapped {result['swapped']} links, success={result['success']}"
        )
        return result
    except Exception as e:
        result['error'] = f"execute_link_swap_task failed: {e}"
        logger.error(result['error'], exc_info=True)
        return result


def execute_ai_generation_task(task_id: int) -> Dict[str, Any]:
    result = {'success': False, 'generated': 0, 'error': None, 'creatives': None}
    try:
        from .ai_service import AIService
        task = ScheduledTask.query.get(task_id)
        if not task:
            result['error'] = 'Task not found'
            return result

        params = task.params or {}
        landing_data = params.get('landing_page_data') or params.get('landing_data', {})
        template_id = params.get('prompt_template_id')

        if not landing_data:
            result['error'] = 'No landing page data for AI generation'
            return result

        from ..models import PromptTemplate
        template = PromptTemplate.query.get(template_id) if template_id else None

        ai_service = AIService(tenant_id=task.tenant_id)
        ai_result = ai_service.generate_ad_creative(
            landing_page_data=landing_data,
            prompt_template=template,
            **params
        )

        result['success'] = ai_result['success']
        result['error'] = ai_result.get('error')
        result['creatives'] = ai_result.get('creatives')
        result['ai_provider'] = ai_result.get('ai_provider')
        result['ai_model'] = ai_result.get('ai_model')
        result['tokens'] = ai_result.get('tokens')
        result['cost_usd'] = ai_result.get('cost_usd')
        result['generated'] = 1 if ai_result['success'] else 0

        logger.info(
            f"AI generation task {task_id}: success={result['success']}, "
            f"provider={result.get('ai_provider')}, cost=${result.get('cost_usd', 0):.6f}"
        )
        return result
    except Exception as e:
        result['error'] = f"execute_ai_generation_task failed: {e}"
        logger.error(result['error'], exc_info=True)
        return result


def execute_scheduled_task(task_id: int):
    task = ScheduledTask.query.get(task_id)
    if not task or not task.is_active:
        return

    exec_log = TaskExecution(
        task_id=task.id,
        started_at=datetime.utcnow(),
        status='running',
    )
    db.session.add(exec_log)
    db.session.flush()

    try:
        _update_task_pre_run(task)
        db.session.flush()

        task_type = (task.task_type or '').lower()
        result = {}

        if task_type == 'sync_ads' or task_type == 'sync':
            result = execute_sync_task(task_id)
        elif task_type == 'click_bot' or task_type == 'click':
            result = execute_click_task(task_id)
            if result.get('click_details'):
                exec_log.click_details = result['click_details'][-1] if result['click_details'] else {}
        elif task_type == 'link_swap' or task_type == 'swap':
            result = execute_link_swap_task(task_id)
            if result.get('swapped'):
                exec_log.link_details = {'swapped_count': result['swapped']}
        elif task_type == 'ai_generate' or task_type == 'ai_generation' or task_type == 'ai':
            result = execute_ai_generation_task(task_id)
        elif task_type == 'budget_update':
            result = {'success': True, 'info': 'budget update dry run'}
            logger.info(f"Budget update task {task_id}: dry run")
        else:
            logger.warning(f"Unknown task type: {task.task_type} for task {task_id}")
            result = {'success': False, 'error': f'Unknown task type: {task.task_type}'}

        success = bool(result.get('success'))
        error_msg = result.get('error') if not success else None

        _finalize_execution(
            exec_log,
            success=success,
            result={k: v for k, v in result.items() if k not in ('creatives',)},
            error=error_msg,
        )
        _update_task_post_run(task, success, error_msg)

        retry_count = 0
        while not success and retry_count < MAX_RETRY_COUNT and error_msg:
            retry_count += 1
            logger.info(f"Retrying task {task_id}, attempt {retry_count}/{MAX_RETRY_COUNT}")
            try:
                if task_type == 'sync_ads' or task_type == 'sync':
                    result = execute_sync_task(task_id)
                elif task_type == 'click_bot' or task_type == 'click':
                    result = execute_click_task(task_id)
                elif task_type == 'link_swap' or task_type == 'swap':
                    result = execute_link_swap_task(task_id)
                elif task_type == 'ai_generate' or task_type == 'ai_generation' or task_type == 'ai':
                    result = execute_ai_generation_task(task_id)

                success = bool(result.get('success'))
                if success:
                    _finalize_execution(exec_log, success=True, result=result)
                    _update_task_post_run(task, True)
                    logger.info(f"Retry successful for task {task_id}")
                    break
            except Exception as retry_e:
                logger.warning(f"Retry attempt {retry_count} for task {task_id} failed: {retry_e}")

        db.session.commit()

    except Exception as e:
        tb_str = traceback.format_exc()
        logger.error(f"execute_scheduled_task fatal error for task {task_id}: {e}", exc_info=True)
        try:
            _finalize_execution(
                exec_log,
                success=False,
                error=str(e),
                tb=tb_str,
            )
            _update_task_post_run(task, False, str(e))
            db.session.commit()
        except Exception:
            db.session.rollback()
