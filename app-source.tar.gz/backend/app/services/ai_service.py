import json
import logging
import time
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

import requests
from flask import current_app

from ..models import AIConfig, PromptTemplate, db

logger = logging.getLogger(__name__)


class AIService:
    def __init__(self, tenant_id: Optional[int] = None):
        self.tenant_id = tenant_id
        self.max_retries = 3
        self.retry_delay = 2

    def _get_provider_configs(self) -> Dict:
        try:
            return current_app.config['AI_PROVIDERS']
        except Exception:
            return {}

    def _select_ai_config(self, preferred_provider: Optional[str] = None,
                          preferred_model: Optional[str] = None) -> Optional[AIConfig]:
        query = AIConfig.query.filter_by(is_active=True)
        if self.tenant_id:
            query = query.filter_by(tenant_id=self.tenant_id)

        configs = query.all()
        if not configs:
            return None

        scored = []
        for cfg in configs:
            score = 0
            if cfg.is_free_tier:
                score += 1000
            score -= cfg.priority
            if preferred_provider and cfg.provider == preferred_provider:
                score += 500
            if preferred_model and cfg.model == preferred_model:
                score += 500
            scored.append((score, cfg))

        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[0][1] if scored else None

    def _get_backup_configs(self, exclude_provider: str,
                            exclude_model: str) -> List[AIConfig]:
        query = AIConfig.query.filter_by(is_active=True)
        if self.tenant_id:
            query = query.filter_by(tenant_id=self.tenant_id)
        configs = query.filter(
            AIConfig.provider != exclude_provider,
            AIConfig.model != exclude_model
        ).all()
        configs.sort(key=lambda c: (-1 if c.is_free_tier else 0, c.priority))
        return configs

    def _build_provider_headers(self, cfg: AIConfig) -> Dict[str, str]:
        provider = cfg.provider
        api_key = cfg.api_key or os.environ.get(
            self._get_provider_configs().get(provider, {}).get('api_key_env', '')
        )
        headers = {'Content-Type': 'application/json'}

        if provider == 'openai':
            headers['Authorization'] = f'Bearer {api_key}'
        elif provider == 'anthropic':
            headers['x-api-key'] = api_key
            headers['anthropic-version'] = '2023-06-01'
        elif provider == 'google':
            headers['x-goog-api-key'] = api_key
        elif provider in ['deepseek', 'zhipu', 'moonshot', 'qwen']:
            headers['Authorization'] = f'Bearer {api_key}'

        return headers

    def _build_provider_url(self, cfg: AIConfig) -> str:
        provider_cfg = self._get_provider_configs().get(cfg.provider, {})
        base_url = cfg.base_url or provider_cfg.get('base_url', '')

        if cfg.provider == 'anthropic':
            return f"{base_url}/messages"
        elif cfg.provider == 'google':
            return f"{base_url}/models/{cfg.model}:generateContent"
        else:
            return f"{base_url}/chat/completions"

    def _build_request_payload(self, cfg: AIConfig, messages: List[Dict],
                               **kwargs) -> Dict[str, Any]:
        provider = cfg.provider
        payload: Dict[str, Any] = {}

        if provider == 'google':
            payload['contents'] = [{'parts': [{'text': m['content']}]} for m in messages]
            if cfg.temperature is not None:
                payload['generationConfig'] = {
                    'temperature': float(cfg.temperature),
                    'maxOutputTokens': kwargs.get('max_tokens', cfg.max_tokens) or cfg.max_tokens
                }
        elif provider == 'anthropic':
            system_msgs = [m['content'] for m in messages if m['role'] == 'system']
            user_msgs = [m for m in messages if m['role'] != 'system']
            payload['model'] = cfg.model
            payload['max_tokens'] = kwargs.get('max_tokens', cfg.max_tokens) or cfg.max_tokens
            payload['messages'] = [{'role': m['role'], 'content': m['content']} for m in user_msgs]
            if system_msgs:
                payload['system'] = system_msgs[0]
            if cfg.temperature is not None:
                payload['temperature'] = float(cfg.temperature)
        else:
            payload['model'] = cfg.model
            payload['messages'] = [{'role': m['role'], 'content': m['content']} for m in messages]
            payload['max_tokens'] = kwargs.get('max_tokens', cfg.max_tokens) or cfg.max_tokens
            if cfg.temperature is not None:
                payload['temperature'] = float(cfg.temperature)

        return payload

    def _parse_response(self, cfg: AIConfig, response_data: Dict) -> Tuple[str, int, int]:
        provider = cfg.provider
        content = ''
        input_tokens = 0
        output_tokens = 0

        try:
            if provider == 'google':
                if 'candidates' in response_data and response_data['candidates']:
                    parts = response_data['candidates'][0].get('content', {}).get('parts', [])
                    if parts:
                        content = parts[0].get('text', '')
                usage = response_data.get('usageMetadata', {})
                input_tokens = usage.get('promptTokenCount', 0)
                output_tokens = usage.get('candidatesTokenCount', 0)
            elif provider == 'anthropic':
                content_blocks = response_data.get('content', [])
                if content_blocks:
                    content = content_blocks[0].get('text', '')
                usage = response_data.get('usage', {})
                input_tokens = usage.get('input_tokens', 0)
                output_tokens = usage.get('output_tokens', 0)
            else:
                if 'choices' in response_data and response_data['choices']:
                    choice = response_data['choices'][0]
                    msg = choice.get('message', {})
                    content = msg.get('content', '')
                usage = response_data.get('usage', {})
                input_tokens = usage.get('prompt_tokens', 0)
                output_tokens = usage.get('completion_tokens', 0)
        except Exception as e:
            logger.warning(f"Parse AI response failed for {provider}: {e}")

        return content, input_tokens, output_tokens

    def _calculate_cost(self, cfg: AIConfig, input_tokens: int, output_tokens: int) -> float:
        try:
            cost_input = (float(cfg.cost_per_1k_input or 0) * input_tokens) / 1000.0
            cost_output = (float(cfg.cost_per_1k_output or 0) * output_tokens) / 1000.0
            return cost_input + cost_output
        except Exception:
            return 0.0

    def _update_usage(self, cfg: AIConfig, input_tokens: int, output_tokens: int, cost: float):
        try:
            cfg.total_tokens_used = (cfg.total_tokens_used or 0) + input_tokens + output_tokens
            cfg.total_cost_usd = float(cfg.total_cost_usd or 0) + cost
            cfg.last_used = datetime.utcnow()
            db.session.add(cfg)
            db.session.commit()
        except Exception as e:
            logger.warning(f"Update AIConfig usage failed: {e}")
            db.session.rollback()

    def chat_completion(self, messages: List[Dict],
                        preferred_provider: Optional[str] = None,
                        preferred_model: Optional[str] = None,
                        **kwargs) -> Dict[str, Any]:
        result = {
            'success': False,
            'content': '',
            'provider': None,
            'model': None,
            'input_tokens': 0,
            'output_tokens': 0,
            'cost_usd': 0.0,
            'error': None
        }

        primary_cfg = self._select_ai_config(preferred_provider, preferred_model)
        if not primary_cfg:
            result['error'] = 'No active AI config found'
            logger.error(result['error'])
            return result

        configs_to_try = [primary_cfg] + self._get_backup_configs(
            primary_cfg.provider, primary_cfg.model
        )

        for cfg in configs_to_try:
            for attempt in range(1, self.max_retries + 1):
                try:
                    url = self._build_provider_url(cfg)
                    headers = self._build_provider_headers(cfg)
                    payload = self._build_request_payload(cfg, messages, **kwargs)

                    timeout = kwargs.get('timeout', 120)
                    resp = requests.post(url, headers=headers, json=payload, timeout=timeout)

                    if resp.status_code == 429:
                        retry_after = int(resp.headers.get('Retry-After', self.retry_delay * attempt))
                        logger.info(f"Rate limited {cfg.provider}, retry after {retry_after}s")
                        time.sleep(retry_after)
                        continue

                    if resp.status_code != 200:
                        logger.warning(f"AI API {cfg.provider}/{cfg.model} failed: {resp.status_code} {resp.text[:200]}")
                        break

                    data = resp.json()
                    content, input_tokens, output_tokens = self._parse_response(cfg, data)
                    cost = self._calculate_cost(cfg, input_tokens, output_tokens)

                    if not content:
                        logger.warning(f"Empty content from {cfg.provider}/{cfg.model}")
                        break

                    self._update_usage(cfg, input_tokens, output_tokens, cost)

                    result.update({
                        'success': True,
                        'content': content,
                        'provider': cfg.provider,
                        'model': cfg.model,
                        'input_tokens': input_tokens,
                        'output_tokens': output_tokens,
                        'cost_usd': cost,
                    })
                    logger.info(f"AI completion success: {cfg.provider}/{cfg.model}, "
                                f"tokens={input_tokens + output_tokens}, cost=${cost:.6f}")
                    return result

                except requests.exceptions.Timeout:
                    logger.warning(f"AI timeout attempt {attempt}/{self.max_retries} for {cfg.provider}")
                    if attempt < self.max_retries:
                        time.sleep(self.retry_delay * attempt)
                except requests.exceptions.RequestException as e:
                    logger.warning(f"AI request error attempt {attempt}: {e}")
                    if attempt < self.max_retries:
                        time.sleep(self.retry_delay * attempt)
                except Exception as e:
                    logger.error(f"AI completion unexpected error: {e}", exc_info=True)
                    break

            logger.info(f"Falling back from {cfg.provider}/{cfg.model} to next config")

        result['error'] = 'All AI providers failed after retries'
        logger.error(result['error'])
        return result

    def generate_ad_creative(self, landing_page_data: Dict,
                             prompt_template: Optional[PromptTemplate] = None,
                             **kwargs) -> Dict[str, Any]:
        result = {
            'success': False,
            'creatives': None,
            'raw_content': '',
            'ai_provider': None,
            'ai_model': None,
            'tokens': 0,
            'cost_usd': 0.0,
            'error': None
        }

        try:
            system_msg = (
                "You are a professional Google Ads copywriter. "
                "Generate high-converting ad creatives in strict JSON format. "
                "Output only valid JSON, no markdown, no explanation."
            )

            if prompt_template and prompt_template.template:
                tmpl = prompt_template.template
            else:
                tmpl = (
                    "Based on the following landing page data, generate Google Ads creatives:\n"
                    "Landing Page Data: {landing_data}\n"
                    "Target: {target_language} / {target_country}\n\n"
                    "Return JSON with this exact structure:\n"
                    "{{\n"
                    '  "headlines": [{{"text": "string", "pinned": "HEADLINE_1|HEADLINE_2|HEADLINE_3|null"}}],\n'
                    '  "descriptions": [{{"text": "string", "pinned": "DESCRIPTION_1|DESCRIPTION_2|null"}}],\n'
                    '  "paths": ["path1", "path2"],\n'
                    '  "keywords": [{{"text": "string", "match_type": "EXACT|PHRASE|BROAD"}}],\n'
                    '  "summary": "brief rationale"\n'
                    "}}"
                )

            target_language = kwargs.get('target_language', 'en')
            target_country = kwargs.get('target_country', '')
            formatted_prompt = tmpl.format(
                landing_data=json.dumps(landing_page_data, ensure_ascii=False),
                target_language=target_language,
                target_country=target_country,
                **{k: v for k, v in kwargs.items() if k not in ['target_language', 'target_country']}
            )

            messages = [
                {'role': 'system', 'content': system_msg},
                {'role': 'user', 'content': formatted_prompt}
            ]

            preferred_provider = kwargs.get('preferred_provider')
            preferred_model = kwargs.get('preferred_model')

            ai_result = self.chat_completion(
                messages=messages,
                preferred_provider=preferred_provider,
                preferred_model=preferred_model,
                max_tokens=kwargs.get('max_tokens', 4000)
            )

            if not ai_result['success']:
                result['error'] = ai_result['error']
                return result

            result['raw_content'] = ai_result['content']
            result['ai_provider'] = ai_result['provider']
            result['ai_model'] = ai_result['model']
            result['tokens'] = ai_result['input_tokens'] + ai_result['output_tokens']
            result['cost_usd'] = ai_result['cost_usd']

            content = ai_result['content'].strip()
            if content.startswith('```json'):
                content = content[7:]
            if content.startswith('```'):
                content = content[3:]
            if content.endswith('```'):
                content = content[:-3]
            content = content.strip()

            try:
                parsed = json.loads(content)
            except json.JSONDecodeError:
                try:
                    start = content.find('{')
                    end = content.rfind('}') + 1
                    if start >= 0 and end > start:
                        parsed = json.loads(content[start:end])
                    else:
                        raise ValueError("Cannot extract JSON")
                except Exception as e:
                    result['error'] = f"Failed to parse AI JSON: {e}"
                    logger.error(f"{result['error']}. Raw: {content[:500]}")
                    return result

            creatives = {
                'headlines': parsed.get('headlines', []),
                'descriptions': parsed.get('descriptions', []),
                'paths': parsed.get('paths', []),
                'keywords': parsed.get('keywords', []),
                'summary': parsed.get('summary', '')
            }

            if not isinstance(creatives['headlines'], list):
                creatives['headlines'] = []
            if not isinstance(creatives['descriptions'], list):
                creatives['descriptions'] = []
            if not isinstance(creatives['keywords'], list):
                creatives['keywords'] = []

            result['creatives'] = creatives
            result['success'] = True

            if prompt_template:
                try:
                    prompt_template.usage_count = (prompt_template.usage_count or 0) + 1
                    db.session.commit()
                except Exception:
                    db.session.rollback()

            return result

        except Exception as e:
            result['error'] = f"generate_ad_creative failed: {e}"
            logger.error(result['error'], exc_info=True)
            return result
