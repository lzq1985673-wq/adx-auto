import json
import logging
import hashlib
import secrets
import string
from datetime import datetime
from typing import Dict, List, Optional, Any

import requests
from flask import current_app

from ..models import (
    MCCAccount, AdsSubAccount, Campaign, AdGroup, Ad, Keyword,
    AdsSyncLog, db
)

logger = logging.getLogger(__name__)


class GoogleAdsService:
    def __init__(self, tenant_id: Optional[int] = None):
        self.tenant_id = tenant_id
        self.timeout = 30

    def _generate_random_fingerprint(self, length: int = 16) -> str:
        chars = string.ascii_letters + string.digits
        return ''.join(secrets.choice(chars) for _ in range(length))

    def generate_ads_script(self, mcc_id: str, script_fingerprint: str,
                            worker_domain: str) -> str:
        try:
            salt = current_app.config.get('FINGERPRINT_SALT', 'default-salt')
            instance_id = hashlib.sha256(
                f"{mcc_id}:{script_fingerprint}:{salt}".encode()
            ).hexdigest()[:12]

            script_template = f"""// Google Ads Script - Auto Generated
// MCC: {mcc_id}
// Fingerprint: {script_fingerprint}
// Instance: {instance_id}
// Generated: {datetime.utcnow().isoformat()}

const WORKER_ENDPOINT = 'https://{worker_domain}/ads-sync/{instance_id}';
const SCRIPT_FINGERPRINT = '{script_fingerprint}';

function main() {{
  const mcc = AdsApp.currentAccount();
  const customerId = mcc.getCustomerId();

  const payload = {{
    fingerprint: SCRIPT_FINGERPRINT,
    mcc_id: '{mcc_id}',
    customer_id: customerId,
    timestamp: new Date().toISOString(),
    action: 'PING'
  }};

  const options = {{
    method: 'POST',
    contentType: 'application/json',
    payload: JSON.stringify(payload),
    headers: {{
      'X-Script-Fingerprint': SCRIPT_FINGERPRINT,
      'X-Instance-Id': '{instance_id}'
    }}
  }};

  try {{
    const response = UrlFetchApp.fetch(WORKER_ENDPOINT, options);
    const commands = JSON.parse(response.getContentText());
    executeCommands(commands);
  }} catch (e) {{
    Logger.log('Sync error: ' + e.toString());
  }}
}}

function executeCommands(commands) {{
  if (!commands || !Array.isArray(commands)) return;
  commands.forEach(cmd => {{
    switch (cmd.action) {{
      case 'PULL_DATA':
        executePull(cmd);
        break;
      case 'PUSH_DATA':
        executePush(cmd);
        break;
      case 'CREATE_CAMPAIGN':
        executeCreateCampaign(cmd);
        break;
      default:
        Logger.log('Unknown action: ' + cmd.action);
    }}
  }});
}}

function executePull(cmd) {{
  const result = {{ type: 'PULL_RESULT', ref: cmd.ref }};
  if (cmd.scope === 'CAMPAIGNS') {{
    const campaigns = [];
    const it = AdsApp.campaigns().get();
    while (it.hasNext()) {{
      const c = it.next();
      campaigns.push({{
        id: c.getId(),
        name: c.getName(),
        status: c.getStatus(),
        budget: c.getBudget().getAmount(),
        spend: c.getStatsFor('LAST_7_DAYS').getCost()
      }});
    }}
    result.data = campaigns;
  }}
  sendResult(result);
}}

function executePush(cmd) {{
  Logger.log('PUSH not implemented');
}}

function executeCreateCampaign(cmd) {{
  Logger.log('CREATE_CAMPAIGN: ' + JSON.stringify(cmd));
}}

function sendResult(result) {{
  const options = {{
    method: 'POST',
    contentType: 'application/json',
    payload: JSON.stringify(result),
    headers: {{
      'X-Script-Fingerprint': SCRIPT_FINGERPRINT,
      'X-Instance-Id': '{instance_id}'
    }}
  }};
  UrlFetchApp.fetch(WORKER_ENDPOINT, options);
}}
"""
            logger.info(f"Generated Ads script for MCC {mcc_id}, instance={instance_id}")
            return script_template
        except Exception as e:
            logger.error(f"generate_ads_script failed: {e}", exc_info=True)
            raise

    def generate_cloudflare_worker_script(self, mcc_id: str) -> str:
        try:
            salt = current_app.config.get('FINGERPRINT_SALT', 'default-salt')
            route_secret = hashlib.sha256(f"worker:{mcc_id}:{salt}".encode()).hexdigest()[:24]

            worker_script = f"""// Cloudflare Worker - Ads Sync Bridge
// MCC: {mcc_id}
// Route Secret: {route_secret}
// Inbound/Outbound Isolated

const INBOUND_ALLOWED_FPS = new Set(['{self._generate_random_fingerprint(32)}']);
const OUTBOUND_UPSTREAM = process.env.UPSTREAM_BACKEND || 'https://localhost:5000';

const CACHE = caches.default;

export default {{
  async fetch(request, env, ctx) {{
    const url = new URL(request.url);

    if (url.pathname.startsWith('/health')) {{
      return new Response(JSON.stringify({{ status: 'ok', mcc: '{mcc_id}' }}), {{
        headers: {{ 'Content-Type': 'application/json' }}
      }});
    }}

    if (url.pathname.startsWith('/ads-sync/')) {{
      return handleAdsSync(request, url, env);
    }}

    if (url.pathname.startsWith('/outbound/')) {{
      return handleOutbound(request, url, env);
    }}

    return new Response('Forbidden', {{ status: 403 }});
  }}
}};

async function handleAdsSync(request, url, env) {{
  const fp = request.headers.get('X-Script-Fingerprint');
  const instanceId = url.pathname.split('/').pop();

  if (!fp || !INBOUND_ALLOWED_FPS.has(fp)) {{
    return new Response('Unauthorized', {{ status: 401 }});
  }}

  const inboundData = {{
    method: request.method,
    fp: fp,
    instance: instanceId,
    url: url.pathname,
    ts: Date.now()
  }};

  const upstreamUrl = `${{OUTBOUND_UPSTREAM}}/api/ads/script-callback/${{instanceId}}`;
  const body = request.method === 'POST' ? await request.text() : null;

  const upstreamReq = new Request(upstreamUrl, {{
    method: request.method,
    headers: {{
      'Content-Type': 'application/json',
      'X-Worker-MCC': '{mcc_id}',
      'X-Worker-Route': '{route_secret}'
    }},
    body: body
  }});

  const response = await fetch(upstreamReq);
  const respBody = await response.text();

  return new Response(respBody, {{
    status: response.status,
    headers: {{
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store'
    }}
  }});
}}

async function handleOutbound(request, url, env) {{
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {{
    return new Response('Unauthorized', {{ status: 401 }});
  }}

  const target = url.searchParams.get('url');
  if (!target) {{
    return new Response('Missing url', {{ status: 400 }});
  }}

  const proxyReq = new Request(target, {{
    method: request.method,
    headers: Object.fromEntries(request.headers)
  }});

  return await fetch(proxyReq);
}}
"""
            logger.info(f"Generated Cloudflare Worker script for MCC {mcc_id}")
            return worker_script
        except Exception as e:
            logger.error(f"generate_cloudflare_worker_script failed: {e}", exc_info=True)
            raise

    def _create_sync_log(self, mcc_id: int, direction: str,
                         method: str = 'script') -> AdsSyncLog:
        log = AdsSyncLog(
            mcc_id=mcc_id,
            direction=direction,
            started_at=datetime.utcnow(),
            status='running',
            sync_method=method,
        )
        db.session.add(log)
        db.session.commit()
        return log

    def _finalize_sync_log(self, log: AdsSyncLog, status: str,
                           processed: int = 0, updated: int = 0,
                           created: int = 0, failed: int = 0,
                           error: Optional[str] = None,
                           stats: Optional[Dict] = None):
        try:
            log.finished_at = datetime.utcnow()
            log.status = status
            log.records_processed = processed
            log.records_updated = updated
            log.records_created = created
            log.records_failed = failed
            if error:
                log.error_message = error[:2000] if len(error) > 2000 else error
            if stats:
                log.raw_stats = stats
            db.session.commit()
        except Exception as e:
            logger.warning(f"Finalize sync log failed: {e}")
            db.session.rollback()

    def pull_data_via_script(self, script_endpoint: str,
                             params: Optional[Dict] = None) -> Dict[str, Any]:
        result = {
            'success': False,
            'data': None,
            'mcc_id': None,
            'records': 0,
            'error': None
        }

        sync_log = None
        try:
            payload = {
                'action': 'PULL_DATA',
                'params': params or {},
                'timestamp': datetime.utcnow().isoformat()
            }

            resp = requests.post(
                script_endpoint,
                json=payload,
                timeout=self.timeout,
                headers={'Content-Type': 'application/json'}
            )

            if resp.status_code != 200:
                result['error'] = f"Script endpoint returned {resp.status_code}"
                return result

            data = resp.json()
            result['success'] = True
            result['data'] = data
            result['records'] = len(data) if isinstance(data, list) else 1

            mcc = MCCAccount.query.filter_by(
                worker_domain=script_endpoint.split('/')[2] if '://' in script_endpoint else None
            ).first()
            if mcc:
                result['mcc_id'] = mcc.id
                sync_log = self._create_sync_log(mcc.id, 'pull', 'script')
                self._finalize_sync_log(
                    sync_log, 'success',
                    processed=result['records'],
                    updated=result['records']
                )

            logger.info(f"Pull data via script: {result['records']} records")
            return result

        except requests.exceptions.Timeout:
            result['error'] = 'Script pull timeout'
            logger.error(result['error'])
        except requests.exceptions.RequestException as e:
            result['error'] = f"Script pull request failed: {e}"
            logger.error(result['error'])
        except Exception as e:
            result['error'] = f"pull_data_via_script failed: {e}"
            logger.error(result['error'], exc_info=True)

        if sync_log:
            self._finalize_sync_log(sync_log, 'failed', error=result['error'])
        return result

    def push_data_via_script(self) -> Dict[str, Any]:
        result = {
            'success': False,
            'pushed': 0,
            'failed': 0,
            'error': None
        }
        try:
            logger.info("Push data via script called (stub implementation)")
            result['success'] = True
            result['pushed'] = 0
            return result
        except Exception as e:
            result['error'] = f"push_data_via_script failed: {e}"
            logger.error(result['error'], exc_info=True)
            return result

    def create_campaign_structure(self, sub_account_id: int,
                                  creative_data: Dict) -> Dict[str, Any]:
        result = {
            'success': False,
            'campaign_id': None,
            'ad_group_id': None,
            'ad_ids': [],
            'keyword_ids': [],
            'error': None
        }

        sync_log = None
        try:
            sub_account = AdsSubAccount.query.get(sub_account_id)
            if not sub_account:
                result['error'] = f"Sub account {sub_account_id} not found"
                logger.error(result['error'])
                return result

            mcc = sub_account.mcc
            if mcc:
                sync_log = self._create_sync_log(mcc.id, 'push', 'script')

            campaign_name = creative_data.get('campaign_name') or \
                f"Campaign_{sub_account.external_id}_{datetime.utcnow().strftime('%Y%m%d')}"

            campaign = Campaign(
                tenant_id=sub_account.mcc.tenant_id if sub_account.mcc else None,
                sub_account_id=sub_account.id,
                name=campaign_name,
                status='paused',
                budget=creative_data.get('budget', 10.0),
                budget_type='daily',
                bid_strategy=creative_data.get('bid_strategy', 'MAXIMIZE_CLICKS'),
                advertising_channel=creative_data.get('channel', 'SEARCH'),
                settings={'created_from_ai_creative': True}
            )
            db.session.add(campaign)
            db.session.flush()
            result['campaign_id'] = campaign.id

            ad_group_name = creative_data.get('ad_group_name') or f"AG_{campaign_name}"
            ad_group = AdGroup(
                campaign_id=campaign.id,
                name=ad_group_name,
                status='paused',
                cpc_bid=creative_data.get('cpc_bid', 1.0)
            )
            db.session.add(ad_group)
            db.session.flush()
            result['ad_group_id'] = ad_group.id

            headlines = creative_data.get('headlines', [])
            descriptions = creative_data.get('descriptions', [])
            paths = creative_data.get('paths', [])
            final_url = creative_data.get('final_url', '')

            ad = Ad(
                ad_group_id=ad_group.id,
                ad_type='RESPONSIVE_SEARCH_AD',
                headlines=[h for h in headlines if isinstance(h, dict) and h.get('text')],
                descriptions=[d for d in descriptions if isinstance(d, dict) and d.get('text')],
                paths=paths[:2] if isinstance(paths, list) else [],
                final_url=final_url,
                status='paused',
                ai_generated=True
            )
            db.session.add(ad)
            db.session.flush()
            result['ad_ids'].append(ad.id)

            keywords = creative_data.get('keywords', [])
            for kw_data in keywords:
                if isinstance(kw_data, dict) and kw_data.get('text'):
                    kw = Keyword(
                        ad_group_id=ad_group.id,
                        text=kw_data['text'].strip(),
                        match_type=kw_data.get('match_type', 'BROAD'),
                        status='enabled',
                        ai_generated=True
                    )
                    db.session.add(kw)
                    db.session.flush()
                    result['keyword_ids'].append(kw.id)

            db.session.commit()
            result['success'] = True

            if sync_log:
                self._finalize_sync_log(
                    sync_log, 'success',
                    processed=1 + len(result['keyword_ids']),
                    created=4 + len(result['keyword_ids'])
                )

            logger.info(
                f"Created campaign structure: campaign={campaign.id}, "
                f"ad_group={ad_group.id}, ads={len(result['ad_ids'])}, "
                f"keywords={len(result['keyword_ids'])}"
            )
            return result

        except Exception as e:
            result['error'] = f"create_campaign_structure failed: {e}"
            logger.error(result['error'], exc_info=True)
            db.session.rollback()
            if sync_log:
                self._finalize_sync_log(sync_log, 'failed', error=result['error'])
            return result
