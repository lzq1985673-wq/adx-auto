import json
import logging
import random
import hashlib
import time
import secrets
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple

import requests
from flask import current_app

from ..models import Campaign, ClickTask, ProxyConfig, Ad, db

logger = logging.getLogger(__name__)

UA_POOL_DESKTOP = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
]

UA_POOL_MOBILE = [
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPad; CPU OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1",
]

REFERER_POOL = [
    ("https://www.google.com/search?q={kw}", 35),
    ("https://www.bing.com/search?q={kw}", 15),
    ("https://search.yahoo.com/search?p={kw}", 8),
    ("https://duckduckgo.com/?q={kw}", 5),
    ("https://www.facebook.com/", 8),
    ("https://www.youtube.com/", 7),
    ("https://twitter.com/", 5),
    ("https://www.linkedin.com/", 4),
    ("https://www.reddit.com/", 4),
    ("https://www.pinterest.com/", 3),
    ("https://t.co/", 3),
    ("https://news.ycombinator.com/", 2),
]

COUNTRY_TIMEZONES = {
    'US': ['America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles'],
    'GB': ['Europe/London'],
    'CA': ['America/Toronto', 'America/Vancouver'],
    'AU': ['Australia/Sydney', 'Australia/Melbourne'],
    'DE': ['Europe/Berlin'],
    'FR': ['Europe/Paris'],
    'JP': ['Asia/Tokyo'],
    'CN': ['Asia/Shanghai'],
    'IN': ['Asia/Kolkata'],
    'BR': ['America/Sao_Paulo'],
}


class ClickExecutionService:
    def __init__(self, tenant_id: Optional[int] = None):
        self.tenant_id = tenant_id
        self.ip_validation_retries = 3

    def _get_proxy_for_country(self, country: str) -> Optional[ProxyConfig]:
        try:
            query = ProxyConfig.query.filter_by(is_active=True)
            if self.tenant_id:
                query = query.filter_by(tenant_id=self.tenant_id)
            proxies = query.order_by(ProxyConfig.priority.asc()).all()
            if not proxies:
                return None

            matching = []
            for p in proxies:
                rules = p.country_rules or []
                if not rules:
                    matching.append(p)
                else:
                    for rule in rules:
                        if rule.get('country') == country or rule.get('country') == 'GLOBAL':
                            matching.append(p)
                            break
            return matching[0] if matching else (proxies[0] if proxies else None)
        except Exception as e:
            logger.warning(f"Get proxy failed: {e}")
            return None

    def _build_proxy_url(self, proxy: ProxyConfig, country: str,
                         session_id: Optional[str] = None) -> Optional[str]:
        try:
            if not proxy or not proxy.username or not proxy.endpoint:
                return None
            session = session_id or hashlib.md5(
                f"{time.time()}:{secrets.token_hex(8)}".encode()
            ).hexdigest()[:16]

            country_suffix = f"-country-{country.lower()}" if country else ""
            proxy_user = f"{proxy.username}{country_suffix}-session-{session}"
            return f"{proxy.protocol}://{proxy_user}:{proxy.password}@{proxy.endpoint}:{proxy.port or 80}"
        except Exception as e:
            logger.warning(f"Build proxy URL failed: {e}")
            return None

    def validate_ip_physical_location(self, ip: str) -> Tuple[bool, Dict]:
        result = {
            'ip': ip,
            'country': None,
            'city': None,
            'timezone': None,
            'latitude': None,
            'longitude': None,
            'is_proxy': False,
            'sources_matched': 0,
            'details': {}
        }

        apis = [
            f"https://ipapi.co/{ip}/json/",
            f"https://ipinfo.io/{ip}/json",
            f"https://get.geojs.io/v1/ip/geo/{ip}.json",
        ]

        matches = 0
        last_country = None
        last_tz = None

        for idx, api_url in enumerate(apis[:self.ip_validation_retries]):
            try:
                resp = requests.get(api_url, timeout=8)
                if resp.status_code != 200:
                    continue
                data = resp.json()

                if idx == 0:
                    result['country'] = data.get('country_code') or data.get('country')
                    result['city'] = data.get('city')
                    result['timezone'] = data.get('timezone')
                    result['latitude'] = data.get('latitude')
                    result['longitude'] = data.get('longitude')
                    last_country = result['country']
                    last_tz = result['timezone']
                    matches += 1
                else:
                    c = data.get('country_code') or data.get('country')
                    t = data.get('timezone')
                    if c and c == last_country:
                        matches += 1
                    if t and last_tz and t == last_tz:
                        matches += 0.5

                result['details'][f'source_{idx}'] = {
                    'country': data.get('country_code') or data.get('country'),
                    'timezone': data.get('timezone')
                }

            except Exception as e:
                logger.debug(f"IP validation source {idx} failed: {e}")

        result['sources_matched'] = matches
        is_valid = matches >= 2
        logger.info(f"IP {ip} validation: valid={is_valid}, matches={matches}")
        return is_valid, result

    def _select_user_agent(self, device_type: str) -> Tuple[str, str, str, str]:
        if device_type == 'mobile':
            ua = random.choice(UA_POOL_MOBILE)
        else:
            ua = random.choice(UA_POOL_DESKTOP)

        browser = 'Chrome'
        if 'Firefox' in ua:
            browser = 'Firefox'
        elif 'Safari' in ua and 'Chrome' not in ua:
            browser = 'Safari'
        elif 'Edg' in ua:
            browser = 'Edge'

        os = 'Windows'
        if 'Mac' in ua:
            os = 'macOS'
        elif 'Linux' in ua:
            os = 'Linux'
        elif 'iPhone' in ua or 'iPad' in ua:
            os = 'iOS'
        elif 'Android' in ua:
            os = 'Android'

        resolution = random.choice(['1920x1080', '1366x768', '1440x900', '1536x864', '2560x1440']) \
            if device_type == 'desktop' else random.choice(['390x844', '414x896', '360x800', '768x1024'])

        language = random.choice(['en-US', 'en-GB', 'en-CA', 'en-AU', 'de-DE', 'fr-FR', 'ja-JP', 'zh-CN'])

        return ua, browser, os, resolution, language

    def build_referer_traffic_distribution(self) -> List[Tuple[str, float]]:
        total_weight = sum(w for _, w in REFERER_POOL)
        return [(url, w / total_weight) for url, w in REFERER_POOL]

    def _select_referer(self, keyword: Optional[str] = None) -> str:
        dist = self.build_referer_traffic_distribution()
        r = random.random()
        cumulative = 0
        selected = dist[0][0]
        for url, weight in dist:
            cumulative += weight
            if r <= cumulative:
                selected = url
                break

        kw = keyword or random.choice(['buy', 'best', 'review', 'online', 'shop'])
        return selected.format(kw=kw)

    def distribute_traffic_schedule(self, daily_clicks: int, country: str,
                                    timezone_str: str) -> List[Dict[str, Any]]:
        schedule = []

        time_slots = [
            (0, 3, 0.02),
            (3, 6, 0.01),
            (6, 8, 0.04),
            (8, 12, 0.20),
            (12, 14, 0.12),
            (14, 18, 0.22),
            (18, 21, 0.25),
            (21, 24, 0.14),
        ]

        for start_h, end_h, ratio in time_slots:
            slot_clicks = max(1, int(round(daily_clicks * ratio))) if daily_clicks > 0 else 0
            slot_minutes = (end_h - start_h) * 60

            for i in range(slot_clicks):
                minute_offset = random.randint(0, max(1, slot_minutes - 1))
                abs_minutes = start_h * 60 + minute_offset
                hour = abs_minutes // 60
                minute = abs_minutes % 60

                tz_list = COUNTRY_TIMEZONES.get(country, [timezone_str or 'UTC'])
                assigned_tz = random.choice(tz_list)

                schedule.append({
                    'hour': hour,
                    'minute': minute,
                    'timezone': assigned_tz,
                    'country': country,
                    'slot': f"{start_h:02d}-{end_h:02d}",
                })

        random.shuffle(schedule)
        logger.info(f"Distributed {daily_clicks} clicks into {len(schedule)} schedule items for {country}")
        return schedule

    def simulate_human_behavior(self, session: requests.Session, target_url: str,
                                metrics: Dict) -> Dict:
        behavior_metrics = {
            'scroll_depth_pct': 0,
            'total_scroll_events': 0,
            'mouse_move_events': 0,
            'click_events_internal': 0,
            'hover_events': 0,
            'time_on_page_sec': 0,
            'pages_viewed': 1,
            'bounce_rate_risk': False,
            'engagement_score': 0,
        }

        try:
            start_time = time.time()
            response = session.get(target_url, timeout=30, allow_redirects=True)
            metrics['http_status'] = response.status_code
            metrics['response_time_ms'] = int(response.elapsed.total_seconds() * 1000)
            metrics['content_length'] = len(response.content)
            metrics['final_url'] = response.url

            total_stay = random.randint(25, 120)
            scroll_events = random.randint(3, 10)
            for _ in range(scroll_events):
                time.sleep(random.uniform(1, 4))
                behavior_metrics['scroll_depth_pct'] = min(
                    100, behavior_metrics['scroll_depth_pct'] + random.randint(5, 25)
                )
                behavior_metrics['total_scroll_events'] += 1

            behavior_metrics['mouse_move_events'] = random.randint(20, 200)
            behavior_metrics['hover_events'] = random.randint(2, 15)

            if random.random() < 0.35:
                behavior_metrics['pages_viewed'] += random.randint(1, 3)
                behavior_metrics['click_events_internal'] = behavior_metrics['pages_viewed'] - 1

            time.sleep(max(0, total_stay - (time.time() - start_time)))

            behavior_metrics['time_on_page_sec'] = int(time.time() - start_time)

            engagement = (
                behavior_metrics['scroll_depth_pct'] * 0.3 +
                min(100, behavior_metrics['time_on_page_sec']) * 0.4 +
                behavior_metrics['pages_viewed'] * 10 * 0.3
            )
            behavior_metrics['engagement_score'] = min(100, int(engagement))
            behavior_metrics['bounce_rate_risk'] = (
                behavior_metrics['pages_viewed'] == 1 and
                behavior_metrics['time_on_page_sec'] < 10
            )

            logger.info(
                f"Human behavior simulated: stay={behavior_metrics['time_on_page_sec']}s, "
                f"scroll={behavior_metrics['scroll_depth_pct']}%, pages={behavior_metrics['pages_viewed']}"
            )

        except Exception as e:
            logger.warning(f"Simulate human behavior error: {e}")
            behavior_metrics['engagement_score'] = random.randint(20, 60)

        metrics.update(behavior_metrics)
        return behavior_metrics

    def _generate_fingerprint(self, ip: str, ua: str, campaign_id: int) -> str:
        salt = current_app.config.get('FINGERPRINT_SALT', 'default-salt')
        raw = f"{campaign_id}:{ip}:{ua}:{time.time()}:{secrets.token_hex(8)}:{salt}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    def run_single_click(self, campaign_id: int,
                         click_task_params: Optional[Dict] = None) -> Dict[str, Any]:
        result = {
            'success': False,
            'click_task_id': None,
            'ip': None,
            'country': None,
            'fingerprint': None,
            'duration_seconds': 0,
            'pages_viewed': 1,
            'metrics': {},
            'error': None,
        }

        click_task = None
        try:
            campaign = Campaign.query.get(campaign_id)
            if not campaign:
                result['error'] = f"Campaign {campaign_id} not found"
                logger.error(result['error'])
                return result

            params = click_task_params or {}
            country = params.get('country') or random.choice(
                campaign.click_countries or ['US']
            )
            device_type = params.get('device_type') or (
                'mobile' if random.random() < 0.6 else 'desktop'
            )
            target_url = params.get('target_url')
            if not target_url and campaign.ad_groups:
                for ag in campaign.ad_groups:
                    if ag.ads:
                        target_url = ag.ads[0].final_url
                        break
            if not target_url:
                result['error'] = "No target URL found"
                logger.error(result['error'])
                return result

            proxy = self._get_proxy_for_country(country)
            proxy_url = None
            actual_ip = None

            if proxy:
                session_id = hashlib.md5(
                    f"{campaign_id}:{time.time()}:{secrets.token_hex(4)}".encode()
                ).hexdigest()[:12]
                proxy_url = self._build_proxy_url(proxy, country, session_id)

            proxies = {'http': proxy_url, 'https': proxy_url} if proxy_url else None

            ua, browser, os, resolution, language = self._select_user_agent(device_type)
            referer = self._select_referer(params.get('keyword'))
            fingerprint = self._generate_fingerprint(
                actual_ip or 'local', ua, campaign_id
            )

            click_task = ClickTask(
                campaign_id=campaign_id,
                ad_id=params.get('ad_id'),
                keyword=params.get('keyword'),
                target_url=target_url,
                country=country,
                timezone=COUNTRY_TIMEZONES.get(country, ['UTC'])[0],
                user_agent=ua,
                fingerprint=fingerprint,
                referer=referer,
                device_type=device_type,
                browser=browser,
                os=os,
                resolution=resolution,
                language=language,
                ip_proxy=proxy.provider if proxy else None,
                status='running',
                executed_at=datetime.utcnow(),
            )
            db.session.add(click_task)
            db.session.commit()
            result['click_task_id'] = click_task.id
            result['fingerprint'] = fingerprint

            session = requests.Session()
            session.headers.update({
                'User-Agent': ua,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': language,
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': referer,
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'cross-site',
            })

            if proxies:
                session.proxies.update(proxies)

            try:
                ip_check = session.get('https://api.ipify.org?format=json', timeout=10)
                if ip_check.status_code == 200:
                    actual_ip = ip_check.json().get('ip')
                    click_task.ip_address = actual_ip
                    result['ip'] = actual_ip
                    result['country'] = country

                    ip_valid, ip_info = self.validate_ip_physical_location(actual_ip)
                    if not ip_valid:
                        logger.warning(f"IP {actual_ip} location validation weak, continuing anyway")
                    click_task.city = ip_info.get('city')
                    click_task.timezone = ip_info.get('timezone') or click_task.timezone
            except Exception as e:
                logger.debug(f"IP detection failed: {e}")

            metrics: Dict[str, Any] = {
                'campaign_id': campaign_id,
                'fingerprint': fingerprint,
                'proxy_provider': proxy.provider if proxy else None,
                'proxy_protocol': proxy.protocol if proxy else None,
                'device_type': device_type,
                'browser': browser,
                'os': os,
                'resolution': resolution,
                'language': language,
                'referer': referer,
                'http_status': 0,
                'response_time_ms': 0,
                'content_length': 0,
                'redirect_count': 0,
                'final_url': target_url,
                'session_started': datetime.utcnow().isoformat(),
                'dom_nodes_approx': random.randint(500, 5000),
                'js_heap_size_mb': random.randint(10, 80),
                'cpu_cores': random.choice([2, 4, 6, 8, 12, 16]),
                'memory_gb': random.choice([4, 8, 16, 32]),
                'platform': 'Win32' if device_type == 'desktop' and 'Windows' in os else (
                    'MacIntel' if 'mac' in os.lower() else 'Linux x86_64'
                ),
                'hardware_concurrency': random.choice([2, 4, 6, 8, 12]),
                'device_memory': random.choice([4, 8, 16, 32]),
                'color_depth': 24,
                'pixel_ratio': random.choice([1, 1.25, 1.5, 2, 3]),
                'touch_supported': device_type == 'mobile',
                'max_touch_points': random.choice([0, 1, 5, 10]),
                'cookie_enabled': True,
                'local_storage_enabled': True,
                'session_storage_enabled': True,
                'webgl_vendor': random.choice([
                    'Google Inc. (NVIDIA)', 'Google Inc. (Intel)',
                    'Apple Inc.', 'Mozilla'
                ]),
                'webgl_renderer': random.choice([
                    'ANGLE (NVIDIA GeForce)', 'ANGLE (Intel Iris)',
                    'Apple M1', 'SwiftShader'
                ]),
                'canvas_fingerprint': hashlib.md5(
                    f"{fingerprint}:canvas".encode()
                ).hexdigest()[:16],
                'audio_fingerprint': hashlib.md5(
                    f"{fingerprint}:audio".encode()
                ).hexdigest()[:16],
                'fonts_hash': hashlib.md5(
                    f"{fingerprint}:fonts:{browser}".encode()
                ).hexdigest()[:16],
                'timezone_offset_min': random.randint(-720, 720),
                'timezone_name': click_task.timezone,
                'webdriver_detected': False,
                'permissions_notifications': 'default',
                'permissions_geolocation': 'prompt',
            }

            behavior = self.simulate_human_behavior(session, target_url, metrics)

            result['duration_seconds'] = behavior['time_on_page_sec']
            result['pages_viewed'] = behavior['pages_viewed']
            result['success'] = True
            result['metrics'] = metrics

            click_task.duration_seconds = behavior['time_on_page_sec']
            click_task.pages_viewed = behavior['pages_viewed']
            click_task.status = 'success'
            click_task.metrics_data = metrics
            db.session.commit()

            logger.info(
                f"Click executed: task={click_task.id}, campaign={campaign_id}, "
                f"ip={actual_ip}, country={country}, duration={behavior['time_on_page_sec']}s"
            )
            return result

        except Exception as e:
            result['error'] = f"run_single_click failed: {e}"
            logger.error(result['error'], exc_info=True)
            if click_task:
                try:
                    click_task.status = 'failed'
                    click_task.error_message = str(e)[:1000]
                    db.session.commit()
                except Exception:
                    db.session.rollback()
            return result
