import json
import logging
import random
import hashlib
import time
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

import requests
from flask import current_app

from ..models import Campaign, Ad, LinkSwapTask, ClickTask, ProxyConfig, db

logger = logging.getLogger(__name__)


class LinkSwapService:
    def __init__(self, tenant_id: Optional[int] = None):
        self.tenant_id = tenant_id
        self.min_swap_interval_minutes = 10

    def generate_unique_link_fingerprint(self, url: str, campaign_id: int) -> str:
        salt = current_app.config.get('FINGERPRINT_SALT', 'default-salt')
        raw = f"{campaign_id}:{url}:{time.time()}:{salt}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    def _get_shared_pool_from_click_tasks(self, campaign_id: int,
                                   limit: int = 5) -> List[Dict]:
        try:
            recent = ClickTask.query.filter_by(
                campaign_id=campaign_id,
                status='success'
            ).order_by(ClickTask.executed_at.desc()).limit(limit).all()

            pool = []
            for ct in recent:
                pool.append({
                    'ip_address': ct.ip_address,
                    'user_agent': ct.user_agent,
                    'fingerprint': ct.fingerprint,
                    'country': ct.country,
                    'proxy_provider': ct.ip_proxy,
                })
            return pool
        except Exception as e:
            logger.warning(f"Get shared pool failed: {e}")
            return []

    def _get_proxy_for_country(self, country: Optional[str]) -> Optional[ProxyConfig]:
        try:
            query = ProxyConfig.query.filter_by(is_active=True)
            if self.tenant_id:
                query = query.filter_by(tenant_id=self.tenant_id)
            return query.order_by(ProxyConfig.priority.asc()).first()
        except Exception:
            return None

    def _build_proxies_dict(self, proxy: Optional[ProxyConfig],
                            country: Optional[str]) -> Optional[Dict[str, str]]:
        if not proxy or not proxy.username:
            return None
        try:
            session_id = hashlib.md5(f"swap:{time.time()}".encode()).hexdigest()[:12]
            country_suffix = f"-country-{country.lower()}" if country else ""
            user = f"{proxy.username}{country_suffix}-session-{session_id}"
            url = f"{proxy.protocol}://{user}:{proxy.password}@{proxy.endpoint}:{proxy.port or 80}"
            return {'http': url, 'https': url}
        except Exception:
            return None

    def crawl_final_destination_url(self, url: str,
                                   proxy: Optional[ProxyConfig] = None) -> Dict[str, Any]:
        result = {
            'original_url': url,
            'final_url': url,
            'status_code': 0,
            'redirect_chain': [],
            'tracking_params': {},
            'error': None,
            'success': False,
            'response_time_ms': 0,
        }

        proxies = self._build_proxies_dict(proxy, None)

        shared_pool = self._get_shared_pool_from_click_tasks(0, 1) if not proxy else []
        ua = shared_pool[0]['user_agent'] if shared_pool else (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        )

        try:
            start = time.time()
            session = requests.Session()
            session.headers.update({
                'User-Agent': ua,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
            })

            history: List[Dict] = []
            response = session.get(url, timeout=30, allow_redirects=True, proxies=proxies)

            for r in response.history:
                history.append({
                    'status': r.status_code,
                    'url': r.url,
                })
            history.append({
                'status': response.status_code,
                'url': response.url,
            })

            result['redirect_chain'] = history
            result['final_url'] = response.url
            result['status_code'] = response.status_code
            result['response_time_ms'] = int((time.time() - start) * 1000)

            parsed = urlparse(response.url)
            tracking_params = parse_qs(parsed.query)
            result['tracking_params'] = {
                k: v[0] if len(v) == 1 else v
                for k, v in tracking_params.items()
            }
            result['success'] = response.status_code < 400

            logger.info(
                f"Crawl URL: {url[:80]} -> status={response.status_code}, "
                f"redirects={len(response.history)}"
            )

        except requests.exceptions.Timeout:
            result['error'] = 'Crawl timeout'
            logger.warning(f"Crawl timeout for {url[:80]}")
        except requests.exceptions.RequestException as e:
            result['error'] = f"Request failed: {e}"
            logger.warning(f"Crawl request failed: {e}")
        except Exception as e:
            result['error'] = f"Crawl failed: {e}"
            logger.error(result['error'], exc_info=True)

        return result

    def update_tracking_params_reversely(self, landing_url: str,
                                         tracking_params: Dict[str, Any]) -> str:
        try:
            parsed = urlparse(landing_url)
            existing_params = parse_qs(parsed.query)

            for k, v in tracking_params.items():
                if isinstance(v, list):
                    existing_params[k] = v
                else:
                    existing_params[k] = [str(v)]

            new_query = urlencode(existing_params, doseq=True)
            new_parts = parsed._replace(query=new_query)
            return urlunparse(new_parts)
        except Exception as e:
            logger.error(f"update_tracking_params_reversely failed: {e}")
            return landing_url

    def _check_last_swap_time(self, campaign_id: int,
                             ad_id: Optional[int]) -> Optional[datetime]:
        try:
            query = LinkSwapTask.query.filter_by(campaign_id=campaign_id)
            if ad_id:
                query = query.filter_by(ad_id=ad_id)
            last = query.order_by(LinkSwapTask.executed_at.desc()).first()
            return last.executed_at if last else None
        except Exception:
            return None

    def _enforce_min_interval(self, campaign_id: int,
                              ad_id: Optional[int]) -> Tuple[bool, str]:
        last_exec = self._check_last_swap_time(campaign_id, ad_id)
        if not last_exec:
            return True, ''

        elapsed = (datetime.utcnow() - last_exec).total_seconds() / 60.0
        if elapsed < self.min_swap_interval_minutes:
            wait = self.min_swap_interval_minutes - elapsed
            return False, f"Too frequent swap, wait {wait:.1f} minutes"
        return True, ''

    def _check_fingerprint_exists(self, fingerprint: str) -> bool:
        try:
            return LinkSwapTask.query.filter_by(
                link_fingerprint=fingerprint
            ).first() is not None
        except Exception:
            return False

    def swap_ad_links(self, campaign_id: int, ad_id: Optional[int],
                      new_urls: List[Dict[str, str]]) -> Dict[str, Any]:
        result = {
            'success': False,
            'swapped_count': 0,
            'tasks': [],
            'error': None,
        }

        try:
            campaign = Campaign.query.get(campaign_id)
            if not campaign:
                result['error'] = f"Campaign {campaign_id} not found"
                logger.error(result['error'])
                return result

            interval_ok, interval_msg = self._enforce_min_interval(campaign_id, ad_id)
            if not interval_ok:
                result['error'] = interval_msg
                logger.warning(result['error'])
                return result

            ads_to_update: List[Ad] = []
            if ad_id:
                ad = Ad.query.get(ad_id)
                if ad:
                    ads_to_update.append(ad)
            else:
                for ag in campaign.ad_groups:
                    ads_to_update.extend(ag.ads)

            if not ads_to_update:
                result['error'] = "No ads found to update"
                logger.warning(result['error'])
                return result

            shared_pool = self._get_shared_pool_from_click_tasks(campaign_id, limit=3)

            for idx, ad in enumerate(ads_to_update):
                try:
                    url_data = new_urls[idx % len(new_urls)] if new_urls else {}
                    new_final_url = url_data.get('final_url') or url_data.get('url')
                    new_tracking_url = url_data.get('tracking_url')
                    old_final_url = ad.final_url
                    old_tracking_url = ad.tracking_url_template

                    if not new_final_url:
                        logger.debug(f"Skip ad {ad.id}: no new URL provided")
                        continue

                    fingerprint = self.generate_unique_link_fingerprint(
                        new_final_url, campaign_id
                    )
                    retry_count = 0
                    while self._check_fingerprint_exists(fingerprint) and retry_count < 5:
                        fingerprint = self.generate_unique_link_fingerprint(
                            f"{new_final_url}:{retry_count}", campaign_id
                        )
                        retry_count += 1

                    crawl_info = {'success': False}
                    proxy = None
                    if shared_pool:
                        country = shared_pool[idx % len(shared_pool)].get('country')
                        proxy = self._get_proxy_for_country(country)
                        crawl_info = self.crawl_final_destination_url(new_final_url, proxy)

                    tracking_updated = {}
                    if crawl_info.get('tracking_params'):
                        updated_url = self.update_tracking_params_reversely(
                            new_final_url, crawl_info['tracking_params']
                        )
                        tracking_updated = crawl_info['tracking_params']
                        new_final_url = updated_url

                    swap_task = LinkSwapTask(
                        campaign_id=campaign_id,
                        ad_id=ad.id,
                        old_tracking_url=old_tracking_url or '',
                        old_final_url=old_final_url or '',
                        new_tracking_url=new_tracking_url or '',
                        new_final_url=new_final_url,
                        link_fingerprint=fingerprint,
                        crawled_destination=crawl_info.get('final_url', new_final_url),
                        tracking_params_updated=tracking_updated,
                        executed_at=datetime.utcnow(),
                        status='success' if crawl_info.get('success') else 'pending',
                        same_origin_click=bool(shared_pool),
                    )
                    db.session.add(swap_task)
                    db.session.flush()

                    ad.final_url = new_final_url
                    if new_tracking_url:
                        ad.tracking_url_template = new_tracking_url
                    ad.updated_at = datetime.utcnow()

                    result['tasks'].append({
                        'swap_task_id': swap_task.id,
                        'ad_id': ad.id,
                        'old_final_url': old_final_url,
                        'new_final_url': new_final_url,
                        'fingerprint': fingerprint,
                    })
                    result['swapped_count'] += 1

                    logger.info(
                        f"Link swapped: ad={ad.id}, campaign={campaign_id}, "
                        f"fingerprint={fingerprint[:12]}, origin_shared={bool(shared_pool)}"
                    )

                except Exception as e:
                    logger.error(f"Swap single ad {ad.id} failed: {e}")
                    continue

            db.session.commit()
            result['success'] = result['swapped_count'] > 0
            logger.info(f"Link swap complete: {result['swapped_count']}/{len(ads_to_update)} ads")
            return result

        except Exception as e:
            result['error'] = f"swap_ad_links failed: {e}"
            logger.error(result['error'], exc_info=True)
            db.session.rollback()
            return result
