import json
import logging
import hashlib
import secrets
import string
import random
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

from flask import current_app

from ..models import MCCAccount, Tenant, AIConfig, ProxyConfig, db

logger = logging.getLogger(__name__)


class AntiAssociationService:
    def __init__(self, tenant_id: Optional[int] = None):
        self.tenant_id = tenant_id

    def _get_salt(self) -> str:
        try:
            return current_app.config.get('FINGERPRINT_SALT', 'adx-auto-default-salt')
        except Exception:
            return 'adx-auto-default-salt'

    def _random_hex(self, length: int = 8) -> str:
        return secrets.token_hex(length)

    def _random_string(self, length: int = 16) -> str:
        chars = string.ascii_lowercase + string.digits
        return ''.join(random.choice(chars) for _ in range(length))

    def generate_isolated_script_fingerprint(self, mcc_account: MCCAccount) -> str:
        try:
            salt = self._get_salt()
            raw = (
                f"{mcc_account.id}:{mcc_account.customer_id}:"
                f"{mcc_account.created_at or datetime.utcnow()}:"
                f"{self._random_hex(4)}:{salt}"
            )
            fingerprint = hashlib.sha256(raw.encode()).hexdigest()[:32]

            mcc_account.script_fingerprint = fingerprint
            db.session.commit()

            logger.info(
                f"Generated isolated fingerprint for MCC {mcc_account.id}: {fingerprint[:12]}..."
            )
            return fingerprint

        except Exception as e:
            logger.error(f"generate_isolated_script_fingerprint failed: {e}", exc_info=True)
            db.session.rollback()
            raise

    def assign_worker_domain(self, mcc_id: int) -> Dict[str, Any]:
        result = {
            'success': False,
            'worker_domain': None,
            'subdomain': None,
            'mcc_id': mcc_id,
            'error': None,
        }
        try:
            mcc = MCCAccount.query.get(mcc_id)
            if not mcc:
                result['error'] = f"MCC account {mcc_id} not found"
                logger.error(result['error'])
                return result

            if mcc.worker_domain:
                result['success'] = True
                result['worker_domain'] = mcc.worker_domain
                result['subdomain'] = mcc.worker_domain.split('.')[0]
                logger.info(f"MCC {mcc_id} already has worker domain: {mcc.worker_domain}")
                return result

            salt = self._get_salt()
            raw = f"worker:{mcc.id}:{mcc.customer_id}:{salt}:{self._random_hex(4)}"
            subdomain_hash = hashlib.sha256(raw.encode()).hexdigest()[:10]
            prefix = self._random_string(4)
            subdomain = f"{prefix}-{subdomain_hash}"

            base_domain = current_app.config.get('WORKER_BASE_DOMAIN', 'adx-worker.app')
            worker_domain = f"{subdomain}.{base_domain}"

            isolation_group = f"group_{hashlib.md5(f'mcc:{mcc.id}:{salt}'.encode()).hexdigest()[:8]}"

            mcc.worker_domain = worker_domain
            mcc.isolation_group = isolation_group
            db.session.commit()

            result['success'] = True
            result['worker_domain'] = worker_domain
            result['subdomain'] = subdomain
            result['isolation_group'] = isolation_group

            logger.info(
                f"Assigned worker domain for MCC {mcc_id}: {worker_domain}, "
                f"isolation_group={isolation_group}"
            )
            return result

        except Exception as e:
            result['error'] = f"assign_worker_domain failed: {e}"
            logger.error(result['error'], exc_info=True)
            db.session.rollback()
            return result

    def isolate_inbound_outbound(self, mcc_id: int,
                                 request_data: Dict[str, Any]) -> Dict[str, Any]:
        result = {
            'success': False,
            'inbound_isolated': False,
            'outbound_isolated': False,
            'inbound_filtered': None,
            'outbound_endpoint': None,
            'isolation_token': None,
            'error': None,
        }

        try:
            mcc = MCCAccount.query.get(mcc_id)
            if not mcc:
                result['error'] = f"MCC {mcc_id} not found"
                return result

            if not mcc.script_fingerprint:
                self.generate_isolated_script_fingerprint(mcc)

            if not mcc.worker_domain:
                self.assign_worker_domain(mcc_id)

            salt = self._get_salt()
            token_raw = (
                f"isolate:{mcc.id}:{mcc.script_fingerprint}:"
                f"{datetime.utcnow().isoformat()}:{salt}"
            )
            isolation_token = hashlib.sha256(token_raw.encode()).hexdigest()

            inbound_allowed_keys = {
                'action', 'ref', 'timestamp', 'customer_id',
                'scope', 'data', 'fingerprint'
            }
            inbound_filtered = {
                k: v for k, v in request_data.items()
                if k in inbound_allowed_keys
            }

            outbound_endpoint = f"https://{mcc.worker_domain}/outbound/{isolation_token[:16]}"

            result['success'] = True
            result['inbound_isolated'] = True
            result['outbound_isolated'] = True
            result['inbound_filtered'] = inbound_filtered
            result['outbound_endpoint'] = outbound_endpoint
            result['isolation_token'] = isolation_token
            result['isolation_group'] = mcc.isolation_group

            logger.info(
                f"Inbound/outbound isolated for MCC {mcc_id}: "
                f"group={mcc.isolation_group}, token={isolation_token[:12]}..."
            )
            return result

        except Exception as e:
            result['error'] = f"isolate_inbound_outbound failed: {e}"
            logger.error(result['error'], exc_info=True)
            return result

    def isolate_ai_calls(self, tenant_id: int, provider: str) -> Dict[str, Any]:
        result = {
            'success': False,
            'isolated_provider': None,
            'isolation_key': None,
            'dedicated_config_id': None,
            'headers_patched': {},
            'error': None,
        }

        try:
            tenant = Tenant.query.get(tenant_id)
            if not tenant:
                result['error'] = f"Tenant {tenant_id} not found"
                return result

            salt = self._get_salt()
            isolation_key_raw = f"ai-isolate:{tenant_id}:{provider}:{salt}:{self._random_hex(4)}"
            isolation_key = hashlib.sha256(isolation_key_raw.encode()).hexdigest()[:24]

            active_configs = AIConfig.query.filter_by(
                tenant_id=tenant_id,
                provider=provider,
                is_active=True
            ).order_by(AIConfig.priority.asc()).all()

            dedicated_config = None
            for cfg in active_configs:
                cfg_json = cfg.settings or {}
                if cfg_json.get('isolation_key') == isolation_key:
                    dedicated_config = cfg
                    break

            if not dedicated_config and active_configs:
                dedicated_config = active_configs[0]
                settings = dedicated_config.settings or {}
                settings['isolation_key'] = isolation_key
                settings['isolated_tenant'] = tenant_id
                settings['isolated_at'] = datetime.utcnow().isoformat()
                dedicated_config.settings = settings
                db.session.commit()

            patched_headers = {
                'X-Isolation-Key': isolation_key,
                'X-Tenant-Id': str(tenant_id),
                'X-AI-Provider': provider,
                'X-Request-Nonce': self._random_hex(8),
            }

            result['success'] = True
            result['isolated_provider'] = provider
            result['isolation_key'] = isolation_key
            result['dedicated_config_id'] = dedicated_config.id if dedicated_config else None
            result['headers_patched'] = patched_headers

            logger.info(
                f"AI calls isolated for tenant {tenant_id}, provider={provider}: "
                f"key={isolation_key[:12]}..., config_id={result['dedicated_config_id']}"
            )
            return result

        except Exception as e:
            result['error'] = f"isolate_ai_calls failed: {e}"
            logger.error(result['error'], exc_info=True)
            db.session.rollback()
            return result

    def rotate_fingerprints(self, tenant_id: int) -> Dict[str, Any]:
        result = {
            'success': False,
            'rotated_mcc_count': 0,
            'rotated_ai_count': 0,
            'rotated_proxy_count': 0,
            'details': [],
            'error': None,
        }

        try:
            tenant = Tenant.query.get(tenant_id)
            if not tenant:
                result['error'] = f"Tenant {tenant_id} not found"
                return result

            mcc_accounts = MCCAccount.query.filter_by(tenant_id=tenant_id).all()
            for mcc in mcc_accounts:
                try:
                    old_fp = mcc.script_fingerprint or ''
                    new_fp = self.generate_isolated_script_fingerprint(mcc)

                    if mcc.worker_domain:
                        self.assign_worker_domain(mcc.id)
                        result['details'].append({
                            'type': 'mcc_worker',
                            'mcc_id': mcc.id,
                            'old_fingerprint': old_fp[:12],
                            'new_fingerprint': new_fp[:12],
                            'new_domain': mcc.worker_domain,
                        })
                    else:
                        result['details'].append({
                            'type': 'mcc_fingerprint',
                            'mcc_id': mcc.id,
                            'old_fingerprint': old_fp[:12],
                            'new_fingerprint': new_fp[:12],
                        })
                    result['rotated_mcc_count'] += 1
                except Exception as e:
                    logger.warning(f"Rotate fingerprint for MCC {mcc.id} failed: {e}")
                    continue

            ai_configs = AIConfig.query.filter_by(tenant_id=tenant_id, is_active=True).all()
            for ai_cfg in ai_configs:
                try:
                    settings = ai_cfg.settings or {}
                    old_isolation = settings.get('isolation_key', '')
                    ai_iso = self.isolate_ai_calls(tenant_id, ai_cfg.provider)
                    if ai_iso.get('isolation_key'):
                        new_iso = ai_iso['isolation_key']
                        result['details'].append({
                            'type': 'ai_isolation',
                            'ai_config_id': ai_cfg.id,
                            'provider': ai_cfg.provider,
                            'old_isolation': old_isolation[:12] if old_isolation else '',
                            'new_isolation': new_iso[:12],
                        })
                        result['rotated_ai_count'] += 1
                except Exception as e:
                    logger.warning(f"Rotate AI isolation for config {ai_cfg.id} failed: {e}")
                    continue

            proxy_configs = ProxyConfig.query.filter_by(tenant_id=tenant_id, is_active=True).all()
            for proxy in proxy_configs:
                try:
                    test_result = proxy.test_result or {}
                    test_result['last_rotation'] = datetime.utcnow().isoformat()
                    test_result['rotation_nonce'] = self._random_hex(8)
                    proxy.test_result = test_result
                    proxy.last_test = datetime.utcnow()
                    db.session.commit()
                    result['details'].append({
                        'type': 'proxy_rotation_touch',
                        'proxy_id': proxy.id,
                        'provider': proxy.provider,
                    })
                    result['rotated_proxy_count'] += 1
                except Exception as e:
                    logger.warning(f"Rotate proxy touch for {proxy.id} failed: {e}")
                    continue

            result['success'] = True
            logger.info(
                f"Fingerprints rotated for tenant {tenant_id}: "
                f"mcc={result['rotated_mcc_count']}, ai={result['rotated_ai_count']}, "
                f"proxy={result['rotated_proxy_count']}"
            )
            return result

        except Exception as e:
            result['error'] = f"rotate_fingerprints failed: {e}"
            logger.error(result['error'], exc_info=True)
            db.session.rollback()
            return result

    def verify_isolation_compliance(self, mcc_id: int) -> Dict[str, Any]:
        result = {
            'success': False,
            'mcc_id': mcc_id,
            'compliance_score': 0,
            'checks': {},
            'violations': [],
            'warnings': [],
            'recommendations': [],
            'error': None,
        }

        try:
            mcc = MCCAccount.query.get(mcc_id)
            if not mcc:
                result['error'] = f"MCC {mcc_id} not found"
                return result

            checks_passed = 0
            total_checks = 0

            total_checks += 1
            check_fp = bool(mcc.script_fingerprint and len(mcc.script_fingerprint) >= 16)
            result['checks']['fingerprint_exists'] = check_fp
            if check_fp:
                checks_passed += 1
            else:
                result['violations'].append('MCC has no valid script fingerprint assigned')
                result['recommendations'].append('Run generate_isolated_script_fingerprint()')

            total_checks += 1
            check_domain = bool(mcc.worker_domain)
            result['checks']['worker_domain_assigned'] = check_domain
            if check_domain:
                checks_passed += 1
            else:
                result['violations'].append('MCC has no dedicated Cloudflare Worker domain')
                result['recommendations'].append('Run assign_worker_domain()')

            total_checks += 1
            check_group = bool(mcc.isolation_group)
            result['checks']['isolation_group'] = check_group
            if check_group:
                checks_passed += 1
            else:
                result['warnings'].append('MCC isolation_group not set')

            if mcc.worker_domain:
                total_checks += 1
                same_domain = MCCAccount.query.filter(
                    MCCAccount.id != mcc.id,
                    MCCAccount.worker_domain == mcc.worker_domain
                ).count()
                check_unique_domain = same_domain == 0
                result['checks']['worker_domain_unique'] = check_unique_domain
                if check_unique_domain:
                    checks_passed += 1
                else:
                    result['violations'].append(
                        f'Worker domain shared with {same_domain} other MCC account(s)'
                    )
                    result['recommendations'].append('Reassign unique worker domain')

            if mcc.script_fingerprint:
                total_checks += 1
                same_fp = MCCAccount.query.filter(
                    MCCAccount.id != mcc.id,
                    MCCAccount.script_fingerprint == mcc.script_fingerprint
                ).count()
                check_unique_fp = same_fp == 0
                result['checks']['fingerprint_unique'] = check_unique_fp
                if check_unique_fp:
                    checks_passed += 1
                else:
                    result['violations'].append(
                        f'Script fingerprint shared with {same_fp} other MCC account(s)'
                    )
                    result['recommendations'].append('Regenerate fingerprint via rotate_fingerprints()')

            total_checks += 1
            if mcc.tenant_id:
                ai_iso_count = 0
                ai_cfgs = AIConfig.query.filter_by(tenant_id=mcc.tenant_id, is_active=True).all()
                for ai_cfg in ai_cfgs:
                    s = ai_cfg.settings or {}
                    if s.get('isolation_key'):
                        ai_iso_count += 1
                ai_iso_ratio = ai_iso_count / len(ai_cfgs) if ai_cfgs else 1.0
                check_ai_iso = ai_iso_ratio >= 0.5
                result['checks']['ai_isolation_coverage'] = check_ai_iso
                if check_ai_iso:
                    checks_passed += 1
                else:
                    result['warnings'].append(
                        f'AI isolation coverage only {int(ai_iso_ratio * 100)}% '
                        f'({ai_iso_count}/{len(ai_cfgs)} configs)'
                    )
                    result['recommendations'].append('Run isolate_ai_calls() for remaining providers')

            total_checks += 1
            status_ok = mcc.status in ('active', 'syncing')
            result['checks']['account_status_healthy'] = status_ok
            if status_ok:
                checks_passed += 1
            else:
                result['warnings'].append(f"MCC account status is '{mcc.status}', not active")

            result['compliance_score'] = int(
                (checks_passed / total_checks) * 100
            ) if total_checks > 0 else 0

            if result['compliance_score'] >= 85 and not result['violations']:
                result['success'] = True
            elif result['compliance_score'] >= 70:
                result['success'] = True
                result['warnings'].append('Compliance score acceptable but improvements recommended')
            else:
                result['warnings'].append(
                    f'Compliance score {result["compliance_score"]}% below 70% threshold'
                )

            logger.info(
                f"Isolation compliance check for MCC {mcc_id}: "
                f"score={result['compliance_score']}%, passed={checks_passed}/{total_checks}, "
                f"violations={len(result['violations'])}"
            )
            return result

        except Exception as e:
            result['error'] = f"verify_isolation_compliance failed: {e}"
            logger.error(result['error'], exc_info=True)
            return result
