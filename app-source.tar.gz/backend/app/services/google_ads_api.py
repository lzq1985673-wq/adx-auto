"""
Google Ads API 客户端服务
基于 google-ads-python 官方SDK，支持 OAuth 2.0 授权和真实 API 调用

接入步骤:
1. 在 Google Cloud Console 创建 OAuth 2.0 凭据 (https://console.cloud.google.com/apis/credentials)
2. 启用 Google Ads API (https://console.cloud.google.com/apis/library/googleads.googleapis.com)
3. 将 client_id 和 client_secret 填入 .env
4. 在后台 MCC管理 → 添加MCC → 点击"Google OAuth 授权" → 授权后自动获取 refresh_token
5. 授权成功后即可同步子账号、广告系列等数据
"""
import os
import logging
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from urllib.parse import urlencode, quote_plus

import requests
from flask import current_app, url_for

from ..models import (
    MCCAccount, AdsSubAccount, Campaign, AdGroup, Ad, Keyword,
    AdsSyncLog, db
)

logger = logging.getLogger(__name__)

# Google OAuth 2.0 端点
GOOGLE_OAUTH_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth'
GOOGLE_OAUTH_TOKEN_URL = 'https://oauth2.googleapis.com/token'
GOOGLE_OAUTH_USERINFO_URL = 'https://www.googleapis.com/oauth2/v2/userinfo'
GOOGLE_ADS_API_BASE = 'https://googleads.googleapis.com'


class GoogleAdsAPIClient:
    """
    Google Ads API 客户端
    支持两种模式:
    1. API模式: 使用 google-ads-python SDK 直接调用 (需要 OAuth + Developer Token)
    2. Script模式: 使用 Google Ads Script + Cloudflare Worker (无需API审批)
    """

    def __init__(self, mcc_account: Optional[MCCAccount] = None):
        self.mcc = mcc_account
        self.developer_token = current_app.config.get('GOOGLE_ADS_DEVELOPER_TOKEN', '')
        self.client_id = current_app.config.get('GOOGLE_CLIENT_ID', '')
        self.client_secret = current_app.config.get('GOOGLE_CLIENT_SECRET', '')
        self.redirect_uri = current_app.config.get('GOOGLE_REDIRECT_URI', '')
        self.api_version = current_app.config.get('GOOGLE_ADS_API_VERSION', 'v17')
        self.scopes = current_app.config.get('GOOGLE_ADS_SCOPES', [
            'https://www.googleapis.com/auth/adwords'
        ])

        # 如果有 MCC 账号，使用其专属凭据
        if mcc_account:
            if mcc_account.developer_token:
                self.developer_token = mcc_account.developer_token
            if mcc_account.client_id:
                self.client_id = mcc_account.client_id
            if mcc_account.client_secret:
                self.client_secret = mcc_account.client_secret
            self.refresh_token = mcc_account.refresh_token
            self.login_customer_id = (mcc_account.login_customer_id or
                                      mcc_account.customer_id or '').replace('-', '')
        else:
            self.refresh_token = None
            self.login_customer_id = current_app.config.get('GOOGLE_ADS_LOGIN_CUSTOMER_ID', '').replace('-', '')

    # ==================== OAuth 2.0 授权流程 ====================

    def get_authorization_url(self, state: str = '') -> str:
        """
        生成 Google OAuth 2.0 授权URL
        用户访问此URL → 授权 → Google回调 redirect_uri → 获取 code → 换取 refresh_token
        """
        params = {
            'client_id': self.client_id,
            'redirect_uri': self.redirect_uri,
            'response_type': 'code',
            'scope': ' '.join(self.scopes),
            'access_type': 'offline',  # 获取 refresh_token
            'prompt': 'consent',        # 每次都强制授权（确保获取新的refresh_token）
            'include_granted_scopes': 'true',
        }
        if state:
            params['state'] = state

        auth_url = f"{GOOGLE_OAUTH_AUTH_URL}?{urlencode(params)}"
        logger.info(f"Generated OAuth URL for state={state[:20]}...")
        return auth_url

    def exchange_code_for_tokens(self, authorization_code: str) -> Dict[str, Any]:
        """
        用授权码换取 access_token 和 refresh_token
        """
        data = {
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'code': authorization_code,
            'redirect_uri': self.redirect_uri,
            'grant_type': 'authorization_code',
        }

        resp = requests.post(GOOGLE_OAUTH_TOKEN_URL, data=data, timeout=30)

        if resp.status_code != 200:
            error_detail = resp.json() if resp.headers.get('content-type', '').startswith('application/json') else resp.text
            logger.error(f"OAuth token exchange failed: {resp.status_code} {error_detail}")
            return {
                'success': False,
                'error': f"Token exchange failed: {resp.status_code}",
                'detail': error_detail,
            }

        tokens = resp.json()
        logger.info("OAuth token exchange successful, refresh_token acquired")

        # 获取用户信息
        user_info = {}
        if tokens.get('access_token'):
            user_info = self._get_userinfo(tokens['access_token'])

        return {
            'success': True,
            'access_token': tokens.get('access_token'),
            'refresh_token': tokens.get('refresh_token'),
            'expires_in': tokens.get('expires_in', 3600),
            'scope': tokens.get('scope'),
            'token_type': tokens.get('token_type', 'Bearer'),
            'user_info': user_info,
        }

    def refresh_access_token(self, refresh_token: str = None) -> Dict[str, Any]:
        """
        使用 refresh_token 获取新的 access_token
        """
        rt = refresh_token or self.refresh_token
        if not rt:
            return {'success': False, 'error': 'No refresh_token available'}

        data = {
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'refresh_token': rt,
            'grant_type': 'refresh_token',
        }

        resp = requests.post(GOOGLE_OAUTH_TOKEN_URL, data=data, timeout=30)

        if resp.status_code != 200:
            error_detail = resp.json() if resp.headers.get('content-type', '').startswith('application/json') else resp.text
            logger.error(f"Token refresh failed: {resp.status_code} {error_detail}")
            return {
                'success': False,
                'error': f"Token refresh failed: {resp.status_code}",
                'detail': error_detail,
            }

        tokens = resp.json()
        return {
            'success': True,
            'access_token': tokens.get('access_token'),
            'expires_in': tokens.get('expires_in', 3600),
            'token_type': tokens.get('token_type', 'Bearer'),
        }

    def _get_userinfo(self, access_token: str) -> Dict:
        """获取 Google 账号用户信息"""
        try:
            resp = requests.get(
                GOOGLE_OAUTH_USERINFO_URL,
                headers={'Authorization': f'Bearer {access_token}'},
                timeout=10
            )
            if resp.status_code == 200:
                return resp.json()
        except Exception as e:
            logger.warning(f"Get userinfo failed: {e}")
        return {}

    # ==================== Google Ads API 调用 ====================

    def _get_access_token(self) -> Optional[str]:
        """获取有效的 access_token（自动刷新）"""
        if not self.refresh_token:
            logger.error("No refresh_token, cannot get access_token")
            return None

        result = self.refresh_access_token()
        if result.get('success'):
            return result['access_token']
        else:
            logger.error(f"Failed to refresh access_token: {result.get('error')}")
            return None

    def _api_request(self, method: str, path: str,
                     json_body: Optional[Dict] = None,
                     params: Optional[Dict] = None) -> Dict[str, Any]:
        """
        调用 Google Ads REST API
        文档: https://developers.google.com/google-ads/api/docs/start
        """
        access_token = self._get_access_token()
        if not access_token:
            return {'success': False, 'error': '无法获取 access_token，请先完成 OAuth 授权'}

        url = f"{GOOGLE_ADS_API_BASE}/{self.api_version}{path}"

        headers = {
            'Authorization': f'Bearer {access_token}',
            'developer-token': self.developer_token,
            'Content-Type': 'application/json',
        }
        if self.login_customer_id:
            headers['login-customer-id'] = self.login_customer_id

        try:
            resp = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=json_body,
                params=params,
                timeout=60,
            )

            if resp.status_code == 200:
                return {'success': True, 'data': resp.json()}
            else:
                error_detail = {}
                try:
                    error_detail = resp.json()
                except Exception:
                    error_detail = {'raw': resp.text[:1000]}

                error_msg = self._extract_api_error(error_detail)
                logger.error(f"Google Ads API error: {resp.status_code} {error_msg}")
                return {
                    'success': False,
                    'error': error_msg,
                    'status_code': resp.status_code,
                    'detail': error_detail,
                }

        except requests.exceptions.Timeout:
            return {'success': False, 'error': 'Google Ads API 请求超时'}
        except requests.exceptions.RequestException as e:
            logger.error(f"Google Ads API request failed: {e}")
            return {'success': False, 'error': f'API请求失败: {e}'}

    def _extract_api_error(self, error_detail: Dict) -> str:
        """从 Google Ads API 错误响应中提取可读信息"""
        try:
            if 'error' in error_detail:
                err = error_detail['error']
                if 'details' in err:
                    for detail in err['details']:
                        if 'errors' in detail:
                            msgs = [e.get('message', '') for e in detail['errors']]
                            return '; '.join(msgs) if msgs else str(err)
                return err.get('message', str(err))
            return str(error_detail)[:500]
        except Exception:
            return str(error_detail)[:500]

    # ==================== 账号层级操作 ====================

    def list_accessible_customers(self) -> Dict[str, Any]:
        """
        列出当前 OAuth 凭据可访问的所有客户账号
        API: GET /v17/customers:listAccessibleCustomers
        """
        result = self._api_request('GET', '/customers:listAccessibleCustomers')
        if not result.get('success'):
            return result

        customers = result['data'].get('resourceNames', [])
        # resourceName 格式: customers/123-456-7890
        customer_ids = [c.split('/')[-1] for c in customers]
        return {
            'success': True,
            'customer_ids': customer_ids,
            'count': len(customer_ids),
        }

    def get_customer_info(self, customer_id: str) -> Dict[str, Any]:
        """
        获取客户账号详细信息
        API: GET /v17/customers/{customer_id}
        """
        cid = customer_id.replace('-', '')
        result = self._api_request('GET', f'/customers/{cid}')
        if not result.get('success'):
            return result

        data = result['data']
        return {
            'success': True,
            'customer': {
                'id': data.get('resourceName', '').split('/')[-1],
                'name': data.get('descriptiveName', ''),
                'currency_code': data.get('currencyCode', ''),
                'time_zone': data.get('timeZone', ''),
                'status': data.get('status', ''),
                'manager': data.get('manager', False),
                'test_account': data.get('testAccount', False),
            }
        }

    def list_sub_accounts(self, mcc_customer_id: str = None) -> Dict[str, Any]:
        """
        列出 MCC 管理账号下的所有子账号
        使用 Google Ads Query Language (GAQL)
        """
        cid = (mcc_customer_id or self.login_customer_id or '').replace('-', '')
        if not cid:
            return {'success': False, 'error': '缺少 MCC Customer ID'}

        # 使用 search 接口查询客户账号
        query = """
            SELECT
                customer_client.client_customer,
                customer_client.level,
                customer_client.status,
                customer_client.manager,
                customer_client.descriptive_name,
                customer_client.currency_code,
                customer_client.time_zone
            FROM customer_client
            WHERE customer_client.level <= 1
        """

        result = self._api_request(
            'POST',
            f'/customers/{cid}/googleAds:search',
            json_body={'query': query}
        )

        if not result.get('success'):
            return result

        sub_accounts = []
        for row in result['data'].get('results', []):
            ci = row.get('customerClient', {})
            sub_accounts.append({
                'external_id': ci.get('clientCustomer', '').split('/')[-1],
                'name': ci.get('descriptiveName', ''),
                'currency_code': ci.get('currencyCode', ''),
                'time_zone': ci.get('timeZone', ''),
                'status': ci.get('status', ''),
                'manager': ci.get('manager', False),
                'level': ci.get('level', 0),
            })

        return {
            'success': True,
            'sub_accounts': sub_accounts,
            'count': len(sub_accounts),
        }

    # ==================== 广告系列操作 ====================

    def list_campaigns(self, customer_id: str) -> Dict[str, Any]:
        """
        获取客户账号下的所有广告系列
        """
        cid = customer_id.replace('-', '')
        query = """
            SELECT
                campaign.id,
                campaign.name,
                campaign.status,
                campaign.advertising_channel_type,
                campaign.bidding_strategy_type,
                campaign_budget.amount_micros,
                campaign.start_date,
                campaign.end_date,
                metrics.cost_micros,
                metrics.impressions,
                metrics.clicks,
                metrics.conversions,
                metrics.ctr,
                metrics.average_cpc
            FROM campaign
            WHERE campaign.status != 'REMOVED'
        """

        result = self._api_request(
            'POST',
            f'/customers/{cid}/googleAds:search',
            json_body={'query': query}
        )

        if not result.get('success'):
            return result

        campaigns = []
        for row in result['data'].get('results', []):
            c = row.get('campaign', {})
            budget = row.get('campaignBudget', {})
            metrics = row.get('metrics', {})
            campaigns.append({
                'external_id': c.get('id', ''),
                'name': c.get('name', ''),
                'status': c.get('status', ''),
                'channel_type': c.get('advertisingChannelType', ''),
                'bid_strategy': c.get('biddingStrategyType', ''),
                'budget': float(budget.get('amountMicros', 0)) / 1_000_000,
                'start_date': c.get('startDate', ''),
                'end_date': c.get('endDate', ''),
                'spend': float(metrics.get('costMicros', 0)) / 1_000_000,
                'impressions': int(metrics.get('impressions', 0)),
                'clicks': int(metrics.get('clicks', 0)),
                'conversions': float(metrics.get('conversions', 0)),
                'ctr': float(metrics.get('ctr', 0)),
                'avg_cpc': float(metrics.get('averageCpc', 0)) / 1_000_000,
            })

        return {'success': True, 'campaigns': campaigns, 'count': len(campaigns)}

    def list_ad_groups(self, customer_id: str, campaign_id: str = None) -> Dict[str, Any]:
        """获取广告组列表"""
        cid = customer_id.replace('-', '')
        query = """
            SELECT
                ad_group.id,
                ad_group.name,
                ad_group.status,
                ad_group.cpc_bid_micros,
                ad_group.type,
                campaign.id,
                metrics.cost_micros,
                metrics.impressions,
                metrics.clicks,
                metrics.conversions
            FROM ad_group
            WHERE ad_group.status != 'REMOVED'
        """
        if campaign_id:
            query += f" AND ad_group.campaign = 'customers/{cid}/campaigns/{campaign_id}'"

        result = self._api_request(
            'POST',
            f'/customers/{cid}/googleAds:search',
            json_body={'query': query}
        )

        if not result.get('success'):
            return result

        ad_groups = []
        for row in result['data'].get('results', []):
            ag = row.get('adGroup', {})
            metrics = row.get('metrics', {})
            ad_groups.append({
                'external_id': ag.get('id', ''),
                'name': ag.get('name', ''),
                'status': ag.get('status', ''),
                'cpc_bid': float(ag.get('cpcBidMicros', 0)) / 1_000_000,
                'type': ag.get('type', ''),
                'campaign_external_id': row.get('campaign', {}).get('id', ''),
                'spend': float(metrics.get('costMicros', 0)) / 1_000_000,
                'impressions': int(metrics.get('impressions', 0)),
                'clicks': int(metrics.get('clicks', 0)),
                'conversions': float(metrics.get('conversions', 0)),
            })

        return {'success': True, 'ad_groups': ad_groups, 'count': len(ad_groups)}

    def list_ads(self, customer_id: str, ad_group_id: str = None) -> Dict[str, Any]:
        """获取广告列表"""
        cid = customer_id.replace('-', '')
        query = """
            SELECT
                ad_group_ad.ad.id,
                ad_group_ad.ad.responsive_search_ad.headlines,
                ad_group_ad.ad.responsive_search_ad.descriptions,
                ad_group_ad.ad.responsive_search_ad.paths,
                ad_group_ad.ad.final_urls,
                ad_group_ad.status,
                ad_group_ad.ad_approval_status,
                ad_group_ad.policy_summary,
                ad_group.id,
                campaign.id,
                metrics.cost_micros,
                metrics.impressions,
                metrics.clicks,
                metrics.conversions
            FROM ad_group_ad
            WHERE ad_group_ad.status != 'REMOVED'
        """
        if ad_group_id:
            query += f" AND ad_group_ad.ad_group = 'customers/{cid}/adGroups/{ad_group_id}'"

        result = self._api_request(
            'POST',
            f'/customers/{cid}/googleAds:search',
            json_body={'query': query}
        )

        if not result.get('success'):
            return result

        ads = []
        for row in result['data'].get('results', []):
            aga = row.get('adGroupAd', {})
            ad_data = aga.get('ad', {})
            rsa = ad_data.get('responsiveSearchAd', {})
            metrics = row.get('metrics', {})

            headlines = []
            for h in rsa.get('headlines', []):
                headlines.append({'text': h.get('text', ''), 'pinned': h.get('pinnedField', '')})

            descriptions = []
            for d in rsa.get('descriptions', []):
                descriptions.append({'text': d.get('text', ''), 'pinned': d.get('pinnedField', '')})

            paths = []
            for p in rsa.get('paths', []):
                paths.append(p.get('text', ''))

            ads.append({
                'external_id': ad_data.get('id', ''),
                'type': 'RESPONSIVE_SEARCH_AD',
                'headlines': headlines,
                'descriptions': descriptions,
                'paths': paths,
                'final_url': (ad_data.get('finalUrls', ['']) or [''])[0],
                'status': aga.get('status', ''),
                'approval_status': aga.get('adApprovalStatus', ''),
                'ad_group_external_id': row.get('adGroup', {}).get('id', ''),
                'campaign_external_id': row.get('campaign', {}).get('id', ''),
                'spend': float(metrics.get('costMicros', 0)) / 1_000_000,
                'impressions': int(metrics.get('impressions', 0)),
                'clicks': int(metrics.get('clicks', 0)),
                'conversions': float(metrics.get('conversions', 0)),
            })

        return {'success': True, 'ads': ads, 'count': len(ads)}

    def list_keywords(self, customer_id: str, ad_group_id: str = None) -> Dict[str, Any]:
        """获取关键词列表"""
        cid = customer_id.replace('-', '')
        query = """
            SELECT
                ad_group_criterion.keyword.text,
                ad_group_criterion.keyword.match_type,
                ad_group_criterion.status,
                ad_group_criterion.cpc_bid_micros,
                ad_group_criterion.quality_info.quality_score,
                ad_group.id,
                campaign.id,
                metrics.cost_micros,
                metrics.impressions,
                metrics.clicks,
                metrics.conversions
            FROM keyword_view
            WHERE ad_group_criterion.status != 'REMOVED'
              AND ad_group_criterion.type = 'KEYWORD'
        """
        if ad_group_id:
            query += f" AND ad_group_criterion.ad_group = 'customers/{cid}/adGroups/{ad_group_id}'"

        result = self._api_request(
            'POST',
            f'/customers/{cid}/googleAds:search',
            json_body={'query': query}
        )

        if not result.get('success'):
            return result

        keywords = []
        for row in result['data'].get('results', []):
            agc = row.get('adGroupCriterion', {})
            kw = agc.get('keyword', {})
            metrics = row.get('metrics', {})
            qi = agc.get('qualityInfo', {})

            keywords.append({
                'text': kw.get('text', ''),
                'match_type': kw.get('matchType', ''),
                'status': agc.get('status', ''),
                'cpc_bid': float(agc.get('cpcBidMicros', 0)) / 1_000_000,
                'quality_score': qi.get('qualityScore', None),
                'ad_group_external_id': row.get('adGroup', {}).get('id', ''),
                'campaign_external_id': row.get('campaign', {}).get('id', ''),
                'spend': float(metrics.get('costMicros', 0)) / 1_000_000,
                'impressions': int(metrics.get('impressions', 0)),
                'clicks': int(metrics.get('clicks', 0)),
                'conversions': float(metrics.get('conversions', 0)),
            })

        return {'success': True, 'keywords': keywords, 'count': len(keywords)}

    # ==================== 写操作（创建/更新/删除） ====================

    def create_campaign(self, customer_id: str, campaign_data: Dict) -> Dict[str, Any]:
        """
        创建广告系列
        API: POST /v17/customers/{cid}/campaigns:mutate
        """
        cid = customer_id.replace('-', '')

        operations = [{
            'create': {
                'name': campaign_data.get('name', ''),
                'status': campaign_data.get('status', 'PAUSED'),
                'advertisingChannelType': campaign_data.get('channel_type', 'SEARCH'),
                'biddingStrategyType': campaign_data.get('bid_strategy', 'MAXIMIZE_CLICKS'),
                'campaignBudget': campaign_data.get('budget_resource_name', ''),
                'startDate': campaign_data.get('start_date', datetime.now().strftime('%Y-%m-%d')),
                'endDate': campaign_data.get('end_date', ''),
            }
        }]

        result = self._api_request(
            'POST',
            f'/customers/{cid}/campaigns:mutate',
            json_body={'operations': operations}
        )

        if not result.get('success'):
            return result

        return {
            'success': True,
            'campaign_resource_name': result['data'].get('results', [{}])[0].get('resourceName', ''),
        }

    def create_ad_group(self, customer_id: str, campaign_resource_name: str,
                        ad_group_data: Dict) -> Dict[str, Any]:
        """创建广告组"""
        cid = customer_id.replace('-', '')

        cpc_bid_micros = int(float(ad_group_data.get('cpc_bid', 1.0)) * 1_000_000)

        operations = [{
            'create': {
                'name': ad_group_data.get('name', ''),
                'status': ad_group_data.get('status', 'PAUSED'),
                'campaign': campaign_resource_name,
                'type': 'SEARCH_STANDARD',
                'cpcBidMicros': cpc_bid_micros,
            }
        }]

        result = self._api_request(
            'POST',
            f'/customers/{cid}/adGroups:mutate',
            json_body={'operations': operations}
        )

        if not result.get('success'):
            return result

        return {
            'success': True,
            'ad_group_resource_name': result['data'].get('results', [{}])[0].get('resourceName', ''),
        }

    def create_responsive_search_ad(self, customer_id: str,
                                     ad_group_resource_name: str,
                                     ad_data: Dict) -> Dict[str, Any]:
        """
        创建响应式搜索广告 (RSA)
        """
        cid = customer_id.replace('-', '')

        headlines = []
        for h in ad_data.get('headlines', []):
            item = {'text': h.get('text', '')[:30]}  # 最多30字符
            if h.get('pinned'):
                item['pinnedField'] = h['pinned']
            headlines.append(item)

        descriptions = []
        for d in ad_data.get('descriptions', []):
            item = {'text': d.get('text', '')[:90]}  # 最多90字符
            if d.get('pinned'):
                item['pinnedField'] = d['pinned']
            descriptions.append(item)

        paths = []
        for p in ad_data.get('paths', [])[:2]:
            paths.append({'text': p[:15]})  # 最多15字符

        final_urls = [ad_data.get('final_url', '')] if ad_data.get('final_url') else []

        operations = [{
            'create': {
                'ad_group': ad_group_resource_name,
                'status': ad_data.get('status', 'PAUSED'),
                'ad': {
                    'responsiveSearchAd': {
                        'headlines': headlines,
                        'descriptions': descriptions,
                        'path1': paths[0]['text'] if len(paths) > 0 else '',
                        'path2': paths[1]['text'] if len(paths) > 1 else '',
                    },
                    'finalUrls': final_urls,
                }
            }
        }]

        result = self._api_request(
            'POST',
            f'/customers/{cid}/adGroupAds:mutate',
            json_body={'operations': operations}
        )

        if not result.get('success'):
            return result

        return {
            'success': True,
            'ad_resource_name': result['data'].get('results', [{}])[0].get('resourceName', ''),
        }

    def create_keywords(self, customer_id: str, ad_group_resource_name: str,
                        keywords: List[Dict]) -> Dict[str, Any]:
        """
        批量创建关键词
        keywords: [{text, match_type}]
        """
        cid = customer_id.replace('-', '')

        operations = []
        for kw in keywords:
            operations.append({
                'create': {
                    'ad_group': ad_group_resource_name,
                    'status': 'ENABLED',
                    'keyword': {
                        'text': kw.get('text', ''),
                        'match_type': kw.get('match_type', 'BROAD'),
                    }
                }
            })

        result = self._api_request(
            'POST',
            f'/customers/{cid}/adGroupCriteria:mutate',
            json_body={'operations': operations}
        )

        if not result.get('success'):
            return result

        return {
            'success': True,
            'count': len(result['data'].get('results', [])),
        }

    def update_campaign_status(self, customer_id: str,
                               campaign_resource_name: str,
                               status: str) -> Dict[str, Any]:
        """更新广告系列状态 (ENABLED / PAUSED / REMOVED)"""
        cid = customer_id.replace('-', '')

        operations = [{
            'update': {
                'resource_name': campaign_resource_name,
                'status': status,
            },
            'update_mask': 'status'
        }]

        result = self._api_request(
            'POST',
            f'/customers/{cid}/campaigns:mutate',
            json_body={'operations': operations}
        )

        return {'success': result.get('success', False)} if result.get('success') else result

    # ==================== 完整同步流程 ====================

    def full_sync_from_google(self, mcc_id: int) -> Dict[str, Any]:
        """
        从 Google Ads API 完整同步数据到本地数据库
        流程: MCC → 子账号 → 广告系列 → 广告组 → 广告 → 关键词
        """
        mcc = MCCAccount.query.get(mcc_id)
        if not mcc:
            return {'success': False, 'error': 'MCC账号不存在'}

        if not mcc.refresh_token:
            return {'success': False, 'error': 'MCC账号未完成OAuth授权，请先授权'}

        # 创建同步日志
        sync_log = AdsSyncLog(
            mcc_id=mcc.id,
            direction='pull',
            started_at=datetime.utcnow(),
            status='running',
            sync_method='api',
        )
        db.session.add(sync_log)
        db.session.commit()

        mcc.status = 'syncing'
        db.session.commit()

        stats = {'sub_accounts': 0, 'campaigns': 0, 'ad_groups': 0,
                 'ads': 0, 'keywords': 0, 'errors': []}
        client = GoogleAdsAPIClient(mcc)

        try:
            # Step 1: 同步子账号
            logger.info(f"[Sync] Step 1: Listing sub accounts for MCC {mcc.customer_id}")
            sub_result = client.list_sub_accounts(mcc.customer_id)
            if not sub_result.get('success'):
                raise Exception(f"子账号同步失败: {sub_result.get('error')}")

            for sub_data in sub_result.get('sub_accounts', []):
                sub = AdsSubAccount.query.filter_by(
                    mcc_id=mcc.id,
                    external_id=sub_data['external_id']
                ).first()

                if not sub:
                    sub = AdsSubAccount(
                        mcc_id=mcc.id,
                        external_id=sub_data['external_id'],
                        name=sub_data.get('name', ''),
                        currency_code=sub_data.get('currency_code', ''),
                        time_zone=sub_data.get('time_zone', ''),
                        status=sub_data.get('status', 'active').lower(),
                    )
                    db.session.add(sub)
                else:
                    sub.name = sub_data.get('name', sub.name)
                    sub.currency_code = sub_data.get('currency_code', sub.currency_code)
                    sub.time_zone = sub_data.get('time_zone', sub.time_zone)
                    sub.status = sub_data.get('status', sub.status).lower()
                    sub.last_sync = datetime.utcnow()

                db.session.flush()
                stats['sub_accounts'] += 1

                # Step 2: 同步广告系列
                cid = sub.external_id
                camp_result = client.list_campaigns(cid)
                if not camp_result.get('success'):
                    stats['errors'].append(f"子账号{cid}广告系列同步失败: {camp_result.get('error')}")
                    continue

                for camp_data in camp_result.get('campaigns', []):
                    camp = Campaign.query.filter_by(
                        sub_account_id=sub.id,
                        external_id=camp_data['external_id']
                    ).first()

                    if not camp:
                        camp = Campaign(
                            tenant_id=mcc.tenant_id,
                            sub_account_id=sub.id,
                            external_id=camp_data['external_id'],
                            name=camp_data['name'],
                        )
                        db.session.add(camp)
                    else:
                        camp.name = camp_data['name']

                    camp.status = (camp_data.get('status') or 'PAUSED').lower()
                    camp.budget = camp_data.get('budget', 0)
                    camp.spend = camp_data.get('spend', 0)
                    camp.impressions = camp_data.get('impressions', 0)
                    camp.clicks = camp_data.get('clicks', 0)
                    camp.conversions = camp_data.get('conversions', 0)
                    camp.ctr = camp_data.get('ctr', 0)
                    camp.avg_cpc = camp_data.get('avg_cpc', 0)
                    camp.advertising_channel = camp_data.get('channel_type', 'SEARCH')
                    camp.bid_strategy = camp_data.get('bid_strategy', '')
                    camp.last_sync = datetime.utcnow()
                    db.session.flush()
                    stats['campaigns'] += 1

                    # Step 3: 同步广告组
                    ag_result = client.list_ad_groups(cid, camp_data['external_id'])
                    if ag_result.get('success'):
                        for ag_data in ag_result.get('ad_groups', []):
                            ag = AdGroup.query.filter_by(
                                campaign_id=camp.id,
                                external_id=ag_data['external_id']
                            ).first()
                            if not ag:
                                ag = AdGroup(
                                    campaign_id=camp.id,
                                    external_id=ag_data['external_id'],
                                    name=ag_data['name'],
                                )
                                db.session.add(ag)
                            else:
                                ag.name = ag_data['name']

                            ag.status = (ag_data.get('status') or 'PAUSED').lower()
                            ag.cpc_bid = ag_data.get('cpc_bid', 0)
                            ag.spend = ag_data.get('spend', 0)
                            ag.impressions = ag_data.get('impressions', 0)
                            ag.clicks = ag_data.get('clicks', 0)
                            ag.conversions = ag_data.get('conversions', 0)
                            db.session.flush()
                            stats['ad_groups'] += 1

                            # Step 4: 同步广告
                            ad_result = client.list_ads(cid, ag_data['external_id'])
                            if ad_result.get('success'):
                                for ad_data in ad_result.get('ads', []):
                                    ad = Ad.query.filter_by(
                                        ad_group_id=ag.id,
                                        external_id=ad_data['external_id']
                                    ).first()
                                    if not ad:
                                        ad = Ad(
                                            ad_group_id=ag.id,
                                            external_id=ad_data['external_id'],
                                            ad_type=ad_data.get('type', 'RESPONSIVE_SEARCH_AD'),
                                        )
                                        db.session.add(ad)

                                    ad.headlines = ad_data.get('headlines', [])
                                    ad.descriptions = ad_data.get('descriptions', [])
                                    ad.paths = ad_data.get('paths', [])
                                    ad.final_url = ad_data.get('final_url', '')
                                    ad.status = (ad_data.get('status') or 'PAUSED').lower()
                                    ad.approval_status = ad_data.get('approval_status', '')
                                    ad.spend = ad_data.get('spend', 0)
                                    ad.impressions = ad_data.get('impressions', 0)
                                    ad.clicks = ad_data.get('clicks', 0)
                                    ad.conversions = ad_data.get('conversions', 0)
                                    db.session.flush()
                                    stats['ads'] += 1

                            # Step 5: 同步关键词
                            kw_result = client.list_keywords(cid, ag_data['external_id'])
                            if kw_result.get('success'):
                                for kw_data in kw_result.get('keywords', []):
                                    kw = Keyword.query.filter_by(
                                        ad_group_id=ag.id,
                                        text=kw_data['text'],
                                        match_type=kw_data['match_type']
                                    ).first()
                                    if not kw:
                                        kw = Keyword(
                                            ad_group_id=ag.id,
                                            text=kw_data['text'],
                                            match_type=kw_data['match_type'],
                                        )
                                        db.session.add(kw)

                                    kw.status = (kw_data.get('status') or 'ENABLED').lower()
                                    kw.cpc_bid = kw_data.get('cpc_bid', 0)
                                    kw.quality_score = kw_data.get('quality_score')
                                    kw.spend = kw_data.get('spend', 0)
                                    kw.impressions = kw_data.get('impressions', 0)
                                    kw.clicks = kw_data.get('clicks', 0)
                                    kw.conversions = kw_data.get('conversions', 0)
                                    stats['keywords'] += 1

            db.session.commit()

            # 更新 MCC 状态
            mcc.status = 'active'
            mcc.last_sync = datetime.utcnow()
            mcc.error_message = None
            db.session.commit()

            # 完成同步日志
            sync_log.finished_at = datetime.utcnow()
            sync_log.status = 'success'
            sync_log.records_processed = sum(stats.values()) if isinstance(stats, dict) else 0
            sync_log.records_updated = stats.get('campaigns', 0) + stats.get('ad_groups', 0)
            sync_log.records_created = stats.get('ads', 0) + stats.get('keywords', 0)
            sync_log.raw_stats = stats
            db.session.commit()

            logger.info(f"[Sync] Complete: {stats}")
            return {
                'success': True,
                'stats': stats,
                'sync_log_id': sync_log.id,
            }

        except Exception as e:
            logger.error(f"Full sync failed: {e}", exc_info=True)
            db.session.rollback()

            mcc.status = 'error'
            mcc.error_message = str(e)[:500]
            db.session.commit()

            sync_log.finished_at = datetime.utcnow()
            sync_log.status = 'failed'
            sync_log.error_message = str(e)[:2000]
            db.session.commit()

            return {'success': False, 'error': str(e), 'stats': stats}

    # ==================== 配置检查 ====================

    @staticmethod
    def check_api_config() -> Dict[str, Any]:
        """检查 Google Ads API 配置是否完整"""
        config = current_app.config
        issues = []

        developer_token = config.get('GOOGLE_ADS_DEVELOPER_TOKEN', '')
        client_id = config.get('GOOGLE_CLIENT_ID', '')
        client_secret = config.get('GOOGLE_CLIENT_SECRET', '')
        redirect_uri = config.get('GOOGLE_REDIRECT_URI', '')

        if not developer_token:
            issues.append('缺少 GOOGLE_ADS_DEVELOPER_TOKEN')
        if not client_id:
            issues.append('缺少 GOOGLE_CLIENT_ID (在 Google Cloud Console 创建 OAuth 凭据)')
        if not client_secret:
            issues.append('缺少 GOOGLE_CLIENT_SECRET')
        if not redirect_uri:
            issues.append('缺少 GOOGLE_REDIRECT_URI')

        return {
            'configured': len(issues) == 0,
            'issues': issues,
            'developer_token_set': bool(developer_token),
            'oauth_configured': bool(client_id and client_secret),
            'redirect_uri': redirect_uri,
            'api_version': config.get('GOOGLE_ADS_API_VERSION', 'v17'),
        }
