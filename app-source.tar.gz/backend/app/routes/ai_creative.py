from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_current_user
from ..extensions import db
from ..models import (
    AICreativeTask, PromptTemplate, AIConfig,
    Campaign, AdGroup, Ad, Keyword
)
from datetime import datetime

ai_bp = Blueprint('ai_creative', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


@ai_bp.route('/generate', methods=['POST'])
@jwt_required()
def generate_creative():
    user = get_current_user()
    tenant_id = user.tenant_id
    data = request.get_json() or {}

    offer_url = data.get('offer_url')
    if not offer_url:
        return fail('offer_url is required')

    target_language = data.get('target_language', 'en')
    target_country = data.get('target_country')
    niche = data.get('niche')
    ai_config_id = data.get('ai_config_id')
    prompt_template_id = data.get('prompt_template_id')

    ai_cfg = None
    if ai_config_id:
        ai_cfg = AIConfig.query.filter_by(
            id=ai_config_id, tenant_id=tenant_id, is_active=True
        ).first()
    if not ai_cfg:
        ai_cfg = AIConfig.query.filter_by(
            tenant_id=tenant_id, is_active=True
        ).order_by(AIConfig.priority.asc()).first()

    task = AICreativeTask(
        tenant_id=tenant_id,
        user_id=user.id,
        offer_url=offer_url,
        target_language=target_language,
        target_country=target_country,
        niche=niche,
        ai_provider=ai_cfg.provider if ai_cfg else current_app.config.get('DEFAULT_AI_PROVIDER'),
        ai_model=ai_cfg.model if ai_cfg else current_app.config.get('DEFAULT_AI_MODEL'),
        custom_prompt_template_id=prompt_template_id,
        status='crawling',
    )
    db.session.add(task)
    db.session.commit()

    try:
        task.status = 'generating'
        task.crawled_title = f'Sample Title for {offer_url}'
        task.crawled_description = 'Sample description from crawled landing page'
        task.crawled_features = ['Feature 1', 'Feature 2', 'Feature 3']
        task.crawled_reviews = [
            {'author': 'User1', 'rating': 5, 'content': 'Great product!'},
            {'author': 'User2', 'rating': 4, 'content': 'Works well.'}
        ]
        task.generated_creatives = [
            {
                'headlines': [
                    {'text': 'Premium Quality Guaranteed'},
                    {'text': 'Free Shipping Worldwide'},
                    {'text': '30-Day Money Back'},
                    {'text': 'Best Seller in Category'},
                    {'text': 'Limited Time Offer'}
                ],
                'descriptions': [
                    {'text': 'Experience the difference with our premium product today.'},
                    {'text': 'Join thousands of satisfied customers worldwide.'},
                    {'text': 'Shop now and enjoy exclusive discounts.'},
                    {'text': 'Fast delivery and 24/7 customer support.'}
                ],
                'paths': ['Shop', 'Premium'],
                'keywords': [
                    {'text': 'buy premium product', 'match_type': 'EXACT'},
                    {'text': 'best product online', 'match_type': 'PHRASE'},
                    {'text': 'quality product', 'match_type': 'BROAD'},
                    {'text': 'product for sale', 'match_type': 'PHRASE'},
                    {'text': 'affordable product', 'match_type': 'BROAD'}
                ]
            }
        ] * 3
        task.status = 'reviewed'
    except Exception as e:
        task.status = 'failed'
        task.error_message = str(e)
    db.session.commit()

    return success({'task_id': task.id, 'status': task.status})


@ai_bp.route('/tasks', methods=['GET'])
@jwt_required()
def list_tasks():
    user = get_current_user()
    tenant_id = user.tenant_id
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 20), type=int)
    status = request.args.get('status')

    q = AICreativeTask.query.filter_by(tenant_id=tenant_id)
    if status:
        q = q.filter_by(status=status)
    pagination = q.order_by(AICreativeTask.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    data = {
        'items': [{
            'id': t.id,
            'offer_url': t.offer_url,
            'niche': t.niche,
            'target_country': t.target_country,
            'target_language': t.target_language,
            'status': t.status,
            'ai_provider': t.ai_provider,
            'ai_model': t.ai_model,
            'submitted_campaign_id': t.submitted_campaign_id,
            'created_at': t.created_at.isoformat() if t.created_at else None,
        } for t in pagination.items],
        'total': pagination.total,
        'page': page,
        'per_page': per_page,
    }
    return success(data)


@ai_bp.route('/tasks/<int:task_id>', methods=['GET'])
@jwt_required()
def get_task(task_id):
    user = get_current_user()
    t = AICreativeTask.query.filter_by(id=task_id, tenant_id=user.tenant_id).first()
    if not t:
        return fail('task not found', code=404)
    data = {
        'id': t.id,
        'offer_url': t.offer_url,
        'niche': t.niche,
        'target_country': t.target_country,
        'target_language': t.target_language,
        'ai_provider': t.ai_provider,
        'ai_model': t.ai_model,
        'custom_prompt_template_id': t.custom_prompt_template_id,
        'crawled_title': t.crawled_title,
        'crawled_description': t.crawled_description,
        'crawled_reviews': t.crawled_reviews,
        'crawled_features': t.crawled_features,
        'generated_creatives': t.generated_creatives,
        'status': t.status,
        'error_message': t.error_message,
        'submitted_campaign_id': t.submitted_campaign_id,
        'cost_tokens': t.cost_tokens,
        'cost_usd': float(t.cost_usd) if t.cost_usd else 0,
        'created_at': t.created_at.isoformat() if t.created_at else None,
        'updated_at': t.updated_at.isoformat() if t.updated_at else None,
    }
    return success(data)


@ai_bp.route('/tasks/<int:task_id>/review', methods=['POST'])
@jwt_required()
def review_task(task_id):
    user = get_current_user()
    t = AICreativeTask.query.filter_by(id=task_id, tenant_id=user.tenant_id).first()
    if not t:
        return fail('task not found', code=404)
    data = request.get_json() or {}
    action = data.get('action')  # approve / reject
    creative_index = data.get('creative_index')
    edited_creative = data.get('creative')

    if action not in ('approve', 'reject'):
        return fail('action must be approve or reject')

    if action == 'approve':
        if edited_creative is not None and creative_index is not None:
            creatives = t.generated_creatives or []
            if 0 <= creative_index < len(creatives):
                creatives[creative_index] = edited_creative
                t.generated_creatives = creatives
        t.status = 'reviewed'
    else:
        t.status = 'failed'
        t.error_message = data.get('reason', 'rejected by user')
    db.session.commit()
    return success({'status': t.status})


@ai_bp.route('/tasks/<int:task_id>/submit', methods=['POST'])
@jwt_required()
def submit_to_ads(task_id):
    user = get_current_user()
    tenant_id = user.tenant_id
    t = AICreativeTask.query.filter_by(id=task_id, tenant_id=tenant_id).first()
    if not t:
        return fail('task not found', code=404)
    if t.status not in ('reviewed',):
        return fail('task must be reviewed before submitting')
    if not t.generated_creatives:
        return fail('no generated creatives')

    data = request.get_json() or {}
    campaign_id = data.get('campaign_id')
    creative_index = data.get('creative_index', 0)

    campaign = None
    if campaign_id:
        campaign = Campaign.query.filter_by(id=campaign_id, tenant_id=tenant_id).first()
    if not campaign:
        campaign = Campaign(
            tenant_id=tenant_id,
            name=f'AI Campaign - {t.offer_url[:40]}',
            status='paused',
            budget=0,
        )
        db.session.add(campaign)
        db.session.flush()

    creatives = t.generated_creatives or []
    if creative_index >= len(creatives):
        return fail('creative_index out of range')
    creative = creatives[creative_index]

    ag = AdGroup(campaign_id=campaign.id, name=f'AG-AI-{task_id}-{creative_index}', status='enabled')
    db.session.add(ag)
    db.session.flush()

    ad = Ad(
        ad_group_id=ag.id,
        ad_type='RESPONSIVE_SEARCH_AD',
        headlines=creative.get('headlines', []),
        descriptions=creative.get('descriptions', []),
        paths=creative.get('paths', []),
        final_url=t.offer_url,
        status='paused',
        ai_generated=True,
    )
    db.session.add(ad)

    for kw in creative.get('keywords', []):
        keyword = Keyword(
            ad_group_id=ag.id,
            text=kw.get('text'),
            match_type=kw.get('match_type', 'BROAD'),
            status='enabled',
            ai_generated=True,
        )
        db.session.add(keyword)

    t.submitted_campaign_id = campaign.id
    t.status = 'submitted'
    db.session.commit()

    return success({'campaign_id': campaign.id, 'ad_group_id': ag.id})


@ai_bp.route('/prompt-templates', methods=['GET'])
@jwt_required()
def list_prompts():
    user = get_current_user()
    category = request.args.get('category')
    language = request.args.get('language')
    q = PromptTemplate.query.filter(
        (PromptTemplate.tenant_id == user.tenant_id) | (PromptTemplate.is_system == True)
    )
    if category:
        q = q.filter_by(category=category)
    if language:
        q = q.filter_by(language=language)
    items = [{
        'id': p.id,
        'name': p.name,
        'category': p.category,
        'language': p.language,
        'variables': p.variables,
        'is_system': p.is_system,
        'is_active': p.is_active,
        'usage_count': p.usage_count,
        'template': p.template,
        'created_at': p.created_at.isoformat() if p.created_at else None,
    } for p in q.order_by(PromptTemplate.is_system.desc(), PromptTemplate.created_at.desc()).all()]
    return success(items)


@ai_bp.route('/prompt-templates', methods=['POST'])
@jwt_required()
def create_prompt():
    user = get_current_user()
    data = request.get_json() or {}
    p = PromptTemplate(
        tenant_id=user.tenant_id,
        name=data.get('name', 'Untitled'),
        category=data.get('category', 'creative'),
        language=data.get('language', 'en'),
        template=data.get('template', ''),
        variables=data.get('variables', []),
        is_system=False,
        is_active=data.get('is_active', True),
    )
    db.session.add(p)
    db.session.commit()
    return success({'id': p.id})


@ai_bp.route('/prompt-templates/<int:pid>', methods=['PUT'])
@jwt_required()
def update_prompt(pid):
    user = get_current_user()
    p = PromptTemplate.query.filter_by(id=pid).first()
    if not p:
        return fail('not found', code=404)
    if p.is_system:
        return fail('system template cannot be modified')
    if p.tenant_id != user.tenant_id:
        return fail('forbidden', code=403)
    data = request.get_json() or {}
    for k in ('name', 'category', 'language', 'template', 'variables', 'is_active'):
        if k in data:
            setattr(p, k, data[k])
    db.session.commit()
    return success({'id': p.id})


@ai_bp.route('/prompt-templates/<int:pid>', methods=['DELETE'])
@jwt_required()
def delete_prompt(pid):
    user = get_current_user()
    p = PromptTemplate.query.filter_by(id=pid).first()
    if not p:
        return fail('not found', code=404)
    if p.is_system:
        return fail('system template cannot be deleted')
    if p.tenant_id != user.tenant_id:
        return fail('forbidden', code=403)
    db.session.delete(p)
    db.session.commit()
    return success()


@ai_bp.route('/models', methods=['GET'])
@jwt_required()
def list_models():
    providers = current_app.config.get('AI_PROVIDERS', {})
    result = []
    for key, p in providers.items():
        result.append({
            'provider': key,
            'name': p.get('name'),
            'base_url': p.get('base_url'),
            'models': p.get('models', []),
        })
    return success(result)
