from flask import Blueprint, request, jsonify, current_app, redirect, url_for, session
from flask_jwt_extended import jwt_required, get_current_user
from ..extensions import db
from ..models import MCCAccount, AdsSubAccount, Campaign, AdGroup, Ad, Keyword
from ..services.google_ads_api import GoogleAdsAPIClient
from datetime import datetime
import hashlib
import secrets

accounts_bp = Blueprint('accounts', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


# ==================== Google Ads API 配置检查 ====================

@accounts_bp.route('/api-config-check', methods=['GET'])
@jwt_required()
def check_api_config():
    """检查 Google Ads API 配置是否完整"""
    result = GoogleAdsAPIClient.check_api_config()
    return success(result)


# ==================== OAuth 2.0 授权流程 ====================

# 临时存储 OAuth state → MCC ID 的映射（生产环境应使用 Redis）
_oauth_states = {}


@accounts_bp.route('/oauth/authorize', methods=['POST'])
@jwt_required()
def oauth_authorize():
    """
    发起 Google OAuth 2.0 授权流程
    前端调用此接口获取授权URL，用户在浏览器中打开URL进行授权
    """
    user = get_current_user()
    data = request.get_json() or {}
    mcc_id = data.get('mcc_id')

    # 如果有 mcc_id，表示为已有MCC账号授权
    if mcc_id:
        mcc = MCCAccount.query.filter_by(id=mcc_id, tenant_id=user.tenant_id).first()
        if not mcc:
            return fail('MCC账号不存在', code=404)

    # 生成安全的 state 参数（防CSRF）
    state_raw = f"{user.id}:{mcc_id or 0}:{secrets.token_hex(16)}"
    state = hashlib.sha256(state_raw.encode()).hexdigest()
    _oauth_states[state] = {
        'user_id': user.id,
        'tenant_id': user.tenant_id,
        'mcc_id': mcc_id,
        'created_at': datetime.utcnow().isoformat(),
    }

    client = GoogleAdsAPIClient(mcc_account=MCCAccount.query.get(mcc_id) if mcc_id else None)
    auth_url = client.get_authorization_url(state=state)

    return success({
        'auth_url': auth_url,
        'state': state,
        'instructions': '请在浏览器中打开此URL完成Google授权，授权后系统将自动获取refresh_token',
    })


@accounts_bp.route('/oauth/callback', methods=['GET'])
def oauth_callback():
    """
    Google OAuth 2.0 回调
    Google 在用户授权后重定向到此地址，携带 code 参数
    """
    code = request.args.get('code')
    state = request.args.get('state')
    error = request.args.get('error')

    if error:
        return _oauth_result_page(False, f'授权被拒绝: {error}')

    if not code or not state:
        return _oauth_result_page(False, '缺少 code 或 state 参数')

    state_data = _oauth_states.pop(state, None)
    if not state_data:
        return _oauth_result_page(False, '无效或过期的 state 参数，请重新发起授权')

    mcc_id = state_data.get('mcc_id')
    mcc = None
    if mcc_id:
        mcc = MCCAccount.query.get(mcc_id)

    client = GoogleAdsAPIClient(mcc_account=mcc)
    token_result = client.exchange_code_for_tokens(code)

    if not token_result.get('success'):
        return _oauth_result_page(False, f'获取Token失败: {token_result.get("error")}')

    refresh_token = token_result.get('refresh_token')
    user_info = token_result.get('user_info', {})

    if not refresh_token:
        return _oauth_result_page(False, '未获取到 refresh_token，请重新授权（确保使用 prompt=consent）')

    # 保存 refresh_token
    if mcc:
        # 更新已有 MCC
        mcc.refresh_token = refresh_token
        mcc.status = 'active'
        mcc.error_message = None
        db.session.commit()
    else:
        # 新授权，创建或更新一个待配置的 MCC 记录
        existing = MCCAccount.query.filter_by(
            tenant_id=state_data['tenant_id'],
            customer_id=user_info.get('id', ''),
        ).first()

        if existing:
            existing.refresh_token = refresh_token
            existing.status = 'active'
        else:
            mcc = MCCAccount(
                tenant_id=state_data['tenant_id'],
                name=f"Google Account ({user_info.get('email', 'Unknown')})",
                customer_id='',
                refresh_token=refresh_token,
                developer_token=client.developer_token,
                client_id=client.client_id,
                client_secret=client.client_secret,
                status='active',
                settings={'oauth_user_info': user_info},
            )
            mcc.generate_fingerprint()
            db.session.add(mcc)
        db.session.commit()
        mcc_id = mcc.id if mcc else existing.id

    return _oauth_result_page(True, '授权成功！refresh_token 已保存，现在可以同步账号数据了。',
                              mcc_id=mcc_id)


def _oauth_result_page(success_flag, message, mcc_id=None):
    """返回一个简单的HTML页面给用户（OAuth回调后展示）"""
    status_color = '#10B981' if success_flag else '#EF4444'
    status_text = '✅ 授权成功' if success_flag else '❌ 授权失败'
    redirect_js = ''
    if success_flag:
        redirect_js = f'''
        <script>
            setTimeout(function() {{
                window.location.href = '/dashboard/accounts?oauth=success&mcc_id={mcc_id or ""}';
            }}, 3000);
        </script>
        '''

    html = f'''<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Google Ads OAuth 授权结果</title>
<style>
    body {{ font-family: -apple-system, sans-serif; display: flex; justify-content: center;
           align-items: center; min-height: 100vh; margin: 0; background: #f8fafc; }}
    .card {{ background: white; border-radius: 16px; padding: 40px; max-width: 500px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08); text-align: center; }}
    .icon {{ font-size: 48px; margin-bottom: 16px; }}
    h1 {{ color: {status_color}; margin: 0 0 12px; font-size: 24px; }}
    p {{ color: #64748b; line-height: 1.6; }}
    .hint {{ margin-top: 20px; padding: 12px; background: #f1f5f9; border-radius: 8px;
             font-size: 14px; color: #64748b; }}
</style></head>
<body><div class="card">
    <div class="icon">{status_text}</div>
    <p>{message}</p>
    <div class="hint">3秒后自动返回管理后台...</div>
</div>
{redirect_js}
</body></html>'''
    from flask import Response
    return Response(html, mimetype='text/html')


@accounts_bp.route('/mcc', methods=['GET'])
@jwt_required()
def list_mcc():
    user = get_current_user()
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 20), type=int)
    status = request.args.get('status')
    q = MCCAccount.query.filter_by(tenant_id=user.tenant_id)
    if status:
        q = q.filter_by(status=status)
    pagination = q.order_by(MCCAccount.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    items = []
    for m in pagination.items:
        items.append({
            'id': m.id,
            'name': m.name,
            'customer_id': m.customer_id,
            'manager_customer_id': m.manager_customer_id,
            'login_customer_id': m.login_customer_id,
            'worker_domain': m.worker_domain,
            'isolation_group': m.isolation_group,
            'status': m.status,
            'last_sync': m.last_sync.isoformat() if m.last_sync else None,
            'sync_interval': m.sync_interval,
            'error_message': m.error_message,
            'sub_accounts_count': len(m.sub_accounts),
            'created_at': m.created_at.isoformat() if m.created_at else None,
        })
    return success({'items': items, 'total': pagination.total, 'page': page, 'per_page': per_page})


@accounts_bp.route('/mcc', methods=['POST'])
@jwt_required()
def create_mcc():
    user = get_current_user()
    data = request.get_json() or {}
    m = MCCAccount(
        tenant_id=user.tenant_id,
        name=data.get('name', 'New MCC'),
        customer_id=data.get('customer_id', ''),
        manager_customer_id=data.get('manager_customer_id'),
        refresh_token=data.get('refresh_token'),
        developer_token=data.get('developer_token'),
        client_id=data.get('client_id'),
        client_secret=data.get('client_secret'),
        login_customer_id=data.get('login_customer_id'),
        worker_domain=data.get('worker_domain'),
        isolation_group=data.get('isolation_group', 'default'),
        status=data.get('status', 'active'),
        sync_interval=data.get('sync_interval', 15),
        settings=data.get('settings', {}),
    )
    m.generate_fingerprint()
    db.session.add(m)
    db.session.commit()
    return success({'id': m.id})


@accounts_bp.route('/mcc/<int:mid>', methods=['GET'])
@jwt_required()
def get_mcc(mid):
    user = get_current_user()
    m = MCCAccount.query.filter_by(id=mid, tenant_id=user.tenant_id).first()
    if not m:
        return fail('not found', code=404)
    subs = [{
        'id': s.id,
        'external_id': s.external_id,
        'name': s.name,
        'currency_code': s.currency_code,
        'time_zone': s.time_zone,
        'spend': float(s.spend or 0),
        'impressions': int(s.impressions or 0),
        'clicks': int(s.clicks or 0),
        'conversions': float(s.conversions or 0),
        'status': s.status,
    } for s in m.sub_accounts]
    return success({
        'id': m.id,
        'name': m.name,
        'customer_id': m.customer_id,
        'manager_customer_id': m.manager_customer_id,
        'login_customer_id': m.login_customer_id,
        'script_fingerprint': m.script_fingerprint,
        'worker_domain': m.worker_domain,
        'isolation_group': m.isolation_group,
        'status': m.status,
        'last_sync': m.last_sync.isoformat() if m.last_sync else None,
        'sync_interval': m.sync_interval,
        'error_message': m.error_message,
        'settings': m.settings,
        'sub_accounts': subs,
        'created_at': m.created_at.isoformat() if m.created_at else None,
    })


@accounts_bp.route('/mcc/<int:mid>', methods=['PUT'])
@jwt_required()
def update_mcc(mid):
    user = get_current_user()
    m = MCCAccount.query.filter_by(id=mid, tenant_id=user.tenant_id).first()
    if not m:
        return fail('not found', code=404)
    data = request.get_json() or {}
    fields = ('name', 'customer_id', 'manager_customer_id', 'refresh_token',
              'developer_token', 'client_id', 'client_secret', 'login_customer_id',
              'worker_domain', 'isolation_group', 'status', 'sync_interval', 'settings')
    for k in fields:
        if k in data:
            setattr(m, k, data[k])
    db.session.commit()
    return success({'id': m.id})


@accounts_bp.route('/mcc/<int:mid>', methods=['DELETE'])
@jwt_required()
def delete_mcc(mid):
    user = get_current_user()
    m = MCCAccount.query.filter_by(id=mid, tenant_id=user.tenant_id).first()
    if not m:
        return fail('not found', code=404)
    db.session.delete(m)
    db.session.commit()
    return success()


@accounts_bp.route('/mcc/<int:mid>/sync', methods=['POST'])
@jwt_required()
def sync_mcc(mid):
    """
    触发 MCC 账号同步
    优先使用 Google Ads API 真实同步（需要OAuth授权），降级到Script模式
    """
    user = get_current_user()
    m = MCCAccount.query.filter_by(id=mid, tenant_id=user.tenant_id).first()
    if not m:
        return fail('MCC账号不存在', code=404)

    if not m.refresh_token:
        return fail('该MCC账号尚未完成OAuth授权，请先点击"Google授权"获取refresh_token', code=400)

    # 更新状态为同步中
    m.status = 'syncing'
    m.last_sync = datetime.utcnow()
    db.session.commit()

    # 调用 Google Ads API 执行真实同步
    try:
        client = GoogleAdsAPIClient(mcc_account=m)
        result = client.full_sync_from_google(m.id)

        if result.get('success'):
            return success({
                'status': 'active',
                'last_sync': m.last_sync.isoformat() if m.last_sync else None,
                'stats': result.get('stats', {}),
                'sync_log_id': result.get('sync_log_id'),
            }, msg='同步完成')
        else:
            return fail(
                f'同步失败: {result.get("error", "未知错误")}',
                data={'stats': result.get('stats', {})}
            )
    except Exception as e:
        m.status = 'error'
        m.error_message = str(e)[:500]
        db.session.commit()
        return fail(f'同步异常: {e}')


@accounts_bp.route('/sub-accounts', methods=['GET'])
@jwt_required()
def list_sub_accounts():
    user = get_current_user()
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 20), type=int)
    mcc_id = request.args.get('mcc_id', type=int)
    mcc_ids = [m.id for m in MCCAccount.query.filter_by(tenant_id=user.tenant_id).all()]
    q = AdsSubAccount.query.filter(AdsSubAccount.mcc_id.in_(mcc_ids))
    if mcc_id:
        q = q.filter_by(mcc_id=mcc_id)
    pagination = q.order_by(AdsSubAccount.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    mcc_map = {m.id: m.name for m in MCCAccount.query.filter_by(tenant_id=user.tenant_id).all()}
    items = [{
        'id': s.id,
        'mcc_id': s.mcc_id,
        'mcc_name': mcc_map.get(s.mcc_id),
        'external_id': s.external_id,
        'name': s.name,
        'currency_code': s.currency_code,
        'time_zone': s.time_zone,
        'spend': float(s.spend or 0),
        'impressions': int(s.impressions or 0),
        'clicks': int(s.clicks or 0),
        'conversions': float(s.conversions or 0),
        'status': s.status,
        'last_sync': s.last_sync.isoformat() if s.last_sync else None,
    } for s in pagination.items]
    return success({'items': items, 'total': pagination.total, 'page': page, 'per_page': per_page})


# ==================== Google Ads API 辅助接口 ====================

@accounts_bp.route('/google/accessible-customers', methods=['GET'])
@jwt_required()
def google_accessible_customers():
    """
    列出当前OAuth凭据可访问的所有Google Ads客户账号
    用于授权后让用户选择哪个MCC账号导入
    """
    user = get_current_user()
    mcc_id = request.args.get('mcc_id', type=int)

    mcc = None
    if mcc_id:
        mcc = MCCAccount.query.filter_by(id=mcc_id, tenant_id=user.tenant_id).first()
        if not mcc:
            return fail('MCC账号不存在', code=404)
    else:
        # 使用第一个有 refresh_token 的 MCC
        mcc = MCCAccount.query.filter(
            MCCAccount.tenant_id == user.tenant_id,
            MCCAccount.refresh_token.isnot(None)
        ).first()

    if not mcc or not mcc.refresh_token:
        return fail('没有已授权的MCC账号，请先完成OAuth授权', code=400)

    client = GoogleAdsAPIClient(mcc_account=mcc)
    result = client.list_accessible_customers()

    if result.get('success'):
        return success({
            'customer_ids': result.get('customer_ids', []),
            'count': result.get('count', 0),
        })
    else:
        return fail(result.get('error', '获取可访问客户列表失败'))


@accounts_bp.route('/google/sub-accounts/<int:mid>', methods=['GET'])
@jwt_required()
def google_list_sub_accounts(mid):
    """
    通过 Google Ads API 实时获取 MCC 下的子账号列表
    （不写库，仅实时查询展示）
    """
    user = get_current_user()
    m = MCCAccount.query.filter_by(id=mid, tenant_id=user.tenant_id).first()
    if not m:
        return fail('MCC账号不存在', code=404)

    if not m.refresh_token:
        return fail('该MCC尚未完成OAuth授权', code=400)

    if not m.customer_id:
        return fail('请先在MCC编辑中填入Customer ID（MCC管理账号ID，格式: 123-456-7890）', code=400)

    client = GoogleAdsAPIClient(mcc_account=m)
    result = client.list_sub_accounts(m.customer_id)

    if result.get('success'):
        return success({
            'sub_accounts': result.get('sub_accounts', []),
            'count': result.get('count', 0),
        })
    else:
        return fail(result.get('error', '获取子账号列表失败'))
