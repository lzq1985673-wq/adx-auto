from flask import Blueprint, jsonify

marketing_bp = Blueprint('marketing', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


@marketing_bp.route('/api/marketing/site-info', methods=['GET'])
@marketing_bp.route('/site-info', methods=['GET'])
def site_info():
    data = {
        'site': {
            'name': 'ADX-Auto',
            'title': 'ADX-Auto - Google Ads 全自动运营平台',
            'subtitle': 'AI驱动的Google Ads自动化解决方案 · 7合1智能投放矩阵',
            'description': 'ADX-Auto 是一站式 Google Ads 自动化运营平台，集成 MCC 批量管理、AI创意生成、防关联补点击、智能换链、定时任务、代理池、数据看板7大核心模块，帮助独立站卖家、DTC品牌、营销代理商实现广告全流程自动化运营。',
            'keywords': [
                'Google Ads 自动化', 'MCC批量管理', 'AI广告创意生成',
                '广告防关联', '补点击脚本', 'Google Ads换链',
                'Ads自动化运营', '独立站投放', 'DTC品牌广告',
            ],
            'domain': 'adx-auto.com',
            'logo_url': '/logo.svg',
            'og_image': '/og-image.png',
            'favicon': '/favicon.ico',
            'contact_email': 'hello@adx-auto.com',
            'support_email': 'support@adx-auto.com',
            'sales_email': 'sales@adx-auto.com',
            'phone': '+86 400-888-8888',
            'social': {
                'twitter': 'https://twitter.com/adxauto',
                'telegram': 'https://t.me/adxauto',
                'github': 'https://github.com/adx-auto',
                'youtube': 'https://youtube.com/@adxauto',
                'linkedin': 'https://linkedin.com/company/adxauto',
            }
        },
        'features': [
            {
                'key': 'mcc',
                'name': 'MCC批量管理',
                'icon': 'accounts',
                'tagline': '一人管理100+账号',
                'description': '支持批量导入MCC账号，多账号隔离防关联，Cloudflare Worker分布式脚本，统一视图管理所有子账户、广告系列、广告组、关键词。',
                'highlights': [
                    'MCC无限层级账号嵌套',
                    'Script/API双模式数据同步',
                    '账号级独立脚本指纹',
                    '异常账号自动告警',
                ]
            },
            {
                'key': 'ai_creative',
                'name': 'AI创意工厂',
                'icon': 'auto-awesome',
                'tagline': '一条Offer生成3组合规创意',
                'description': '自动爬虫采集Offer落地页，结合7大AI模型（GPT-4/Claude/Gemini/GLM-4/Kimi/DeepSeek/通义千问），一键生成Responsive Search Ads标题、描述、关键词、落地页路径。',
                'highlights': [
                    '爬虫自动采集标题/卖点/评价',
                    '7家AI Provider自由切换',
                    '3组创意一次性产出',
                    '内置优质提示词模板库',
                    '人工审核 + 一键提交到Ads',
                ]
            },
            {
                'key': 'click_bot',
                'name': '智能补点击',
                'icon': 'ads-click',
                'tagline': '50项指标完全匹配真实用户',
                'description': '基于5家代理池（Oxylabs/BrightData/IPIDEA/SmartProxy/GeoSurf），8时间段+10个头部媒体Referer+随机Fingerprint，精准补齐CTR/CVR，提升广告权重。',
                'highlights': [
                    '5家顶级住宅代理池对接',
                    '国家/城市/运营商级定向',
                    '50项指标匹配真实流量',
                    'UA/分辨率/时区/语言完全仿真',
                    '停留时长/翻页/点击深度随机',
                ]
            },
            {
                'key': 'link_swap',
                'name': '智能换链接',
                'icon': 'swap-horiz',
                'tagline': '1分钟完成追踪链接轮换',
                'description': '追踪链接批量替换不触发审核，反向采集落地页验证跳转，与补点击同源执行，自定义间隔轮换，保护主链接安全。',
                'highlights': [
                    'Tracking URL无痕替换',
                    '反向采集+跳转校验',
                    '与补点击同源IP执行',
                    '指纹轮换防关联',
                    '定时/手动双模式',
                ]
            },
            {
                'key': 'scheduler',
                'name': '定时任务引擎',
                'icon': 'schedule',
                'tagline': 'Cron级精确调度',
                'description': '支持Cron表达式/间隔双模式调度，涵盖数据同步、补点击、换链、AI生成、预算调整、报告生成等任务，历史可追溯，失败自动告警。',
                'highlights': [
                    'Cron表达式+间隔分钟双模式',
                    '8种任务类型全支持',
                    '执行历史+日志全链路',
                    '立即触发+启停开关',
                    '失败自动重试+邮件告警',
                ]
            },
            {
                'key': 'proxy',
                'name': '代理池管理',
                'icon': 'vpn-lock',
                'tagline': '5大厂+自定义代理一体化',
                'description': '内置Oxylabs/BrightData/IPIDEA/SmartProxy/GeoSurf五家对接，支持自定义HTTP/SOCKS5，一键连通性测试，国家/池类型/会话规则精细化配置。',
                'highlights': [
                    '5家预置对接快速接入',
                    'HTTP/SOCKS5自定义支持',
                    '住宅/数据中心/移动/ISP池',
                    '连通性+匿名度测试',
                    '多配置优先级调度',
                ]
            },
            {
                'key': 'analytics',
                'name': '数据看板',
                'icon': 'monitoring',
                'tagline': '多租户ROI全景视图',
                'description': '账号/广告系列/广告组三级维度总览，按天花费/展示/点击/转化/CTR/CPC/CPA/ROI趋势，Top广告系列排行，任务状态实时监控。',
                'highlights': [
                    '花费/展示/点击/转化/ROI全览',
                    '按天/周/月趋势对比',
                    'Top Campaign多维度排行',
                    '账号/广告状态分布',
                    '定时任务状态实时监控',
                ]
            },
        ],
        'pricing': [
            {
                'plan': 'free',
                'name': '免费版',
                'monthly_price': 0,
                'yearly_price': 0,
                'price_note': '永久免费',
                'tagline': '适合个人体验',
                'highlighted': False,
                'features': {
                    'mcc_accounts': 1,
                    'campaigns': 3,
                    'ai_credits_monthly': 5,
                    'click_bot_monthly': 100,
                    'link_swap_monthly': 50,
                    'proxy_support': False,
                    'scheduled_tasks': 5,
                    'team_members': 1,
                    'api_access': False,
                    'priority_support': False,
                },
                'button_text': '立即开始',
                'button_action': 'register_free',
            },
            {
                'plan': 'pro',
                'name': 'Pro专业版',
                'monthly_price': 499,
                'yearly_price': 4990,
                'save_note': '年付省2个月',
                'tagline': '适合小型团队/独立站卖家',
                'highlighted': True,
                'features': {
                    'mcc_accounts': 5,
                    'campaigns': 100,
                    'ai_credits_monthly': 200,
                    'click_bot_monthly': 5000,
                    'link_swap_monthly': 2000,
                    'proxy_support': True,
                    'scheduled_tasks': 50,
                    'team_members': 5,
                    'api_access': True,
                    'priority_support': False,
                },
                'button_text': '升级Pro',
                'button_action': 'subscribe_pro',
            },
            {
                'plan': 'enterprise',
                'name': '企业版',
                'monthly_price': 2999,
                'yearly_price': 29990,
                'save_note': '年付送定制部署',
                'tagline': '适合代理商/品牌方',
                'highlighted': False,
                'features': {
                    'mcc_accounts': '无限',
                    'campaigns': '无限',
                    'ai_credits_monthly': '无限',
                    'click_bot_monthly': '无限',
                    'link_swap_monthly': '无限',
                    'proxy_support': True,
                    'scheduled_tasks': '无限',
                    'team_members': '无限',
                    'api_access': True,
                    'priority_support': True,
                    'custom_branding': True,
                    'dedicated_csm': True,
                    'on_premise_deploy': True,
                    'sla_99_9': True,
                },
                'button_text': '联系销售',
                'button_action': 'contact_sales',
            },
        ],
        'case_studies': [
            {
                'id': 1,
                'industry': 'DTC家居品牌',
                'company': '某家居独立站',
                'title': '3个月ROAS提升3.2倍',
                'metric': {
                    'before': {'roas': 1.2, 'cpa': 45, 'monthly_spend': 18000},
                    'after': {'roas': 3.84, 'cpa': 18, 'monthly_spend': 72000},
                },
                'tags': ['AI创意', '补点击', 'MCC批量'],
                'story': '客户拥有3个MCC账号15个子账户，之前人工维护创意CTR持续低于2%。接入ADX-Auto后，使用AI创意工厂每周产出20+合规创意，智能补点击维持CTR在4.5%左右，3个月月度花费提升4倍同时CPA下降60%。'
            },
            {
                'id': 2,
                'industry': '营销代理公司',
                'company': '某深圳营销代理商',
                'title': '人效提升8倍，客户续约率95%',
                'metric': {
                    'before': {'accounts_per_op': 12, 'report_hours': 16, 'churn_rate': 0.25},
                    'after': {'accounts_per_op': 96, 'report_hours': 2, 'churn_rate': 0.05},
                },
                'tags': ['MCC批量', '定时任务', '数据看板'],
                'story': '代理商管理200+广告客户账户，8人优化团队疲于奔命。部署ADX-Auto企业版后，所有客户账号统一接入，数据15分钟自动同步，报告自动生成，优化师人均管理账户数从12提升到96。'
            },
            {
                'id': 3,
                'industry': '健康保健',
                'company': '某保健品DTC品牌',
                'title': '换链+补点击规避审核通过率98%',
                'metric': {
                    'before': {'approval_rate': 0.62, 'suspensions_monthly': 5, 'avg_link_life': 9},
                    'after': {'approval_rate': 0.98, 'suspensions_monthly': 0, 'avg_link_life': 45},
                },
                'tags': ['智能换链', '代理池', '防关联'],
                'story': '客户保健品Offer容易触发Google审核，之前平均9天换一次追踪链接。使用ADX-Auto智能换链+同源补点击+5大代理池轮换后，追踪链接平均寿命提升至45天，审核通过率从62%提升到98%。'
            },
            {
                'id': 4,
                'industry': '服装时尚',
                'company': '某女装独立站',
                'title': 'AI产出爆款创意速度提升10倍',
                'metric': {
                    'before': {'creatives_weekly': 3, 'winning_rate': 0.12, 'time_per_creative_h': 4},
                    'after': {'creatives_weekly': 30, 'winning_rate': 0.28, 'time_per_creative_h': 0.2},
                },
                'tags': ['AI创意', '多模型切换'],
                'story': '女装季节性强、产品迭代快，之前文案团队每周最多产出3组创意。使用ADX-Auto接入GPT-4 + Claude双模型，一键爬取落地页、自动生成3组合规创意，人工直接审核即可，创意产出速度提升10倍，跑赢率也从12%提升到28%。'
            },
        ],
        'faq': [
            {'q': 'ADX-Auto和Google Ads Editor有什么区别？',
             'a': 'Google Ads Editor是客户端批量编辑工具，ADX-Auto是服务器端自动化运营平台，除了批量编辑还包含AI创意生成、智能补点击、智能换链、代理池管理、定时任务、数据看板等完整自动化闭环。'},
            {'q': '补点击会不会触发Google异常流量检测？',
             'a': 'ADX-Auto采用5大顶级住宅代理池（非数据中心IP）、8时间段均匀分布、10个自然Referer、50项真实用户指标（UA/分辨率/语言/时区/滚动深度/停留时长/翻页数）完全匹配真实访客，配合CTR不超过行业均值1.5倍的安全阈值，不会触发异常流量检测。'},
            {'q': 'AI生成的创意能直接通过Google审核吗？',
             'a': '系统内置Google Ads最新政策合规提示词模板，生成的标题（<30字符）、描述（<90字符）、路径（<15字符）均严格符合Google字符限制，默认不含违规词。创意生成后仍需要人工审核环节确认后再提交，实际审核通过率可达95%以上。'},
            {'q': '支持独立部署（私有化）吗？',
             'a': '企业版支持私有化部署（On-Premise），可部署在客户自己的AWS/GCP/Azure/阿里云等基础设施或本地服务器，数据不出域，支持定制化功能开发、专属CSM、SLA 99.9%等服务。'},
            {'q': '是否支持国内/海外银行付款？',
             'a': '专业版及以上支持支付宝、微信支付、国内对公转账、VISA/MasterCard信用卡、Stripe、USDT等多种付款方式，可按需开具增值税专用发票或海外Invoice。'},
            {'q': '我的MCC账号有风险吗，会不会关联？',
             'a': 'ADX-Auto默认通过Google Ads API + 分布式Cloudflare Worker脚本两种方式同步数据，每个MCC账号分配独立的脚本指纹、独立的Worker域名、独立的IP段隔离，严格遵循一账号一指纹的防关联策略，不会造成账号关联风险。'},
        ],
        'stats': {
            'total_users': 8500,
            'total_mcc_accounts': 22000,
            'total_monthly_spend_managed_usd': 128000000,
            'total_ai_creatives_generated': 5200000,
            'avg_roas_improvement_pct': 180,
            'avg_cpa_reduction_pct': 55,
            'countries': 48,
            'team_size': 35,
        },
        'compare': {
            'vs_manual': '8倍运营效率提升',
            'vs_competitor_1': 'AI模型覆盖多2倍',
            'vs_competitor_2': '代理池内置对接多3家',
        },
        'roadmap': [
            {'quarter': '2024 Q4', 'items': ['Meta Ads 支持', 'TikTok Ads 支持', 'AI自动否定关键词']},
            {'quarter': '2025 Q1', 'items': ['GA4数据打通', '智能出价策略优化', '多语言站点一键投放']},
            {'quarter': '2025 Q2', 'items': ['Shopify/Magento插件', '竞品广告监控', 'LTV预测模型']},
        ],
    }
    return success(data)
