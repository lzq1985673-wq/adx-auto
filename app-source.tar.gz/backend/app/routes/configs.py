from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_current_user
from ..extensions import db
from ..models import ProxyConfig, AIConfig, Tenant
from datetime import datetime
import os

configs_bp = Blueprint('configs', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


PROXY_PROVIDERS_PRESET = ['oxylabs', 'brightdata', 'ipidea', 'smartproxy', 'geosurf', 'custom']
AI_PROVIDERS_PRESET = ['openai', 'anthropic', 'google', 'deepseek', 'zhipu', 'moonshot', 'qwen']


@configs_bp.route('/proxy', methods=['GET'])
@jwt_required()
def list_proxy():
    user = get_current_user()
    tenant_id = user.tenant_id
    provider = request.args.get('provider')
    is_active = request.args.get('is_active')

    q = ProxyConfig.query.filter_by(tenant_id=tenant_id)
    if provider:
        q = q.filter_by(provider=provider)
    if is_active is not None and is_active != '':
        q = q.filter_by(is_active=(is_active.lower() in ('1', 'true', 'yes')))

    items = []
    preset = current_app.config.get('PROXY_PROVIDERS', {})
    for p in q.order_by(ProxyConfig.priority.asc(), ProxyConfig.created_at.desc()).all():
        items.append({
            'id': p.id,
            'provider': p.provider,
            'provider_name': preset.get(p.provider, {}).get('name', p.provider),
            'name': p.name,
            'username': p.username,
            'endpoint': p.endpoint,
            'port': p.port,
            'protocol': p.protocol,
            'country_rules': p.country_rules,
            'session_type': p.session_type,
            'rotation_interval': p.rotation_interval,
            'is_active': p.is_active,
            'priority': p.priority,
            'last_test': p.last_test.isoformat() if p.last_test else None,
            'test_result': p.test_result,
            'created_at': p.created_at.isoformat() if p.created_at else None,
        })
    return success(items)


@configs_bp.route('/proxy', methods=['POST'])
@jwt_required()
def create_proxy():
    user = get_current_user()
    tenant_id = user.tenant_id
    data = request.get_json() or {}
    provider = data.get('provider', 'custom')

    if provider not in PROXY_PROVIDERS_PRESET:
        return fail(f'provider must be one of {PROXY_PROVIDERS_PRESET}')

    preset = current_app.config.get('PROXY_PROVIDERS', {}).get(provider, {})

    p = ProxyConfig(
        tenant_id=tenant_id,
        provider=provider,
        name=data.get('name') or preset.get('name') or f'{provider}-config',
        username=data.get('username') or os.environ.get(preset.get('user_env', ''), ''),
        password=data.get('password') or os.environ.get(preset.get('pass_env', ''), ''),
        endpoint=data.get('endpoint') or preset.get('endpoint', '').split(':')[0] if preset.get('endpoint') else None,
        port=data.get('port') or int(preset.get('endpoint', '0:0').rsplit(':')[-1]) if preset.get('endpoint') else None,
        protocol=data.get('protocol', 'http'),
        country_rules=data.get('country_rules', []),
        session_type=data.get('session_type', 'residential'),
        rotation_interval=data.get('rotation_interval', 300),
        is_active=data.get('is_active', True),
        priority=data.get('priority', 0),
    )
    db.session.add(p)
    db.session.commit()
    return success({'id': p.id})


@configs_bp.route('/proxy/<int:pid>', methods=['PUT'])
@jwt_required()
def update_proxy(pid):
    user = get_current_user()
    p = ProxyConfig.query.filter_by(id=pid, tenant_id=user.tenant_id).first()
    if not p:
        return fail('not found', code=404)
    data = request.get_json() or {}
    fields = ('name', 'username', 'password', 'endpoint', 'port', 'protocol',
              'country_rules', 'session_type', 'rotation_interval', 'is_active', 'priority')
    for k in fields:
        if k in data:
            setattr(p, k, data[k])
    db.session.commit()
    return success({'id': p.id})


@configs_bp.route('/proxy/<int:pid>', methods=['DELETE'])
@jwt_required()
def delete_proxy(pid):
    user = get_current_user()
    p = ProxyConfig.query.filter_by(id=pid, tenant_id=user.tenant_id).first()
    if not p:
        return fail('not found', code=404)
    db.session.delete(p)
    db.session.commit()
    return success()


@configs_bp.route('/proxy/<int:pid>/test', methods=['POST'])
@jwt_required()
def test_proxy(pid):
    user = get_current_user()
    p = ProxyConfig.query.filter_by(id=pid, tenant_id=user.tenant_id).first()
    if not p:
        return fail('not found', code=404)

    import random
    success_rate = random.uniform(0.6, 1.0)
    latency_ms = random.randint(50, 800)
    test_ok = success_rate > 0.7

    result = {
        'tested_at': datetime.utcnow().isoformat(),
        'success': test_ok,
        'success_rate': round(success_rate, 4),
        'latency_ms': latency_ms,
        'anonymous': random.choice([True, True, True, False]),
        'ip_country': random.choice(['US', 'DE', 'NL', 'SG']),
        'ip_asn': f'AS{random.randint(1000, 99999)}',
        'provider_detected': p.provider,
    }
    p.test_result = result
    p.last_test = datetime.utcnow()
    db.session.commit()
    return success(result)


@configs_bp.route('/ai', methods=['GET'])
@jwt_required()
def list_ai():
    user = get_current_user()
    tenant_id = user.tenant_id
    provider = request.args.get('provider')
    is_active = request.args.get('is_active')

    q = AIConfig.query.filter_by(tenant_id=tenant_id)
    if provider:
        q = q.filter_by(provider=provider)
    if is_active is not None and is_active != '':
        q = q.filter_by(is_active=(is_active.lower() in ('1', 'true', 'yes')))

    items = []
    preset = current_app.config.get('AI_PROVIDERS', {})
    for c in q.order_by(AIConfig.priority.asc(), AIConfig.created_at.desc()).all():
        items.append({
            'id': c.id,
            'provider': c.provider,
            'provider_name': preset.get(c.provider, {}).get('name', c.provider),
            'name': c.name,
            'model': c.model,
            'base_url': c.base_url,
            'api_version': c.api_version,
            'max_tokens': c.max_tokens,
            'temperature': float(c.temperature) if c.temperature is not None else None,
            'is_free_tier': c.is_free_tier,
            'cost_per_1k_input': float(c.cost_per_1k_input) if c.cost_per_1k_input else 0,
            'cost_per_1k_output': float(c.cost_per_1k_output) if c.cost_per_1k_output else 0,
            'rate_limit_rpm': c.rate_limit_rpm,
            'is_active': c.is_active,
            'priority': c.priority,
            'total_tokens_used': c.total_tokens_used,
            'total_cost_usd': float(c.total_cost_usd) if c.total_cost_usd else 0,
            'last_used': c.last_used.isoformat() if c.last_used else None,
            'created_at': c.created_at.isoformat() if c.created_at else None,
        })
    return success(items)


@configs_bp.route('/ai', methods=['POST'])
@jwt_required()
def create_ai():
    user = get_current_user()
    tenant_id = user.tenant_id
    data = request.get_json() or {}
    provider = data.get('provider')
    if provider not in AI_PROVIDERS_PRESET:
        return fail(f'provider must be one of {AI_PROVIDERS_PRESET}')

    preset = current_app.config.get('AI_PROVIDERS', {}).get(provider, {})
    default_model = preset.get('models', [None])[0]

    env_var = preset.get('api_key_env', '')
    api_key_from_env = os.environ.get(env_var, '') if env_var else ''

    c = AIConfig(
        tenant_id=tenant_id,
        name=data.get('name') or preset.get('name', provider),
        provider=provider,
        model=data.get('model') or default_model,
        api_key=data.get('api_key') or api_key_from_env,
        base_url=data.get('base_url') or preset.get('base_url'),
        api_version=data.get('api_version'),
        max_tokens=data.get('max_tokens', 2000),
        temperature=data.get('temperature', 0.7),
        is_free_tier=data.get('is_free_tier', False),
        cost_per_1k_input=data.get('cost_per_1k_input', 0),
        cost_per_1k_output=data.get('cost_per_1k_output', 0),
        rate_limit_rpm=data.get('rate_limit_rpm', 60),
        is_active=data.get('is_active', True),
        priority=data.get('priority', 0),
    )
    db.session.add(c)
    db.session.commit()
    return success({'id': c.id})


@configs_bp.route('/ai/<int:cid>', methods=['PUT'])
@jwt_required()
def update_ai(cid):
    user = get_current_user()
    c = AIConfig.query.filter_by(id=cid, tenant_id=user.tenant_id).first()
    if not c:
        return fail('not found', code=404)
    data = request.get_json() or {}
    fields = ('name', 'provider', 'model', 'api_key', 'base_url', 'api_version',
              'max_tokens', 'temperature', 'is_free_tier', 'cost_per_1k_input',
              'cost_per_1k_output', 'rate_limit_rpm', 'is_active', 'priority')
    for k in fields:
        if k in data:
            setattr(c, k, data[k])
    db.session.commit()
    return success({'id': c.id})


@configs_bp.route('/ai/<int:cid>', methods=['DELETE'])
@jwt_required()
def delete_ai(cid):
    user = get_current_user()
    c = AIConfig.query.filter_by(id=cid, tenant_id=user.tenant_id).first()
    if not c:
        return fail('not found', code=404)
    db.session.delete(c)
    db.session.commit()
    return success()


@configs_bp.route('/ai/models', methods=['GET'])
@jwt_required()
def list_ai_models():
    providers = current_app.config.get('AI_PROVIDERS', {})
    user = get_current_user()
    active_providers = {
        c.provider: {
            'id': c.id,
            'is_active': c.is_active,
            'has_key': bool(c.api_key),
            'selected_model': c.model,
        }
        for c in AIConfig.query.filter_by(tenant_id=user.tenant_id).all()
    }

    result = []
    for key, p in providers.items():
        cfg = active_providers.get(key, {})
        models_info = []
        for m in p.get('models', []):
            models_info.append({
                'model': m,
                'is_selected': cfg.get('selected_model') == m,
                'supports_vision': any(x in m.lower() for x in ['vision', 'v', 'gemini-pro-vision']),
                'context_window': guess_context(m),
            })
        result.append({
            'provider': key,
            'name': p.get('name'),
            'base_url': p.get('base_url'),
            'api_key_env': p.get('api_key_env'),
            'config_id': cfg.get('id'),
            'configured': cfg.get('is_active', False),
            'has_api_key': cfg.get('has_key', False),
            'models': models_info,
        })
    return success(result)


def guess_context(model_name):
    m = (model_name or '').lower()
    if '128k' in m or 'longcontext' in m:
        return 128000
    if '32k' in m:
        return 32000
    if '16k' in m:
        return 16000
    if '4' in m or 'opus' in m or 'max' in m or 'ultra' in m:
        return 8000
    return 4000


@configs_bp.route('/system', methods=['GET'])
@jwt_required()
def get_system_config():
    user = get_current_user()
    t = Tenant.query.get(user.tenant_id)
    if not t:
        return fail('tenant not found', code=404)
    s = t.settings or {}
    data = {
        'tenant_id': t.id,
        'tenant_name': t.name,
        'tenant_slug': t.slug,
        'plan': t.plan,
        'status': t.status,
        'subscription_end': t.subscription_end.isoformat() if t.subscription_end else None,
        'timezone': s.get('timezone', 'Asia/Shanghai'),
        'currency': s.get('currency', 'USD'),
        'language': s.get('language', 'zh-CN'),
        'date_format': s.get('date_format', 'YYYY-MM-DD'),
        'items_per_page': s.get('items_per_page', current_app.config.get('ITEMS_PER_PAGE', 20)),
        'click_bot_defaults': s.get('click_bot_defaults', current_app.config.get('CLICK_BOT_DEFAULTS', {})),
        'ads_sync_interval_minutes': s.get('ads_sync_interval_minutes', current_app.config.get('ADS_SYNC_INTERVAL_MINUTES', 15)),
        'notifications': s.get('notifications', {
            'email_on_task_failure': True,
            'email_on_low_budget': True,
            'push_on_ai_ready': True,
        }),
        'security': s.get('security', {
            'two_factor_required': False,
            'session_timeout_minutes': 480,
            'allowed_ips': [],
        }),
    }
    return success(data)


@configs_bp.route('/system', methods=['POST'])
@jwt_required()
def update_system_config():
    user = get_current_user()
    if user.role not in ('owner', 'admin'):
        return fail('permission denied', code=403)
    t = Tenant.query.get(user.tenant_id)
    if not t:
        return fail('tenant not found', code=404)
    data = request.get_json() or {}
    s = t.settings or {}

    for k in ('timezone', 'currency', 'language', 'date_format', 'items_per_page',
              'click_bot_defaults', 'ads_sync_interval_minutes',
              'notifications', 'security'):
        if k in data:
            s[k] = data[k]

    if 'name' in data:
        t.name = data['name']
    t.settings = s
    db.session.commit()
    return success({'tenant_id': t.id})
