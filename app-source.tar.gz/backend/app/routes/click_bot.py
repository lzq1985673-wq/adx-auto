from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_current_user
from ..extensions import db
from ..models import Campaign, ClickTask, TaskExecution
from datetime import datetime, timedelta
import random
import uuid

click_bp = Blueprint('click_bot', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


@click_bp.route('/campaigns/<int:campaign_id>/config', methods=['GET'])
@jwt_required()
def get_click_config(campaign_id):
    user = get_current_user()
    c = Campaign.query.filter_by(id=campaign_id, tenant_id=user.tenant_id).first()
    if not c:
        return fail('campaign not found', code=404)
    data = {
        'campaign_id': c.id,
        'campaign_name': c.name,
        'click_bot_enabled': c.click_bot_enabled,
        'click_daily_target': c.click_daily_target,
        'click_countries': c.click_countries,
        'click_time_slots': c.click_time_slots,
        'click_referers': c.click_referers,
        'settings': c.settings.get('click_bot', {}),
    }
    return success(data)


@click_bp.route('/campaigns/<int:campaign_id>/config', methods=['POST'])
@jwt_required()
def set_click_config(campaign_id):
    user = get_current_user()
    c = Campaign.query.filter_by(id=campaign_id, tenant_id=user.tenant_id).first()
    if not c:
        return fail('campaign not found', code=404)
    data = request.get_json() or {}
    if 'click_bot_enabled' in data:
        c.click_bot_enabled = bool(data['click_bot_enabled'])
    if 'click_daily_target' in data:
        c.click_daily_target = int(data['click_daily_target'])
    if 'click_countries' in data:
        c.click_countries = data['click_countries'] or []
    if 'click_time_slots' in data:
        c.click_time_slots = data['click_time_slots'] or []
    if 'click_referers' in data:
        c.click_referers = data['click_referers'] or []
    if 'settings' in data:
        s = c.settings or {}
        s['click_bot'] = data['settings']
        c.settings = s
    db.session.commit()
    return success({'campaign_id': c.id})


@click_bp.route('/campaigns/<int:campaign_id>/run-once', methods=['POST'])
@jwt_required()
def run_once(campaign_id):
    user = get_current_user()
    tenant_id = user.tenant_id
    c = Campaign.query.filter_by(id=campaign_id, tenant_id=tenant_id).first()
    if not c:
        return fail('campaign not found', code=404)

    data = request.get_json() or {}
    country = data.get('country') or (c.click_countries[0] if c.click_countries else 'US')
    referer = data.get('referer') or (c.click_referers[0] if c.click_referers else 'https://www.google.com')

    countries = c.click_countries or ['US', 'UK', 'CA', 'DE', 'FR']
    devices = ['desktop', 'mobile', 'tablet']
    browsers = ['Chrome', 'Firefox', 'Safari', 'Edge']
    os_list = ['Windows 10', 'Windows 11', 'macOS 14', 'iOS 17', 'Android 14']
    resolutions = ['1920x1080', '1366x768', '2560x1440', '375x812', '414x896']
    referers = c.click_referers or [
        'https://www.google.com', 'https://www.bing.com', 'https://duckduckgo.com',
        'https://www.facebook.com', 'https://www.youtube.com'
    ]
    ua_list = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1',
    ]

    ad = None
    for ag in c.ad_groups:
        for a in ag.ads:
            if a.status == 'enabled':
                ad = a
                break
        if ad:
            break

    ct = ClickTask(
        campaign_id=c.id,
        ad_id=ad.id if ad else None,
        target_url=ad.final_url if ad else None,
        country=random.choice(countries),
        ip_address=f'{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}',
        ip_provider='custom',
        user_agent=random.choice(ua_list),
        fingerprint=uuid.uuid4().hex[:32],
        referer=random.choice(referers),
        device_type=random.choice(devices),
        browser=random.choice(browsers),
        os=random.choice(os_list),
        resolution=random.choice(resolutions),
        language='en-US',
        executed_at=datetime.utcnow(),
        duration_seconds=random.randint(30, 240),
        pages_viewed=random.randint(1, 6),
        status='success',
        metrics_data={
            'time_on_page': random.randint(20, 180),
            'bounce_rate': round(random.uniform(0.1, 0.6), 2),
            'scroll_depth': random.randint(40, 95),
            'interactions': random.randint(1, 10),
        },
    )
    db.session.add(ct)

    c.clicks = (c.clicks or 0) + 1
    db.session.commit()

    return success({
        'click_task_id': ct.id,
        'country': ct.country,
        'ip_address': ct.ip_address,
        'fingerprint': ct.fingerprint,
        'duration_seconds': ct.duration_seconds,
    })


@click_bp.route('/logs', methods=['GET'])
@jwt_required()
def list_logs():
    user = get_current_user()
    tenant_id = user.tenant_id
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 20), type=int)
    campaign_id = request.args.get('campaign_id', type=int)
    status = request.args.get('status')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    campaign_ids = [c.id for c in Campaign.query.filter_by(tenant_id=tenant_id).all()]
    q = ClickTask.query.filter(ClickTask.campaign_id.in_(campaign_ids))
    if campaign_id:
        q = q.filter_by(campaign_id=campaign_id)
    if status:
        q = q.filter_by(status=status)
    if start_date:
        try:
            q = q.filter(ClickTask.created_at >= datetime.fromisoformat(start_date))
        except ValueError:
            pass
    if end_date:
        try:
            q = q.filter(ClickTask.created_at <= datetime.fromisoformat(end_date) + timedelta(days=1))
        except ValueError:
            pass

    pagination = q.order_by(ClickTask.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    cmap = {c.id: c.name for c in Campaign.query.filter_by(tenant_id=tenant_id).all()}
    data = {
        'items': [{
            'id': t.id,
            'campaign_id': t.campaign_id,
            'campaign_name': cmap.get(t.campaign_id),
            'ad_id': t.ad_id,
            'target_url': t.target_url,
            'country': t.country,
            'city': t.city,
            'ip_address': t.ip_address,
            'device_type': t.device_type,
            'browser': t.browser,
            'os': t.os,
            'resolution': t.resolution,
            'referer': t.referer,
            'fingerprint': t.fingerprint,
            'duration_seconds': t.duration_seconds,
            'pages_viewed': t.pages_viewed,
            'status': t.status,
            'error_message': t.error_message,
            'executed_at': t.executed_at.isoformat() if t.executed_at else None,
            'created_at': t.created_at.isoformat() if t.created_at else None,
        } for t in pagination.items],
        'total': pagination.total,
        'page': page,
        'per_page': per_page,
    }
    return success(data)


@click_bp.route('/analytics', methods=['GET'])
@jwt_required()
def analytics():
    user = get_current_user()
    tenant_id = user.tenant_id
    days = request.args.get('days', 7, type=int)
    campaign_id = request.args.get('campaign_id', type=int)

    campaign_ids = [c.id for c in Campaign.query.filter_by(tenant_id=tenant_id).all()]
    if campaign_id and campaign_id in campaign_ids:
        campaign_ids = [campaign_id]

    end = datetime.utcnow()
    start = end - timedelta(days=days)

    q = ClickTask.query.filter(
        ClickTask.campaign_id.in_(campaign_ids),
        ClickTask.created_at >= start,
    )

    all_tasks = q.all()
    total_clicks = len(all_tasks)
    success_clicks = len([t for t in all_tasks if t.status == 'success'])
    success_rate = round(success_clicks / total_clicks, 4) if total_clicks > 0 else 0
    avg_duration = round(sum(t.duration_seconds or 0 for t in all_tasks) / total_clicks, 2) if total_clicks else 0

    by_country = {}
    by_device = {}
    by_referer = {}
    by_day = {}
    for t in all_tasks:
        by_country[t.country] = by_country.get(t.country, 0) + 1
        by_device[t.device_type] = by_device.get(t.device_type, 0) + 1
        if t.referer:
            short_r = t.referer.split('://', 1)[-1].split('/')[0] if '://' in t.referer else t.referer
            by_referer[short_r] = by_referer.get(short_r, 0) + 1
        if t.created_at:
            day = t.created_at.strftime('%Y-%m-%d')
            by_day[day] = by_day.get(day, 0) + 1

    return success({
        'period_days': days,
        'summary': {
            'total_clicks': total_clicks,
            'success_clicks': success_clicks,
            'success_rate': success_rate,
            'avg_duration_seconds': avg_duration,
            'avg_pages_viewed': round(sum(t.pages_viewed or 0 for t in all_tasks) / total_clicks, 2) if total_clicks else 0,
        },
        'by_country': [{'country': k, 'count': v} for k, v in sorted(by_country.items(), key=lambda x: -x[1])],
        'by_device': [{'device': k, 'count': v} for k, v in sorted(by_device.items(), key=lambda x: -x[1])],
        'by_referer': [{'referer': k, 'count': v} for k, v in sorted(by_referer.items(), key=lambda x: -x[1])[:10]],
        'by_day': [{'date': k, 'clicks': v} for k, v in sorted(by_day.items())],
    })
