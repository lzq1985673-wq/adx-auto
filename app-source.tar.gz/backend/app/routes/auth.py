from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import (
    create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_current_user
)
from ..extensions import db, bcrypt
from ..models import User, Tenant
from datetime import datetime

auth_bp = Blueprint('auth', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return fail('username and password are required')
    user = User.query.filter_by(username=username).first()
    if not user or not user.check_password(password):
        return fail('invalid credentials', code=401)
    if user.status != 'active':
        return fail('user is disabled', code=403)
    user.last_login = datetime.utcnow()
    user.last_ip = request.remote_addr
    db.session.commit()

    access_token = create_access_token(identity=user)
    refresh_token = create_refresh_token(identity=user)
    user_info = {
        'id': user.id,
        'tenant_id': user.tenant_id,
        'username': user.username,
        'email': user.email,
        'role': user.role,
        'avatar': user.avatar,
    }
    return success({
        'access_token': access_token,
        'refresh_token': refresh_token,
        'token': access_token,
        'user': user_info,
        'userInfo': user_info,
        'permissions': [],
        'tenantInfo': user.tenant_id and {
            'id': user.tenant_id,
            'name': user.tenant.name if hasattr(user, 'tenant') else 'Default Tenant',
            'plan': user.tenant.plan if hasattr(user, 'tenant') else 'pro',
        } or None,
    })


@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')
    tenant_name = data.get('tenant_name', username)
    if not username or not password:
        return fail('username and password are required')
    if User.query.filter_by(username=username).first():
        return fail('username already exists')
    if email and User.query.filter_by(email=email).first():
        return fail('email already exists')

    tenant = Tenant(name=tenant_name, slug=username.lower(), plan='free')
    db.session.add(tenant)
    db.session.flush()

    user = User(tenant_id=tenant.id, username=username, email=email, role='owner')
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    access_token = create_access_token(identity=user)
    refresh_token = create_refresh_token(identity=user)
    user_info = {'id': user.id, 'tenant_id': user.tenant_id, 'username': user.username, 'email': user.email, 'role': user.role, 'avatar': user.avatar}
    return success({
        'access_token': access_token,
        'refresh_token': refresh_token,
        'token': access_token,
        'user': user_info,
        'userInfo': user_info,
        'permissions': [],
        'tenantInfo': {
            'id': tenant.id,
            'name': tenant.name,
            'plan': tenant.plan,
        },
    })


@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    from ..models import User
    user = User.query.get(int(identity))
    if not user:
        return fail('user not found', code=404)
    access_token = create_access_token(identity=user)
    return success({
        'access_token': access_token,
        'token': access_token,
    })


@auth_bp.route('/refresh-token', methods=['POST'])
@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh_token():
    identity = get_jwt_identity()
    from ..models import User
    user = User.query.get(int(identity))
    if not user:
        return fail('user not found', code=404)
    access_token = create_access_token(identity=user)
    return success({
        'access_token': access_token,
        'token': access_token,
    })


def _build_user_info_response(user):
    """统一的用户信息返回结构，兼容前端多种取值方式"""
    t = Tenant.query.get(user.tenant_id)
    user_info = {
        'id': user.id,
        'tenant_id': user.tenant_id,
        'username': user.username,
        'email': user.email,
        'role': user.role,
        'avatar': user.avatar,
        'status': user.status,
        'last_login': user.last_login.isoformat() if user.last_login else None,
    }
    tenant_info = {
        'id': t.id,
        'name': t.name,
        'slug': t.slug,
        'plan': t.plan,
        'status': t.status,
        'subscription_end': t.subscription_end.isoformat() if t.subscription_end else None,
    } if t else None
    return success({
        # 原始结构
        **user_info,
        'tenant': tenant_info,
        # 前端期望结构
        'userInfo': user_info,
        'permissions': [],
        'tenantInfo': tenant_info,
    })


@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def me():
    user = get_current_user()
    return _build_user_info_response(user)


@auth_bp.route('/user-info', methods=['GET'])
@jwt_required()
def user_info():
    user = get_current_user()
    return _build_user_info_response(user)


@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    return success()
