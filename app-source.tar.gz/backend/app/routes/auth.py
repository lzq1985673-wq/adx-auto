from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import (
    create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_current_user
)
from ..extensions import db, bcrypt
from ..models import User, Tenant
from datetime import datetime

auth_bp = Blueprint('auth', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return fail('username and password are required')
    user = User.query.filter_by(username=username).first()
    if not user or not user.check_password(password):
        return fail('invalid credentials', code=401)
    if user.status != 'active':
        return fail('user is disabled', code=403)
    user.last_login = datetime.utcnow()
    user.last_ip = request.remote_addr
    db.session.commit()

    access_token = create_access_token(identity=user)
    refresh_token = create_refresh_token(identity=user)
    return success({
        'access_token': access_token,
        'refresh_token': refresh_token,
        'user': {
            'id': user.id,
            'tenant_id': user.tenant_id,
            'username': user.username,
            'email': user.email,
            'role': user.role,
            'avatar': user.avatar,
        }
    })


@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')
    tenant_name = data.get('tenant_name', username)
    if not username or not password:
        return fail('username and password are required')
    if User.query.filter_by(username=username).first():
        return fail('username already exists')
    if email and User.query.filter_by(email=email).first():
        return fail('email already exists')

    tenant = Tenant(name=tenant_name, slug=username.lower(), plan='free')
    db.session.add(tenant)
    db.session.flush()

    user = User(tenant_id=tenant.id, username=username, email=email, role='owner')
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    access_token = create_access_token(identity=user)
    refresh_token = create_refresh_token(identity=user)
    return success({
        'access_token': access_token,
        'refresh_token': refresh_token,
        'user': {'id': user.id, 'tenant_id': user.tenant_id, 'username': user.username, 'email': user.email, 'role': user.role},
    })


@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    from ..models import User
    user = User.query.get(int(identity))
    if not user:
        return fail('user not found', code=404)
    access_token = create_access_token(identity=user)
    return success({'access_token': access_token})


@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def me():
    user = get_current_user()
    t = Tenant.query.get(user.tenant_id)
    return success({
        'id': user.id,
        'tenant_id': user.tenant_id,
        'username': user.username,
        'email': user.email,
        'role': user.role,
        'avatar': user.avatar,
        'status': user.status,
        'last_login': user.last_login.isoformat() if user.last_login else None,
        'tenant': {
            'id': t.id,
            'name': t.name,
            'slug': t.slug,
            'plan': t.plan,
            'status': t.status,
            'subscription_end': t.subscription_end.isoformat() if t.subscription_end else None,
        } if t else None,
    })


@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    return success()
