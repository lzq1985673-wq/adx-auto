from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_current_user
from ..extensions import db
from ..models import Campaign, LinkSwapTask, Ad
from datetime import datetime, timedelta
import uuid
import random

link_swap_bp = Blueprint('link_swap', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


@link_swap_bp.route('/campaigns/<int:campaign_id>/config', methods=['GET'])
@jwt_required()
def get_config(campaign_id):
    user = get_current_user()
    c = Campaign.query.filter_by(id=campaign_id, tenant_id=user.tenant_id).first()
    if not c:
        return fail('campaign not found', code=404)
    return success({
        'campaign_id': c.id,
        'campaign_name': c.name,
        'link_swap_enabled': c.link_swap_enabled,
        'link_swap_interval': c.link_swap_interval,
        'link_templates': c.link_templates,
        'settings': (c.settings or {}).get('link_swap', {}),
    })


@link_swap_bp.route('/campaigns/<int:campaign_id>/config', methods=['POST'])
@jwt_required()
def set_config(campaign_id):
    user = get_current_user()
    c = Campaign.query.filter_by(id=campaign_id, tenant_id=user.tenant_id).first()
    if not c:
        return fail('campaign not found', code=404)
    data = request.get_json() or {}
    if 'link_swap_enabled' in data:
        c.link_swap_enabled = bool(data['link_swap_enabled'])
    if 'link_swap_interval' in data:
        c.link_swap_interval = int(data['link_swap_interval'])
    if 'link_templates' in data:
        c.link_templates = data['link_templates'] or []
    if 'settings' in data:
        s = c.settings or {}
        s['link_swap'] = data['settings']
        c.settings = s
    db.session.commit()
    return success({'campaign_id': c.id})


@link_swap_bp.route('/campaigns/<int:campaign_id>/swap', methods=['POST'])
@jwt_required()
def execute_swap(campaign_id):
    user = get_current_user()
    tenant_id = user.tenant_id
    c = Campaign.query.filter_by(id=campaign_id, tenant_id=tenant_id).first()
    if not c:
        return fail('campaign not found', code=404)

    data = request.get_json() or {}
    ad_id = data.get('ad_id')
    new_tracking_url = data.get('new_tracking_url')
    new_final_url = data.get('new_final_url')

    target_ad = None
    if ad_id:
        for ag in c.ad_groups:
            for a in ag.ads:
                if a.id == ad_id:
                    target_ad = a
                    break
            if target_ad:
                break
    else:
        for ag in c.ad_groups:
            for a in ag.ads:
                if a.status != 'removed':
                    target_ad = a
                    break
            if target_ad:
                break

    if not target_ad:
        return fail('no active ads found in campaign')

    old_tracking = target_ad.tracking_url_template
    old_final = target_ad.final_url

    templates = c.link_templates or []
    if not new_tracking_url and templates:
        tpl = random.choice(templates)
        new_tracking_url = tpl.get('tracking_url')
        new_final_url = new_final_url or tpl.get('final_url')
    if not new_final_url:
        new_final_url = old_final

    target_ad.tracking_url_template = new_tracking_url
    target_ad.final_url = new_final_url

    fingerprint = uuid.uuid4().hex[:32]

    task = LinkSwapTask(
        campaign_id=c.id,
        ad_id=target_ad.id,
        old_tracking_url=old_tracking,
        old_final_url=old_final,
        new_tracking_url=new_tracking_url,
        new_final_url=new_final_url,
        link_fingerprint=fingerprint,
        crawled_destination=new_final_url,
        tracking_params_updated={
            'fp': fingerprint,
            'ts': datetime.utcnow().timestamp(),
        },
        executed_at=datetime.utcnow(),
        status='success',
        same_origin_click=bool(data.get('same_origin_click', True)),
    )
    db.session.add(task)
    db.session.commit()

    return success({
        'swap_task_id': task.id,
        'ad_id': target_ad.id,
        'old_final_url': old_final,
        'new_final_url': new_final_url,
        'old_tracking_url': old_tracking,
        'new_tracking_url': new_tracking_url,
        'fingerprint': fingerprint,
    })


@link_swap_bp.route('/logs', methods=['GET'])
@jwt_required()
def list_logs():
    user = get_current_user()
    tenant_id = user.tenant_id
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 20), type=int)
    campaign_id = request.args.get('campaign_id', type=int)
    status = request.args.get('status')

    campaign_ids = [c.id for c in Campaign.query.filter_by(tenant_id=tenant_id).all()]
    q = LinkSwapTask.query.filter(LinkSwapTask.campaign_id.in_(campaign_ids))
    if campaign_id:
        q = q.filter_by(campaign_id=campaign_id)
    if status:
        q = q.filter_by(status=status)

    pagination = q.order_by(LinkSwapTask.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    cmap = {c.id: c.name for c in Campaign.query.filter_by(tenant_id=tenant_id).all()}
    data = {
        'items': [{
            'id': t.id,
            'campaign_id': t.campaign_id,
            'campaign_name': cmap.get(t.campaign_id),
            'ad_id': t.ad_id,
            'old_tracking_url': t.old_tracking_url,
            'old_final_url': t.old_final_url,
            'new_tracking_url': t.new_tracking_url,
            'new_final_url': t.new_final_url,
            'link_fingerprint': t.link_fingerprint,
            'crawled_destination': t.crawled_destination,
            'same_origin_click': t.same_origin_click,
            'status': t.status,
            'error_message': t.error_message,
            'executed_at': t.executed_at.isoformat() if t.executed_at else None,
            'created_at': t.created_at.isoformat() if t.created_at else None,
        } for t in pagination.items],
        'total': pagination.total,
        'page': page,
        'per_page': per_page,
    }
    return success(data)
