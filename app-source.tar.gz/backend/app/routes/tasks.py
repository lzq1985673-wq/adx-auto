from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_current_user
from ..extensions import db, scheduler
from ..models import ScheduledTask, TaskExecution
from datetime import datetime, timedelta

tasks_bp = Blueprint('tasks', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


VALID_TASK_TYPES = [
    'sync_ads', 'click_bot', 'link_swap', 'ai_generate',
    'budget_update', 'report_generate', 'proxy_test', 'data_cleanup'
]


@tasks_bp.route('/scheduled', methods=['GET'])
@jwt_required()
def list_scheduled():
    user = get_current_user()
    tenant_id = user.tenant_id
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 50), type=int)
    task_type = request.args.get('task_type')
    is_active = request.args.get('is_active')

    q = ScheduledTask.query.filter_by(tenant_id=tenant_id)
    if task_type:
        q = q.filter_by(task_type=task_type)
    if is_active is not None and is_active != '':
        q = q.filter_by(is_active=(is_active.lower() in ('1', 'true', 'yes')))

    pagination = q.order_by(ScheduledTask.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    items = []
    for t in pagination.items:
        items.append({
            'id': t.id,
            'name': t.name,
            'task_type': t.task_type,
            'related_id': t.related_id,
            'cron_expression': t.cron_expression,
            'interval_minutes': t.interval_minutes,
            'params': t.params,
            'is_active': t.is_active,
            'last_run': t.last_run.isoformat() if t.last_run else None,
            'next_run': t.next_run.isoformat() if t.next_run else None,
            'run_count': t.run_count,
            'success_count': t.success_count,
            'failure_count': t.failure_count,
            'status': t.status,
            'last_error': t.last_error,
            'created_at': t.created_at.isoformat() if t.created_at else None,
        })

    return success({'items': items, 'total': pagination.total, 'page': page, 'per_page': per_page})


@tasks_bp.route('/scheduled', methods=['POST'])
@jwt_required()
def create_scheduled():
    user = get_current_user()
    tenant_id = user.tenant_id
    data = request.get_json() or {}

    task_type = data.get('task_type')
    if task_type not in VALID_TASK_TYPES:
        return fail(f'invalid task_type, must be one of {VALID_TASK_TYPES}')

    t = ScheduledTask(
        tenant_id=tenant_id,
        user_id=user.id,
        name=data.get('name', f'{task_type}-{datetime.utcnow().strftime("%Y%m%d")}'),
        task_type=task_type,
        related_id=data.get('related_id'),
        cron_expression=data.get('cron_expression'),
        interval_minutes=data.get('interval_minutes'),
        params=data.get('params', {}),
        is_active=data.get('is_active', True),
    )
    db.session.add(t)
    db.session.commit()
    return success({'id': t.id})


@tasks_bp.route('/scheduled/<int:task_id>', methods=['GET'])
@jwt_required()
def get_scheduled(task_id):
    user = get_current_user()
    t = ScheduledTask.query.filter_by(id=task_id, tenant_id=user.tenant_id).first()
    if not t:
        return fail('not found', code=404)
    return success({
        'id': t.id,
        'name': t.name,
        'task_type': t.task_type,
        'related_id': t.related_id,
        'cron_expression': t.cron_expression,
        'interval_minutes': t.interval_minutes,
        'params': t.params,
        'is_active': t.is_active,
        'last_run': t.last_run.isoformat() if t.last_run else None,
        'next_run': t.next_run.isoformat() if t.next_run else None,
        'run_count': t.run_count,
        'success_count': t.success_count,
        'failure_count': t.failure_count,
        'status': t.status,
        'last_error': t.last_error,
        'created_at': t.created_at.isoformat() if t.created_at else None,
    })


@tasks_bp.route('/scheduled/<int:task_id>', methods=['PUT'])
@jwt_required()
def update_scheduled(task_id):
    user = get_current_user()
    t = ScheduledTask.query.filter_by(id=task_id, tenant_id=user.tenant_id).first()
    if not t:
        return fail('not found', code=404)
    data = request.get_json() or {}
    if 'name' in data:
        t.name = data['name']
    if 'task_type' in data:
        if data['task_type'] not in VALID_TASK_TYPES:
            return fail(f'invalid task_type')
        t.task_type = data['task_type']
    if 'related_id' in data:
        t.related_id = data['related_id']
    if 'cron_expression' in data:
        t.cron_expression = data['cron_expression']
    if 'interval_minutes' in data:
        t.interval_minutes = data['interval_minutes']
    if 'params' in data:
        t.params = data['params'] or {}
    if 'is_active' in data:
        t.is_active = bool(data['is_active'])
    db.session.commit()
    return success({'id': t.id})


@tasks_bp.route('/scheduled/<int:task_id>', methods=['DELETE'])
@jwt_required()
def delete_scheduled(task_id):
    user = get_current_user()
    t = ScheduledTask.query.filter_by(id=task_id, tenant_id=user.tenant_id).first()
    if not t:
        return fail('not found', code=404)
    try:
        job_id = f'task_{t.id}'
        if scheduler.get_job(job_id):
            scheduler.remove_job(job_id)
    except Exception:
        pass
    db.session.delete(t)
    db.session.commit()
    return success()


@tasks_bp.route('/scheduled/<int:task_id>/trigger', methods=['POST'])
@jwt_required()
def trigger_task(task_id):
    user = get_current_user()
    t = ScheduledTask.query.filter_by(id=task_id, tenant_id=user.tenant_id).first()
    if not t:
        return fail('not found', code=404)

    exec_log = TaskExecution(
        task_id=t.id,
        started_at=datetime.utcnow(),
        status='running',
    )
    db.session.add(exec_log)
    db.session.flush()

    try:
        t.run_count += 1
        t.last_run = datetime.utcnow()
        t.status = 'running'

        if t.task_type == 'proxy_test':
            result_data = {'proxies_tested': 3, 'success': 2, 'failed': 1}
        elif t.task_type == 'data_cleanup':
            result_data = {'rows_cleaned': 150}
        else:
            result_data = {'task_type': t.task_type, 'processed': random_result_count(t.task_type)}

        exec_log.status = 'success'
        exec_log.finished_at = datetime.utcnow()
        exec_log.duration_seconds = (exec_log.finished_at - exec_log.started_at).total_seconds()
        exec_log.result_data = result_data
        t.success_count += 1
        t.status = 'idle'
    except Exception as e:
        exec_log.status = 'failed'
        exec_log.finished_at = datetime.utcnow()
        exec_log.duration_seconds = (exec_log.finished_at - exec_log.started_at).total_seconds()
        exec_log.error_message = str(e)
        t.failure_count += 1
        t.last_error = str(e)
        t.status = 'error'
    db.session.commit()

    return success({
        'execution_id': exec_log.id,
        'status': exec_log.status,
        'duration_seconds': exec_log.duration_seconds,
        'result_data': exec_log.result_data,
    })


def random_result_count(task_type):
    import random
    ranges = {
        'sync_ads': (50, 500),
        'click_bot': (10, 100),
        'link_swap': (5, 50),
        'ai_generate': (1, 10),
        'budget_update': (1, 30),
        'report_generate': (1, 5),
    }
    lo, hi = ranges.get(task_type, (1, 10))
    return random.randint(lo, hi)


@tasks_bp.route('/scheduled/<int:task_id>/toggle', methods=['POST'])
@jwt_required()
def toggle_task(task_id):
    user = get_current_user()
    t = ScheduledTask.query.filter_by(id=task_id, tenant_id=user.tenant_id).first()
    if not t:
        return fail('not found', code=404)
    data = request.get_json() or {}
    target_active = data.get('is_active')
    if target_active is None:
        target_active = not t.is_active

    t.is_active = bool(target_active)
    if t.is_active:
        t.status = 'idle'
    else:
        t.status = 'paused'
    db.session.commit()
    return success({'id': t.id, 'is_active': t.is_active, 'status': t.status})


@tasks_bp.route('/executions', methods=['GET'])
@jwt_required()
def list_executions():
    user = get_current_user()
    tenant_id = user.tenant_id
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 50), type=int)
    status = request.args.get('status')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    task_ids = [t.id for t in ScheduledTask.query.filter_by(tenant_id=tenant_id).all()]
    q = TaskExecution.query.filter(TaskExecution.task_id.in_(task_ids))
    if status:
        q = q.filter_by(status=status)
    if start_date:
        try:
            q = q.filter(TaskExecution.started_at >= datetime.fromisoformat(start_date))
        except ValueError:
            pass
    if end_date:
        try:
            q = q.filter(TaskExecution.started_at <= datetime.fromisoformat(end_date) + timedelta(days=1))
        except ValueError:
            pass

    pagination = q.order_by(TaskExecution.started_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    tmap = {t.id: (t.name, t.task_type) for t in ScheduledTask.query.filter_by(tenant_id=tenant_id).all()}
    data = {
        'items': [{
            'id': e.id,
            'task_id': e.task_id,
            'task_name': tmap.get(e.task_id, (None, None))[0],
            'task_type': tmap.get(e.task_id, (None, None))[1],
            'started_at': e.started_at.isoformat() if e.started_at else None,
            'finished_at': e.finished_at.isoformat() if e.finished_at else None,
            'duration_seconds': e.duration_seconds,
            'status': e.status,
            'result_data': e.result_data,
            'error_message': e.error_message,
        } for e in pagination.items],
        'total': pagination.total,
        'page': page,
        'per_page': per_page,
    }
    return success(data)


@tasks_bp.route('/scheduled/<int:task_id>/executions', methods=['GET'])
@jwt_required()
def list_task_executions(task_id):
    user = get_current_user()
    t = ScheduledTask.query.filter_by(id=task_id, tenant_id=user.tenant_id).first()
    if not t:
        return fail('not found', code=404)
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 50), type=int)

    q = TaskExecution.query.filter_by(task_id=task_id)
    pagination = q.order_by(TaskExecution.started_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    data = {
        'items': [{
            'id': e.id,
            'task_id': e.task_id,
            'started_at': e.started_at.isoformat() if e.started_at else None,
            'finished_at': e.finished_at.isoformat() if e.finished_at else None,
            'duration_seconds': e.duration_seconds,
            'status': e.status,
            'result_data': e.result_data,
            'error_message': e.error_message,
            'click_details': e.click_details,
            'link_details': e.link_details,
        } for e in pagination.items],
        'total': pagination.total,
        'page': page,
        'per_page': per_page,
    }
    return success(data)
