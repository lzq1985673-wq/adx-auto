from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_current_user
from ..extensions import db
from ..models import Campaign, AdGroup, Ad, Keyword, AdsSubAccount, MCCAccount
from datetime import datetime

ads_bp = Blueprint('ads', __name__)


def success(data=None, msg='ok'):
    return jsonify({'code': 0, 'msg': msg, 'data': data})


def fail(msg='error', data=None, code=1):
    return jsonify({'code': code, 'msg': msg, 'data': data})


@ads_bp.route('/campaigns', methods=['GET'])
@jwt_required()
def list_campaigns():
    user = get_current_user()
    tenant_id = user.tenant_id
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', current_app.config.get('ITEMS_PER_PAGE', 20), type=int)
    status = request.args.get('status')
    sub_account_id = request.args.get('sub_account_id', type=int)
    q = Campaign.query.filter_by(tenant_id=tenant_id)
    if status:
        q = q.filter_by(status=status)
    if sub_account_id:
        q = q.filter_by(sub_account_id=sub_account_id)
    pagination = q.order_by(Campaign.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)

    sub_map = {s.id: s.name for s in AdsSubAccount.query.all()}
    items = [{
        'id': c.id,
        'sub_account_id': c.sub_account_id,
        'sub_account_name': sub_map.get(c.sub_account_id),
        'external_id': c.external_id,
        'name': c.name,
        'status': c.status,
        'budget': float(c.budget or 0),
        'budget_type': c.budget_type,
        'bid_strategy': c.bid_strategy,
        'advertising_channel': c.advertising_channel,
        'spend': float(c.spend or 0),
        'impressions': int(c.impressions or 0),
        'clicks': int(c.clicks or 0),
        'conversions': float(c.conversions or 0),
        'ctr': float(c.ctr or 0),
        'avg_cpc': float(c.avg_cpc or 0),
        'click_bot_enabled': c.click_bot_enabled,
        'link_swap_enabled': c.link_swap_enabled,
        'start_date': c.start_date.isoformat() if c.start_date else None,
        'end_date': c.end_date.isoformat() if c.end_date else None,
        'created_at': c.created_at.isoformat() if c.created_at else None,
    } for c in pagination.items]
    return success({'items': items, 'total': pagination.total, 'page': page, 'per_page': per_page})


@ads_bp.route('/campaigns', methods=['POST'])
@jwt_required()
def create_campaign():
    user = get_current_user()
    data = request.get_json() or {}
    c = Campaign(
        tenant_id=user.tenant_id,
        sub_account_id=data.get('sub_account_id'),
        external_id=data.get('external_id'),
        name=data.get('name', 'New Campaign'),
        status=data.get('status', 'paused'),
        budget=data.get('budget', 0),
        budget_type=data.get('budget_type', 'daily'),
        bid_strategy=data.get('bid_strategy'),
        advertising_channel=data.get('advertising_channel', 'SEARCH'),
        start_date=data.get('start_date'),
        end_date=data.get('end_date'),
        settings=data.get('settings', {}),
    )
    db.session.add(c)
    db.session.commit()
    return success({'id': c.id})


@ads_bp.route('/campaigns/<int:cid>', methods=['GET'])
@jwt_required()
def get_campaign(cid):
    user = get_current_user()
    c = Campaign.query.filter_by(id=cid, tenant_id=user.tenant_id).first()
    if not c:
        return fail('not found', code=404)
    ag_list = []
    for ag in c.ad_groups:
        ad_list = []
        for a in ag.ads:
            ad_list.append({
                'id': a.id,
                'ad_type': a.ad_type,
                'headlines': a.headlines,
                'descriptions': a.descriptions,
                'paths': a.paths,
                'final_url': a.final_url,
                'status': a.status,
                'ai_generated': a.ai_generated,
            })
        kw_list = []
        for k in ag.keywords:
            kw_list.append({
                'id': k.id,
                'text': k.text,
                'match_type': k.match_type,
                'status': k.status,
                'cpc_bid': float(k.cpc_bid) if k.cpc_bid else None,
                'quality_score': k.quality_score,
            })
        ag_list.append({
            'id': ag.id,
            'name': ag.name,
            'status': ag.status,
            'cpc_bid': float(ag.cpc_bid) if ag.cpc_bid else None,
            'target_cpa': float(ag.target_cpa) if ag.target_cpa else None,
            'ads': ad_list,
            'keywords': kw_list,
        })
    return success({
        'id': c.id,
        'sub_account_id': c.sub_account_id,
        'external_id': c.external_id,
        'name': c.name,
        'status': c.status,
        'budget': float(c.budget or 0),
        'budget_type': c.budget_type,
        'bid_strategy': c.bid_strategy,
        'advertising_channel': c.advertising_channel,
        'spend': float(c.spend or 0),
        'impressions': int(c.impressions or 0),
        'clicks': int(c.clicks or 0),
        'conversions': float(c.conversions or 0),
        'ctr': float(c.ctr or 0),
        'avg_cpc': float(c.avg_cpc or 0),
        'click_bot_enabled': c.click_bot_enabled,
        'click_daily_target': c.click_daily_target,
        'click_countries': c.click_countries,
        'click_time_slots': c.click_time_slots,
        'click_referers': c.click_referers,
        'link_swap_enabled': c.link_swap_enabled,
        'link_swap_interval': c.link_swap_interval,
        'link_templates': c.link_templates,
        'ad_groups': ag_list,
        'settings': c.settings,
        'start_date': c.start_date.isoformat() if c.start_date else None,
        'end_date': c.end_date.isoformat() if c.end_date else None,
        'created_at': c.created_at.isoformat() if c.created_at else None,
        'updated_at': c.updated_at.isoformat() if c.updated_at else None,
    })


@ads_bp.route('/campaigns/<int:cid>', methods=['PUT'])
@jwt_required()
def update_campaign(cid):
    user = get_current_user()
    c = Campaign.query.filter_by(id=cid, tenant_id=user.tenant_id).first()
    if not c:
        return fail('not found', code=404)
    data = request.get_json() or {}
    fields = ('name', 'status', 'budget', 'budget_type', 'bid_strategy',
              'advertising_channel', 'start_date', 'end_date', 'settings',
              'click_bot_enabled', 'click_daily_target', 'click_countries',
              'click_time_slots', 'click_referers', 'link_swap_enabled',
              'link_swap_interval', 'link_templates')
    for k in fields:
        if k in data:
            setattr(c, k, data[k])
    db.session.commit()
    return success({'id': c.id})


@ads_bp.route('/campaigns/<int:cid>', methods=['DELETE'])
@jwt_required()
def delete_campaign(cid):
    user = get_current_user()
    c = Campaign.query.filter_by(id=cid, tenant_id=user.tenant_id).first()
    if not c:
        return fail('not found', code=404)
    c.status = 'removed'
    db.session.commit()
    return success()


@ads_bp.route('/ad-groups', methods=['POST'])
@jwt_required()
def create_ad_group():
    user = get_current_user()
    data = request.get_json() or {}
    campaign_id = data.get('campaign_id')
    c = Campaign.query.filter_by(id=campaign_id, tenant_id=user.tenant_id).first()
    if not c:
        return fail('campaign not found')
    ag = AdGroup(
        campaign_id=campaign_id,
        name=data.get('name', 'New Ad Group'),
        status=data.get('status', 'enabled'),
        cpc_bid=data.get('cpc_bid'),
        target_cpa=data.get('target_cpa'),
    )
    db.session.add(ag)
    db.session.commit()
    return success({'id': ag.id})


@ads_bp.route('/ads', methods=['POST'])
@jwt_required()
def create_ad():
    user = get_current_user()
    data = request.get_json() or {}
    ag = AdGroup.query.get(data.get('ad_group_id'))
    if not ag or not ag.campaign or ag.campaign.tenant_id != user.tenant_id:
        return fail('ad group not found', code=404)
    a = Ad(
        ad_group_id=ag.id,
        ad_type=data.get('ad_type', 'RESPONSIVE_SEARCH_AD'),
        headlines=data.get('headlines', []),
        descriptions=data.get('descriptions', []),
        paths=data.get('paths', []),
        final_url=data.get('final_url'),
        tracking_url_template=data.get('tracking_url_template'),
        status=data.get('status', 'paused'),
    )
    db.session.add(a)
    db.session.commit()
    return success({'id': a.id})


@ads_bp.route('/ads/<int:aid>', methods=['PUT'])
@jwt_required()
def update_ad(aid):
    user = get_current_user()
    a = Ad.query.get(aid)
    if not a or not a.ad_group or not a.ad_group.campaign or a.ad_group.campaign.tenant_id != user.tenant_id:
        return fail('not found', code=404)
    data = request.get_json() or {}
    fields = ('headlines', 'descriptions', 'paths', 'final_url',
              'tracking_url_template', 'status')
    for k in fields:
        if k in data:
            setattr(a, k, data[k])
    db.session.commit()
    return success({'id': a.id})


@ads_bp.route('/keywords', methods=['POST'])
@jwt_required()
def create_keyword():
    user = get_current_user()
    data = request.get_json() or {}
    ag = AdGroup.query.get(data.get('ad_group_id'))
    if not ag or not ag.campaign or ag.campaign.tenant_id != user.tenant_id:
        return fail('ad group not found', code=404)
    k = Keyword(
        ad_group_id=ag.id,
        text=data.get('text', ''),
        match_type=data.get('match_type', 'BROAD'),
        status=data.get('status', 'enabled'),
        cpc_bid=data.get('cpc_bid'),
        final_url=data.get('final_url'),
    )
    db.session.add(k)
    db.session.commit()
    return success({'id': k.id})


@ads_bp.route('/keywords/<int:kid>', methods=['PUT'])
@jwt_required()
def update_keyword(kid):
    user = get_current_user()
    k = Keyword.query.get(kid)
    if not k or not k.ad_group or not k.ad_group.campaign or k.ad_group.campaign.tenant_id != user.tenant_id:
        return fail('not found', code=404)
    data = request.get_json() or {}
    for f in ('text', 'match_type', 'status', 'cpc_bid', 'final_url'):
        if f in data:
            setattr(k, f, data[f])
    db.session.commit()
    return success({'id': k.id})
