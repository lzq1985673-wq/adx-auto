import re
import json
from urllib.parse import urljoin, urlparse
from datetime import datetime

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

try:
    from bs4 import BeautifulSoup
    HAS_BS4 = True
except ImportError:
    HAS_BS4 = False

from .helpers import random_user_agent


DEFAULT_HEADERS = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
    'Accept-Encoding': 'gzip, deflate, br',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Cache-Control': 'max-age=0',
}


def _get_domain(url):
    try:
        return urlparse(url).netloc
    except Exception:
        return ''


def _clean_text(text):
    if not text:
        return ''
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _extract_meta_tag(soup, name):
    if not HAS_BS4:
        return ''
    tag = soup.find('meta', attrs={'name': name})
    if not tag:
        tag = soup.find('meta', attrs={'property': f'og:{name}'})
    if not tag:
        tag = soup.find('meta', attrs={'property': name})
    if tag and tag.get('content'):
        return _clean_text(tag['content'])
    return ''


def _extract_json_ld(soup):
    if not HAS_BS4:
        return []
    scripts = soup.find_all('script', type='application/ld+json')
    items = []
    for s in scripts:
        try:
            text = s.string or s.get_text()
            if text:
                data = json.loads(text)
                if isinstance(data, list):
                    items.extend(data)
                else:
                    items.append(data)
        except (json.JSONDecodeError, Exception):
            continue
    return items


def scrape_landing_page(url, timeout=30, retries=2, proxy=None, user_agent=None):
    if not HAS_REQUESTS or not HAS_BS4:
        return {
            'url': url,
            'success': False,
            'error': 'requests or BeautifulSoup4 is not installed',
            'timestamp': datetime.utcnow().isoformat(),
        }

    domain = _get_domain(url)
    final_url = url
    raw_html = ''
    response_status = None
    headers = dict(DEFAULT_HEADERS)
    headers['User-Agent'] = user_agent or random_user_agent('desktop')

    for attempt in range(retries + 1):
        try:
            proxies = None
            if proxy:
                proxies = {'http': proxy, 'https': proxy}

            resp = requests.get(
                url,
                headers=headers,
                timeout=timeout,
                proxies=proxies,
                allow_redirects=True,
                verify=True,
            )
            final_url = resp.url
            response_status = resp.status_code
            raw_html = resp.text
            if resp.status_code >= 400:
                if attempt < retries:
                    continue
            break
        except requests.exceptions.RequestException as e:
            if attempt < retries:
                continue
            return {
                'url': url,
                'final_url': final_url,
                'domain': domain,
                'success': False,
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat(),
            }

    if not raw_html:
        return {
            'url': url,
            'final_url': final_url,
            'domain': domain,
            'success': False,
            'error': 'Empty response body',
            'status_code': response_status,
            'timestamp': datetime.utcnow().isoformat(),
        }

    soup = BeautifulSoup(raw_html, 'html.parser')

    title = ''
    if soup.title and soup.title.string:
        title = _clean_text(soup.title.string)
    if not title:
        title = _extract_meta_tag(soup, 'title')

    description = _extract_meta_tag(soup, 'description')
    if not description:
        description = _extract_meta_tag(soup, 'Description')

    og_title = _extract_meta_tag(soup, 'og:title')
    og_description = _extract_meta_tag(soup, 'og:description')
    og_image = _extract_meta_tag(soup, 'og:image')
    og_type = _extract_meta_tag(soup, 'og:type')
    og_url = _extract_meta_tag(soup, 'og:url')

    canonical_url = ''
    canonical_tag = soup.find('link', rel='canonical')
    if canonical_tag and canonical_tag.get('href'):
        canonical_url = canonical_tag['href']

    h_tags = {}
    for level in range(1, 7):
        found = soup.find_all(f'h{level}')
        items = []
        for h in found:
            text = _clean_text(h.get_text())
            if text:
                items.append(text)
        h_tags[f'h{level}'] = items

    paragraphs = []
    for p in soup.find_all('p'):
        text = _clean_text(p.get_text())
        if len(text) >= 20:
            paragraphs.append(text)
    paragraphs = paragraphs[:50]

    images = []
    for img in soup.find_all('img'):
        src = img.get('src') or img.get('data-src') or ''
        alt = _clean_text(img.get('alt', ''))
        if src:
            if not src.startswith('http'):
                src = urljoin(final_url, src)
            images.append({
                'url': src,
                'alt': alt,
                'width': img.get('width'),
                'height': img.get('height'),
            })
    images = images[:50]

    features = []
    feature_selectors = [
        'ul.features li', 'ul.feature-list li', '.features li', '.feature-list li',
        'div.features div', '.feature-item', '.benefit-item', '.benefits li',
        '.value-prop li', '.key-features li', 'ol.features li',
        '[class*="feature"] li', '[class*="benefit"] li',
    ]
    for selector in feature_selectors:
        try:
            found = soup.select(selector)
            for el in found:
                text = _clean_text(el.get_text())
                if text and len(text) >= 10 and text not in features:
                    features.append(text)
        except Exception:
            continue

    if not features:
        for li in soup.find_all('li'):
            text = _clean_text(li.get_text())
            if text and len(text) >= 15 and len(text) <= 200:
                if any(k in text.lower() for k in ['✓', 'free', 'save', '%', 'guarantee',
                                                    'premium', 'secure', 'fast', 'easy',
                                                    'best', 'top', 'new', '24', 'support',
                                                    '100%', '包邮', '免', '优惠', '质保',
                                                    '正品', '保障', '免费', '极速']):
                    if text not in features:
                        features.append(text)

    features = features[:30]

    reviews = []
    review_selectors = [
        '.review', '.reviews .review-item', '.customer-review', '.testimonial',
        '.testimonials .testimonial-item', '[class*="review"]', '[class*="testimonial"]',
        'blockquote', '.comment-item', '.review-item',
    ]
    for selector in review_selectors:
        try:
            found = soup.select(selector)
            for el in found:
                try:
                    author_el = el.select_one('[class*="name"], [class*="author"], .reviewer-name, strong')
                    rating_el = el.select_one('[class*="star"], [class*="rating"], [aria-label*="star"]')
                    date_el = el.select_one('[class*="date"], time, [class*="time"]')
                    text_el = el.select_one('[class*="content"], [class*="body"], p')

                    author = _clean_text(author_el.get_text()) if author_el else ''
                    rating_text = ''
                    if rating_el:
                        rating_text = _clean_text(rating_el.get_text())
                        if not rating_text and rating_el.get('aria-label'):
                            rating_text = rating_el['aria-label']
                    date = _clean_text(date_el.get_text()) if date_el else ''
                    text = ''
                    if text_el:
                        text = _clean_text(text_el.get_text())
                    else:
                        text = _clean_text(el.get_text())

                    if text and len(text) >= 20:
                        review = {
                            'author': author[:100],
                            'rating': rating_text[:50],
                            'date': date[:50],
                            'content': text[:2000],
                        }
                        if review not in reviews:
                            reviews.append(review)
                except Exception:
                    continue
        except Exception:
            continue

    json_ld_items = _extract_json_ld(soup)
    for item in json_ld_items:
        if isinstance(item, dict):
            itype = item.get('@type', '')
            if isinstance(itype, list):
                itype = ','.join(itype)
            if 'Review' in str(itype) or 'AggregateRating' in str(itype):
                author = ''
                if item.get('author'):
                    a = item['author']
                    if isinstance(a, dict):
                        author = a.get('name', '')
                    else:
                        author = str(a)
                rating_value = ''
                rating = item.get('reviewRating') or item.get('aggregateRating')
                if isinstance(rating, dict):
                    rating_value = f"{rating.get('ratingValue', '')}/{rating.get('bestRating', '5')}"
                text = item.get('reviewBody') or item.get('description') or ''
                if text and len(text) >= 10:
                    reviews.append({
                        'author': author[:100],
                        'rating': rating_value,
                        'date': str(item.get('datePublished', ''))[:50],
                        'content': str(text)[:2000],
                        'source': 'json-ld',
                    })

    reviews = reviews[:30]

    pricing_info = {}
    price_selectors = [
        '.price', '[class*="price"]', '.pricing', '[itemprop="price"]',
        '.amount', '.cost',
    ]
    for selector in price_selectors[:5]:
        try:
            found = soup.select(selector)
            for el in found[:5]:
                text = _clean_text(el.get_text())
                if text and len(text) <= 50 and re.search(r'[\d,.]', text):
                    if 'prices' not in pricing_info:
                        pricing_info['prices'] = []
                    pricing_info['prices'].append(text)
        except Exception:
            continue

    links = []
    for a in soup.find_all('a', href=True):
        href = a['href']
        text = _clean_text(a.get_text())
        if href.startswith('http') or href.startswith('/'):
            if not href.startswith('http'):
                href = urljoin(final_url, href)
            links.append({
                'url': href,
                'text': text[:200],
                'is_internal': domain in href if domain else False,
            })
    links = links[:100]

    page_text_content = _clean_text(soup.get_text())
    estimated_word_count = len(re.findall(r'\b\w+\b', page_text_content))

    return {
        'url': url,
        'final_url': final_url,
        'canonical_url': canonical_url,
        'domain': domain,
        'status_code': response_status,
        'success': True,
        'timestamp': datetime.utcnow().isoformat(),
        'title': title,
        'og_title': og_title,
        'description': description,
        'og_description': og_description,
        'og_image': og_image,
        'og_type': og_type,
        'og_url': og_url,
        'headings': h_tags,
        'paragraphs': paragraphs,
        'features': features,
        'reviews': reviews,
        'images': images,
        'links': links,
        'pricing_info': pricing_info,
        'json_ld': json_ld_items,
        'estimated_word_count': estimated_word_count,
        'content_length': len(raw_html),
    }
