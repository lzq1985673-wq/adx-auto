import hashlib
import random
import string
import uuid
from datetime import datetime, timedelta, timezone


def generate_fingerprint(length=32):
    raw = f"{uuid.uuid4().hex}{datetime.utcnow().timestamp()}{random.random()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:length]


def ip_location_lookup(ip):
    mock_data = {
        'US': {
            'country': 'United States',
            'country_code': 'US',
            'cities': ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix',
                       'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose'],
            'timezone': 'America/New_York',
            'timezones': ['America/New_York', 'America/Los_Angeles', 'America/Chicago',
                          'America/Denver', 'America/Phoenix'],
        },
        'GB': {
            'country': 'United Kingdom',
            'country_code': 'GB',
            'cities': ['London', 'Manchester', 'Birmingham', 'Leeds', 'Glasgow',
                       'Liverpool', 'Bristol', 'Sheffield', 'Edinburgh', 'Cardiff'],
            'timezone': 'Europe/London',
            'timezones': ['Europe/London'],
        },
        'DE': {
            'country': 'Germany',
            'country_code': 'DE',
            'cities': ['Berlin', 'Munich', 'Hamburg', 'Cologne', 'Frankfurt',
                       'Stuttgart', 'Dusseldorf', 'Leipzig', 'Dortmund', 'Essen'],
            'timezone': 'Europe/Berlin',
            'timezones': ['Europe/Berlin'],
        },
        'FR': {
            'country': 'France',
            'country_code': 'FR',
            'cities': ['Paris', 'Marseille', 'Lyon', 'Toulouse', 'Nice',
                       'Nantes', 'Montpellier', 'Strasbourg', 'Bordeaux', 'Lille'],
            'timezone': 'Europe/Paris',
            'timezones': ['Europe/Paris'],
        },
        'JP': {
            'country': 'Japan',
            'country_code': 'JP',
            'cities': ['Tokyo', 'Yokohama', 'Osaka', 'Nagoya', 'Sapporo',
                       'Fukuoka', 'Kobe', 'Kyoto', 'Kawasaki', 'Saitama'],
            'timezone': 'Asia/Tokyo',
            'timezones': ['Asia/Tokyo'],
        },
        'CN': {
            'country': 'China',
            'country_code': 'CN',
            'cities': ['Beijing', 'Shanghai', 'Guangzhou', 'Shenzhen', 'Chengdu',
                       'Hangzhou', 'Wuhan', 'Xi\'an', 'Nanjing', 'Chongqing'],
            'timezone': 'Asia/Shanghai',
            'timezones': ['Asia/Shanghai'],
        },
        'CA': {
            'country': 'Canada',
            'country_code': 'CA',
            'cities': ['Toronto', 'Montreal', 'Vancouver', 'Calgary', 'Ottawa',
                       'Edmonton', 'Quebec City', 'Winnipeg', 'Hamilton', 'Victoria'],
            'timezone': 'America/Toronto',
            'timezones': ['America/Toronto', 'America/Vancouver', 'America/Calgary', 'America/Montreal'],
        },
        'AU': {
            'country': 'Australia',
            'country_code': 'AU',
            'cities': ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide',
                       'Gold Coast', 'Newcastle', 'Canberra', 'Wollongong', 'Hobart'],
            'timezone': 'Australia/Sydney',
            'timezones': ['Australia/Sydney', 'Australia/Melbourne', 'Australia/Perth', 'Australia/Brisbane'],
        },
        'BR': {
            'country': 'Brazil',
            'country_code': 'BR',
            'cities': ['Sao Paulo', 'Rio de Janeiro', 'Brasilia', 'Salvador', 'Fortaleza',
                       'Belo Horizonte', 'Manaus', 'Curitiba', 'Recife', 'Porto Alegre'],
            'timezone': 'America/Sao_Paulo',
            'timezones': ['America/Sao_Paulo', 'America/Recife', 'America/Manaus'],
        },
        'IN': {
            'country': 'India',
            'country_code': 'IN',
            'cities': ['Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai',
                       'Kolkata', 'Pune', 'Ahmedabad', 'Jaipur', 'Surat'],
            'timezone': 'Asia/Kolkata',
            'timezones': ['Asia/Kolkata'],
        },
    }

    country_codes = list(mock_data.keys())
    octets = ip.split('.') if '.' in ip else None
    if octets and len(octets) == 4:
        idx = int(octets[0]) % len(country_codes)
    else:
        idx = random.randint(0, len(country_codes) - 1)

    country_code = country_codes[idx]
    info = mock_data[country_code]
    city = random.choice(info['cities'])
    tz = random.choice(info['timezones'])

    return {
        'ip': ip,
        'country': info['country'],
        'country_code': info['country_code'],
        'city': city,
        'timezone': tz,
        'latitude': round(random.uniform(-90, 90), 4),
        'longitude': round(random.uniform(-180, 180), 4),
        'isp': random.choice(['Comcast', 'AT&T', 'Verizon', 'Charter', 'Spectrum',
                              'BT', 'Deutsche Telekom', 'Orange', 'NTT', 'China Mobile']),
        'connection_type': random.choice(['cable', 'dsl', 'fiber', 'mobile', 'wifi']),
    }


def get_referer_pool(country=None):
    global_referers = [
        'https://www.google.com/search?q=',
        'https://www.google.com/',
        'https://www.bing.com/search?q=',
        'https://search.yahoo.com/search?p=',
        'https://duckduckgo.com/?q=',
        'https://www.facebook.com/',
        'https://twitter.com/',
        'https://www.linkedin.com/',
        'https://www.reddit.com/',
        'https://www.youtube.com/',
    ]

    country_specific = {
        'CN': [
            'https://www.baidu.com/s?wd=',
            'https://www.sogou.com/web?query=',
            'https://weibo.com/',
            'https://www.zhihu.com/',
            'https://www.toutiao.com/',
            'https://www.baidu.com/',
            'https://www.douyin.com/',
            'https://www.kuaishou.com/',
            'https://www.bilibili.com/',
            'https://www.taobao.com/',
        ],
        'JP': [
            'https://www.yahoo.co.jp/search?p=',
            'https://www.google.co.jp/search?q=',
            'https://twitter.com/',
            'https://www.facebook.com/',
            'https://www.youtube.com/',
            'https://www.amazon.co.jp/',
            'https://www.rakuten.co.jp/',
            'https://www.nicovideo.jp/',
            'https://www.livedoor.com/',
            'https://www.excite.co.jp/',
        ],
        'RU': [
            'https://yandex.ru/search/?text=',
            'https://www.google.ru/search?q=',
            'https://vk.com/',
            'https://ok.ru/',
            'https://www.youtube.com/',
            'https://www.avito.ru/',
            'https://www.ozon.ru/',
            'https://www.wildberries.ru/',
            'https://dzen.ru/',
            'https://mail.ru/',
        ],
        'DE': [
            'https://www.google.de/search?q=',
            'https://duckduckgo.com/?q=',
            'https://www.bing.com/search?q=',
            'https://www.facebook.com/',
            'https://twitter.com/',
            'https://www.xing.com/',
            'https://www.linkedin.com/',
            'https://www.youtube.com/',
            'https://www.amazon.de/',
            'https://www.ebay.de/',
        ],
        'FR': [
            'https://www.google.fr/search?q=',
            'https://www.bing.com/search?q=',
            'https://duckduckgo.com/?q=',
            'https://www.facebook.com/',
            'https://twitter.com/',
            'https://www.linkedin.com/',
            'https://www.youtube.com/',
            'https://www.leboncoin.fr/',
            'https://www.amazon.fr/',
            'https://www.cdiscount.com/',
        ],
    }

    if country and country in country_specific:
        referers = country_specific[country]
    else:
        referers = global_referers

    return list(referers)


def distribute_clicks_by_timeslot(daily_total, timezone_str, slots=8):
    if daily_total <= 0:
        return []

    tz_offsets = {
        'Asia/Shanghai': 8,
        'Asia/Tokyo': 9,
        'Asia/Kolkata': 5.5,
        'Europe/London': 0,
        'Europe/Berlin': 1,
        'Europe/Paris': 1,
        'America/New_York': -5,
        'America/Los_Angeles': -8,
        'America/Chicago': -6,
        'America/Denver': -7,
        'America/Toronto': -5,
        'America/Sao_Paulo': -3,
        'Australia/Sydney': 11,
    }

    offset_hours = tz_offsets.get(timezone_str, 0)

    slot_ranges = [
        (0, 3),
        (3, 6),
        (6, 9),
        (9, 12),
        (12, 15),
        (15, 18),
        (18, 21),
        (21, 24),
    ]

    slot_weights = [
        0.02,
        0.01,
        0.08,
        0.18,
        0.15,
        0.17,
        0.25,
        0.14,
    ]

    local_weights = [0.0] * slots
    for i in range(slots):
        shifted_idx = (i + int(offset_hours / 3)) % slots
        local_weights[shifted_idx] = slot_weights[i]

    total_weight = sum(local_weights)
    normalized_weights = [w / total_weight for w in local_weights]

    distribution = []
    remaining = daily_total
    for i in range(slots):
        if i == slots - 1:
            count = remaining
        else:
            base = daily_total * normalized_weights[i]
            count = int(base + random.uniform(-0.1 * base, 0.1 * base))
            count = max(0, min(count, remaining))
        remaining -= count

        start_hour, end_hour = slot_ranges[i]
        distribution.append({
            'slot_index': i,
            'time_range': f"{start_hour:02d}:00-{end_hour:02d}:00",
            'weight': round(normalized_weights[i], 4),
            'click_count': count,
        })

    return distribution


def calculate_bot_metrics(country=None):
    metrics = {}

    metrics['avg_session_duration'] = round(random.uniform(45, 180), 2)
    metrics['avg_pages_per_session'] = round(random.uniform(1.5, 6.5), 2)
    metrics['bounce_rate'] = round(random.uniform(0.25, 0.7), 4)
    metrics['time_on_page_avg'] = round(random.uniform(20, 120), 2)
    metrics['scroll_depth_avg'] = round(random.uniform(0.35, 0.85), 4)
    metrics['click_through_rate'] = round(random.uniform(0.01, 0.08), 4)
    metrics['conversion_rate'] = round(random.uniform(0.005, 0.05), 4)
    metrics['returning_visitor_rate'] = round(random.uniform(0.15, 0.5), 4)
    metrics['new_visitor_rate'] = round(1 - metrics['returning_visitor_rate'], 4)
    metrics['direct_traffic_pct'] = round(random.uniform(0.1, 0.35), 4)
    metrics['organic_search_pct'] = round(random.uniform(0.3, 0.55), 4)
    metrics['paid_search_pct'] = round(random.uniform(0.1, 0.3), 4)
    metrics['social_traffic_pct'] = round(random.uniform(0.05, 0.2), 4)
    metrics['referral_traffic_pct'] = round(random.uniform(0.05, 0.2), 4)
    metrics['email_traffic_pct'] = round(random.uniform(0.01, 0.1), 4)
    metrics['display_traffic_pct'] = round(random.uniform(0.01, 0.08), 4)
    metrics['desktop_share'] = round(random.uniform(0.45, 0.7), 4)
    metrics['mobile_share'] = round(1 - metrics['desktop_share'] - random.uniform(0.02, 0.08), 4)
    metrics['tablet_share'] = round(1 - metrics['desktop_share'] - metrics['mobile_share'], 4)
    metrics['chrome_share'] = round(random.uniform(0.55, 0.75), 4)
    metrics['safari_share'] = round(random.uniform(0.1, 0.25), 4)
    metrics['firefox_share'] = round(random.uniform(0.03, 0.1), 4)
    metrics['edge_share'] = round(random.uniform(0.03, 0.08), 4)
    metrics['other_browser_share'] = round(1 - metrics['chrome_share'] - metrics['safari_share']
                                         - metrics['firefox_share'] - metrics['edge_share'], 4)
    metrics['windows_share'] = round(random.uniform(0.35, 0.55), 4)
    metrics['macos_share'] = round(random.uniform(0.12, 0.28), 4)
    metrics['ios_share'] = round(random.uniform(0.15, 0.28), 4)
    metrics['android_share'] = round(random.uniform(0.2, 0.35), 4)
    metrics['linux_share'] = round(random.uniform(0.01, 0.04), 4)
    metrics['traffic_peak_hour'] = int(random.uniform(9, 22))
    metrics['avg_click_delay_ms'] = int(random.uniform(800, 5000))
    metrics['mouse_movements_per_page'] = int(random.uniform(15, 80))
    metrics['clicks_per_session'] = round(random.uniform(2, 12), 2)
    metrics['form_fill_errors_avg'] = round(random.uniform(0, 1.5), 2)
    metrics['image_load_rate'] = round(random.uniform(0.92, 0.99), 4)
    metrics['js_error_rate'] = round(random.uniform(0, 0.03), 4)
    metrics['api_call_count_avg'] = round(random.uniform(5, 30), 1)
    metrics['network_requests_page'] = int(random.uniform(30, 120))
    metrics['local_storage_items'] = int(random.uniform(2, 20))
    metrics['cookie_count'] = int(random.uniform(5, 30))
    metrics['canvas_fingerprint_variation'] = round(random.uniform(0.95, 1.0), 4)
    metrics['webgl_vendor_match_rate'] = round(random.uniform(0.9, 0.99), 4)
    metrics['audio_fingerprint_variation'] = round(random.uniform(0.92, 0.99), 4)
    metrics['timezone_consistency'] = round(random.uniform(0.95, 1.0), 4)
    metrics['language_header_consistency'] = round(random.uniform(0.9, 0.99), 4)
    metrics['screen_resolution_naturalness'] = round(random.uniform(0.88, 0.99), 4)
    metrics['viewport_match_rate'] = round(random.uniform(0.92, 0.99), 4)
    metrics['connection_rtt_ms'] = int(random.uniform(20, 200))
    metrics['download_speed_mbps'] = round(random.uniform(2, 100), 2)
    metrics['packet_loss_rate'] = round(random.uniform(0, 0.01), 4)
    metrics['tls_version_distribution'] = random.choice(['1.2', '1.3'])
    metrics['h2_h3_ratio'] = round(random.uniform(0.4, 0.8), 2)
    metrics['ipv6_support_rate'] = round(random.uniform(0.2, 0.5), 4)

    if country:
        country_bias = {
            'US': {'mobile_share_bias': 0.05, 'chrome_share_bias': 0.02, 'ios_share_bias': 0.08},
            'CN': {'mobile_share_bias': 0.15, 'android_share_bias': 0.1, 'windows_share_bias': 0.05},
            'JP': {'ios_share_bias': 0.15, 'safari_share_bias': 0.1, 'macos_share_bias': 0.05},
            'DE': {'windows_share_bias': 0.08, 'firefox_share_bias': 0.03, 'desktop_share_bias': 0.05},
        }
        bias = country_bias.get(country, {})
        for key, val in bias.items():
            if key.endswith('_bias'):
                base_key = key.replace('_bias', '')
                if base_key in metrics:
                    metrics[base_key] = round(max(0.0, min(1.0, metrics[base_key] + val)), 4)

    return metrics


def random_user_agent(device_type='desktop'):
    desktop_chrome = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.{}.{} Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_{}_{}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.{}.{} Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.{}.{} Safari/537.36',
    ]
    desktop_safari = [
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_{}_{}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/1{}.{} Safari/605.1.15',
    ]
    desktop_firefox = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{}.0) Gecko/20100101 Firefox/{}.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.{}; rv:{}.0) Gecko/20100101 Firefox/{}.0',
    ]
    desktop_edge = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.{}.{} Safari/537.36 Edg/{}.0.{}.{}',
    ]
    mobile_ios = [
        'Mozilla/5.0 (iPhone; CPU iPhone OS {}_{} like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/1{}.{} Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (iPad; CPU OS {}_{} like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/1{}.{} Mobile/15E148 Safari/604.1',
    ]
    mobile_android = [
        'Mozilla/5.0 (Linux; Android {}.0; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.{}.{} Mobile Safari/537.36',
        'Mozilla/5.0 (Linux; Android {}.0; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.{}.{} Mobile Safari/537.36',
        'Mozilla/5.0 (Linux; Android {}.0; Mi 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.{}.{} Mobile Safari/537.36',
    ]

    chrome_major = random.randint(115, 128)
    chrome_build = random.randint(5000, 6500)
    chrome_rev = random.randint(100, 250)
    safari_major = random.randint(6, 7)
    safari_minor = random.randint(0, 5)
    firefox_major = random.randint(115, 130)
    osx_major = random.randint(14, 18)
    osx_minor = random.randint(0, 9)
    ios_major = random.randint(15, 17)
    ios_minor = random.randint(0, 6)
    android_major = random.randint(10, 14)
    edge_major = random.randint(115, 128)
    edge_build = random.randint(1500, 2800)
    edge_rev = random.randint(30, 90)

    if device_type == 'desktop':
        r = random.random()
        if r < 0.6:
            template = random.choice(desktop_chrome)
            if 'Macintosh' in template:
                return template.format(osx_major, osx_minor, chrome_major, chrome_build, chrome_rev)
            return template.format(chrome_major, chrome_build, chrome_rev)
        elif r < 0.78:
            return random.choice(desktop_safari).format(osx_major, osx_minor, safari_major, safari_minor)
        elif r < 0.9:
            template = random.choice(desktop_firefox)
            if 'Mac' in template:
                return template.format(osx_major, firefox_major, firefox_major)
            return template.format(firefox_major, firefox_major)
        else:
            return random.choice(desktop_edge).format(chrome_major, chrome_build, chrome_rev, edge_major, edge_build, edge_rev)
    elif device_type in ('mobile', 'tablet'):
        r = random.random()
        if r < 0.35:
            template = random.choice(mobile_ios)
            return template.format(ios_major, ios_minor, safari_major, safari_minor)
        else:
            template = random.choice(mobile_android)
            return template.format(android_major, chrome_major, chrome_build, chrome_rev)
    else:
        return random.choice(desktop_chrome).format(chrome_major, chrome_build, chrome_rev)
