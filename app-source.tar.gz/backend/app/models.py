from datetime import datetime
from .extensions import db, bcrypt
from sqlalchemy import JSON
import hashlib
from flask import current_app


# ==================== Tenant (多租户) ====================
class Tenant(db.Model):
    __tablename__ = 'tenants'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    slug = db.Column(db.String(50), unique=True)
    plan = db.Column(db.String(20), default='free')  # free/pro/enterprise/永久
    status = db.Column(db.String(20), default='active')  # active/suspended/expired
    subscription_end = db.Column(db.DateTime)
    settings = db.Column(JSON, default={})
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    users = db.relationship('User', backref='tenant', lazy=True, cascade='all,delete-orphan')
    mcc_accounts = db.relationship('MCCAccount', backref='tenant', lazy=True, cascade='all,delete-orphan')
    campaigns = db.relationship('Campaign', backref='tenant', lazy=True, cascade='all,delete-orphan')
    proxy_configs = db.relationship('ProxyConfig', backref='tenant', lazy=True, cascade='all,delete-orphan')
    ai_configs = db.relationship('AIConfig', backref='tenant', lazy=True, cascade='all,delete-orphan')
    scheduled_tasks = db.relationship('ScheduledTask', backref='tenant', lazy=True, cascade='all,delete-orphan')


# ==================== User ====================
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default='member')  # owner/admin/member/viewer
    avatar = db.Column(db.String(500))
    status = db.Column(db.String(20), default='active')  # active/disabled/pending
    last_login = db.Column(db.DateTime)
    last_ip = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)

    def has_permission(self, permission):
        role_perms = {
            'owner': ['all'],
            'admin': ['mcc:manage', 'ads:manage', 'ai:manage', 'proxy:manage', 'task:manage', 'user:manage', 'config:manage'],
            'member': ['mcc:view', 'ads:manage', 'ai:use', 'task:view'],
            'viewer': ['mcc:view', 'ads:view'],
        }
        perms = role_perms.get(self.role, [])
        return 'all' in perms or permission in perms


# ==================== MCC Account ====================
class MCCAccount(db.Model):
    __tablename__ = 'mcc_accounts'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    name = db.Column(db.String(100), nullable=False)
    customer_id = db.Column(db.String(50), nullable=False)  # MCC ID
    manager_customer_id = db.Column(db.String(50))
    refresh_token = db.Column(db.String(500))
    developer_token = db.Column(db.String(200))
    client_id = db.Column(db.String(200))
    client_secret = db.Column(db.String(200))
    login_customer_id = db.Column(db.String(50))
    # 防关联
    script_fingerprint = db.Column(db.String(100))
    worker_domain = db.Column(db.String(200))
    isolation_group = db.Column(db.String(50))
    status = db.Column(db.String(20), default='active')  # active/disabled/syncing/error
    last_sync = db.Column(db.DateTime)
    sync_interval = db.Column(db.Integer, default=15)  # minutes
    error_message = db.Column(db.Text)
    settings = db.Column(JSON, default={})
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    sub_accounts = db.relationship('AdsSubAccount', backref='mcc', lazy=True, cascade='all,delete-orphan')

    def generate_fingerprint(self):
        salt = current_app.config['FINGERPRINT_SALT']
        raw = f"{self.id}:{self.customer_id}:{self.created_at}:{salt}"
        self.script_fingerprint = hashlib.sha256(raw.encode()).hexdigest()[:32]


# ==================== Ads Sub Account ====================
class AdsSubAccount(db.Model):
    __tablename__ = 'ads_sub_accounts'
    id = db.Column(db.Integer, primary_key=True)
    mcc_id = db.Column(db.Integer, db.ForeignKey('mcc_accounts.id'))
    external_id = db.Column(db.String(50), nullable=False)
    name = db.Column(db.String(200))
    currency_code = db.Column(db.String(10))
    time_zone = db.Column(db.String(50))
    spend = db.Column(db.Numeric(12, 2), default=0)
    impressions = db.Column(db.BigInteger, default=0)
    clicks = db.Column(db.BigInteger, default=0)
    conversions = db.Column(db.BigInteger, default=0)
    status = db.Column(db.String(20), default='active')
    last_sync = db.Column(db.DateTime)
    raw_data = db.Column(JSON, default={})
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    campaigns = db.relationship('Campaign', backref='sub_account', lazy=True)


# ==================== Campaign ====================
class Campaign(db.Model):
    __tablename__ = 'campaigns'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    sub_account_id = db.Column(db.Integer, db.ForeignKey('ads_sub_accounts.id'))
    external_id = db.Column(db.String(50))
    name = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(20), default='paused')  # enabled/paused/removed
    budget = db.Column(db.Numeric(12, 2), default=0)
    budget_type = db.Column(db.String(20), default='daily')
    bid_strategy = db.Column(db.String(50))
    advertising_channel = db.Column(db.String(50), default='SEARCH')
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    # 补点击配置
    click_bot_enabled = db.Column(db.Boolean, default=False)
    click_daily_target = db.Column(db.Integer, default=0)
    click_countries = db.Column(JSON, default=[])
    click_time_slots = db.Column(JSON, default=[])
    click_referers = db.Column(JSON, default=[])
    # 换链接配置
    link_swap_enabled = db.Column(db.Boolean, default=False)
    link_swap_interval = db.Column(db.Integer, default=60)  # minutes
    link_templates = db.Column(JSON, default=[])  # [{tracking_url, final_url, fingerprint}]
    # 统计
    spend = db.Column(db.Numeric(12, 2), default=0)
    impressions = db.Column(db.BigInteger, default=0)
    clicks = db.Column(db.BigInteger, default=0)
    conversions = db.Column(db.Numeric(12, 2), default=0)
    ctr = db.Column(db.Numeric(8, 4), default=0)
    avg_cpc = db.Column(db.Numeric(10, 4), default=0)
    last_sync = db.Column(db.DateTime)
    settings = db.Column(JSON, default={})
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    ad_groups = db.relationship('AdGroup', backref='campaign', lazy=True, cascade='all,delete-orphan')
    click_tasks = db.relationship('ClickTask', backref='campaign', lazy=True)
    link_swap_tasks = db.relationship('LinkSwapTask', backref='campaign', lazy=True)


# ==================== Ad Group ====================
class AdGroup(db.Model):
    __tablename__ = 'ad_groups'
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaigns.id'))
    external_id = db.Column(db.String(50))
    name = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(20), default='paused')
    cpc_bid = db.Column(db.Numeric(10, 4), default=0)
    target_cpa = db.Column(db.Numeric(10, 4))
    spend = db.Column(db.Numeric(12, 2), default=0)
    impressions = db.Column(db.BigInteger, default=0)
    clicks = db.Column(db.BigInteger, default=0)
    conversions = db.Column(db.Numeric(12, 2), default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    ads = db.relationship('Ad', backref='ad_group', lazy=True, cascade='all,delete-orphan')
    keywords = db.relationship('Keyword', backref='ad_group', lazy=True, cascade='all,delete-orphan')


# ==================== Ad ====================
class Ad(db.Model):
    __tablename__ = 'ads'
    id = db.Column(db.Integer, primary_key=True)
    ad_group_id = db.Column(db.Integer, db.ForeignKey('ad_groups.id'))
    external_id = db.Column(db.String(50))
    ad_type = db.Column(db.String(30), default='RESPONSIVE_SEARCH_AD')
    headlines = db.Column(JSON, default=[])  # [{text, pinned}]
    descriptions = db.Column(JSON, default=[])  # [{text, pinned}]
    paths = db.Column(JSON, default=[])  # [path1, path2]
    final_url = db.Column(db.String(1000))
    display_url = db.Column(db.String(500))
    tracking_url_template = db.Column(db.String(1000))
    status = db.Column(db.String(20), default='paused')  # enabled/paused/under_review/disapproved
    approval_status = db.Column(db.String(30))
    policy_topics = db.Column(JSON, default=[])
    ai_generated = db.Column(db.Boolean, default=False)
    ai_config_id = db.Column(db.Integer, db.ForeignKey('ai_configs.id'))
    spend = db.Column(db.Numeric(12, 2), default=0)
    impressions = db.Column(db.BigInteger, default=0)
    clicks = db.Column(db.BigInteger, default=0)
    conversions = db.Column(db.Numeric(12, 2), default=0)
    last_google_submit = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ==================== Keyword ====================
class Keyword(db.Model):
    __tablename__ = 'keywords'
    id = db.Column(db.Integer, primary_key=True)
    ad_group_id = db.Column(db.Integer, db.ForeignKey('ad_groups.id'))
    external_id = db.Column(db.String(50))
    text = db.Column(db.String(255), nullable=False)
    match_type = db.Column(db.String(20), default='BROAD')  # EXACT/PHRASE/BROAD/BROAD_MODIFIER
    status = db.Column(db.String(20), default='enabled')
    cpc_bid = db.Column(db.Numeric(10, 4))
    final_url = db.Column(db.String(1000))
    impressions = db.Column(db.BigInteger, default=0)
    clicks = db.Column(db.BigInteger, default=0)
    spend = db.Column(db.Numeric(12, 2), default=0)
    conversions = db.Column(db.Numeric(12, 2), default=0)
    quality_score = db.Column(db.Integer)
    ai_generated = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ==================== AI Creative Generation ====================
class AICreativeTask(db.Model):
    __tablename__ = 'ai_creative_tasks'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    offer_url = db.Column(db.String(1000), nullable=False)
    target_language = db.Column(db.String(20), default='en')
    target_country = db.Column(db.String(10))
    niche = db.Column(db.String(100))
    ai_provider = db.Column(db.String(50))
    ai_model = db.Column(db.String(100))
    custom_prompt_template_id = db.Column(db.Integer, db.ForeignKey('prompt_templates.id'))
    # Crawled data
    crawled_title = db.Column(db.String(500))
    crawled_description = db.Column(db.Text)
    crawled_reviews = db.Column(JSON, default=[])
    crawled_features = db.Column(JSON, default=[])
    # Generated output
    generated_creatives = db.Column(JSON, default=[])  # [{headlines, descriptions, keywords}]
    status = db.Column(db.String(20), default='pending')  # pending/crawling/generating/reviewed/submitted/failed
    error_message = db.Column(db.Text)
    submitted_campaign_id = db.Column(db.Integer, db.ForeignKey('campaigns.id'))
    cost_tokens = db.Column(db.Integer, default=0)
    cost_usd = db.Column(db.Numeric(10, 6), default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ==================== Prompt Template ====================
class PromptTemplate(db.Model):
    __tablename__ = 'prompt_templates'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50), default='creative')  # creative/keyword/optimization
    language = db.Column(db.String(20), default='en')
    template = db.Column(db.Text, nullable=False)
    variables = db.Column(JSON, default=[])
    is_system = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    usage_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ==================== Proxy Config ====================
class ProxyConfig(db.Model):
    __tablename__ = 'proxy_configs'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    provider = db.Column(db.String(30))  # oxylabs/brightdata/ipidea/smartproxy/geosurf/custom
    name = db.Column(db.String(100))
    username = db.Column(db.String(200))
    password = db.Column(db.String(200))
    endpoint = db.Column(db.String(200))
    port = db.Column(db.Integer)
    protocol = db.Column(db.String(10), default='http')  # http/socks5
    country_rules = db.Column(JSON, default=[])  # [{country, pool, session_type}]
    session_type = db.Column(db.String(20), default='residential')  # residential/datacenter/mobile/isp
    rotation_interval = db.Column(db.Integer, default=300)  # seconds
    is_active = db.Column(db.Boolean, default=True)
    priority = db.Column(db.Integer, default=0)
    test_result = db.Column(JSON, default={})
    last_test = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ==================== AI Config ====================
class AIConfig(db.Model):
    __tablename__ = 'ai_configs'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    name = db.Column(db.String(100))
    provider = db.Column(db.String(30), nullable=False)
    model = db.Column(db.String(100), nullable=False)
    api_key = db.Column(db.String(500))
    base_url = db.Column(db.String(500))
    api_version = db.Column(db.String(50))
    max_tokens = db.Column(db.Integer, default=2000)
    temperature = db.Column(db.Numeric(3, 2), default=0.7)
    is_free_tier = db.Column(db.Boolean, default=False)  # 优先使用免费
    cost_per_1k_input = db.Column(db.Numeric(10, 6), default=0)
    cost_per_1k_output = db.Column(db.Numeric(10, 6), default=0)
    rate_limit_rpm = db.Column(db.Integer, default=60)
    is_active = db.Column(db.Boolean, default=True)
    priority = db.Column(db.Integer, default=0)  # 低数字优先
    total_tokens_used = db.Column(db.BigInteger, default=0)
    total_cost_usd = db.Column(db.Numeric(12, 6), default=0)
    last_used = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ==================== Scheduled Task ====================
class ScheduledTask(db.Model):
    __tablename__ = 'scheduled_tasks'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    name = db.Column(db.String(200))
    task_type = db.Column(db.String(50), nullable=False)  # sync_ads/click_bot/link_swap/ai_generate/budget_update
    related_id = db.Column(db.Integer)  # campaign_id / mcc_id etc.
    cron_expression = db.Column(db.String(100))
    interval_minutes = db.Column(db.Integer)
    params = db.Column(JSON, default={})
    is_active = db.Column(db.Boolean, default=True)
    last_run = db.Column(db.DateTime)
    next_run = db.Column(db.DateTime)
    run_count = db.Column(db.Integer, default=0)
    success_count = db.Column(db.Integer, default=0)
    failure_count = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='idle')  # idle/running/paused/error
    last_error = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    executions = db.relationship('TaskExecution', backref='task', lazy=True, cascade='all,delete-orphan')


# ==================== Task Execution Log ====================
class TaskExecution(db.Model):
    __tablename__ = 'task_executions'
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('scheduled_tasks.id'))
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    finished_at = db.Column(db.DateTime)
    duration_seconds = db.Column(db.Float)
    status = db.Column(db.String(20), nullable=False)  # success/failed/running/skipped
    result_data = db.Column(JSON, default={})
    error_message = db.Column(db.Text)
    # 点击任务详细信息
    click_details = db.Column(JSON, default={})  # {ip, fingerprint, referer, country, ua, duration}
    # 换链详细信息
    link_details = db.Column(JSON, default={})  # {old_url, new_url, fingerprint, campaign_id}
    traceback = db.Column(db.Text)


# ==================== Click Task (补点击) ====================
class ClickTask(db.Model):
    __tablename__ = 'click_tasks'
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaigns.id'))
    ad_id = db.Column(db.Integer, db.ForeignKey('ads.id'))
    keyword = db.Column(db.String(255))
    target_url = db.Column(db.String(1000))
    country = db.Column(db.String(10))
    city = db.Column(db.String(100))
    timezone = db.Column(db.String(50))
    ip_address = db.Column(db.String(50))
    ip_provider = db.Column(db.String(30))
    user_agent = db.Column(db.String(500))
    fingerprint = db.Column(db.String(100))
    referer = db.Column(db.String(500))
    device_type = db.Column(db.String(20), default='desktop')
    browser = db.Column(db.String(50))
    os = db.Column(db.String(50))
    resolution = db.Column(db.String(20))
    language = db.Column(db.String(20))
    scheduled_at = db.Column(db.DateTime)
    executed_at = db.Column(db.DateTime)
    duration_seconds = db.Column(db.Integer)
    pages_viewed = db.Column(db.Integer, default=1)
    status = db.Column(db.String(20), default='pending')  # pending/running/success/failed/skipped
    error_message = db.Column(db.Text)
    # 50项指标匹配数据
    metrics_data = db.Column(JSON, default={})
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ==================== Link Swap Task (换链接) ====================
class LinkSwapTask(db.Model):
    __tablename__ = 'link_swap_tasks'
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaigns.id'))
    ad_id = db.Column(db.Integer, db.ForeignKey('ads.id'))
    old_tracking_url = db.Column(db.String(1000))
    old_final_url = db.Column(db.String(1000))
    new_tracking_url = db.Column(db.String(1000))
    new_final_url = db.Column(db.String(1000))
    link_fingerprint = db.Column(db.String(100))
    # 反向采集
    crawled_destination = db.Column(db.String(1000))
    tracking_params_updated = db.Column(JSON, default={})
    executed_at = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='pending')
    error_message = db.Column(db.Text)
    same_origin_click = db.Column(db.Boolean, default=True)  # 与补点击同源
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ==================== Sync Log (数据同步) ====================
class AdsSyncLog(db.Model):
    __tablename__ = 'ads_sync_logs'
    id = db.Column(db.Integer, primary_key=True)
    mcc_id = db.Column(db.Integer, db.ForeignKey('mcc_accounts.id'))
    direction = db.Column(db.String(10), default='pull')  # push/pull
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    finished_at = db.Column(db.DateTime)
    status = db.Column(db.String(20))
    records_processed = db.Column(db.Integer, default=0)
    records_updated = db.Column(db.Integer, default=0)
    records_created = db.Column(db.Integer, default=0)
    records_failed = db.Column(db.Integer, default=0)
    error_message = db.Column(db.Text)
    sync_method = db.Column(db.String(20), default='script')  # script/api
    script_instance_id = db.Column(db.String(100))  # Cloudflare Worker 隔离
    raw_stats = db.Column(JSON, default={})


# ==================== System Audit Log ====================
class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('tenants.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    action = db.Column(db.String(100), nullable=False)
    resource_type = db.Column(db.String(50))
    resource_id = db.Column(db.Integer)
    ip_address = db.Column(db.String(50))
    user_agent = db.Column(db.String(500))
    request_id = db.Column(db.String(100))
    old_values = db.Column(JSON, default={})
    new_values = db.Column(JSON, default={})
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
