import os
from flask import Flask, jsonify, request, send_from_directory
from .extensions import db, migrate, jwt, bcrypt, cors, scheduler
from config import config
from flask_jwt_extended import JWTManager


def create_app(config_name=None):
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')

    app = Flask(__name__,
                static_folder='../frontend/dist',
                static_url_path='/',
                template_folder='../frontend/dist')
    app.config.from_object(config[config_name])

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    bcrypt.init_app(app)
    cors.init_app(app, resources={
        r"/api/*": {
            "origins": ["http://localhost:5173", "http://localhost:8080",
                        "https://adx-auto.onrender.com"],
            "supports_credentials": True,
        }
    })

    # Register blueprints
    from .routes.auth import auth_bp
    from .routes.accounts import accounts_bp
    from .routes.ads import ads_bp
    from .routes.ai_creative import ai_bp
    from .routes.click_bot import click_bp
    from .routes.link_swap import link_swap_bp
    from .routes.tasks import tasks_bp
    from .routes.configs import configs_bp
    from .routes.dashboard import dashboard_bp
    from .routes.marketing import marketing_bp

    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(accounts_bp, url_prefix='/api/accounts')
    app.register_blueprint(ads_bp, url_prefix='/api/ads')
    app.register_blueprint(ai_bp, url_prefix='/api/ai')
    app.register_blueprint(click_bp, url_prefix='/api/click-bot')
    app.register_blueprint(link_swap_bp, url_prefix='/api/link-swap')
    app.register_blueprint(tasks_bp, url_prefix='/api/tasks')
    app.register_blueprint(configs_bp, url_prefix='/api/configs')
    app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    app.register_blueprint(marketing_bp)

    # JWT Callbacks
    @jwt.user_identity_loader
    def user_identity_lookup(user):
        return user.id if hasattr(user, 'id') else user

    @jwt.user_lookup_loader
    def user_lookup_callback(_jwt_header, jwt_data):
        from .models import User
        identity = jwt_data['sub']
        return User.query.get(int(identity))

    # Error handlers
    @app.errorhandler(404)
    def not_found(e):
        # SPA fallback
        if not request.path.startswith('/api/'):
            index_path = os.path.join(app.static_folder, 'index.html')
            if os.path.exists(index_path):
                return send_from_directory(app.static_folder, 'index.html')
        return jsonify({'error': 'Not found'}), 404

    @app.errorhandler(500)
    def internal_error(e):
        app.logger.error(f"Server Error: {str(e)}")
        return jsonify({'error': 'Internal server error', 'message': str(e)}), 500

    # Health check
    @app.route('/api/health')
    def health():
        return jsonify({
            'status': 'ok',
            'app': 'ADX-Auto',
            'version': '1.0.0',
            'scheduler_running': scheduler.running,
        })

    # Create tables and init default data
    with app.app_context():
        from .init_data import init_default_data
        db.create_all()
        init_default_data()

        # Start scheduler (don't start in reloader process)
        if not app.debug or os.environ.get('WERKZEUG_RUN_MAIN') == 'true':
            try:
                if not scheduler.running:
                    from .services.scheduler_service import register_all_scheduled_tasks
                    register_all_scheduled_tasks()
                    scheduler.start()
                    app.logger.info("Scheduler started")
            except Exception as e:
                app.logger.warning(f"Scheduler start failed: {e}")

    return app
